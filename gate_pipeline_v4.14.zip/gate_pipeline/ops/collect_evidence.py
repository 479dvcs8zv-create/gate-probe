"""
ops/collect_evidence.py (v4.14)
===============================
一鍵蒐證：輸入股票代號與民國年度，自動向官方網站取得 Gate5B 截止點需要的三層證據，
保存所有請求與回應的原始位元組，並用正式解析器算出各季截止點。只讀官方網站、只產生檔案，
不改任何 Gate 判定；只用標準函式庫。設計給 GitHub Actions 執行（.github/workflows/gate-pipeline-collect.yml）。

  python gate_pipeline/ops/collect_evidence.py --co-id 2330 --roc-years 113,114,115 --out results/2330/<run_id>

流程（每一步的原始回應都存檔並記 SHA-256，失敗也照實記錄，不中斷其他步驟）：
  1. 每個年度：重大訊息全年清單（mopsov ajax_t05st01，step=1）
  2. 用 mops_t05st01 解析；連續年度合併成一份（第四季的公告在隔年初）
  3. 詳細頁（step=2）：
       - 被分類為財務結果事件的公告（EPS、董事會通過財報、法說會、季末月營收）
       - 季末到「清單層級最早事件的隔天」之間未分類的公告（供人工審查時看原文）
  4. 每個年度：財務報告書申報清單（doc.twse.com.tw t57sb01，seamon 留空，mtype=A）
  5. 每一季：mops_t05st01.cutoff_candidates 計算截止點（含人工審查紀錄，如有）
輸出：
  <out>/requests/*.bin、<out>/responses/*.bin   原始位元組
  <out>/manifest.json                            每一個請求的網址、參數、取得時間、雜湊、Content-Type
  <out>/summary.json                             各季截止點、阻擋原因、待人工審查的公告
每次請求之間預設停 3 秒；詳細頁總數有上限，避免對官方網站造成負擔。
"""

import argparse
import hashlib
import json
import os
import re
import sys
import time
from datetime import date, datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))

import announcement_probe as ap  # noqa: E402
import network_probe as npb  # noqa: E402
from mops_t05st01 import (TPE, classify, cutoff_candidates, merge_listings,  # noqa: E402
                          parse_t05st01_detail, parse_t05st01_listing)
from mops_t57sb01 import parse_t57sb01_listing  # noqa: E402

COLLECTOR_VERSION = "4.14-collect"
DEFAULT_DOC_BASE = "https://doc.twse.com.tw"


def _read(out_dir, rel):
    return open(os.path.join(out_dir, rel), "rb").read() if rel else b""


def _ct(hop):
    return (hop.get("response_headers") or {}).get("Content-Type", "")


def _record(manifest, kind, entry, params, url=None):
    hop = entry.get("hop") or (entry.get("hops") or [{}])[-1]
    rec = {"kind": kind, "params": params, "request_url": url or hop.get("url") or entry.get("url"),
           "status": entry.get("status"), "error": entry.get("error"),
           "retrieved_at": hop.get("started_at"), "content_type": _ct(hop),
           "response_file": entry.get("saved_as"), "response_sha256": entry.get("body_sha256"),
           "response_length": entry.get("content_length"),
           "request_body_file": entry.get("request_body_saved_as"),
           "request_body_sha256": entry.get("request_body_sha256"),
           "peer_address": hop.get("peer_address"), "cert_sha256": (hop.get("tls") or {}).get("cert_sha256")}
    manifest["requests"].append(rec)
    return rec


def _quarters(first_roc_year, last_roc_year, today):
    out = []
    for y in range(first_roc_year + 1911, last_roc_year + 1911 + 1):
        for q in range(1, 5):
            q_end = date(y + (q == 4), (3 * q) % 12 + 1, 1)
            if q_end <= today:   # 季度已結束才有財報
                out.append(f"{y}Q{q}")
    return out


def _fmt_event(e):
    return {"event_type": e["event_type"], "at": e["at"].isoformat(), "precision": e["precision"],
            "document_id": e["document_id"], "detail_verified": e["detail_verified"], "subject": e.get("subject")}


def collect(co_id, roc_years, out_dir, mops_base=ap.DEFAULT_MOPS_BASE, doc_base=DEFAULT_DOC_BASE, delay=3.0,
            timeout=30.0, max_details=150, reviews=None, today=None):
    os.makedirs(os.path.join(out_dir, "responses"), exist_ok=True)
    manifest = {"collector_version": COLLECTOR_VERSION, "co_id": co_id, "roc_years": roc_years,
                "started_at": datetime.now(timezone.utc).isoformat(), "environment": ap.environment(),
                "mops_base": mops_base, "doc_base": doc_base, "delay_seconds": delay, "requests": []}
    summary = {"co_id": co_id, "roc_years": roc_years, "listings": {}, "filings": {}, "details": {},
               "quarters": {}, "notes": []}
    first = True

    def pause():
        nonlocal first
        if not first:
            time.sleep(delay)
        first = False

    # 1–2. 全年清單
    listings = {}
    for y in roc_years:
        pause()
        e = ap.query_t05st01(mops_base, co_id, str(y), "", out_dir, timeout)
        rec = _record(manifest, "t05st01_listing", e, {"co_id": co_id, "roc_year": str(y), "month": ""})
        lst, fails = parse_t05st01_listing(_read(out_dir, e.get("saved_as")), rec["content_type"], rec["request_url"],
                                           co_id, str(y), "", e.get("body_sha256"))
        summary["listings"][str(y)] = ({"items": len(lst.items), "sha256": lst.response_sha256,
                                        "company_name": lst.company_name} if lst else
                                       {"failures": [list(f) for f in fails], "status": e.get("status"),
                                        "error": e.get("error")})
        if lst:
            listings[y] = lst
    if not listings:
        summary["notes"].append("沒有任何年度的清單可以解析，停止後續步驟")
        return manifest, summary

    # 連續年度合併
    runs, cur = [], []
    for y in sorted(listings):
        if cur and y != cur[-1] + 1:
            runs.append(cur)
            cur = []
        cur.append(y)
    runs.append(cur)
    merged = {tuple(r): merge_listings([listings[y] for y in r]) for r in runs}
    company = next(iter(listings.values())).company_name

    # 3. 詳細頁
    today = today or datetime.now(TPE).date()
    wanted = {}   # document_id -> item
    for (yrs, ml) in merged.items():
        for it in ml.items:
            if classify(it):
                wanted[it.document_id] = it
        for q in _quarters(yrs[0], yrs[-1], today):
            cc = cutoff_candidates(ml, q)
            if cc["earliest"] is None:
                continue
            m = re.fullmatch(r"(\d{4})Q([1-4])", q)
            qn = int(m.group(2))
            q_end_next = date(int(m.group(1)) + (qn == 4), (3 * qn) % 12 + 1, 1)
            lo = datetime(q_end_next.year, q_end_next.month, q_end_next.day, tzinfo=TPE)
            hi = datetime.combine(cc["earliest"]["at"].date(), datetime.max.time(), tzinfo=TPE)
            for it in ml.items:
                if lo <= it.announced_at <= hi and not classify(it):
                    wanted[it.document_id] = it
    items = sorted(wanted.values(), key=lambda it: it.announced_at)
    if len(items) > max_details:
        summary["notes"].append(f"詳細頁 {len(items)} 則超過上限 {max_details}，只取前 {max_details} 則")
        items = items[:max_details]
    details = {}
    for it in items:
        pause()
        p = dict(it.detail_params)
        e = ap.query_t05st01_detail(mops_base, co_id, it.typek, str(it.announced_at.year - 1911), "all",
                                    p["spoke_date"], p["spoke_time"], p["seq_no"], out_dir, timeout)
        rec = _record(manifest, "t05st01_detail", e, {"document_id": it.document_id, "spoke_date": p["spoke_date"],
                                                      "spoke_time": p["spoke_time"], "seq_no": p["seq_no"]})
        d, fails = parse_t05st01_detail(_read(out_dir, e.get("saved_as")), rec["content_type"], rec["request_url"],
                                        it, e.get("body_sha256"))
        if d:
            details[it.document_id] = d
            summary["details"][it.document_id] = {"ok": True, "clause": d.clause, "fact_date": d.fact_date.isoformat()}
        else:
            summary["details"][it.document_id] = {"ok": False, "failures": [list(f) for f in fails],
                                                  "status": e.get("status"), "error": e.get("error")}

    # 4. 財報申報清單
    filings = []
    for y in roc_years:
        pause()
        url = (f"{doc_base.rstrip('/')}/server-java/t57sb01?step=1&colorchg=1&co_id={co_id}"
               f"&year={y}&seamon=&mtype=A&")
        e = npb.probe_url(url, out_dir, timeout)
        rec = _record(manifest, "t57sb01_list", e, {"co_id": co_id, "roc_year": str(y)}, url=url)
        retrieved = datetime.fromisoformat(rec["retrieved_at"]) if rec.get("retrieved_at") else None
        fl, fails = parse_t57sb01_listing(_read(out_dir, e.get("saved_as")), rec["content_type"], url, co_id, str(y),
                                          company, retrieved, e.get("body_sha256"))
        summary["filings"][str(y)] = ({"rows": [[r.fiscal_quarter, r.filename, r.uploaded_at.isoformat()] for r in fl.rows],
                                       "sha256": fl.response_sha256} if fl else
                                      {"failures": [list(f) for f in fails], "status": e.get("status"),
                                       "error": e.get("error")})
        if fl:
            filings.append(fl)

    # 5. 各季截止點
    for (yrs, ml) in merged.items():
        for q in _quarters(yrs[0], yrs[-1], today):
            rv = (reviews or {}).get((co_id, q))
            reviewed = {r["document_id"] for r in rv["reviewed_non_results"]} if rv else set()
            cc = cutoff_candidates(ml, q, details=details, filings=filings, reviewed_non_results=reviewed)
            summary["quarters"][q] = {
                "status": cc["status"], "earliest": _fmt_event(cc["earliest"]) if cc["earliest"] else None,
                "blocking": cc["blocking"], "events": [_fmt_event(e) for e in cc["events"]],
                "review_window": [{"document_id": r["document_id"], "announced_at": r["announced_at"].isoformat(),
                                   "subject": r["subject"],
                                   "clause": (details.get(r["document_id"]).clause
                                              if details.get(r["document_id"]) else None)}
                                  for r in cc["review_window"]],
                "financial_report_status": cc["financial_report_status"],
                "review_record": bool(rv)}
    manifest["finished_at"] = datetime.now(timezone.utc).isoformat()
    return manifest, summary


def load_reviews(path):
    out = {}
    if path and os.path.isdir(path):
        for name in sorted(os.listdir(path)):
            if name.endswith(".json"):
                rv = json.load(open(os.path.join(path, name), encoding="utf-8"))
                if rv.get("decision") == "not_financial_results" and rv.get("reviewer") and rv.get("decided_at"):
                    out[(rv["co_id"], rv["fiscal_quarter"])] = rv
    return out


def main(argv=None):
    p = argparse.ArgumentParser(description="一鍵蒐證：Gate5B 截止點需要的官方證據")
    p.add_argument("--co-id", required=True)
    p.add_argument("--roc-years", required=True, help="民國年，逗號分隔，例如 113,114,115")
    p.add_argument("--out", required=True)
    p.add_argument("--reviews", default=None, help="人工審查紀錄資料夾（*.json）")
    p.add_argument("--mops-base", default=ap.DEFAULT_MOPS_BASE)
    p.add_argument("--doc-base", default=DEFAULT_DOC_BASE)
    p.add_argument("--delay", type=float, default=3.0)
    p.add_argument("--timeout", type=float, default=30.0)
    p.add_argument("--max-details", type=int, default=150)
    a = p.parse_args(argv)
    if not re.fullmatch(r"\d{4,6}", a.co_id):
        p.error("股票代號必須是 4–6 位數字")
    if not re.fullmatch(r"\d{3}(,\d{3}){0,5}", a.roc_years):
        p.error("年度格式錯誤，例如 113,114,115（最多 6 個年度）")
    years = sorted({int(x) for x in a.roc_years.split(",")})
    manifest, summary = collect(a.co_id, years, a.out, a.mops_base, a.doc_base, a.delay, a.timeout, a.max_details,
                                load_reviews(a.reviews))
    for name, obj in (("manifest.json", manifest), ("summary.json", summary)):
        with open(os.path.join(a.out, name), "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
    # 簡短摘要（給執行紀錄與 Step Summary）
    lines = [f"## 蒐證結果 {a.co_id}（民國 {a.roc_years}）", "", "| 季度 | 狀態 | 最早事件 | 時間 | 阻擋原因 |", "|---|---|---|---|---|"]
    for q, s in sorted(summary["quarters"].items()):
        e = s["earliest"] or {}
        lines.append(f"| {q} | {s['status']} | {e.get('event_type', '')} | {e.get('at', '')} | "
                     f"{'；'.join(s['blocking']).replace('|', '/')} |")
    for n in summary["notes"]:
        lines.append(f"\n- {n}")
    text = "\n".join(lines)
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
