"""
mops_evidence.py (v4.13)
========================
把公開資訊觀測站的三層官方證據接進 Gate5B 的官方公告時間查證（verify_earnings_announcement）。

證據包 MopsEvidenceBundle 只放「官方回應的原始位元組＋取得資訊」，不放任何解析結果：
  listing          重大訊息全年清單（ajax_t05st01，step=1）
  details          清單中財務結果事件的詳細頁（step=2），以 spoke_date/spoke_time/seq_no 對應清單列
  filings          財務報告書申報清單（doc.twse.com.tw t57sb01）
  monthly_listings 選用：單月清單，與全年清單交叉核對
  review           季末到最早事件之間未分類公告的人工審查紀錄（可稽核）

verify_mops_evidence_bundle 每次都從原始位元組重新解析、重算雜湊、交叉核對，再用
mops_t05st01.cutoff_candidates 算出截止點；任何阻擋原因都會變成 failure，Gate5B 因此 fail-closed。
回傳格式與 verify_earnings_announcement 相同（ok、cutoff、failures、trace）。

RecordedMopsVerifier 用「已錄製的官方回應」回答查詢（離線重播），供本機與契約測試使用；
正式環境要改成在可連網的執行環境（例如 GitHub Actions）即時抓取同樣的三層證據。
"""

import json
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from mops_t05st01 import cross_check_listings, cutoff_candidates, parse_t05st01_detail, parse_t05st01_listing
from mops_t57sb01 import parse_t57sb01_listing
from reject_codes import RC


@dataclass
class OfficialResponse:
    request_url: str
    response_bytes: bytes
    response_sha256: str
    content_type: str
    retrieved_at: str                     # 探測紀錄的取得時間（ISO8601，帶時區）
    params: dict = field(default_factory=dict)


@dataclass
class MopsEvidenceBundle:
    co_id: str
    roc_year: str
    listing: OfficialResponse
    details: List[OfficialResponse]
    filings: Optional[OfficialResponse]
    monthly_listings: List[OfficialResponse] = field(default_factory=list)
    review: Optional[dict] = None
    clause_policy: Optional[dict] = None   # v4.15：使用者核准的條款自動排除規則（reviews/clause_policy.json）


def _co_id_of(ticker: str) -> str:
    return re.sub(r"\.(TW|TWO)$", "", str(ticker).strip().upper())


def _review_ids(review, fiscal_quarter, co_id):
    """人工審查紀錄必須指明公司、期間、審查人、時間；不完整的紀錄不採用。回傳 (ids, failures)。"""
    if review is None:
        return set(), []
    need = ("co_id", "fiscal_quarter", "reviewer", "decided_at", "decision", "reviewed_non_results")
    missing = [k for k in need if not review.get(k)]
    if missing:
        return set(), [(RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, f"人工審查紀錄缺少欄位：{missing}")]
    if review["co_id"] != co_id or review["fiscal_quarter"] != fiscal_quarter or review["decision"] != "not_financial_results":
        return set(), []   # 不是這一季的紀錄：不採用，未分類公告仍會阻擋
    return {r["document_id"] for r in review["reviewed_non_results"] if r.get("document_id")}, []


def _policy_clauses(policy):
    """條款自動排除規則必須有審查人、時間、決定類型與條款清單；不完整就整份不採用（回報失敗）。"""
    if policy is None:
        return set(), []
    need = ("reviewer", "decided_at", "decision", "clauses")
    missing = [k for k in need if not policy.get(k)]
    if missing or policy.get("decision") != "auto_clear_non_results_by_clause":
        return set(), [(RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, f"條款自動排除規則不完整或類型不符：缺 {missing}")]
    clauses = {str(c) for c in policy["clauses"]}
    if not all(re.fullmatch(r"\d{1,2}", c) for c in clauses):
        return set(), [(RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, f"條款自動排除規則的條款格式不正確：{sorted(clauses)}")]
    return clauses, []


def verify_mops_evidence_bundle(bundle: MopsEvidenceBundle, ticker: str, fiscal_quarter: str) -> dict:
    result = {"ok": False, "cutoff": None, "failures": [],
              "trace": {"ticker": ticker, "fiscal_quarter": fiscal_quarter, "verifier_calls": 1,
                        "evidence_kind": "mops_official_responses"}}
    fails = result["failures"]
    co_id = _co_id_of(ticker)
    m = re.fullmatch(r"(\d{4})Q([1-4])", str(fiscal_quarter))
    if bundle.co_id != co_id:
        fails.append((RC.ANNOUNCEMENT_ISSUER_MISMATCH, f"證據包是 {bundle.co_id} 的官方回應，不是 {co_id}"))
        return result
    if not m or int(bundle.roc_year) + 1911 != int(m.group(1)):
        fails.append((RC.ANNOUNCEMENT_COVERAGE_INCOMPLETE,
                      f"證據包是民國 {bundle.roc_year} 年的清單，不涵蓋 {fiscal_quarter}"))
        return result

    L = bundle.listing
    listing, f = parse_t05st01_listing(L.response_bytes, L.content_type, L.request_url, co_id, bundle.roc_year, "",
                                       L.response_sha256)
    fails.extend(f)
    if listing is None:
        return result
    trace = result["trace"]
    trace["listing"] = {"request_url": L.request_url, "sha256": listing.response_sha256, "items": len(listing.items),
                        "retrieved_at": L.retrieved_at}

    monthly = []
    for ml in bundle.monthly_listings:
        parsed, f = parse_t05st01_listing(ml.response_bytes, ml.content_type, ml.request_url, co_id, bundle.roc_year,
                                          ml.params.get("month", ""), ml.response_sha256)
        fails.extend(f)
        if parsed:
            monthly.append(parsed)
    if monthly:
        fails.extend(cross_check_listings(listing, monthly))
    trace["monthly_cross_checked"] = [x.month for x in monthly]

    by_key = {(dict(it.detail_params)["spoke_date"], dict(it.detail_params)["spoke_time"], str(it.seq_no)): it
              for it in listing.items}
    details, trace["details"] = {}, []
    for d in bundle.details:
        key = (d.params.get("spoke_date"), d.params.get("spoke_time"), str(d.params.get("seq_no")))
        item = by_key.get(key)
        if item is None:
            fails.append((RC.ANNOUNCEMENT_DOCUMENT_NOT_LISTED, f"詳細頁 {key} 不在官方清單中"))
            continue
        parsed, f = parse_t05st01_detail(d.response_bytes, d.content_type, d.request_url, item, d.response_sha256)
        fails.extend(f)
        if parsed:
            details[item.document_id] = parsed
            trace["details"].append({"document_id": item.document_id, "sha256": parsed.response_sha256})

    filings = None
    if bundle.filings is not None:
        F = bundle.filings
        try:
            retrieved = datetime.fromisoformat(F.retrieved_at) if F.retrieved_at else None
        except ValueError:
            retrieved = None
        if retrieved is None or retrieved.tzinfo is None:
            fails.append((RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, f"財報清單的取得時間「{F.retrieved_at}」無效或未帶時區"))
        else:
            filings, f = parse_t57sb01_listing(F.response_bytes, F.content_type, F.request_url, co_id, bundle.roc_year,
                                               listing.company_name, retrieved, F.response_sha256)
            fails.extend(f)
            if filings:
                trace["filings"] = {"request_url": F.request_url, "sha256": filings.response_sha256,
                                    "rows": len(filings.rows), "retrieved_at": F.retrieved_at}

    reviewed, f = _review_ids(bundle.review, fiscal_quarter, co_id)
    fails.extend(f)
    if bundle.review:
        trace["review"] = {k: bundle.review.get(k) for k in ("reviewer", "decided_at", "basis", "decision")}
        trace["review"]["document_ids"] = sorted(reviewed)
    clauses, f = _policy_clauses(bundle.clause_policy)
    fails.extend(f)
    if bundle.clause_policy and clauses:
        trace["clause_policy"] = {"clauses": sorted(clauses), "reviewer": bundle.clause_policy.get("reviewer"),
                                  "decided_at": bundle.clause_policy.get("decided_at")}
    if fails:
        return result   # 任何證據本身有問題，就不計算截止點

    cc = cutoff_candidates(listing, fiscal_quarter, details=details, filings=filings, reviewed_non_results=reviewed,
                           auto_clear_clauses=clauses)
    trace["events"] = [{"event_type": e["event_type"], "at": e["at"].isoformat(), "precision": e["precision"],
                        "document_id": e["document_id"], "detail_verified": e["detail_verified"]} for e in cc["events"]]
    trace["review_window"] = [{"document_id": r["document_id"], "clause": r["clause"], "cleared_by": r["cleared_by"]}
                              for r in cc["review_window"]]
    trace["financial_report_status"] = cc["financial_report_status"]
    trace["cutoff_status"] = cc["status"]
    for b in cc["blocking"]:
        fails.append((RC.ANNOUNCEMENT_REVIEW_PENDING if "需人工確認" in b else RC.ANNOUNCEMENT_COVERAGE_INCOMPLETE, b))
    if fails or cc["status"] != "CUTOFF_VERIFIED" or cc["earliest"] is None:
        return result
    e = cc["earliest"]
    src = bundle.filings.request_url if e["event_type"] == "financial_report" else L.request_url
    result.update(ok=True, cutoff={"dt": e["at"], "precision": e["precision"], "iso": e["at"].isoformat(),
                                   "event_type": e["event_type"], "document_id": e["document_id"], "source_url": src})
    trace.update(cutoff_at=e["at"].isoformat(), cutoff_precision=e["precision"],
                 cutoff_document_id=e["document_id"], cutoff_event_type=e["event_type"])
    return result


class RecordedMopsVerifier:
    """用已錄製的官方回應回答 fetch_announcement_evidence（離線重播）。
    bundles：{(co_id, roc_year): MopsEvidenceBundle}；reviews：{(co_id, fiscal_quarter): review dict}，
    條款自動排除規則放在 reviews["__clause_policy__"]。查不到就回傳 None（判定為無法取得證據，fail-closed）。"""

    def __init__(self, bundles: dict, reviews: Optional[dict] = None):
        self.bundles, self.reviews, self.calls = bundles, reviews or {}, []

    def fetch_announcement_evidence(self, ticker, fiscal_quarter):
        self.calls.append((ticker, fiscal_quarter))
        co_id = _co_id_of(ticker)
        m = re.fullmatch(r"(\d{4})Q([1-4])", str(fiscal_quarter))
        if not m:
            return None
        b = self.bundles.get((co_id, str(int(m.group(1)) - 1911)))
        if b is None:
            return None
        return MopsEvidenceBundle(b.co_id, b.roc_year, b.listing, b.details, b.filings, b.monthly_listings,
                                  self.reviews.get((co_id, fiscal_quarter)), self.reviews.get("__clause_policy__"))


# ---------------------------------------------------------------- 從 contract/mops_real 載入錄製的證據

def _load_case(run_dir, case):
    data = open(os.path.join(run_dir, case["response_file"]), "rb").read()
    return OfficialResponse(case["request_url"], data, case["response_sha256"], case["content_type"],
                            case["retrieved_at"], dict(case.get("params") or {}))


def load_recorded_2330_115(base_dir: str):
    """2330 民國 115 年的錄製證據：全年清單與詳細頁（run 39099468097）、單月清單（run 39091204611）、
    財報申報清單（run 39100629571），以及 reviews/ 中的人工審查紀錄。回傳 (bundle, reviews)。"""
    r10 = os.path.join(base_dir, "run_39099468097")
    r9 = os.path.join(base_dir, "run_39091204611")
    r11 = os.path.join(base_dir, "run_39100629571")
    m10 = json.load(open(os.path.join(r10, "manifest.json"), encoding="utf-8"))
    m9 = json.load(open(os.path.join(r9, "manifest.json"), encoding="utf-8"))
    m11 = json.load(open(os.path.join(r11, "manifest.json"), encoding="utf-8"))
    listing = _load_case(r10, [c for c in m10["cases"] if c["kind"] == "t05st01_query"][0])
    details = [_load_case(r10, c) for c in m10["cases"] if c["kind"] == "t05st01_detail"]
    monthly = []
    for c in m9["cases"]:
        if c["month"]:
            oc = _load_case(r9, c)
            oc.params["month"] = c["month"]
            monthly.append(oc)
    filings = _load_case(r11, [c for c in m11["cases"] if c["name"] == "t57sb01_2330_115_list_get"][0])
    reviews = {}
    rdir = os.path.join(base_dir, "reviews")
    if os.path.isdir(rdir):
        for name in sorted(os.listdir(rdir)):
            if name.endswith(".json"):
                rv = json.load(open(os.path.join(rdir, name), encoding="utf-8"))
                if rv.get("decision") == "auto_clear_non_results_by_clause":
                    reviews["__clause_policy__"] = rv
                else:
                    reviews[(rv["co_id"], rv["fiscal_quarter"])] = rv
    return MopsEvidenceBundle("2330", "115", listing, details, filings, monthly), reviews
