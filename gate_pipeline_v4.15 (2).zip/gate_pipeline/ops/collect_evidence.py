"""
ops/collect_evidence.py (v4.15)
===============================
一鍵蒐證：輸入股票代號與民國年度，自動向官方網站取得 Gate5B 截止點需要的三層證據，
保存所有請求與回應的原始位元組，並用正式解析器算出各季截止點。只讀官方網站、只產生檔案，
不改任何 Gate 判定；只用標準函式庫。設計給 GitHub Actions 執行（.github/workflows/gate-pipeline-collect.yml）。

  python gate_pipeline/ops/collect_evidence.py --co-id 2330 --roc-years 113,114,115 --out results/2330/<run_id>

流程（每一步的原始回應都存檔並記 SHA-256，失敗也照實記錄，不中斷其他步驟）：
  1. 每個年度：重大訊息全年清單（mopsov ajax_t05st01，step=1）
  2. 用 mops_t05st01 解析；連續年度合併成一份（第四季的公告在隔年初）
  3. 詳細頁（step=2）：
       - 被分類為財務結果事件的公告（EPS、董事會通過財報、法說會、季末月營收）
       - 季末到「清單層級最早事件的隔天」之間未分類的公告（供人工審查時看原文）
  4. 每個年度：財務報告書申報清單（doc.twse.com.tw t57sb01，seamon 留空，mtype=A）
  5. 每一季：mops_t05st01.cutoff_candidates 計算截止點（含人工審查紀錄與使用者核准的條款自動排除規則，如有）
重試（v4.15）：連線逾時／中斷、HTTP 429/5xx、官方回「查詢過量」時，依 --retry-waits 等待後重試（預設 10、30 秒，
  最多 3 次）。每一次嘗試都各自記在 manifest（attempt 編號、狀態、錯誤、回應雜湊），不會覆蓋前一次的回應；
  只有最後一次成功解析的回應被採用。官方「查無所需資料」、格式不符、其他 4xx 不重試（重試不會改變結果）。
輸出：
  <out>/requests/*.bin、<out>/responses/*.bin   原始位元組
  <out>/manifest.json                            每一個請求的網址、參數、取得時間、雜湊、Content-Type
  <out>/summary.json                             各季截止點、阻擋原因、待人工審查的公告
每次請求之間預設停 3 秒；詳細頁總數有上限，避免對官方網站造成負擔。
"""

import argparse
import hashlib
import json
import os
import re
import sys
import time
from datetime import date, datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))

import announcement_probe as ap  # noqa: E402
import network_probe as npb  # noqa: E402
from mops_t05st01 import (TPE, classify, cutoff_candidates, merge_listings,  # noqa: E402
                          parse_t05st01_detail, parse_t05st01_listing)
from mops_t57sb01 import parse_t57sb01_listing  # noqa: E402

COLLECTOR_VERSION = "4.15-collect"
DEFAULT_DOC_BASE = "https://doc.twse.com.tw"
DEFAULT_RETRY_WAITS = (10.0, 30.0)
DEFAULT_RETRY_BUDGET = 25   # 整次蒐證最多重試幾次：官方網站整體異常時不要拖到工作逾時（逾時會連已取得的結果都存不了）
RETRY_STATUS = {429, 500, 502, 503, 504}
RETRY_FAILURE_CODES = {"ANNOUNCEMENT_SOURCE_REFUSED"}


def _retryable(entry, fails):
    """暫時性錯誤才重試：連線錯誤／逾時、429/5xx、官方回「查詢過量」。"""
    if entry.get("error"):
        return True
    if entry.get("status") in RETRY_STATUS:
        return True
    return any(f[0] in RETRY_FAILURE_CODES for f in fails)


def _read(out_dir, rel):
    return open(os.path.join(out_dir, rel), "rb").read() if rel else b""


def _ct(hop):
    return (hop.get("response_headers") or {}).get("Content-Type", "")


def _record(manifest, kind, entry, params, url=None):
    hop = entry.get("hop") or (entry.get("hops") or [{}])[-1]
    rec = {"kind": kind, "params": params, "request_url": url or hop.get("url") or entry.get("url"),
           "status": entry.get("status"), "error": entry.get("error"),
           "retrieved_at": hop.get("started_at"), "content_type": _ct(hop),
           "response_file": entry.get("saved_as"), "response_sha256": entry.get("body_sha256"),
           "response_length": entry.get("content_length"),
           "request_body_file": entry.get("request_body_saved_as"),
           "request_body_sha256": entry.get("request_body_sha256"),
           "peer_address": hop.get("peer_address"), "cert_sha256": (hop.get("tls") or {}).get("cert_sha256")}
    manifest["requests"].append(rec)
    return rec


def _quarters(first_roc_year, last_roc_year, today):
    out = []
    for y in range(first_roc_year + 1911, last_roc_year + 1911 + 1):
        for q in range(1, 5):
            q_end = date(y + (q == 4), (3 * q) % 12 + 1, 1)
            if q_end <= today:   # 季度已結束才有財報
                out.append(f"{y}Q{q}")
    return out


def _fmt_event(e):
    return {"event_type": e["event_type"], "at": e["at"].isoformat(), "precision": e["precision"],
            "document_id": e["document_id"], "detail_verified": e["detail_verified"], "subject": e.get("subject")}


def collect(co_id, roc_years, out_dir, mops_base=ap.DEFAULT_MOPS_BASE, doc_base=DEFAULT_DOC_BASE, delay=3.0,
            timeout=30.0, max_details=150, reviews=None, today=None, retry_waits=DEFAULT_RETRY_WAITS,
            retry_budget=DEFAULT_RETRY_BUDGET):
    os.makedirs(os.path.join(out_dir, "responses"), exist_ok=True)
    retry_waits = tuple(retry_waits or ())
    manifest = {"collector_version": COLLECTOR_VERSION, "co_id": co_id, "roc_years": roc_years,
                "started_at": datetime.now(timezone.utc).isoformat(), "environment": ap.environment(),
                "mops_base": mops_base, "doc_base": doc_base, "delay_seconds": delay,
                "retry_waits_seconds": list(retry_waits), "retry_budget": retry_budget, "requests": []}
    summary = {"co_id": co_id, "roc_years": roc_years, "listings": {}, "filings": {}, "details": {},
               "quarters": {}, "notes": []}
    first = True
    budget = {"left": retry_budget}

    def pause():
        nonlocal first
        if not first:
            time.sleep(delay)
        first = False

    def fetch(kind, params, do_request, parse, url=None):
        """送出請求並解析；暫時性錯誤依 retry_waits 重試。每次嘗試都記錄在 manifest。"""
        for n in range(len(retry_waits) + 1):
            if n == 0:
                pause()
            else:
                time.sleep(retry_waits[n - 1])
            e = do_request()
            rec = _record(manifest, kind, e, params, url)
            parsed, fails = parse(e, rec)
            rec.update(attempt=n + 1, parsed=parsed is not None,
                       parse_failures=[list(f) for f in fails] if parsed is None else [])
            if parsed is not None or n == len(retry_waits) or not _retryable(e, fails):
                return e, rec, parsed, fails, n + 1
            if budget["left"] <= 0:
                rec["retry_skipped"] = "整次蒐證的重試次數已用完"
                if "重試次數已用完" not in " ".join(summary["notes"]):
                    summary["notes"].append(f"重試次數已用完（上限 {retry_budget}），之後的暫時性錯誤不再重試")
                return e, rec, parsed, fails, n + 1
            budget["left"] -= 1

    # 1–2. 全年清單
    listings = {}
    for y in roc_years:
        e, rec, lst, fails, tries = fetch(
            "t05st01_listing", {"co_id": co_id, "roc_year": str(y), "month": ""},
            lambda: ap.query_t05st01(mops_base, co_id, str(y), "", out_dir, timeout),
            lambda e, rec: parse_t05st01_listing(_read(out_dir, e.get("saved_as")), rec["content_type"],
                                                 rec["request_url"], co_id, str(y), "", e.get("body_sha256")))
        summary["listings"][str(y)] = ({"items": len(lst.items), "sha256": lst.response_sha256,
                                        "company_name": lst.company_name, "attempts": tries} if lst else
                                       {"failures": [list(f) for f in fails], "status": e.get("status"),
                                        "error": e.get("error"), "attempts": tries})
        if lst:
            listings[y] = lst
    if not listings:
        summary["notes"].append("沒有任何年度的清單可以解析，停止後續步驟")
        return manifest, summary

    merged = _merge_runs(listings)
    company = next(iter(listings.values())).company_name

    # 3. 詳細頁
    today = today or datetime.now(TPE).date()
    wanted = {}   # document_id -> item
    for (yrs, ml) in merged.items():
        for it in ml.items:
            if classify(it):
                wanted[it.document_id] = it
        for q in _quarters(yrs[0], yrs[-1], today):
            cc = cutoff_candidates(ml, q)
            if cc["earliest"] is None:
                continue
            m = re.fullmatch(r"(\d{4})Q([1-4])", q)
            qn = int(m.group(2))
            q_end_next = date(int(m.group(1)) + (qn == 4), (3 * qn) % 12 + 1, 1)
            lo = datetime(q_end_next.year, q_end_next.month, q_end_next.day, tzinfo=TPE)
            hi = datetime.combine(cc["earliest"]["at"].date(), datetime.max.time(), tzinfo=TPE)
            for it in ml.items:
                if lo <= it.announced_at <= hi and not classify(it):
                    wanted[it.document_id] = it
    items = sorted(wanted.values(), key=lambda it: it.announced_at)
    if len(items) > max_details:
        summary["notes"].append(f"詳細頁 {len(items)} 則超過上限 {max_details}，只取前 {max_details} 則")
        items = items[:max_details]
    details = {}
    for it in items:
        p = dict(it.detail_params)
        e, rec, d, fails, tries = fetch(
            "t05st01_detail", {"document_id": it.document_id, "spoke_date": p["spoke_date"],
                               "spoke_time": p["spoke_time"], "seq_no": p["seq_no"]},
            lambda: ap.query_t05st01_detail(mops_base, co_id, it.typek, str(it.announced_at.year - 1911), "all",
                                            p["spoke_date"], p["spoke_time"], p["seq_no"], out_dir, timeout),
            lambda e, rec: parse_t05st01_detail(_read(out_dir, e.get("saved_as")), rec["content_type"],
                                                rec["request_url"], it, e.get("body_sha256")))
        if d:
            details[it.document_id] = d
            summary["details"][it.document_id] = {"ok": True, "clause": d.clause, "fact_date": d.fact_date.isoformat(),
                                                  "attempts": tries}
        else:
            summary["details"][it.document_id] = {"ok": False, "failures": [list(f) for f in fails],
                                                  "status": e.get("status"), "error": e.get("error"),
                                                  "attempts": tries}

    # 4. 財報申報清單
    filings = []
    for y in roc_years:
        url = (f"{doc_base.rstrip('/')}/server-java/t57sb01?step=1&colorchg=1&co_id={co_id}"
               f"&year={y}&seamon=&mtype=A&")

        def parse_filings(e, rec, y=y, url=url):
            retrieved = datetime.fromisoformat(rec["retrieved_at"]) if rec.get("retrieved_at") else None
            return parse_t57sb01_listing(_read(out_dir, e.get("saved_as")), rec["content_type"], url, co_id, str(y),
                                         company, retrieved, e.get("body_sha256"))
        e, rec, fl, fails, tries = fetch("t57sb01_list", {"co_id": co_id, "roc_year": str(y)},
                                         lambda: npb.probe_url(url, out_dir, timeout), parse_filings, url=url)
        summary["filings"][str(y)] = ({"rows": [[r.fiscal_quarter, r.filename, r.uploaded_at.isoformat()] for r in fl.rows],
                                       "sha256": fl.response_sha256, "attempts": tries} if fl else
                                      {"failures": [list(f) for f in fails], "status": e.get("status"),
                                       "error": e.get("error"), "attempts": tries})
        if fl:
            filings.append(fl)

    # 5. 各季截止點
    _evaluate_quarters(co_id, merged, details, filings, reviews, today, summary)
    manifest["finished_at"] = datetime.now(timezone.utc).isoformat()
    return manifest, summary


def _merge_runs(listings):
    """連續年度的清單合併成一份（第四季的公告在隔年初）。{(年, ...): 合併清單}"""
    runs, cur = [], []
    for y in sorted(listings):
        if cur and y != cur[-1] + 1:
            runs.append(cur)
            cur = []
        cur.append(y)
    runs.append(cur)
    return {tuple(r): merge_listings([listings[y] for y in r]) for r in runs}


def _evaluate_quarters(co_id, merged, details, filings, reviews, today, summary):
    reviews = reviews or {}
    policy = reviews.get("__clause_policy__")
    clauses = {str(c) for c in policy["clauses"]} if policy else set()
    summary["clause_policy"] = ({"clauses": sorted(clauses), "reviewer": policy.get("reviewer"),
                                 "decided_at": policy.get("decided_at")} if policy else None)
    for (yrs, ml) in merged.items():
        for q in _quarters(yrs[0], yrs[-1], today):
            rv = reviews.get((co_id, q))
            reviewed = {r["document_id"] for r in rv["reviewed_non_results"]} if rv else set()
            cc = cutoff_candidates(ml, q, details=details, filings=filings, reviewed_non_results=reviewed,
                                   auto_clear_clauses=clauses)
            summary["quarters"][q] = {
                "status": cc["status"], "earliest": _fmt_event(cc["earliest"]) if cc["earliest"] else None,
                "blocking": cc["blocking"], "events": [_fmt_event(e) for e in cc["events"]],
                "review_window": [{"document_id": r["document_id"], "announced_at": r["announced_at"].isoformat(),
                                   "subject": r["subject"], "clause": r["clause"], "cleared_by": r["cleared_by"]}
                                  for r in cc["review_window"]],
                "financial_report_status": cc["financial_report_status"],
                "review_record": bool(rv)}


def replay(out_dir, reviews=None, today=None):
    """離線重算：用某次蒐證存下的原始回應（manifest.json + responses/）重新解析並計算各季截止點，
    不連任何網站。用途：新增人工審查紀錄或規則後重新評估、獨立複驗。
    每個回應都用正式解析器重新解析並比對 manifest 記錄的 SHA-256；同一請求有多次嘗試時採用最後一次解析成功的。
    today 預設為該次蒐證的開始日期（台北時間），讓「哪些季度已結束」與當時一致。"""
    manifest = json.load(open(os.path.join(out_dir, "manifest.json"), encoding="utf-8"))
    co_id = manifest["co_id"]
    summary = {"co_id": co_id, "roc_years": manifest["roc_years"], "listings": {}, "filings": {}, "details": {},
               "quarters": {}, "notes": [], "replayed_from": {"collector_version": manifest.get("collector_version"),
                                                              "started_at": manifest.get("started_at")}}
    reqs = manifest["requests"]
    listings = {}
    for rec in reqs:
        if rec["kind"] != "t05st01_listing":
            continue
        y = rec["params"]["roc_year"]
        if not rec.get("response_file"):
            summary["listings"].setdefault(y, {"failures": [["NO_RESPONSE", rec.get("error") or rec.get("status")]]})
            continue
        lst, fails = parse_t05st01_listing(_read(out_dir, rec["response_file"]), rec["content_type"],
                                           rec["request_url"], co_id, y, "", rec["response_sha256"])
        if lst:
            listings[int(y)] = lst
            summary["listings"][y] = {"items": len(lst.items), "sha256": lst.response_sha256}
        elif int(y) not in listings:
            summary["listings"][y] = {"failures": [list(f) for f in fails], "status": rec.get("status")}
    if not listings:
        summary["notes"].append("沒有任何年度的清單可以解析")
        return summary
    merged = _merge_runs(listings)
    company = next(iter(listings.values())).company_name
    by_id = {it.document_id: it for ml in merged.values() for it in ml.items}
    details = {}
    for rec in reqs:
        if rec["kind"] != "t05st01_detail":
            continue
        doc = rec["params"].get("document_id")
        it = by_id.get(doc)
        if it is None:
            summary["details"][doc] = {"ok": False, "failures": [["ANNOUNCEMENT_DOCUMENT_NOT_LISTED", "不在已解析的清單中"]]}
            continue
        if not rec.get("response_file"):
            summary["details"].setdefault(doc, {"ok": False, "error": rec.get("error"), "status": rec.get("status")})
            continue
        d, fails = parse_t05st01_detail(_read(out_dir, rec["response_file"]), rec["content_type"], rec["request_url"],
                                        it, rec["response_sha256"])
        if d:
            details[doc] = d
            summary["details"][doc] = {"ok": True, "clause": d.clause, "fact_date": d.fact_date.isoformat()}
        elif doc not in details:
            summary["details"][doc] = {"ok": False, "failures": [list(f) for f in fails]}
    filings = {}
    for rec in reqs:
        if rec["kind"] != "t57sb01_list" or not rec.get("response_file"):
            continue
        y = rec["params"]["roc_year"]
        retrieved = datetime.fromisoformat(rec["retrieved_at"]) if rec.get("retrieved_at") else None
        fl, fails = parse_t57sb01_listing(_read(out_dir, rec["response_file"]), rec["content_type"], rec["request_url"],
                                          co_id, y, company, retrieved, rec["response_sha256"])
        if fl:
            filings[y] = fl
            summary["filings"][y] = {"rows": [[r.fiscal_quarter, r.filename, r.uploaded_at.isoformat()]
                                              for r in fl.rows], "sha256": fl.response_sha256}
        elif y not in filings:
            summary["filings"][y] = {"failures": [list(f) for f in fails]}
    if today is None:
        today = datetime.fromisoformat(manifest["started_at"]).astimezone(TPE).date()
    _evaluate_quarters(co_id, merged, details, list(filings.values()), reviews, today, summary)
    return summary


def load_reviews(path):
    """人工審查紀錄：{(co_id, 季度): 紀錄}；條款規則放在 "__clause_policy__"。缺審查人或時間的紀錄不採用。"""
    out = {}
    if path and os.path.isdir(path):
        for name in sorted(os.listdir(path)):
            if name.endswith(".json"):
                rv = json.load(open(os.path.join(path, name), encoding="utf-8"))
                if not (rv.get("reviewer") and rv.get("decided_at")):
                    continue
                if rv.get("decision") == "not_financial_results":
                    out[(rv["co_id"], rv["fiscal_quarter"])] = rv
                elif rv.get("decision") == "auto_clear_non_results_by_clause" and rv.get("clauses"):
                    out["__clause_policy__"] = rv
    return out


def main(argv=None):
    p = argparse.ArgumentParser(description="一鍵蒐證：Gate5B 截止點需要的官方證據")
    p.add_argument("--co-id", required=True)
    p.add_argument("--roc-years", required=True, help="民國年，逗號分隔，例如 113,114,115")
    p.add_argument("--out", required=True)
    p.add_argument("--reviews", default=None, help="人工審查紀錄資料夾（*.json）")
    p.add_argument("--mops-base", default=ap.DEFAULT_MOPS_BASE)
    p.add_argument("--doc-base", default=DEFAULT_DOC_BASE)
    p.add_argument("--delay", type=float, default=3.0)
    p.add_argument("--timeout", type=float, default=30.0)
    p.add_argument("--max-details", type=int, default=150)
    p.add_argument("--retry-waits", default=",".join(f"{w:g}" for w in DEFAULT_RETRY_WAITS),
                   help="重試前等待秒數，逗號分隔（預設 10,30 = 最多 3 次嘗試）；空字串 = 不重試")
    a = p.parse_args(argv)
    if not re.fullmatch(r"\d{4,6}", a.co_id):
        p.error("股票代號必須是 4–6 位數字")
    if not re.fullmatch(r"\d{3}(,\d{3}){0,5}", a.roc_years):
        p.error("年度格式錯誤，例如 113,114,115（最多 6 個年度）")
    if not re.fullmatch(r"(\d{1,3}(\.\d+)?(,\d{1,3}(\.\d+)?){0,4})?", a.retry_waits):
        p.error("重試等待秒數格式錯誤，例如 10,30（最多 5 個）")
    waits = tuple(float(x) for x in a.retry_waits.split(",")) if a.retry_waits else ()
    years = sorted({int(x) for x in a.roc_years.split(",")})
    manifest, summary = collect(a.co_id, years, a.out, a.mops_base, a.doc_base, a.delay, a.timeout, a.max_details,
                                load_reviews(a.reviews), retry_waits=waits)
    for name, obj in (("manifest.json", manifest), ("summary.json", summary)):
        with open(os.path.join(a.out, name), "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
    # 簡短摘要（給執行紀錄與 Step Summary）
    lines = [f"## 蒐證結果 {a.co_id}（民國 {a.roc_years}）", "", "| 季度 | 狀態 | 最早事件 | 時間 | 阻擋原因 |", "|---|---|---|---|---|"]
    for q, s in sorted(summary["quarters"].items()):
        e = s["earliest"] or {}
        lines.append(f"| {q} | {s['status']} | {e.get('event_type', '')} | {e.get('at', '')} | "
                     f"{'；'.join(s['blocking']).replace('|', '/')} |")
    pending = [(q, r) for q, s in sorted(summary["quarters"].items()) for r in s["review_window"]
               if r["cleared_by"] is None]
    auto = sum(1 for s in summary["quarters"].values() for r in s["review_window"] if r["cleared_by"] == "auto_clause_rule")
    retried = sum(1 for r in manifest["requests"] if r.get("attempt", 1) > 1)
    lines += ["", f"條款規則自動排除 {auto} 則；重試 {retried} 次；仍需人工確認 {len(pending)} 則"]
    if pending:
        lines += ["", "| 季度 | 公告時間 | 款 | 主旨 |", "|---|---|---|---|"]
        lines += [f"| {q} | {r['announced_at'][:16]} | {r['clause'] or '未知'} | {r['subject'].replace('|', '/')} |"
                  for q, r in pending]
    for n in summary["notes"]:
        lines.append(f"\n- {n}")
    text = "\n".join(lines)
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
