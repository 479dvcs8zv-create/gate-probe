"""
test_run_39103606949.py (v4.15)
===============================
用 GitHub Actions 一鍵蒐證第一次成功的真實結果（gate-probe run 39103606949，2026-10-18，collector 4.14）
做離線重算：114、115 年全年清單（跨年合併）、53 則詳細頁、113–115 年財報申報清單。
113 年清單當時回 HTTP 502、6 則詳細頁逾時，這些失敗也原樣保留在證據裡。

確認：
  - 離線重算（只用當時的人工審查）與當時存下的 summary.json 完全一致
  - 使用者核准的條款規則（20、6、8 款）只排除已取得詳細頁、條款在清單內的公告，逐則記錄 cleared_by
  - 18 款、抓不到詳細頁（條款未知）的公告不會被自動排除
  - 改動任何一個位元組的回應 → 雜湊不符 → 該季退回暫定
  - 條款規則缺審查人／時間 → 不採用（蒐證程式）或回報證據不完整（證據驗證）

  python test_run_39103606949.py
"""
import copy
import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
from reject_codes import RC  # noqa: E402
from mops_evidence import MopsEvidenceBundle, load_recorded_2330_115, verify_mops_evidence_bundle  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_39103606949")
RECORDED = json.load(open(os.path.join(RUN, "summary.json"), encoding="utf-8"))
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))
POLICY = REVIEWS["__clause_policy__"]
HUMAN_ONLY = {k: v for k, v in REVIEWS.items() if k != "__clause_policy__"}


def test_replay_matches_recorded_summary():
    s = ce.replay(RUN, HUMAN_ONLY)
    assert sorted(s["quarters"]) == sorted(RECORDED["quarters"]) == \
        ["2025Q1", "2025Q2", "2025Q3", "2025Q4", "2026Q1", "2026Q2", "2026Q3"]
    for q, old in RECORDED["quarters"].items():
        new = s["quarters"][q]
        assert (new["status"], new["earliest"], new["blocking"], new["events"]) == \
            (old["status"], old["earliest"], old["blocking"], old["events"]), q
        assert [r["document_id"] for r in new["review_window"]] == [r["document_id"] for r in old["review_window"]], q
    # 113 年清單 502 → 沒有 2024 年各季；114+115 合併
    assert "failures" in s["listings"]["113"] and s["listings"]["114"]["items"] == 248
    assert s["listings"]["115"]["items"] == 153
    # 財報申報清單三年都解析成功，113 年含年報（第四季）
    assert set(s["filings"]) == {"113", "114", "115"}
    assert any(r[0] == "2024Q4" for r in s["filings"]["113"]["rows"]), s["filings"]["113"]["rows"]


def test_cross_year_merge_for_q4():
    """2025Q4 的事件全部在 115 年（2026 年 1 月）的清單裡：需要跨年合併才找得到。"""
    s = ce.replay(RUN, REVIEWS)
    q4 = s["quarters"]["2025Q4"]
    assert q4["earliest"]["at"] == "2026-01-09T13:51:04+08:00"
    assert q4["earliest"]["document_id"].startswith("t05st01:2330:20260109:")
    assert q4["earliest"]["event_type"] == "quarter_revenue_complete"


def test_clause_policy_clears_only_20_6_8_with_detail():
    s = ce.replay(RUN, REVIEWS)
    q = s["quarters"]
    expect = {"2025Q1": ("CUTOFF_VERIFIED", "2025-04-10T14:05:27+08:00"),
              "2025Q2": ("PROVISIONAL", "2025-07-10T14:26:42+08:00"),
              "2025Q3": ("CUTOFF_VERIFIED", "2025-10-09T14:01:10+08:00"),
              "2025Q4": ("PROVISIONAL", "2026-01-09T13:51:04+08:00"),
              "2026Q1": ("CUTOFF_VERIFIED", "2026-04-10T13:50:36+08:00"),
              "2026Q2": ("CUTOFF_VERIFIED", "2026-07-13T13:50:31+08:00"),
              "2026Q3": ("CUTOFF_VERIFIED", "2026-10-08T13:54:04+08:00")}
    for k, (st, at) in expect.items():
        assert (q[k]["status"], q[k]["earliest"]["at"]) == (st, at), (k, q[k]["status"], q[k]["blocking"])
    rows = [r for v in q.values() for r in v["review_window"]]
    auto = [r for r in rows if r["cleared_by"] == "auto_clause_rule"]
    human = [r for r in rows if r["cleared_by"] == "human_review"]
    pending = [r for r in rows if r["cleared_by"] is None]
    assert len(rows) == 23 and len(auto) == 19 and len(human) == 2 and len(pending) == 2, (len(auto), len(human))
    assert all(r["clause"] in {"20", "6", "8"} for r in auto)
    assert sorted((r["document_id"], r["clause"]) for r in pending) == [
        ("t05st01:2330:20250701:195954:1", "18"),     # 18 款：不在規則內
        ("t05st01:2330:20260106:182750:1", None)]      # 詳細頁逾時：條款未知
    # 2025Q2 還有兩則財務事件的詳細頁逾時 → 照樣阻擋（下次重跑會重試）
    assert any("20250717:154843:1" in b and "20250812:182044:2" in b for b in q["2025Q2"]["blocking"])
    assert s["clause_policy"] == {"clauses": ["20", "6", "8"], "reviewer": POLICY["reviewer"],
                                  "decided_at": "2026-10-18T15:34:41+08:00"}


def test_without_policy_nothing_is_auto_cleared():
    s = ce.replay(RUN, HUMAN_ONLY)
    rows = [r for v in s["quarters"].values() for r in v["review_window"]]
    assert not any(r["cleared_by"] == "auto_clause_rule" for r in rows)
    assert [k for k, v in sorted(s["quarters"].items()) if v["status"] == "CUTOFF_VERIFIED"] == ["2026Q2", "2026Q3"]


def test_tampered_response_falls_back_to_provisional():
    """改動 2025Q1 最早事件（4/10 營收）詳細頁的一個位元組 → 雜湊不符 → 不採用 → 2025Q1 退回暫定。"""
    m = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
    rec = [r for r in m["requests"] if r["kind"] == "t05st01_detail"
           and r["params"]["spoke_date"] == "20250410" and r["params"]["spoke_time"] == "140527"]
    assert len(rec) == 1 and rec[0]["response_file"], rec
    tmp = tempfile.mkdtemp(prefix="replay_tamper_")
    try:
        dst = os.path.join(tmp, "run")
        shutil.copytree(RUN, dst)
        path = os.path.join(dst, rec[0]["response_file"])
        data = bytearray(open(path, "rb").read())
        i = data.index(b"<td")
        data[i + 1] = ord("T")
        open(path, "wb").write(bytes(data))
        s = ce.replay(dst, REVIEWS)
        d = s["details"]["t05st01:2330:20250410:140527:2"]
        assert d["ok"] is False and any(f[0] == RC.ANNOUNCEMENT_HASH_MISMATCH for f in d["failures"]), d
        assert s["quarters"]["2025Q1"]["status"] == "PROVISIONAL"
        assert s["quarters"]["2026Q1"]["status"] == "CUTOFF_VERIFIED"   # 其他季不受影響
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_policy_without_reviewer_is_not_used():
    tmp = tempfile.mkdtemp(prefix="policy_")
    try:
        bad = dict(POLICY)
        bad.pop("reviewer")
        json.dump(bad, open(os.path.join(tmp, "clause_policy.json"), "w", encoding="utf-8"), ensure_ascii=False)
        assert "__clause_policy__" not in ce.load_reviews(tmp)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_evidence_verifier_rejects_incomplete_policy():
    bundle, reviews = load_recorded_2330_115(BASE)
    ok = MopsEvidenceBundle(bundle.co_id, bundle.roc_year, bundle.listing, bundle.details, bundle.filings,
                            bundle.monthly_listings, reviews.get(("2330", "2026Q2")), POLICY)
    r = verify_mops_evidence_bundle(ok, "2330", "2026Q2")
    assert r["ok"] and r["cutoff"]["iso"] == "2026-07-13T13:50:31+08:00", r["failures"]
    assert r["trace"]["clause_policy"]["clauses"] == ["20", "6", "8"]
    for broken in ({k: v for k, v in POLICY.items() if k != "decided_at"},
                   dict(POLICY, clauses=["20", "x"]),
                   dict(POLICY, decision="something_else")):
        b = MopsEvidenceBundle(bundle.co_id, bundle.roc_year, bundle.listing, bundle.details, bundle.filings,
                               bundle.monthly_listings, reviews.get(("2330", "2026Q2")), copy.deepcopy(broken))
        r = verify_mops_evidence_bundle(b, "2330", "2026Q2")
        assert not r["ok"] and r["failures"][0][0] == RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, r["failures"]


def test_evidence_verifier_policy_alone_cannot_clear_without_detail():
    """115 年錄製證據沒有 7/02、7/08 的詳細頁：只靠條款規則（沒有人工審查）→ 條款未知 → 待人工確認。"""
    bundle, reviews = load_recorded_2330_115(BASE)
    b = MopsEvidenceBundle(bundle.co_id, bundle.roc_year, bundle.listing, bundle.details, bundle.filings,
                           bundle.monthly_listings, None, POLICY)
    r = verify_mops_evidence_bundle(b, "2330", "2026Q2")
    assert not r["ok"] and any(f[0] == RC.ANNOUNCEMENT_REVIEW_PENDING for f in r["failures"]), r["failures"]
    assert all(w["cleared_by"] is None and w["clause"] is None for w in r["trace"]["review_window"])


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
