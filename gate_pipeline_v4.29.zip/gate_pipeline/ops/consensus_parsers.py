"""
ops/consensus_parsers.py (v4.25)
================================
市場預估（共識）存檔原文的解析器。只產生研究紀錄，不影響任何 Gate 判定。

使用者規則（2026-10-18）：
  - 各來源的數字不同，不代表其中一個錯；只記錄差異，不自行選一個當正確值
  - 分析師人數各來源分開記錄，絕不加總
  - 不同來源數字相同，不代表是獨立分析師（可能是同一份資料）
  - 必須核對目標季度與期間

每個解析器都依真實存檔原文建立（看過原文才加入），並且「看不懂就不輸出數字」：
  - 頁面的股票代號與預期不符 → SYMBOL_MISMATCH，不輸出任何數值
  - 期間標籤無法對應到明確的季度／年度 → 該筆標記 PERIOD_UNMAPPED，不進入比較
  - 防機器人頁面 → BLOCKED_PAGE；頁面裡沒有預估表 → NO_CONSENSUS_VALUE
  - 幣別以頁面上寫的為準；頁面沒寫才用設定檔的假設，並標記 currency_from="config_assumption"

每一筆預估（estimate）的欄位：
  metric（eps／revenue）、period_type（quarter／year）、period_label_raw（原文標籤）、
  fiscal_period（例如 2026Q4、FY2026；無法確定時為 None）、period_end、currency、currency_from、
  quote（頁面的報價代號，例如 TSM、2330.TW）、basis（normalized／gaap／None＝頁面沒寫）、
  n_analysts、avg、low、high、year_ago、raw（原文字串）、flags
"""

import gzip
import html as _html
import json
import re
from datetime import date

PARSER_VERSION = "4.29-consensus-parsers"

_MON = {m: i for i, m in enumerate(("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                                     "Dec"), 1)}


def decode(raw):
    """封存原文可能是 gzip 壓縮（id_ 模式原樣保留）。"""
    if raw[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(raw)
        except (OSError, EOFError):
            return raw
    return raw


def _quarter_end(y, q):
    return date(y + (q == 4), (3 * q) % 12 + 1, 1).toordinal() - 1


def _period_from_month(year, month):
    """季末月份 → 季度。只接受 3、6、9、12 月（台灣公司會計年度＝曆年）；其他月份無法對應。"""
    if month in (3, 6, 9, 12):
        q = month // 3
        return f"{year}Q{q}", date.fromordinal(_quarter_end(year, q)).isoformat()
    return None, None


def _num(s, pct=False):
    """'1.71T'、'854.69B'、'$32.5 B'、'2.23'、'--'、'63.01%' → 數值；無值回傳 None。"""
    if s is None:
        return None
    t = s.strip().replace(",", "").replace("$", "").replace("\u2212", "-")
    if t in ("", "-", "--", "N/A", "n/a", "[PRO]"):
        return None
    m = re.fullmatch(r"(-?\d+(?:\.\d+)?)\s*([KMBT%])?", t)
    if not m:
        raise ValueError(f"無法解析的數值：{s!r}")
    v = float(m.group(1))
    mult = {"K": 1e3, "M": 1e6, "B": 1e9, "T": 1e12, "%": 1, None: 1}[m.group(2)]
    if m.group(2) == "%" and not pct:
        raise ValueError(f"預期數值卻是百分比：{s!r}")
    return v * mult


def _result(source_id, parser, status, reason=None, **kw):
    out = {"source_id": source_id, "parser": parser, "parser_version": PARSER_VERSION, "status": status,
           "reason": reason, "page": {}, "estimates": [], "retrospective": [], "vendor_history": [], "notes": []}
    out.update(kw)
    return out


def _est(metric, ptype, label, fp, pend, currency, currency_from, quote, basis, n, avg, low, high, year_ago, raw,
         flags=None):
    f = list(flags or [])
    if fp is None and "PERIOD_UNMAPPED" not in f:
        f.append("PERIOD_UNMAPPED")
    return {"metric": metric, "period_type": ptype, "period_label_raw": label, "fiscal_period": fp,
            "period_end": pend, "currency": currency, "currency_from": currency_from, "quote": quote, "basis": basis,
            "n_analysts": n, "avg": avg, "low": low, "high": high, "year_ago": year_ago, "raw": raw, "flags": f}


# ------------------------------------------------------------------------------------------------ Yahoo Finance
_Y_SECTIONS = ("earningsEstimate", "revenueEstimate", "earningsHistory", "epsTrend", "epsRevisions")


def _strip(s):
    return re.sub(r"\s+", " ", _html.unescape(re.sub(r"<[^>]+>", "", s))).strip()


def _yahoo_tables(t):
    out = {}
    for m in re.finditer(r'<section[^>]*data-testid="(%s)"' % "|".join(_Y_SECTIONS), t):
        end = t.find("</section>", m.end())
        seg = t[m.start():end if end > 0 else len(t)]
        tm = re.search(r"<table[^>]*>(.*?)</table>", seg, re.S)
        if not tm:
            continue
        heads = [_strip(h) for h in re.findall(r"<th[^>]*>(.*?)</th>", tm.group(1), re.S)]
        rows = []
        for r in re.findall(r"<tr[^>]*>(.*?)</tr>", tm.group(1), re.S):
            cells = [_strip(c) for c in re.findall(r"<td[^>]*>(.*?)</td>", r, re.S)]
            if cells:
                rows.append(cells)
        basis = None
        tog = seg[:tm.start()]
        if re.search(r'<input\s+checked[^>]*value="nongaap"', tog) or re.search(
                r'id="tab-nongaap"\s+aria-selected="true"', tog):
            basis = "normalized"
        elif re.search(r'<input\s+checked[^>]*value="gaap"', tog) or re.search(
                r'id="tab-gaap"\s+aria-selected="true"', tog):
            basis = "gaap"
        out[m.group(1)] = {"heads": heads, "rows": rows, "basis": basis}
    return out


def _yahoo_period(label):
    m = re.fullmatch(r"(?:Current|Next) Qtr\.? \((\w{3}) (\d{4})\)", label)
    if m and m.group(1) in _MON:
        fp, pend = _period_from_month(int(m.group(2)), _MON[m.group(1)])
        return "quarter", fp, pend
    m = re.fullmatch(r"(?:Current|Next) Year \((\d{4})\)", label)
    if m:
        return "year", f"FY{m.group(1)}", f"{m.group(1)}-12-31"
    return None, None, None


def parse_yahoo(source_id, body, expected_quote, config_unit=None):
    t = decode(body).decode("utf-8", "replace")
    title = re.search(r"<title>(.*?)</title>", t, re.S)
    title = _html.unescape(title.group(1)).strip() if title else ""
    qm = re.search(r"\(([A-Z0-9.\-]+)\) Analyst Ratings, Estimates", title)
    quote = qm.group(1) if qm else None
    page = {"title": title, "quote": quote}
    if quote is None:
        return _result(source_id, "yahoo", "UNPARSED", "頁面標題找不到報價代號", page=page)
    if quote.upper() != expected_quote.upper():
        return _result(source_id, "yahoo", "SYMBOL_MISMATCH", f"頁面是 {quote}，預期 {expected_quote}", page=page)
    tabs = _yahoo_tables(t)
    if not tabs and "tdv2-applet-AnalystLeafPage" in t:
        return _result(source_id, "yahoo", "UNSUPPORTED_LAYOUT",
                       "2024 年初以前的舊版面：幣別只在整個區塊標一次，無法確認各表（尤其營收）的幣別，不解析", page=page)
    if "earningsEstimate" not in tabs and "revenueEstimate" not in tabs:
        return _result(source_id, "yahoo", "NO_CONSENSUS_VALUE", "頁面裡沒有 Earnings／Revenue Estimate 表", page=page)
    res = _result(source_id, "yahoo", "PARSED", page=page)
    for sec, metric, ago in (("earningsEstimate", "eps", "Year Ago EPS"), ("revenueEstimate", "revenue", "Year Ago Sales")):
        tb = tabs.get(sec)
        if not tb:
            res["notes"].append(f"{sec} 表不存在")
            continue
        heads, rows = tb["heads"], {r[0]: r[1:] for r in tb["rows"]}
        cm = re.fullmatch(r"Currency in ([A-Z]{3})", heads[0], re.I) if heads else None   # 2024 年中版面為大寫
        if not cm:
            res["notes"].append(f"{sec} 表頭沒有幣別，不輸出")
            continue
        need = ("No. of Analysts", "Avg. Estimate", "Low Estimate", "High Estimate")
        if any(k not in rows or len(rows[k]) != len(heads) - 1 for k in need):
            res["notes"].append(f"{sec} 表欄列數不一致，不輸出")
            continue
        for i, label in enumerate(heads[1:]):
            ptype, fp, pend = _yahoo_period(label)
            raw = {k: rows[k][i] for k in rows if len(rows[k]) == len(heads) - 1}
            n = _num(rows["No. of Analysts"][i])
            res["estimates"].append(_est(
                metric, ptype, label, fp, pend, cm.group(1).upper(), "page", quote, tb["basis"] if metric == "eps" else None,
                int(n) if n is not None else None, _num(rows["Avg. Estimate"][i]), _num(rows["Low Estimate"][i]),
                _num(rows["High Estimate"][i]), _num(rows[ago][i]) if ago in rows else None, raw))
    eh = tabs.get("earningsHistory")
    if eh and eh["heads"]:
        rows = {r[0]: r[1:] for r in eh["rows"]}
        ecm = re.fullmatch(r"Currency in ([A-Z]{3})", eh["heads"][0], re.I)
        for i, label in enumerate(eh["heads"][1:]):
            m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{4})", label)
            fp = _period_from_month(int(m.group(3)), int(m.group(1)))[0] if m else None
            res["retrospective"].append({
                "kind": "vendor_reported_past_estimate", "period_label_raw": label, "fiscal_period": fp,
                "eps_estimate": _num(rows.get("EPS Est.", [None] * 9)[i]) if "EPS Est." in rows else None,
                "eps_actual": _num(rows.get("EPS Actual", [None] * 9)[i]) if "EPS Actual" in rows else None,
                "currency": ecm.group(1).upper() if ecm else None,
                "note": "網站事後列出的「當時預估」，存檔時間晚於該季公布，無法證明公布前就是這個值，不可當成截止點前快照"})
    for sec in ("epsTrend", "epsRevisions"):
        tb = tabs.get(sec)
        if tb and tb["heads"]:
            res["vendor_history"].append({
                "table": sec, "heads": tb["heads"], "rows": tb["rows"],
                "note": "網站自己列出的歷史（例如 7／30／60／90 天前），沒有封存時間證明，只能參考"})
    if not res["estimates"]:
        res["status"] = "NO_CONSENSUS_VALUE"
        res["reason"] = "預估表無法解析出任何數值"
    return res


# ------------------------------------------------------------------------------------------------ Nasdaq API
def parse_nasdaq_api(source_id, body, expected_quote, config_unit=None):
    try:
        j = json.loads(decode(body))
    except ValueError:
        return _result(source_id, "nasdaq_api", "UNPARSED", "原文不是 JSON")
    d = (j or {}).get("data") or {}
    sym = (d.get("symbol") or "").upper()
    page = {"symbol": sym, "status": (j or {}).get("status")}
    if not sym:
        return _result(source_id, "nasdaq_api", "NO_CONSENSUS_VALUE", "JSON 沒有 data／symbol", page=page)
    if sym != expected_quote.upper():
        return _result(source_id, "nasdaq_api", "SYMBOL_MISMATCH", f"JSON 是 {sym}，預期 {expected_quote}", page=page)
    cur = None
    if config_unit and config_unit.startswith("美元"):
        cur = "USD"
    res = _result(source_id, "nasdaq_api", "PARSED", page=page)
    for key, ptype in (("quarterlyForecast", "quarter"), ("yearlyForecast", "year")):
        blk = d.get(key) or {}
        if blk.get("asOf") is None:
            res["notes"].append(f"{key}.asOf 是空的：無法得知這份共識是何時計算的")
        for r in blk.get("rows") or []:
            label = r.get("fiscalEnd") or ""
            m = re.fullmatch(r"(\w{3}) (\d{4})", label)
            fp = pend = None
            if m and m.group(1) in _MON:
                if ptype == "quarter":
                    fp, pend = _period_from_month(int(m.group(2)), _MON[m.group(1)])
                elif _MON[m.group(1)] == 12:
                    fp, pend = f"FY{m.group(2)}", f"{m.group(2)}-12-31"
            res["estimates"].append(_est(
                "eps", ptype, label, fp, pend, cur, "config_assumption", sym, None, r.get("noOfEstimates"),
                r.get("consensusEPSForecast"), r.get("lowEPSForecast"), r.get("highEPSForecast"), None,
                {k: r.get(k) for k in r}, ["EPS_DEFINITION_FOOTNOTED"] if "EPS*" in json.dumps(blk.get("headers")) else []))
    if not res["estimates"]:
        res["status"], res["reason"] = "NO_CONSENSUS_VALUE", "quarterlyForecast／yearlyForecast 沒有資料列"
    return res


# ------------------------------------------------------------------------------------------------ MarketBeat
def _text(t):
    t = re.sub(r"<script.*?</script>", " ", t, flags=re.S)
    t = re.sub(r"<style.*?</style>", " ", t, flags=re.S)
    t = _html.unescape(re.sub(r"<[^>]+>", "|", t))
    return re.sub(r"\s+", " ", re.sub(r"\|[\s|]*", "|", t))


def parse_marketbeat(source_id, body, expected_quote, config_unit=None):
    t = decode(body).decode("utf-8", "replace")
    title = re.search(r"<title>(.*?)</title>", t, re.S)
    title = _html.unescape(title.group(1)).strip() if title else ""
    qm = re.search(r"\(([A-Z0-9.]+)\) Earnings", title)
    page = {"title": title, "quote": qm.group(1) if qm else None}
    if not qm:
        return _result(source_id, "marketbeat", "UNPARSED", "頁面標題找不到報價代號", page=page)
    if qm.group(1).upper() != expected_quote.upper():
        return _result(source_id, "marketbeat", "SYMBOL_MISMATCH", f"頁面是 {qm.group(1)}，預期 {expected_quote}", page=page)
    x = _text(t)
    head = "Analyst EPS Estimates|Quarter|Number of Estimates|Low Estimate|High Estimate|Average Estimate|"
    i = x.find(head)
    if i < 0:
        return _result(source_id, "marketbeat", "NO_CONSENSUS_VALUE", "頁面裡沒有 Analyst EPS Estimates 表", page=page)
    body_seg = x[i + len(head) - 1:i + 5000]
    has_rev = body_seg.startswith("|Revenue Estimate|Company Revenue Guidance|")   # 2026 年起的版面多兩欄
    if has_rev:
        body_seg = body_seg[len("|Revenue Estimate|Company Revenue Guidance"):]
    elif body_seg.startswith("|Company Guidance|"):   # 2024 年版面：多一欄「Company Guidance」，各列通常沒有值
        body_seg = body_seg[len("|Company Guidance"):]
    res = _result(source_id, "marketbeat", "PARSED", page=page)
    # 列：期間｜預估數｜低｜高｜平均［｜營收預估］［｜公司營收財測區間］（2026 年版面才有後兩欄，且年度列與遠期列沒有）
    row_re = re.compile(r"\|(Q[1-4] \d{4}|FY \d{4})\|(\d+)\|(\$[\d.,]+|-)\|(\$[\d.,]+|-)\|(\$[\d.,]+|-)"
                        r"(?:\|(\$[\d.]+ ?[MBT]))?(?:\|(\$[\d.]+ ?[MBT] ?- ?\$[\d.]+ ?[MBT]))?(?=\|)")
    q_avgs = {}
    k = 0
    while True:
        m = row_re.match(body_seg, k)
        if not m:
            break
        k = m.end()
        label = m.group(1)
        if label.startswith("Q"):
            q, y = int(label[1]), int(label[3:])
            fp, pend = f"{y}Q{q}", date.fromordinal(_quarter_end(y, q)).isoformat()
            ptype, flags = "quarter", ["FISCAL_LABEL_ASSUMED_CALENDAR"]
        else:
            y = int(label[3:])
            fp, pend, ptype, flags = f"FY{y}", f"{y}-12-31", "year", ["FISCAL_LABEL_ASSUMED_CALENDAR"]
        n, low, high, avg = int(m.group(2)), _num(m.group(3)), _num(m.group(4)), _num(m.group(5))
        raw = {"label": label, "n": m.group(2), "low": m.group(3), "high": m.group(4), "avg": m.group(5)}
        if has_rev:
            raw.update(revenue_estimate=m.group(6), company_revenue_guidance=m.group(7))
        if ptype == "quarter" and avg is not None:
            q_avgs.setdefault(y, {})[q] = avg
        if ptype == "year" and avg is not None:
            qs = q_avgs.get(y, {})
            if len(qs) == 4 and abs(sum(qs.values()) - avg) < 0.015 and n == 4:
                flags.append("FY_ROW_IS_SUM_OF_QUARTERS")
        res["estimates"].append(_est("eps", ptype, label, fp, pend, "USD", "page", qm.group(1), None, n, avg, low, high,
                                     None, raw, flags))
        if m.group(7):
            res.setdefault("company_guidance_shown", []).append(
                {"fiscal_period": fp, "range_raw": m.group(7),
                 "note": "網站轉載的公司營收財測；官方財測以公開資訊觀測站原文為準，這裡只記錄"})
        if m.group(6):
            res["estimates"].append(_est("revenue", ptype, label, fp, pend, "USD", "page", qm.group(1), None, None,
                                         _num(m.group(6).replace(" ", "")), None, None, None, raw, list(flags)))
    rest = body_seg[k:]
    stop = rest.find("Earnings History by Quarter")
    left = re.findall(r"\|(?:Q[1-4]|FY) \d{4}\|\d+\|", rest[:stop if stop >= 0 else len(rest)])
    if left:
        res["notes"].append(f"預估表後段還有 {len(left)} 列格式不同，未解析（不猜）")
        res["unparsed_rows"] = len(left)
    if any("FY_ROW_IS_SUM_OF_QUARTERS" in e["flags"] for e in res["estimates"]):
        res["notes"].append("年度列的平均＝四季平均相加、預估數＝4（季數），不是獨立的年度共識，也不是 4 位分析師")
    hm = re.search(r"Date\|Quarter\|Consensus Estimate\|Reported EPS\|Beat/Miss\|GAAP EPS\|", x)
    if hm:
        for r in re.finditer(r"(?<=\|)(\d{1,2}/\d{1,2}/\d{4})\|(Q[1-4] \d{4})\|(\$[\d.]+|-)\|(\$[\d.]+|-)\|",
                             x[hm.end() - 1:hm.end() + 8000]):
            res["retrospective"].append({
                "kind": "vendor_reported_past_estimate", "report_date": r.group(1), "period_label_raw": r.group(2),
                "fiscal_period": f"{r.group(2)[3:]}Q{r.group(2)[1]}", "eps_estimate": _num(r.group(3)),
                "eps_actual": _num(r.group(4)), "currency": "USD",
                "note": "網站事後列出的「當時預估」，不能證明公布前就是這個值"})
    if not res["estimates"]:
        res["status"], res["reason"] = "NO_CONSENSUS_VALUE", "預估表沒有可解析的資料列"
    return res


# ------------------------------------------------------------------------------------------------ StockAnalysis
def _js_array(s, key):
    """取出 key:[...] 陣列（字串內的方括號不計，例如 "[PRO]"），回傳 Python 清單。"""
    m = re.search(r"\b%s:\[" % re.escape(key), s)
    if not m:
        return None
    k, in_str = m.end(), False
    while k < len(s):
        c = s[k]
        if in_str:
            if c == '"':
                in_str = False
        elif c == '"':
            in_str = True
        elif c == "]":
            break
        k += 1
    out = []
    for it in re.findall(r'"[^"]*"|[^,]+', s[m.end():k]):
        it = it.strip()
        if it == "null":
            out.append(None)
        elif it.startswith('"'):
            out.append(it.strip('"'))
        else:
            out.append(float(it))
    return out


def _js_object(s, start_token):
    """從 start_token（以 { 結尾）開始，取出對應大括號內的文字（不含最外層括號）。字串內的括號不計。"""
    i = s.find(start_token)
    if i < 0:
        return None
    j = i + len(start_token)
    depth, k, in_str = 1, j, False
    while k < len(s) and depth:
        c = s[k]
        if in_str:
            if c == "\\":
                k += 1
            elif c == '"':
                in_str = False
        elif c == '"':
            in_str = True
        elif c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        k += 1
    return s[j:k - 1] if depth == 0 else None


def parse_stockanalysis(source_id, body, expected_quote, config_unit=None):
    t = decode(body).decode("utf-8", "replace")
    um = re.search(r'uid:"(?:stocks/)?([A-Z0-9.]+)"', t)   # 2024 年版面寫 "stocks/TSM"
    page = {"quote": um.group(1) if um else None}
    if not um:
        return _result(source_id, "stockanalysis", "UNPARSED", "頁面資料找不到報價代號", page=page)
    if um.group(1).upper() != expected_quote.upper():
        return _result(source_id, "stockanalysis", "SYMBOL_MISMATCH", f"頁面是 {um.group(1)}，預期 {expected_quote}",
                       page=page)
    cm = re.search(r"Financial currency is ([A-Z]{3})", t) or re.search(r'financial:"([A-Z]{3})"', t)
    if not cm:
        return _result(source_id, "stockanalysis", "UNPARSED", "頁面沒有寫財報幣別，不輸出", page=page)
    cur = cm.group(1)
    page["financial_currency"] = cur
    ti = t.find("table:{annual:")
    if ti < 0:
        return _result(source_id, "stockanalysis", "NO_CONSENSUS_VALUE", "頁面資料沒有預估表", page=page)
    res = _result(source_id, "stockanalysis", "PARSED", page=page)
    if config_unit and not config_unit.startswith({"TWD": "新台幣", "USD": "美元"}.get(cur, cur)):
        res["notes"].append(f"頁面寫財報幣別 {cur}，與設定檔的單位假設「{config_unit}」不同；以頁面為準")
        res["config_unit_mismatch"] = True
    if "forecasted numbers may be non-GAAP" in t:
        res["notes"].append("頁面說明：歷史 EPS 為 GAAP，預估值可能是非 GAAP")
    table = _js_object(t, "table:{") or ""
    quarterly = _js_object(table, "quarterly:{") or ""
    # 季度：eps 平均與分析師人數（沒有高低值）；lastDate 之前（含）是實際值
    eps, dates, analysts = _js_array(quarterly, "eps"), _js_array(quarterly, "dates"), _js_array(quarterly, "analysts")
    fy, fq = _js_array(quarterly, "fiscalYear"), _js_array(quarterly, "fiscalQuarter")
    rev = _js_array(quarterly, "revenue")
    lm = re.search(r"lastDate:(\d+)", quarterly)
    last = int(lm.group(1)) if lm else None
    if fy is None and fq is None and eps and dates:   # 2024 年版面沒有 fiscalYear／fiscalQuarter：只用日期對應（不交叉核對）
        fy, fq = [None] * len(dates), [None] * len(dates)
        res["notes"].append("頁面沒有會計年度／季度欄位，期間只由日期（季末日）對應")
    if not (eps and dates and analysts and fy and fq and last is not None
            and len({len(eps), len(dates), len(analysts), len(fy), len(fq)}) == 1):
        res["notes"].append("季度預估陣列不完整或長度不一致，不輸出")
    else:
        for i in range(0, min(last + 1, len(dates))):   # lastDate 之前（含）是網站列出的實際值
            if isinstance(eps[i], float):
                fp_a = _period_from_month(int(dates[i][:4]), int(dates[i][5:7]))[0]
                res["retrospective"].append({
                    "kind": "vendor_reported_actual", "period_label_raw": dates[i], "fiscal_period": fp_a,
                    "eps_estimate": None, "eps_actual": eps[i], "currency": cur,
                    "note": "網站列出的實際 EPS，只用來和官方公告比對單位（每股或每 ADR）"})
        for i in range(last + 1, len(dates)):
            if eps[i] == "[PRO]" and analysts[i] == "[PRO]":
                continue
            y, mo = int(dates[i][:4]), int(dates[i][5:7])
            fp, pend = _period_from_month(y, mo)
            flags = []
            if fp and fy[i] is not None and (fp != f"{fy[i]}{fq[i]}"):
                flags.append("FISCAL_LABEL_DIFFERS_FROM_DATE")
                fp = None
            n = analysts[i] if isinstance(analysts[i], float) else None
            for metric, v in (("eps", eps[i]), ("revenue", rev[i] if rev and len(rev) == len(dates) else None)):
                if isinstance(v, float):
                    res["estimates"].append(_est(metric, "quarter", dates[i], fp, pend, cur, "page", um.group(1), None,
                                                 int(n) if n is not None else None, v, None, None, None,
                                                 {"date": dates[i], "fiscal": f"{fy[i]}{fq[i]}" if fy[i] else None, "value": v,
                                                  "analysts": analysts[i]}, flags))
    # 年度：estimatesCharts 有人數、平均、高低
    charts = _js_object(t, "estimatesCharts:{")
    for metric in ("eps", "revenue"):
        blk = _js_object(charts or "", metric + ":{")
        for d, blob in re.findall(r'"(\d{4}-\d{2}-\d{2})":\{([^}]*)\}', blk or ""):
            vals = dict(re.findall(r"(\w+):(-?[\d.]+(?:e[+-]?\d+)?)", blob))
            if not vals:
                continue
            fp = f"FY{d[:4]}" if d[5:] == "12-31" else None
            res["estimates"].append(_est(metric, "year", d, fp, d if fp else None, cur, "page", um.group(1), None,
                                         int(float(vals["no"])) if "no" in vals else None,
                                         float(vals["avg"]) if "avg" in vals else None,
                                         float(vals["low"]) if "low" in vals else None,
                                         float(vals["high"]) if "high" in vals else None, None,
                                         {"date": d, **vals}))
    if not res["estimates"]:
        res["status"], res["reason"] = "NO_CONSENSUS_VALUE", "沒有可用（非付費）的預估值"
    return res


# ------------------------------------------------------------------------------------------------ 其他
def parse_zacks(source_id, body, expected_quote, config_unit=None):
    t = decode(body).decode("utf-8", "replace")
    if "Pardon Our Interruption" in t:
        return _result(source_id, "zacks", "BLOCKED_PAGE",
                       "存到的是網站的防機器人頁面（Pardon Our Interruption），沒有預估值")
    return _result(source_id, "zacks", "UNPARSED", "尚未依真實原文建立 Zacks 解析器")


def parse_nasdaq_html(source_id, body, expected_quote, config_unit=None):
    t = decode(body).decode("utf-8", "replace")
    if "Data is currently not available" in t:
        return _result(source_id, "nasdaq_html", "NO_CONSENSUS_VALUE",
                       "頁面的預估表由瀏覽器另外載入，存檔裡是「Data is currently not available」")
    return _result(source_id, "nasdaq_html", "UNPARSED", "尚未依真實原文建立解析器")


PARSERS = {
    "yahoo_adr_analysis": parse_yahoo,
    "yahoo_tw_analysis": parse_yahoo,
    "nasdaq_api_forecast": parse_nasdaq_api,
    "marketbeat_adr_earnings": parse_marketbeat,
    "stockanalysis_adr_forecast": parse_stockanalysis,
    "zacks_adr_detailed": parse_zacks,
    "zacks_adr_detailed2": parse_zacks,
    "nasdaq_adr_earnings": parse_nasdaq_html,
}


def label_to_period(label, period_type):
    """（v4.27，供逐項審查重新推導）各網站的期間標籤 → 季度／年度。看不懂回傳 None。"""
    s = str(label or "").strip()
    if period_type == "quarter":
        m = re.fullmatch(r"(?:Current|Next) Qtr\.? \((\w{3}) (\d{4})\)", s) or re.fullmatch(r"(\w{3}) (\d{4})", s)
        if m and m.group(1) in _MON:
            return _period_from_month(int(m.group(2)), _MON[m.group(1)])[0]
        m = re.fullmatch(r"Q([1-4]) (\d{4})", s)
        if m:
            return f"{m.group(2)}Q{m.group(1)}"
        m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", s)
        if m and m.group(2) + m.group(3) in ("0331", "0630", "0930", "1231"):
            return _period_from_month(int(m.group(1)), int(m.group(2)))[0]
        return None
    m = re.fullmatch(r"(?:Current|Next) Year \((\d{4})\)|FY (\d{4})|Dec (\d{4})|(\d{4})-12-31", s)
    if m:
        return "FY" + next(g for g in m.groups() if g)
    return None


def expected_quote(source_id, co_id, adr):
    """頁面應該是哪個報價代號。台股頁面＝<代號>.TW；其他（ADR 頁面）＝ADR 代號。"""
    if source_id == "yahoo_tw_analysis":
        return f"{co_id}.TW"
    return adr or ""


def parse_capture(source_id, body, co_id, adr, config_unit=None):
    fn = PARSERS.get(source_id)
    if fn is None:
        return _result(source_id, None, "UNPARSED", "這個網站還沒有解析器")
    q = expected_quote(source_id, co_id, adr)
    if not q:
        return _result(source_id, fn.__name__, "UNPARSED", "沒有可核對的報價代號（無 ADR 對照）")
    try:
        return fn(source_id, body, q, config_unit)
    except (ValueError, KeyError, IndexError) as e:   # 原文格式超出已知範圍：不猜，記錄失敗
        return _result(source_id, fn.__name__, "PARSE_FAILED", f"{type(e).__name__}: {e}")


def discovery_parsers(co_id, adr, units=None):
    """給 consensus_discovery.classify 用的介面：fn(body, quarter) -> {"values": [...]} 或 None。"""
    units = units or {}

    def make(sid):
        def fn(body, quarter):
            r = parse_capture(sid, body, co_id, adr, units.get(sid))
            vals = [e for e in r["estimates"] if e["fiscal_period"] == quarter]
            return {"values": vals, "status": r["status"], "reason": r["reason"]} if r["status"] == "PARSED" else None
        return fn
    return {sid: make(sid) for sid in PARSERS}
