"""
guidance_mops.py (v4.18)
========================
Gate5B 官方財測模式（使用者 2026-10-18 核准的方向：「官方財測＋往後自己存檔」）。

資料來源只有一種：公開資訊觀測站重大訊息中，公司自己發布的「每股盈餘」公告詳細頁（已由 mops_t05st01 以官方網域、
SHA-256、與清單逐欄核對的方式解析）。台積電的這則公告同時包含：
  - 當季實際結果：美元營收、毛利率、營業利益率、每股盈餘
  - 下一季業績展望（財測）：美元營收區間、毛利率區間、營業利益率區間、匯率假設

每一季的判定（全部 fail-closed）：
  1. 財測必須來自「上一季」的每股盈餘公告，且展望的目標季度必須正好是這一季
  2. 財測的發言時間必須早於這一季的官方截止點（cutoff_candidates 算出的最早揭露時間）
  3. 財測發布後、截止點之前，若有主旨像是更新展望的公告，或已取得的詳細頁裡又出現同一季的展望 → 待人工確認
  4. 實際結果必須來自這一季自己的每股盈餘公告
  5. 任何一個欄位解析不到 → 這一季不算（不猜、不補）
比較方式：實際值高於區間上緣 / 在區間內 / 低於區間下緣。

這是「公司財測」，不是「市場共識」：意義不同，摘要與輸出都明確標示。沒有發布量化財測的公司，這個模式不適用。
Python 預驗證通過，不等於正式 Gate PASS。
"""

import re
from datetime import datetime
from typing import Optional

GUIDANCE_MODE_VERSION = "4.18-guidance"
MIN_QUARTERS = 8
CN = {"一": 1, "二": 2, "三": 3, "四": 4}
UPDATE_SUBJECT_WORDS = ("展望", "財測", "財務預測", "營運預測", "業績預估")


def _q(year, cn):
    return f"{int(year)}Q{CN[cn]}"


def next_quarter(q):
    y, n = int(q[:4]), int(q[-1])
    return f"{y + (n == 4)}Q{n % 4 + 1}"


def _num(s):
    return float(s.replace(",", ""))


def _yi_usd(whole, qian_wan=None):
    """「188億7千萬」→ 188.7 億；「467.2億」→ 467.2 億。回傳十億美元（billion）。"""
    v = _num(whole) + (int(qian_wan) / 10 if qian_wan else 0)
    return round(v / 10, 4)


_RE = {
    "reported": re.compile(r"公佈(\d{4})年第([一二三四])季財務報告"),
    "usd_rev": re.compile(r"若以(?:美元|美金)計算，(\d{4})年第([一二三四])季營收為([\d,]+(?:\.\d+)?)億(?:(\d)千萬)?"),
    "margins": re.compile(r"(\d{4})年第([一二三四])季毛利率為([\d.]+)%，營業利益率為([\d.]+)%"),
    "eps": re.compile(r"每股盈餘為新台幣([\d.]+)元（折合美國存託憑證每單位為([\d.]+)美元）"),
    "outlook": re.compile(r"(\d{4})年第([一二三四])季的業績展望如下"),
    "g_rev": re.compile(r"營收預計介於([\d,]+(?:\.\d+)?)億(?:美元)?(?:到|至)([\d,]+(?:\.\d+)?)億美元"),
    "g_gm": re.compile(r"毛利率預計介於([\d.]+)%(?:到|至)([\d.]+)%"),
    "g_opm": re.compile(r"營業利益率預計介於([\d.]+)%(?:到|至)([\d.]+)%"),
    "g_fx": re.compile(r"新台幣([\d.]+)元兌1美元|1美元兌換?([\d.]+)元新台幣"),
}


def parse_eps_announcement(description: str):
    """解析每股盈餘公告的「說明」。回傳 ({"reported_quarter", "actual", "actual_failures", "guidance",
    "guidance_failures"}, failures)。實際結果與財測分開解析：一邊缺欄位，那一邊整個不採用（None），不影響另一邊。
    找不到報告季度 → 整則不採用。"""
    t = re.sub(r"\s+", "", description or "")
    m = _RE["reported"].search(t)
    if not m:
        return None, ["找不到「公佈 YYYY 年第 X 季財務報告」"]
    rq = _q(*m.groups())
    actual, fails = _parse_actual(t, rq)
    guidance, gfails = _parse_guidance(t, rq)
    return {"reported_quarter": rq, "actual": actual, "actual_failures": fails,
            "guidance": guidance, "guidance_failures": gfails}, []


def _parse_actual(t, rq):
    fails = []
    actual = {}
    m = _RE["usd_rev"].search(t)
    if m and _q(m.group(1), m.group(2)) == rq:
        actual["revenue_usd_bn"] = _yi_usd(m.group(3), m.group(4))
    else:
        fails.append("找不到當季美元營收")
    m = _RE["margins"].search(t)
    if m and _q(m.group(1), m.group(2)) == rq:
        actual["gross_margin_pct"], actual["operating_margin_pct"] = float(m.group(3)), float(m.group(4))
    else:
        fails.append("找不到當季毛利率、營業利益率")
    m = _RE["eps"].search(t)
    if m:
        actual["eps_twd"], actual["eps_adr_usd"] = float(m.group(1)), float(m.group(2))
    else:
        fails.append("找不到每股盈餘")
    return (None, fails) if fails else (actual, [])


def _parse_guidance(t, rq):
    found = list(_RE["outlook"].finditer(t))
    if not found:
        return None, ["沒有業績展望段落"]
    if len({m.groups() for m in found}) > 1:
        return None, [f"同一則公告有多個不同季度的展望：{[_q(*m.groups()) for m in found]}"]
    m = found[0]
    target = _q(*m.groups())
    seg = t[m.end():m.end() + 400]
    r, gm, opm, fx = (_RE["g_rev"].search(seg), _RE["g_gm"].search(seg), _RE["g_opm"].search(seg),
                      _RE["g_fx"].search(seg))
    if not (r and gm and opm):
        return None, [f"有「{target} 業績展望」段落，但營收、毛利率或營業利益率區間解析不完整"]
    guidance = {"target_quarter": target,
                "revenue_usd_bn": [_yi_usd(r.group(1)), _yi_usd(r.group(2))],
                "gross_margin_pct": [float(gm.group(1)), float(gm.group(2))],
                "operating_margin_pct": [float(opm.group(1)), float(opm.group(2))],
                "fx_twd_per_usd": float(fx.group(1) or fx.group(2)) if fx else None}
    for k in ("revenue_usd_bn", "gross_margin_pct", "operating_margin_pct"):
        if guidance[k][0] > guidance[k][1]:
            return None, [f"{target} 財測的 {k} 區間下緣大於上緣"]
    if target != next_quarter(rq):
        return None, [f"{rq} 的公告裡的展望目標是 {target}，不是下一季 {next_quarter(rq)}"]
    return guidance, []


def _verdict(actual, rng):
    if actual > rng[1]:
        return "ABOVE"
    if actual < rng[0]:
        return "BELOW"
    return "WITHIN"


def evaluate_guidance(items, details: dict, cutoffs: dict, eps_items=None):
    """items：合併後清單的所有公告（T05st01Item）；details：{document_id: T05st01Detail}（已核對過的官方詳細頁）；
    cutoffs：{季度: datetime}（官方截止點，只放已驗證的季度）；eps_items：被分類為每股盈餘公告的 items。
    回傳 {"quarters": {...}, "gate": {...}, "parse_failures": [...]}"""
    from mops_t05st01 import classify
    if eps_items is None:
        eps_items = [it for it in items if any(e["event_type"] == "self_reported_results" for e in classify(it))]
    parsed, parse_failures = {}, []
    for it in eps_items:
        d = details.get(it.document_id)
        if d is None:
            parse_failures.append({"document_id": it.document_id, "reason": "詳細頁未取得"})
            continue
        p, f = parse_eps_announcement(d.description)
        if p is None:
            parse_failures.append({"document_id": it.document_id, "reason": "；".join(f)})
            continue
        if p["actual_failures"]:
            parse_failures.append({"document_id": it.document_id, "part": "actual",
                                   "reason": "實際結果未採用：" + "；".join(p["actual_failures"])})
        if p["guidance_failures"] and p["guidance_failures"] != ["沒有業績展望段落"]:
            parse_failures.append({"document_id": it.document_id, "part": "guidance",
                                   "reason": "財測未採用：" + "；".join(p["guidance_failures"])})
        parsed[it.document_id] = dict(p, announced_at=it.announced_at, document_id=it.document_id,
                                      response_sha256=d.response_sha256)
    actual_by_q, guidance_by_q = {}, {}
    for p in parsed.values():
        if p["actual"]:
            actual_by_q.setdefault(p["reported_quarter"], []).append(p)
        if p["guidance"]:
            guidance_by_q.setdefault(p["guidance"]["target_quarter"], []).append(p)

    out = {}
    for q, cutoff in sorted(cutoffs.items()):
        e = {"cutoff": cutoff.isoformat(), "status": None, "guidance": None, "actual": None, "verdicts": None,
             "notes": []}
        out[q] = e
        acts = actual_by_q.get(q, [])
        gs = guidance_by_q.get(q, [])
        if len(acts) > 1:
            e.update(status="REVIEW_PENDING")
            e["notes"].append(f"{q} 有 {len(acts)} 則每股盈餘公告：{[a['document_id'] for a in acts]}")
            continue
        pre = [g for g in gs if g["announced_at"] < cutoff]
        if not gs:
            e["status"] = "MISSING_GUIDANCE"
            continue
        if not pre:
            e["status"] = "GUIDANCE_AFTER_CUTOFF"
            continue
        g = max(pre, key=lambda x: x["announced_at"])
        if len(pre) > 1:
            e["notes"].append(f"同一季有 {len(pre)} 則展望，採用截止點前最後一則：{g['document_id']}")
        e["guidance"] = dict(g["guidance"], document_id=g["document_id"], announced_at=g["announced_at"].isoformat(),
                             issued_with_results_of=g["reported_quarter"], response_sha256=g["response_sha256"])
        # 展望發布後、截止點前：主旨像是更新展望的公告 → 待人工確認
        updates = [it for it in items if g["announced_at"] < it.announced_at < cutoff
                   and any(w in it.subject for w in UPDATE_SUBJECT_WORDS)]
        if updates:
            e["status"] = "REVIEW_PENDING"
            e["notes"].append("財測發布後、截止點前有主旨提到展望的公告，需人工確認是否更新財測："
                              + str([it.document_id for it in updates]))
            continue
        if not acts:
            e["status"] = "MISSING_ACTUAL"
            continue
        a = acts[0]
        e["actual"] = dict(a["actual"], document_id=a["document_id"], announced_at=a["announced_at"].isoformat(),
                           response_sha256=a["response_sha256"])
        e["verdicts"] = {k: _verdict(a["actual"][k], g["guidance"][k])
                         for k in ("revenue_usd_bn", "gross_margin_pct", "operating_margin_pct")}
        e["status"] = "VERIFIED"
    n = sum(1 for e in out.values() if e["status"] == "VERIFIED")
    gate = {"mode": "official_guidance", "label": "Gate5B 官方財測模式（Python 預驗證，非正式 Gate PASS）",
            "verified_quarters": n, "min_quarters": MIN_QUARTERS,
            "result": "PRE_VERIFIED" if n >= MIN_QUARTERS else "INSUFFICIENT",
            "meaning": "比較的是公司自己在上一季公布的財測，不是市場共識"}
    return {"version": GUIDANCE_MODE_VERSION, "quarters": out, "gate": gate, "parse_failures": parse_failures}


VERDICT_TEXT = {"ABOVE": "高於", "WITHIN": "區間內", "BELOW": "低於"}


def markdown(g):
    lines = ["", f"### {g['gate']['label']}", "",
             f"已驗證 {g['gate']['verified_quarters']}/{len(g['quarters'])} 季（門檻 {g['gate']['min_quarters']}）："
             f"{g['gate']['result']}。{g['gate']['meaning']}。", "",
             "| 季度 | 狀態 | 財測營收（十億美元） | 實際 | 毛利率財測 | 實際 | 營益率財測 | 實際 |",
             "|---|---|---|---|---|---|---|---|"]
    for q, e in g["quarters"].items():
        if e["status"] != "VERIFIED":
            lines.append(f"| {q} | {e['status']} | | | | | | |")
            continue
        gd, a, v = e["guidance"], e["actual"], e["verdicts"]
        lines.append(
            f"| {q} | 已驗證 | {gd['revenue_usd_bn'][0]:g}–{gd['revenue_usd_bn'][1]:g} | {a['revenue_usd_bn']:g}"
            f"（{VERDICT_TEXT[v['revenue_usd_bn']]}） | {gd['gross_margin_pct'][0]:g}–{gd['gross_margin_pct'][1]:g}% | "
            f"{a['gross_margin_pct']:g}%（{VERDICT_TEXT[v['gross_margin_pct']]}） | "
            f"{gd['operating_margin_pct'][0]:g}–{gd['operating_margin_pct'][1]:g}% | "
            f"{a['operating_margin_pct']:g}%（{VERDICT_TEXT[v['operating_margin_pct']]}） |")
    for f in g["parse_failures"]:
        lines.append(f"\n- 未採用 {f['document_id']}：{f['reason']}")
    return "\n".join(lines)
