"""
test_guidance_mops.py (v4.18)
=============================
Gate5B 官方財測模式：用 gate-probe run 39114411258 的真實官方詳細頁（contract/mops_real/run_39114411258）測試。
  - 每股盈餘公告的實際結果與下一季財測解析（含「美金」「188億7千萬」「467.2億」等真實寫法）
  - 11 季都由「上一季公告的財測」對「這一季公告的實際結果」，且財測早於官方截止點
  - 財測晚於截止點、缺財測公告、截止點前有疑似更新展望的公告、季度只有暫定截止點 → 都不算已驗證
  - 解析失敗（區間顛倒、目標季度不對、欄位缺漏）→ 不採用該部分
  - 原始回應被改動 → 雜湊不符 → 該則不採用

  python test_guidance_mops.py
"""
import dataclasses
import json
import os
import shutil
import sys
import tempfile
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import guidance_mops as gm  # noqa: E402
from mops_t05st01 import parse_t05st01_detail, parse_t05st01_listing  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_39114411258")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))


def _load():
    m = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
    listings = {}
    for r in m["requests"]:
        if r["kind"] == "t05st01_listing" and r["response_file"]:
            lst, _ = parse_t05st01_listing(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                           r["request_url"], "2330", r["params"]["roc_year"], "", r["response_sha256"])
            if lst:
                listings[int(r["params"]["roc_year"])] = lst
    ml = list(ce._merge_runs(listings).values())[0]
    by = {it.document_id: it for it in ml.items}
    details = {}
    for r in m["requests"]:
        if r["kind"] == "t05st01_detail" and r.get("parsed"):
            it = by[r["params"]["document_id"]]
            d, _ = parse_t05st01_detail(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                        r["request_url"], it, r["response_sha256"])
            if d:
                details[it.document_id] = d
    s = ce.replay(RUN, REVIEWS)
    cut = {q: datetime.fromisoformat(v["earliest"]["at"]) for q, v in s["quarters"].items()
           if v["status"] == "CUTOFF_VERIFIED"}
    return ml.items, details, cut


ITEMS, DETAILS, CUT = _load()
JAN24 = "t05st01:2330:20240118:154253:1"
OCT26 = "t05st01:2330:20261015:152138:1"


def test_parse_real_announcements():
    p, f = gm.parse_eps_announcement(DETAILS[JAN24].description)   # 「若以美金計算」、「今（18）公佈」
    assert not f and p["reported_quarter"] == "2023Q4"
    assert p["actual"] == {"revenue_usd_bn": 19.62, "gross_margin_pct": 53.0, "operating_margin_pct": 41.6,
                           "eps_twd": 9.21, "eps_adr_usd": 1.44}, p["actual"]
    assert p["guidance"] == {"target_quarter": "2024Q1", "revenue_usd_bn": [18.0, 18.8], "gross_margin_pct": [52.0, 54.0],
                             "operating_margin_pct": [40.0, 42.0], "fx_twd_per_usd": 31.1}, p["guidance"]
    p, f = gm.parse_eps_announcement(DETAILS[OCT26].description)   # 「營收為467.2億」
    assert p["reported_quarter"] == "2026Q3" and p["actual"]["revenue_usd_bn"] == 46.72
    assert p["actual"]["eps_twd"] == 29.43 and p["actual"]["eps_adr_usd"] == 4.60
    assert p["guidance"]["target_quarter"] == "2026Q4" and p["guidance"]["revenue_usd_bn"] == [52.3, 54.3]


def test_all_eleven_quarters_from_official_evidence():
    g = gm.evaluate_guidance(ITEMS, DETAILS, CUT)
    assert g["gate"]["verified_quarters"] == 11 and g["gate"]["result"] == "PRE_VERIFIED", g["gate"]
    assert g["parse_failures"] == [], g["parse_failures"]
    q1 = g["quarters"]["2024Q1"]
    assert q1["guidance"]["document_id"] == JAN24 and q1["guidance"]["issued_with_results_of"] == "2023Q4"
    assert q1["actual"]["revenue_usd_bn"] == 18.87 and q1["verdicts"] == {
        "revenue_usd_bn": "ABOVE", "gross_margin_pct": "WITHIN", "operating_margin_pct": "WITHIN"}
    for q, e in g["quarters"].items():
        assert e["status"] == "VERIFIED", (q, e)
        assert datetime.fromisoformat(e["guidance"]["announced_at"]) < CUT[q], q   # 財測早於截止點
        assert e["guidance"]["target_quarter"] == q and gm.next_quarter(e["guidance"]["issued_with_results_of"]) == q
        assert datetime.fromisoformat(e["actual"]["announced_at"]) > CUT[q], q   # 實際結果在截止點之後才公布
    q3 = g["quarters"]["2026Q3"]["verdicts"]
    assert q3 == {"revenue_usd_bn": "ABOVE", "gross_margin_pct": "WITHIN", "operating_margin_pct": "ABOVE"}, q3
    md = gm.markdown(g)
    assert "不是市場共識" in md and "| 2024Q1 | 已驗證 | 18–18.8 | 18.87（高於）" in md, md


def test_guidance_after_cutoff_is_rejected():
    cut = dict(CUT, **{"2024Q1": datetime.fromisoformat("2024-01-18T15:00:00+08:00")})   # 財測 15:42 才發布
    g = gm.evaluate_guidance(ITEMS, DETAILS, cut)
    assert g["quarters"]["2024Q1"]["status"] == "GUIDANCE_AFTER_CUTOFF"
    assert g["gate"]["verified_quarters"] == 10


def test_missing_guidance_announcement():
    d = {k: v for k, v in DETAILS.items() if k != JAN24}
    g = gm.evaluate_guidance(ITEMS, d, CUT)
    assert g["quarters"]["2024Q1"]["status"] == "MISSING_GUIDANCE"
    assert {"document_id": JAN24, "reason": "詳細頁未取得"} in g["parse_failures"]


def test_possible_guidance_update_needs_review():
    base = [it for it in ITEMS if it.document_id == JAN24][0]
    fake = dataclasses.replace(base, subject="台積公司更新2024年第一季業績展望",
                               announced_at=datetime.fromisoformat("2024-03-01T17:00:00+08:00"),
                               document_id="t05st01:2330:20240301:170000:9")
    g = gm.evaluate_guidance(ITEMS + [fake], DETAILS, CUT,
                             eps_items=[it for it in ITEMS if it.document_id in DETAILS
                                        and "每股盈餘" in it.subject])
    e = g["quarters"]["2024Q1"]
    assert e["status"] == "REVIEW_PENDING" and "20240301:170000:9" in e["notes"][0], e
    assert g["quarters"]["2024Q2"]["status"] == "VERIFIED"


def test_malformed_texts_are_not_used():
    good = DETAILS[JAN24].description
    p, _ = gm.parse_eps_announcement(good.replace("180億美元到188億美元", "188億美元到180億美元"))
    assert p["guidance"] is None and "下緣大於上緣" in p["guidance_failures"][0]
    p, _ = gm.parse_eps_announcement(good.replace("2024年第一季的業績展望", "2024年第二季的業績展望"))
    assert p["guidance"] is None and "不是下一季" in p["guidance_failures"][0]
    p, _ = gm.parse_eps_announcement(good.replace("毛利率預計介於52%到54%之間", "毛利率另行公布"))
    assert p["guidance"] is None and "解析不完整" in p["guidance_failures"][0]
    p, _ = gm.parse_eps_announcement(good.replace("營業利益率為41.6%", "營業利益率另計"))
    assert p["actual"] is None and p["guidance"] is not None        # 實際結果缺欄位不影響財測
    p, f = gm.parse_eps_announcement("本公司今日召開董事會")
    assert p is None and f


def test_only_verified_cutoffs_are_used_and_gate_threshold():
    partial = {k: v for k, v in REVIEWS.items() if k != ("2330", "2024Q3")}
    s = ce.replay(RUN, partial)
    g = s["guidance"]
    assert "2024Q3" not in g["quarters"] and g["provisional_quarters_excluded"] == ["2024Q3"]
    assert g["gate"]["verified_quarters"] == 10
    few = {q: CUT[q] for q in sorted(CUT)[:7]}
    g = gm.evaluate_guidance(ITEMS, DETAILS, few)
    assert g["gate"]["verified_quarters"] == 7 and g["gate"]["result"] == "INSUFFICIENT"


def test_tampered_guidance_response_is_rejected():
    m = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
    rec = [r for r in m["requests"] if r["kind"] == "t05st01_detail" and r["params"]["document_id"] == JAN24
           and r.get("parsed")][0]
    tmp = tempfile.mkdtemp(prefix="guidance_tamper_")
    try:
        dst = os.path.join(tmp, "run")
        shutil.copytree(RUN, dst)
        path = os.path.join(dst, rec["response_file"])
        data = open(path, "rb").read()
        open(path, "wb").write(data.replace("180億美元".encode(), "170億美元".encode()))
        s = ce.replay(dst, REVIEWS)
        assert s["guidance"]["quarters"]["2024Q1"]["status"] == "MISSING_GUIDANCE", s["guidance"]["quarters"]["2024Q1"]
        assert s["guidance"]["gate"]["verified_quarters"] == 10
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
