"""
ops/collect_evidence.py (v4.15)
===============================
一鍵蒐證：輸入股票代號與民國年度，自動向官方網站取得 Gate5B 截止點需要的三層證據，
保存所有請求與回應的原始位元組，並用正式解析器算出各季截止點。只讀官方網站、只產生檔案，
不改任何 Gate 判定；只用標準函式庫。設計給 GitHub Actions 執行（.github/workflows/gate-pipeline-collect.yml）。

  python gate_pipeline/ops/collect_evidence.py --co-id 2330 --roc-years 113,114,115 --out results/2330/<run_id>

流程（每一步的原始回應都存檔並記 SHA-256，失敗也照實記錄，不中斷其他步驟）：
  1. 每個年度：重大訊息全年清單（mopsov ajax_t05st01，step=1）
  2. 用 mops_t05st01 解析；連續年度合併成一份（第四季的公告在隔年初）
  3. 詳細頁（step=2）：
       - 被分類為財務結果事件的公告（EPS、董事會通過財報、法說會、季末月營收）
       - 季末到「清單層級最早事件的隔天」之間未分類的公告（供人工審查時看原文）
  4. 每個年度：財務報告書申報清單（doc.twse.com.tw t57sb01，seamon 留空，mtype=A）
  5. 每一季：mops_t05st01.cutoff_candidates 計算截止點（含人工審查紀錄與使用者核准的條款自動排除規則，如有）
  6. （v4.18）Gate5B 官方財測模式：從每股盈餘公告詳細頁解析財測與實際結果（guidance_mops.py）；
     v4.19 起另抓「財測發布到截止點之間的每一則公告」原文，逐則檢查有沒有更新財測
  7. （v4.17，v4.19 起預設不做，加 --consensus-discovery 才執行）共識預估來源探測：ops/consensus_discovery.py 查 Wayback 封存索引，看各候選網站在各季截止點之前
     有沒有存檔，並抽樣取回少數原文。只做探測、不產生共識值；失敗不影響前面的結果（照實記錄在 notes）。
重試（v4.15）：連線逾時／中斷、HTTP 429/5xx、官方回「查詢過量」時，依 --retry-waits 等待後重試（預設 10、30 秒，
  最多 3 次）。每一次嘗試都各自記在 manifest（attempt 編號、狀態、錯誤、回應雜湊），不會覆蓋前一次的回應；
  只有最後一次成功解析的回應被採用。官方「查無所需資料」、格式不符、其他 4xx 不重試（重試不會改變結果）。
沿用（v4.19）：同一個結果資料夾（results/<代號>/）裡先前各次蒐證已取得的詳細頁原文會直接沿用
（雜湊核對、正式解析器重新核對、複製進這次的資料夾並註明 cached_from），只向官方網站抓還沒有的；
每次新抓上限 --max-details 則，超過的留待下次。清單與財報申報清單每次都重新取得。
輸出：
  <out>/requests/*.bin、<out>/responses/*.bin   原始位元組
  <out>/manifest.json                            每一個請求的網址、參數、取得時間、雜湊、Content-Type
  <out>/summary.json                             各季截止點、阻擋原因、待人工審查的公告
每次請求之間預設停 3 秒；詳細頁總數有上限，避免對官方網站造成負擔。
"""

import argparse
import hashlib
import json
import os
import re
import sys
import time
from datetime import date, datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))

import announcement_probe as ap  # noqa: E402
import network_probe as npb  # noqa: E402
from mops_t05st01 import (TPE, classify, cutoff_candidates, is_forecast_announcement, merge_listings,  # noqa: E402
                          parse_t05st01_detail, parse_t05st01_listing)
from mops_t57sb01 import parse_t57sb01_listing  # noqa: E402

COLLECTOR_VERSION = "4.26-collect"
DEFAULT_DOC_BASE = "https://doc.twse.com.tw"
DEFAULT_RETRY_WAITS = (10.0, 30.0)
DEFAULT_RETRY_BUDGET = 25   # 整次蒐證最多重試幾次：官方網站整體異常時不要拖到工作逾時（逾時會連已取得的結果都存不了）
RETRY_STATUS = {429, 500, 502, 503, 504}
RETRY_FAILURE_CODES = {"ANNOUNCEMENT_SOURCE_REFUSED"}


def _retryable(entry, fails):
    """暫時性錯誤才重試：連線錯誤／逾時、429/5xx、官方回「查詢過量」。"""
    if entry.get("error"):
        return True
    if entry.get("status") in RETRY_STATUS:
        return True
    return any(f[0] in RETRY_FAILURE_CODES for f in fails)


def _read(out_dir, rel):
    return open(os.path.join(out_dir, rel), "rb").read() if rel else b""


def _ct(hop):
    return (hop.get("response_headers") or {}).get("Content-Type", "")


def _record(manifest, kind, entry, params, url=None):
    hop = entry.get("hop") or (entry.get("hops") or [{}])[-1]
    rec = {"kind": kind, "params": params, "request_url": url or hop.get("url") or entry.get("url"),
           "status": entry.get("status"), "error": entry.get("error"),
           "retrieved_at": hop.get("started_at"), "content_type": _ct(hop),
           "response_file": entry.get("saved_as"), "response_sha256": entry.get("body_sha256"),
           "response_length": entry.get("content_length"),
           "request_body_file": entry.get("request_body_saved_as"),
           "request_body_sha256": entry.get("request_body_sha256"),
           "peer_address": hop.get("peer_address"), "cert_sha256": (hop.get("tls") or {}).get("cert_sha256")}
    manifest["requests"].append(rec)
    return rec


def _quarters(first_roc_year, last_roc_year, today):
    out = []
    for y in range(first_roc_year + 1911, last_roc_year + 1911 + 1):
        for q in range(1, 5):
            q_end = date(y + (q == 4), (3 * q) % 12 + 1, 1)
            if q_end <= today:   # 季度已結束才有財報
                out.append(f"{y}Q{q}")
    return out


def _fmt_event(e):
    return {"event_type": e["event_type"], "at": e["at"].isoformat(), "precision": e["precision"],
            "document_id": e["document_id"], "detail_verified": e["detail_verified"], "subject": e.get("subject")}


def _detail_cache(cache_dir, out_dir):
    """（v4.19）先前各次蒐證已取得的詳細頁原文：{document_id: {"run", "dir", "rec"}}。
    重大訊息發布後內容不變，沿用當時取得的官方原始回應（保留原取得時間與雜湊），不必重抓。
    只收 manifest 記錄解析成功、且檔案雜湊與 manifest 一致的；同一則有多份時用最早取得的。"""
    out = {}
    if not cache_dir or not os.path.isdir(cache_dir):
        return out
    here = os.path.abspath(out_dir)
    for name in sorted(os.listdir(cache_dir)):
        run_dir = os.path.join(cache_dir, name)
        mf = os.path.join(run_dir, "manifest.json")
        if os.path.abspath(run_dir) == here or not os.path.isfile(mf):
            continue
        try:
            m = json.load(open(mf, encoding="utf-8"))
        except ValueError:
            continue
        for rec in m.get("requests", []):
            if rec.get("kind") != "t05st01_detail" or not rec.get("response_file") or rec.get("status") != 200:
                continue
            if rec.get("parsed") is False or rec.get("cached_from"):
                continue
            doc = (rec.get("params") or {}).get("document_id")
            if doc and (doc not in out or (rec.get("retrieved_at") or "") < (out[doc]["rec"].get("retrieved_at") or "")):
                out[doc] = {"run": name, "dir": run_dir, "rec": rec}
    return out


def _use_cached_detail(hit, it, out_dir, manifest):
    """把快取的原始回應複製進這次的結果資料夾（讓每次結果自成一份完整證據），並用正式解析器重新核對。"""
    rec = hit["rec"]
    try:
        data = open(os.path.join(hit["dir"], rec["response_file"]), "rb").read()
    except OSError:
        return None
    if hashlib.sha256(data).hexdigest() != rec.get("response_sha256"):
        return None
    d, fails = parse_t05st01_detail(data, rec["content_type"], rec["request_url"], it, rec["response_sha256"])
    if d is None:
        return None
    folder = os.path.join(out_dir, "responses")
    os.makedirs(folder, exist_ok=True)
    fname = f"responses/cached_{rec['response_sha256'][:16]}.bin"
    with open(os.path.join(out_dir, fname), "wb") as f:
        f.write(data)
    manifest["requests"].append({
        "kind": "t05st01_detail", "params": rec["params"], "request_url": rec["request_url"], "status": rec["status"],
        "error": None, "retrieved_at": rec["retrieved_at"], "content_type": rec["content_type"],
        "response_file": fname, "response_sha256": rec["response_sha256"], "response_length": len(data),
        "request_body_file": None, "request_body_sha256": rec.get("request_body_sha256"),
        "peer_address": rec.get("peer_address"), "cert_sha256": rec.get("cert_sha256"),
        "attempt": 0, "parsed": True, "parse_failures": [],
        "cached_from": f"{hit['run']}/{rec['response_file']}"})
    return d


def collect(co_id, roc_years, out_dir, mops_base=ap.DEFAULT_MOPS_BASE, doc_base=DEFAULT_DOC_BASE, delay=3.0,
            timeout=30.0, max_details=300, reviews=None, today=None, retry_waits=DEFAULT_RETRY_WAITS,
            retry_budget=DEFAULT_RETRY_BUDGET, cache_dir=None):
    os.makedirs(os.path.join(out_dir, "responses"), exist_ok=True)
    retry_waits = tuple(retry_waits or ())
    manifest = {"collector_version": COLLECTOR_VERSION, "co_id": co_id, "roc_years": roc_years,
                "started_at": datetime.now(timezone.utc).isoformat(), "environment": ap.environment(),
                "mops_base": mops_base, "doc_base": doc_base, "delay_seconds": delay,
                "retry_waits_seconds": list(retry_waits), "retry_budget": retry_budget, "requests": []}
    summary = {"co_id": co_id, "roc_years": roc_years, "listings": {}, "filings": {}, "details": {},
               "quarters": {}, "notes": []}
    first = True
    budget = {"left": retry_budget}

    def pause():
        nonlocal first
        if not first:
            time.sleep(delay)
        first = False

    def fetch(kind, params, do_request, parse, url=None):
        """送出請求並解析；暫時性錯誤依 retry_waits 重試。每次嘗試都記錄在 manifest。"""
        for n in range(len(retry_waits) + 1):
            if n == 0:
                pause()
            else:
                time.sleep(retry_waits[n - 1])
            e = do_request()
            rec = _record(manifest, kind, e, params, url)
            parsed, fails = parse(e, rec)
            rec.update(attempt=n + 1, parsed=parsed is not None,
                       parse_failures=[list(f) for f in fails] if parsed is None else [])
            if parsed is not None or n == len(retry_waits) or not _retryable(e, fails):
                return e, rec, parsed, fails, n + 1
            if budget["left"] <= 0:
                rec["retry_skipped"] = "整次蒐證的重試次數已用完"
                if "重試次數已用完" not in " ".join(summary["notes"]):
                    summary["notes"].append(f"重試次數已用完（上限 {retry_budget}），之後的暫時性錯誤不再重試")
                return e, rec, parsed, fails, n + 1
            budget["left"] -= 1

    # 1–2. 全年清單
    listings = {}
    for y in roc_years:
        e, rec, lst, fails, tries = fetch(
            "t05st01_listing", {"co_id": co_id, "roc_year": str(y), "month": ""},
            lambda: ap.query_t05st01(mops_base, co_id, str(y), "", out_dir, timeout),
            lambda e, rec: parse_t05st01_listing(_read(out_dir, e.get("saved_as")), rec["content_type"],
                                                 rec["request_url"], co_id, str(y), "", e.get("body_sha256")))
        summary["listings"][str(y)] = ({"items": len(lst.items), "sha256": lst.response_sha256,
                                        "company_name": lst.company_name, "attempts": tries} if lst else
                                       {"failures": [list(f) for f in fails], "status": e.get("status"),
                                        "error": e.get("error"), "attempts": tries})
        if lst:
            listings[y] = lst
    if not listings:
        summary["notes"].append("沒有任何年度的清單可以解析，停止後續步驟")
        return manifest, summary

    merged = _merge_runs(listings)
    company = next(iter(listings.values())).company_name

    # 3. 詳細頁（優先順序：1 財務結果事件 → 2 季末到最早事件的待審公告 → 3 財測發布到截止點之間的每一則公告）
    today = today or datetime.now(TPE).date()
    wanted = {}   # document_id -> (優先順序, item)

    def want(it, tier):
        if it.document_id not in wanted or wanted[it.document_id][0] > tier:
            wanted[it.document_id] = (tier, it)

    for (yrs, ml) in merged.items():
        eps_at = {}
        for it in ml.items:
            ev = classify(it)
            if ev or is_forecast_announcement(it):   # v4.22：財務預測公告也抓原文（官方財測模式日後解析）
                want(it, 1)
            for x in ev:
                if x["event_type"] == "self_reported_results":
                    eps_at[x["fiscal_quarter"]] = it.announced_at
        for q in _quarters(yrs[0], yrs[-1], today):
            cc = cutoff_candidates(ml, q)
            if cc["earliest"] is None:
                continue
            m = re.fullmatch(r"(\d{4})Q([1-4])", q)
            qn = int(m.group(2))
            q_end_next = date(int(m.group(1)) + (qn == 4), (3 * qn) % 12 + 1, 1)
            lo = datetime(q_end_next.year, q_end_next.month, q_end_next.day, tzinfo=TPE)
            hi = datetime.combine(cc["earliest"]["at"].date(), datetime.max.time(), tzinfo=TPE)
            for it in ml.items:
                if lo <= it.announced_at <= hi and not classify(it):
                    want(it, 2)
            prev = f"{int(m.group(1)) - (qn == 1)}Q{(qn - 2) % 4 + 1}"
            if prev in eps_at:   # 官方財測模式：上一季財報公告（財測發布）到這一季截止點之間的每一則
                for it in ml.items:
                    if eps_at[prev] < it.announced_at <= hi:
                        want(it, 3)
    items = [it for _, it in sorted(wanted.values(), key=lambda x: (x[0], x[1].announced_at))]
    cache = _detail_cache(cache_dir, out_dir) if cache_dir else {}
    details, fetched, from_cache, skipped = {}, 0, 0, []
    for it in items:
        hit = cache.get(it.document_id)
        if hit is not None:
            d = _use_cached_detail(hit, it, out_dir, manifest)
            if d is not None:
                details[it.document_id] = d
                from_cache += 1
                summary["details"][it.document_id] = {"ok": True, "clause": d.clause, "fact_date": d.fact_date.isoformat(),
                                                      "attempts": 0, "cached_from": hit["run"]}
                continue
        if fetched >= max_details:
            skipped.append(it.document_id)
            continue
        fetched += 1
        p = dict(it.detail_params)
        e, rec, d, fails, tries = fetch(
            "t05st01_detail", {"document_id": it.document_id, "spoke_date": p["spoke_date"],
                               "spoke_time": p["spoke_time"], "seq_no": p["seq_no"]},
            lambda: ap.query_t05st01_detail(mops_base, co_id, it.typek, str(it.announced_at.year - 1911), "all",
                                            p["spoke_date"], p["spoke_time"], p["seq_no"], out_dir, timeout),
            lambda e, rec: parse_t05st01_detail(_read(out_dir, e.get("saved_as")), rec["content_type"],
                                                rec["request_url"], it, e.get("body_sha256")))
        if d:
            details[it.document_id] = d
            summary["details"][it.document_id] = {"ok": True, "clause": d.clause, "fact_date": d.fact_date.isoformat(),
                                                  "attempts": tries}
        else:
            summary["details"][it.document_id] = {"ok": False, "failures": [list(f) for f in fails],
                                                  "status": e.get("status"), "error": e.get("error"),
                                                  "attempts": tries}
    summary["detail_counts"] = {"wanted": len(items), "fetched": fetched, "from_cache": from_cache,
                                "skipped_over_limit": len(skipped)}
    if skipped:
        summary["notes"].append(f"本次向官方網站新抓的詳細頁已達上限 {max_details} 則，另有 {len(skipped)} 則留待下次執行"
                                f"（下次會沿用本次已取得的原文，只抓剩下的）")

    # 4. 財報申報清單
    filings = []
    for y in roc_years:
        url = (f"{doc_base.rstrip('/')}/server-java/t57sb01?step=1&colorchg=1&co_id={co_id}"
               f"&year={y}&seamon=&mtype=A&")

        def parse_filings(e, rec, y=y, url=url):
            retrieved = datetime.fromisoformat(rec["retrieved_at"]) if rec.get("retrieved_at") else None
            return parse_t57sb01_listing(_read(out_dir, e.get("saved_as")), rec["content_type"], url, co_id, str(y),
                                         company, retrieved, e.get("body_sha256"))
        e, rec, fl, fails, tries = fetch("t57sb01_list", {"co_id": co_id, "roc_year": str(y)},
                                         lambda: npb.probe_url(url, out_dir, timeout), parse_filings, url=url)
        summary["filings"][str(y)] = ({"rows": [[r.fiscal_quarter, r.filename, r.uploaded_at.isoformat()] for r in fl.rows],
                                       "uncertain": fl.uncertain,
                                       "sha256": fl.response_sha256, "attempts": tries} if fl else
                                      {"failures": [list(f) for f in fails], "status": e.get("status"),
                                       "error": e.get("error"), "attempts": tries})
        if fl:
            filings.append(fl)

    # 5. 各季截止點
    _evaluate_quarters(co_id, merged, details, filings, reviews, today, summary)
    _evaluate_guidance(co_id, merged, details, summary, reviews)
    _recognition_report(merged, summary)
    manifest["finished_at"] = datetime.now(timezone.utc).isoformat()
    return manifest, summary


def _merge_runs(listings):
    """連續年度的清單合併成一份（第四季的公告在隔年初）。{(年, ...): 合併清單}"""
    runs, cur = [], []
    for y in sorted(listings):
        if cur and y != cur[-1] + 1:
            runs.append(cur)
            cur = []
        cur.append(y)
    runs.append(cur)
    return {tuple(r): merge_listings([listings[y] for y in r]) for r in runs}


def _evaluate_quarters(co_id, merged, details, filings, reviews, today, summary):
    reviews = reviews or {}
    policy = reviews.get("__clause_policy__")
    clauses = {str(c) for c in policy["clauses"]} if policy else set()
    summary["clause_policy"] = ({"clauses": sorted(clauses), "reviewer": policy.get("reviewer"),
                                 "decided_at": policy.get("decided_at")} if policy else None)
    for (yrs, ml) in merged.items():
        for q in _quarters(yrs[0], yrs[-1], today):
            rv = reviews.get((co_id, q))
            # 只採用屬於這家公司的公告識別碼（防止審查紀錄被誤放到別家公司的檔名或欄位）
            reviewed = {r["document_id"] for r in rv["reviewed_non_results"]
                        if r["document_id"].startswith(f"t05st01:{co_id}:")} if rv else set()
            cc = cutoff_candidates(ml, q, details=details, filings=filings, reviewed_non_results=reviewed,
                                   auto_clear_clauses=clauses)
            summary["quarters"][q] = {
                "status": cc["status"], "earliest": _fmt_event(cc["earliest"]) if cc["earliest"] else None,
                "blocking": cc["blocking"], "events": [_fmt_event(e) for e in cc["events"]],
                "review_window": [{"document_id": r["document_id"], "announced_at": r["announced_at"].isoformat(),
                                   "subject": r["subject"], "clause": r["clause"], "cleared_by": r["cleared_by"]}
                                  for r in cc["review_window"]],
                "financial_report_status": cc["financial_report_status"],
                "uncertain_filings": cc.get("uncertain_filings", []),
                "snapshot_boundary": ({"at": cc["snapshot_boundary"]["at"].isoformat(), "rule": cc["snapshot_boundary"]["rule"],
                                       "note": cc["snapshot_boundary"]["note"]} if cc.get("snapshot_boundary") else None),
                "review_record": bool(rv)}


def _recognition_report(merged, summary):
    """（v4.21）跨標的稽核：這家公司的重大訊息中，解析器認得哪些財務事件。換股票時一眼看出哪些管道不支援。"""
    from collections import Counter
    c = Counter()
    for ml in merged.values():
        for it in ml.items:
            for e in classify(it):
                c[e["event_type"]] += 1
    for ml in merged.values():
        for it in ml.items:
            if is_forecast_announcement(it):
                c["financial_forecast"] += 1
    g = summary.get("guidance") or {}
    rep = {"events_recognized": dict(c),
           "guidance_quarters_parsed": sum(1 for e in (g.get("quarters") or {}).values() if e.get("guidance")),
           "notes": []}
    names = {"quarter_revenue_complete": "季末月營收公告", "self_reported_results": "每股盈餘公告",
             "board_approved_financials": "董事會通過財報", "investor_conference": "法說會通知"}
    for k, v in names.items():
        if not c.get(k):
            rep["notes"].append(f"重大訊息中沒有認得的「{v}」（可能是公司不用重大訊息公告，或寫法與已支援的格式不同）")
    if not rep["guidance_quarters_parsed"]:
        rep["notes"].append("官方財測模式：沒有解析到任何一季的財測（目前只支援台積電每股盈餘公告的寫法）")
    summary["recognition"] = rep


def _evaluate_guidance(co_id, merged, details, summary, reviews=None):
    """（v4.18／v4.19）Gate5B 官方財測模式：只用已驗證的截止點；結果放在 summary["guidance"]，
    另附 gates.eval_gate5b_official_guidance 的判定（與市場共識模式分開）。"""
    import guidance_mops as gm
    from gates import eval_gate5b_official_guidance
    cut = {q: datetime.fromisoformat(v["earliest"]["at"]) for q, v in summary["quarters"].items()
           if v["status"] == "CUTOFF_VERIFIED" and v.get("earliest")}
    items = [it for ml in merged.values() for it in ml.items]
    greviews = {q: ids for (c, q), ids in ((reviews or {}).get("__guidance_reviews__") or {}).items() if c == co_id}
    gupdates = {q: ids for (c, q), ids in ((reviews or {}).get("__guidance_updates__") or {}).items() if c == co_id}
    g = gm.evaluate_guidance(items, details, cut, guidance_reviews=greviews, guidance_updates=gupdates)
    gr = eval_gate5b_official_guidance(g)
    g["gate_result"] = {"gate_name": gr.gate_name, "status": gr.status, "reasons": gr.reasons,
                        "reject_codes": gr.reject_codes, "raw_count": gr.raw_count, "evidence_count": gr.evidence_count}
    g["provisional_quarters_excluded"] = sorted(q for q, v in summary["quarters"].items()
                                                if v["status"] != "CUTOFF_VERIFIED")
    summary["guidance"] = g


def replay(out_dir, reviews=None, today=None):
    """離線重算：用某次蒐證存下的原始回應（manifest.json + responses/）重新解析並計算各季截止點，
    不連任何網站。用途：新增人工審查紀錄或規則後重新評估、獨立複驗。
    每個回應都用正式解析器重新解析並比對 manifest 記錄的 SHA-256；同一請求有多次嘗試時採用最後一次解析成功的。
    today 預設為該次蒐證的開始日期（台北時間），讓「哪些季度已結束」與當時一致。"""
    manifest = json.load(open(os.path.join(out_dir, "manifest.json"), encoding="utf-8"))
    co_id = manifest["co_id"]
    summary = {"co_id": co_id, "roc_years": manifest["roc_years"], "listings": {}, "filings": {}, "details": {},
               "quarters": {}, "notes": [], "replayed_from": {"collector_version": manifest.get("collector_version"),
                                                              "started_at": manifest.get("started_at")}}
    reqs = manifest["requests"]
    listings = {}
    for rec in reqs:
        if rec["kind"] != "t05st01_listing":
            continue
        y = rec["params"]["roc_year"]
        if not rec.get("response_file"):
            summary["listings"].setdefault(y, {"failures": [["NO_RESPONSE", rec.get("error") or rec.get("status")]]})
            continue
        lst, fails = parse_t05st01_listing(_read(out_dir, rec["response_file"]), rec["content_type"],
                                           rec["request_url"], co_id, y, "", rec["response_sha256"])
        if lst:
            listings[int(y)] = lst
            summary["listings"][y] = {"items": len(lst.items), "sha256": lst.response_sha256}
        elif int(y) not in listings:
            summary["listings"][y] = {"failures": [list(f) for f in fails], "status": rec.get("status")}
    if not listings:
        summary["notes"].append("沒有任何年度的清單可以解析")
        return summary
    merged = _merge_runs(listings)
    company = next(iter(listings.values())).company_name
    by_id = {it.document_id: it for ml in merged.values() for it in ml.items}
    details = {}
    for rec in reqs:
        if rec["kind"] != "t05st01_detail":
            continue
        doc = rec["params"].get("document_id")
        it = by_id.get(doc)
        if it is None:
            summary["details"][doc] = {"ok": False, "failures": [["ANNOUNCEMENT_DOCUMENT_NOT_LISTED", "不在已解析的清單中"]]}
            continue
        if not rec.get("response_file"):
            summary["details"].setdefault(doc, {"ok": False, "error": rec.get("error"), "status": rec.get("status")})
            continue
        d, fails = parse_t05st01_detail(_read(out_dir, rec["response_file"]), rec["content_type"], rec["request_url"],
                                        it, rec["response_sha256"])
        if d:
            details[doc] = d
            summary["details"][doc] = {"ok": True, "clause": d.clause, "fact_date": d.fact_date.isoformat()}
        elif doc not in details:
            summary["details"][doc] = {"ok": False, "failures": [list(f) for f in fails]}
    filings = {}
    for rec in reqs:
        if rec["kind"] != "t57sb01_list" or not rec.get("response_file"):
            continue
        y = rec["params"]["roc_year"]
        retrieved = datetime.fromisoformat(rec["retrieved_at"]) if rec.get("retrieved_at") else None
        fl, fails = parse_t57sb01_listing(_read(out_dir, rec["response_file"]), rec["content_type"], rec["request_url"],
                                          co_id, y, company, retrieved, rec["response_sha256"])
        if fl:
            filings[y] = fl
            summary["filings"][y] = {"rows": [[r.fiscal_quarter, r.filename, r.uploaded_at.isoformat()]
                                              for r in fl.rows], "uncertain": fl.uncertain, "sha256": fl.response_sha256}
        elif y not in filings:
            summary["filings"][y] = {"failures": [list(f) for f in fails]}
    if today is None:
        today = datetime.fromisoformat(manifest["started_at"]).astimezone(TPE).date()
    _evaluate_quarters(co_id, merged, details, list(filings.values()), reviews, today, summary)
    _evaluate_guidance(co_id, merged, details, summary, reviews)
    _recognition_report(merged, summary)
    return summary


def load_reviews(path):
    """人工審查紀錄：{(co_id, 季度): 紀錄}；條款規則放在 "__clause_policy__"。缺審查人或時間的紀錄不採用。"""
    out = {}
    if path and os.path.isdir(path):
        for name in sorted(os.listdir(path)):
            if name.endswith(".json"):
                rv = json.load(open(os.path.join(path, name), encoding="utf-8"))
                if not (rv.get("reviewer") and rv.get("decided_at")):
                    continue
                if rv.get("decision") == "not_financial_results":
                    out[(rv["co_id"], rv["fiscal_quarter"])] = rv
                elif rv.get("decision") == "auto_clear_non_results_by_clause" and rv.get("clauses"):
                    out["__clause_policy__"] = rv
                elif rv.get("decision") in ("guidance_not_updated", "guidance_updated") and rv.get("co_id") \
                        and rv.get("fiscal_quarter"):
                    key = "__guidance_reviews__" if rv["decision"] == "guidance_not_updated" else "__guidance_updates__"
                    ids = {x["document_id"] for x in rv.get("reviewed", []) if x.get("document_id")}
                    out.setdefault(key, {}).setdefault((rv["co_id"], rv["fiscal_quarter"]), set()).update(ids)
    return out


def main(argv=None):
    p = argparse.ArgumentParser(description="一鍵蒐證：Gate5B 截止點需要的官方證據")
    p.add_argument("--co-id", required=True)
    p.add_argument("--roc-years", required=True, help="民國年，逗號分隔，例如 113,114,115")
    p.add_argument("--out", required=True)
    p.add_argument("--reviews", default=None, help="人工審查紀錄資料夾（*.json）")
    p.add_argument("--mops-base", default=ap.DEFAULT_MOPS_BASE)
    p.add_argument("--doc-base", default=DEFAULT_DOC_BASE)
    p.add_argument("--delay", type=float, default=3.0)
    p.add_argument("--timeout", type=float, default=30.0)
    p.add_argument("--max-details", type=int, default=300, help="本次最多向官方網站新抓幾則詳細頁（沿用的不算）")
    p.add_argument("--consensus-discovery", action="store_true",
                   help="（v4.19 起預設不做）另外執行共識預估來源探測；往後改由 gate-pipeline-archive 排程自行存檔")
    p.add_argument("--no-consensus-discovery", action="store_true", help="（相容舊參數，無作用）")
    p.add_argument("--no-cache", action="store_true", help="不沿用先前各次蒐證已取得的詳細頁原文")
    p.add_argument("--discovery-time-budget", type=float, default=1200.0, help="共識來源探測的時間上限（秒）")
    p.add_argument("--wayback-base", default="https://web.archive.org")
    p.add_argument("--retry-waits", default=",".join(f"{w:g}" for w in DEFAULT_RETRY_WAITS),
                   help="重試前等待秒數，逗號分隔（預設 10,30 = 最多 3 次嘗試）；空字串 = 不重試")
    a = p.parse_args(argv)
    if not re.fullmatch(r"\d{4,6}", a.co_id):
        p.error("股票代號必須是 4–6 位數字")
    if not re.fullmatch(r"\d{3}(,\d{3}){0,5}", a.roc_years):
        p.error("年度格式錯誤，例如 113,114,115（最多 6 個年度）")
    if not re.fullmatch(r"(\d{1,3}(\.\d+)?(,\d{1,3}(\.\d+)?){0,4})?", a.retry_waits):
        p.error("重試等待秒數格式錯誤，例如 10,30（最多 5 個）")
    waits = tuple(float(x) for x in a.retry_waits.split(",")) if a.retry_waits else ()
    years = sorted({int(x) for x in a.roc_years.split(",")})
    cache_dir = None if a.no_cache else os.path.dirname(os.path.abspath(a.out))
    manifest, summary = collect(a.co_id, years, a.out, a.mops_base, a.doc_base, a.delay, a.timeout, a.max_details,
                                load_reviews(a.reviews), retry_waits=waits, cache_dir=cache_dir)
    for name, obj in (("manifest.json", manifest), ("summary.json", summary)):
        with open(os.path.join(a.out, name), "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
    discovery_md = ""
    if a.consensus_discovery and summary["quarters"]:
        try:
            import consensus_discovery as cd
            r = cd.discover(a.co_id, cd.cutoffs_from_summary(summary), os.path.join(a.out, "consensus_discovery"),
                            base_url=a.wayback_base, delay=a.delay, time_budget=a.discovery_time_budget)
            discovery_md = cd.markdown(r)
        except Exception as e:   # 探測失敗不能讓前面已取得的官方證據存不下來
            discovery_md = f"\n- 共識來源探測發生錯誤，未完成：{type(e).__name__}: {e}"
    # 簡短摘要（給執行紀錄與 Step Summary）
    lines = [f"## 蒐證結果 {a.co_id}（民國 {a.roc_years}）", "", "| 季度 | 狀態 | 最早事件 | 時間 | 阻擋原因 |", "|---|---|---|---|---|"]
    for q, s in sorted(summary["quarters"].items()):
        e = s["earliest"] or {}
        lines.append(f"| {q} | {s['status']} | {e.get('event_type', '')} | {e.get('at', '')} | "
                     f"{'；'.join(s['blocking']).replace('|', '/')} |")
    pending = [(q, r) for q, s in sorted(summary["quarters"].items()) for r in s["review_window"]
               if r["cleared_by"] is None]
    auto = sum(1 for s in summary["quarters"].values() for r in s["review_window"] if r["cleared_by"] == "auto_clause_rule")
    retried = sum(1 for r in manifest["requests"] if r.get("attempt", 1) > 1)
    lines += ["", f"條款規則自動排除 {auto} 則；重試 {retried} 次；仍需人工確認 {len(pending)} 則"]
    if any((s.get("snapshot_boundary") or {}).get("rule") == "revenue_day_midnight" for s in summary["quarters"].values()):
        lines += ["", "共識快照界線：最早事件是月營收公告的季度，快照必須早於公告當日 00:00"
                      "（月營收申報系統上傳時間未查證；上表的公告時間不變，季度狀態不因此改變）"]
    rec = summary.get("recognition")
    if rec:
        ev = rec["events_recognized"]
        lines += ["", "認得的財務事件：" + "、".join(f"{k} {v} 則" for k, v in sorted(ev.items())) if ev else
                  "認得的財務事件：無"]
        lines += [f"- {n}" for n in rec["notes"]]
    dc = summary.get("detail_counts")
    if dc:
        lines += ["", f"詳細頁：需要 {dc['wanted']} 則；沿用先前已取得 {dc['from_cache']} 則；本次新抓 {dc['fetched']} 則；"
                      f"留待下次 {dc['skipped_over_limit']} 則"]
    if pending:
        lines += ["", "| 季度 | 公告時間 | 款 | 主旨 |", "|---|---|---|---|"]
        lines += [f"| {q} | {r['announced_at'][:16]} | {r['clause'] or '未知'} | {r['subject'].replace('|', '/')} |"
                  for q, r in pending]
    set_aside = [(q, u) for q, s in sorted(summary["quarters"].items()) for u in s.get("uncertain_filings", [])
                 if u.get("set_aside")]
    if set_aside:
        lines += ["", "財報清單中更(補)正欄位不確定、依「財報不可能早於董事會通過」不阻擋的列："]
        lines += [f"- {q} {u['filename']}（{u['detail']}）：董事會開會日 {u['board_bound'][:10]} 晚於截止點"
                  for q, u in set_aside]
    for n in summary["notes"]:
        lines.append(f"\n- {n}")
    guidance_md = ""
    if summary.get("guidance"):
        import guidance_mops as gm
        guidance_md = gm.markdown(summary["guidance"])
    text = "\n".join(lines) + guidance_md + discovery_md
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
