"""
ops/consensus_research.py (v4.25)
=================================
市場共識研究紀錄（MARKET_CONSENSUS_RESEARCH）。只記錄，不影響任何 Gate 判定（gate_impact = "none"）。

把封存原文（自行存檔 results/<代號>/archive/*/、以及探測時找到的他人 Wayback 存檔 */consensus_discovery/）
逐一核對雜湊、用 consensus_parsers 解析，再依季度整理：
  - 時點：每一筆存檔相對於該季官方截止點的位置。月營收截止點同時列出兩種時間界線：
      公告時間（重大訊息原文記載）與當日 00:00（保守界線，月營收申報系統的上傳時間尚未查證）。
      v4.26 使用者採用 00:00 界線：兩者之間的存檔標記 BEFORE_ANNOUNCEMENT_SAME_DAY，不算截止點前、不進入比較。
  - 各來源並列：平均／低／高／分析師人數。差異只記錄（spread），不選邊（choice 永遠是 None）。
  - 分析師人數各來源分開（n_analysts_by_source），不加總。
  - 不同來源數值完全相同 → IDENTICAL_VALUES：可能是同一份資料，不能當成兩個獨立確認。
  - 網站事後列出的「當時預估」（retrospective）與網站自稱的歷史（7／30／60／90 天前）另外列，不當成快照。

  python gate_pipeline/ops/consensus_research.py --co-id 2330 --results-root results/2330 --out research.json
"""

import argparse
import glob
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import consensus_parsers as cp  # noqa: E402

RESEARCH_VERSION = "4.26-consensus-research"
DATA_MODE = "MARKET_CONSENSUS_RESEARCH"
TPE = timezone(timedelta(hours=8))
DEFAULT_SOURCES = os.path.join(os.path.dirname(HERE), "contract", "consensus_sources.json")
RULES = [
    "各來源數字不同不代表其中一個錯：只記錄差異，不選一個當正確值",
    "分析師人數各來源分開記錄，不加總",
    "來源之間數值相同，不代表是獨立分析師（可能是同一份資料）",
    "每一筆都核對目標季度與期間；無法對應的不進入比較",
    "本紀錄不影響任何 Gate 判定",
]
TIMING_TEXT = {
    "BEFORE_CUTOFF": "截止點前 45 天內（也早於當日 00:00）",
    "EARLY_SNAPSHOT": "截止點前超過 45 天（太早，不比較）",
    "BEFORE_ANNOUNCEMENT_SAME_DAY": "公告當天、公告時間之前（依 00:00 界線不算截止點前）",
    "AFTER_CUTOFF": "截止點之後（不是公布前快照）",
    "BEFORE_QUARTER_END": "季度尚未結束（一定早於截止點）",
    "CUTOFF_UNKNOWN": "季度已結束，截止點尚未取得",
}


def _ts_utc(ts):
    return datetime.strptime(ts, "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)


def _sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def load_source_config(path=DEFAULT_SOURCES):
    cfg = json.load(open(path, encoding="utf-8"))
    return cfg.get("adr_map", {}), {s["id"]: s for s in cfg["sources"]}


def captures_from_archive_dir(d):
    """自行存檔（archive_consensus 產生的 archive.json）。"""
    a = json.load(open(os.path.join(d, "archive.json"), encoding="utf-8"))
    out = []
    for t in a["targets"]:
        c = t.get("capture")
        if not c:
            continue
        out.append({"source_id": t["id"], "vendor": t.get("vendor"), "origin": "self_archive",
                    "run": os.path.basename(os.path.normpath(d)), "capture_ts": c["timestamp"],
                    "file": os.path.join(d, c["file"]), "sha256": c["sha256"],
                    "digest_matched": bool(c.get("digest_matched"))})
    return out


def captures_from_discovery_dir(d):
    """探測時找到的他人 Wayback 存檔（consensus_discovery 的 discovery.json 抽樣）。"""
    r = json.load(open(os.path.join(d, "discovery.json"), encoding="utf-8"))
    out = []
    for s in r["sources"]:
        for x in s.get("samples", []):
            if not x.get("file"):
                continue
            out.append({"source_id": s["id"], "vendor": s.get("vendor"), "origin": "third_party_wayback",
                        "run": os.path.basename(os.path.dirname(os.path.normpath(d))), "capture_ts": x["timestamp"],
                        "file": os.path.join(d, x["file"]), "sha256": x["sha256"],
                        "digest_matched": bool(x.get("digest_matched"))})
    return out


def cutoffs_from_summary(summary):
    out = {}
    for q, v in summary.get("quarters", {}).items():
        e = v.get("earliest")
        if e:
            out[q] = {"at": e["at"], "event_type": e.get("event_type"), "status": v.get("status")}
    return out


def discover_inputs(results_root):
    """results/<代號>/ 底下：所有 archive/*/archive.json、*/consensus_discovery/discovery.json、最新的 summary.json。"""
    arch = sorted(os.path.dirname(p) for p in glob.glob(os.path.join(results_root, "archive", "*", "archive.json")))
    disc = sorted(os.path.dirname(p) for p in glob.glob(os.path.join(results_root, "*", "consensus_discovery",
                                                                          "discovery.json")))
    sums = []
    for p in glob.glob(os.path.join(results_root, "*", "summary.json")):
        run = os.path.basename(os.path.dirname(p))
        if run.isdigit():
            sums.append((int(run), p))
    summary = max(sums)[1] if sums else None
    return arch, disc, summary


WINDOW_DAYS = 45          # 與 consensus_discovery 相同：截止點前 45 天內的存檔才算「公布前快照」
CONTEMPORANEOUS_DAYS = 7  # 同一組比較只放存檔時間相差 7 天內的來源


def _timing(period, cap_utc, cutoffs, window_days=WINDOW_DAYS):
    """回傳 (timing, cutoff 資訊)。年度 FYyyyy 用該年第四季的截止點。"""
    m = re.fullmatch(r"(\d{4})Q([1-4])|FY(\d{4})", period)
    if not m:
        return None, None
    q = period if m.group(1) else f"{m.group(3)}Q4"
    y, qn = int(q[:4]), int(q[5])
    next_q = datetime(y + (qn == 4), (3 * qn) % 12 + 1, 1, tzinfo=TPE)
    co = cutoffs.get(q)
    cap = cap_utc.astimezone(TPE)
    if co:
        at = datetime.fromisoformat(co["at"])
        midnight = datetime(at.year, at.month, at.day, tzinfo=at.tzinfo) if co.get("event_type") == \
            "quarter_revenue_complete" else at
        info = {"quarter": q, "announced_at": co["at"], "conservative_boundary": midnight.isoformat(),
                "event_type": co.get("event_type"), "cutoff_status": co.get("status"),
                "hours_before_announcement": round((at - cap).total_seconds() / 3600, 1),
                "days_before_boundary": round((midnight - cap).total_seconds() / 86400, 1)}
        if cap < midnight - timedelta(days=window_days):
            return "EARLY_SNAPSHOT", info
        if cap < midnight:
            return "BEFORE_CUTOFF", info
        if cap < at:
            return "BEFORE_ANNOUNCEMENT_SAME_DAY", info
        return "AFTER_CUTOFF", info
    if cap < next_q:
        return "BEFORE_QUARTER_END", {"quarter": q, "quarter_ends": (next_q - timedelta(seconds=1)).isoformat(),
                                      "days_before_quarter_end": round((next_q - cap).total_seconds() / 86400, 1)}
    return "CUTOFF_UNKNOWN", {"quarter": q}


def _sig(e):
    return (e["avg"], e["low"], e["high"], e["n_analysts"])


def build(co_id, captures, cutoffs, sources_path=DEFAULT_SOURCES, now=None, cutoff_source=None):
    adr_map, cfg = load_source_config(sources_path)
    adr = adr_map.get(co_id)
    out = {"research_version": RESEARCH_VERSION, "data_mode": DATA_MODE, "gate_impact": "none", "co_id": co_id,
           "adr": adr, "generated_at": (now or datetime.now(timezone.utc)).isoformat(), "rules": RULES,
           "cutoff_source": cutoff_source,
           "boundary_rule": {"announced": "重大訊息原文記載的公告時間",
                             "conservative_midnight": "月營收公告當日 00:00（月營收申報系統上傳時間未查證時的保守界線）",
                             "status": "adopted", "decided_at": "2026-10-19T11:10:00+08:00",
                             "decided_by": "Gate Pipeline 擁有者（使用者本人），Claude 對話中選擇「採用（推薦）」",
                             "effect": "公告當日 00:00 之後的存檔不算截止點前快照；公告時間照舊保留；季度狀態不因此改變"},
           "captures": [], "periods": {}, "series": [], "excluded": []}
    parsed = []
    seen_sha = {}
    for c in sorted(captures, key=lambda c: (c["source_id"], c["capture_ts"])):
        rec = {k: c[k] for k in ("source_id", "vendor", "origin", "run", "capture_ts")}
        rec["captured_at_tpe"] = _ts_utc(c["capture_ts"]).astimezone(TPE).isoformat()
        rec["file"] = os.path.basename(c["file"])
        rec["sha256"] = c["sha256"]
        if not os.path.exists(c["file"]):
            rec.update(integrity="FILE_MISSING")
        elif _sha(c["file"]) != c["sha256"]:
            rec.update(integrity="SHA256_MISMATCH")
        elif not c["digest_matched"]:
            rec.update(integrity="ARCHIVE_DIGEST_MISMATCH")
        else:
            rec.update(integrity="OK")
        if rec["integrity"] != "OK":
            out["excluded"].append(rec)
            continue
        key = (c["source_id"], c["sha256"])
        if key in seen_sha:
            rec["same_content_as"] = seen_sha[key]
        else:
            seen_sha[key] = c["capture_ts"]
        unit = (cfg.get(c["source_id"]) or {}).get("unit")
        r = cp.parse_capture(c["source_id"], open(c["file"], "rb").read(), co_id, adr, unit)
        rec.update(parse_status=r["status"], reason=r["reason"], notes=r["notes"],
                   page_quote=(r.get("page") or {}).get("quote") or (r.get("page") or {}).get("symbol"),
                   estimates=len(r["estimates"]))
        out["captures"].append(rec)
        parsed.append((c, rec, r))

    # 每一筆預估加上時點；收集每個季度
    rows = []
    for c, rec, r in parsed:
        cap = _ts_utc(c["capture_ts"])
        for e in r["estimates"]:
            if not e["fiscal_period"]:
                continue
            timing, info = _timing(e["fiscal_period"], cap, cutoffs)
            if timing is None:
                continue
            rows.append({"source_id": c["source_id"], "vendor": c["vendor"], "origin": c["origin"],
                         "capture_ts": c["capture_ts"], "captured_at_tpe": rec["captured_at_tpe"],
                         "timing": timing, "timing_info": info, **e})
        for x in r["retrospective"]:
            if x.get("fiscal_period"):
                p = out["periods"].setdefault(x["fiscal_period"], {"groups": [], "retrospective": []})
                p["retrospective"].append({"source_id": c["source_id"], "capture_ts": c["capture_ts"], **x})

    # 各來源時間序列（同一來源、同一期間、同一指標）：標記與前一次存檔完全相同
    series = {}
    for x in rows:
        series.setdefault((x["source_id"], x["fiscal_period"], x["metric"], x["currency"], x["quote"]), []).append(x)
    for (sid, fp, metric, cur, quote), xs in sorted(series.items()):
        xs.sort(key=lambda x: x["capture_ts"])
        pts = []
        for i, x in enumerate(xs):
            pt = {"capture_ts": x["capture_ts"], "avg": x["avg"], "low": x["low"], "high": x["high"],
                  "n_analysts": x["n_analysts"], "timing": x["timing"]}
            if i and _sig(xs[i - 1]) == _sig(x):
                pt["unchanged_since"] = next(p["capture_ts"] for p in pts if (p["avg"], p["low"], p["high"],
                                                                              p["n_analysts"]) == _sig(x))
            pts.append(pt)
        if len(pts) > 1:
            out["series"].append({"source_id": sid, "fiscal_period": fp, "metric": metric, "currency": cur,
                                  "quote": quote, "points": pts})

    # 各季度比較：每個來源取「截止點前（或季度未結束）」的最新一筆；比較只在同一指標、幣別、報價代號內
    usable = ("BEFORE_CUTOFF", "BEFORE_QUARTER_END")   # EARLY_SNAPSHOT、BEFORE_ANNOUNCEMENT_SAME_DAY 只留在 series
    groups = {}
    for x in rows:
        if x["timing"] not in usable:
            continue
        gk = (x["fiscal_period"], x["metric"], x["currency"], x["quote"] if x["metric"] == "eps" else "company")
        cur = groups.setdefault(gk, {}).get(x["source_id"])
        if cur is None or x["capture_ts"] > cur["capture_ts"]:
            groups[gk][x["source_id"]] = x
    for (fp, metric, cur, quote), by_src in sorted(groups.items()):
        allents = sorted(by_src.values(), key=lambda x: x["source_id"])
        newest = max(_ts_utc(x["capture_ts"]) for x in allents)
        ents = [x for x in allents if newest - _ts_utc(x["capture_ts"]) <= timedelta(days=CONTEMPORANEOUS_DAYS)]
        older = [x for x in allents if x not in ents]
        keys = ("source_id", "vendor", "origin", "capture_ts", "captured_at_tpe", "timing", "timing_info", "period_type",
                "period_label_raw", "basis", "currency_from", "n_analysts", "avg", "low", "high", "flags")
        g = {"metric": metric, "currency": cur, "quote": quote, "choice": None, "flags": [], "notes": [],
             "entries": [{k: x[k] for k in keys} for x in ents],
             "older_entries": [{k: x[k] for k in keys} for x in older],
             "n_analysts_by_source": {x["source_id"]: x["n_analysts"] for x in ents}}
        if older:
            g["flags"].append("NOT_CONTEMPORANEOUS")
            g["notes"].append(f"{'、'.join(x['source_id'] for x in older)} 的存檔比最新一筆早超過 {CONTEMPORANEOUS_DAYS} 天，"
                              "另列，不一起比較")
        derived = [x for x in ents if "FY_ROW_IS_SUM_OF_QUARTERS" in x["flags"]]
        avgs = [x["avg"] for x in ents if x["avg"] is not None and x not in derived]
        if derived:
            g["notes"].append(f"{'、'.join(x['source_id'] for x in derived)} 的年度值是四季單一預估相加，不是年度共識，不列入差異計算")
        if len(avgs) >= 2:
            lo, hi = min(avgs), max(avgs)
            g["difference"] = {"avg_min": lo, "avg_max": hi, "spread": round(hi - lo, 6),
                               "spread_pct_of_min": round((hi - lo) / lo * 100, 2) if lo else None,
                               "sources": len(avgs), "note": "只記錄差異，不判斷哪個正確"}
        for i in range(len(ents)):
            for j in range(i + 1, len(ents)):
                if _sig(ents[i]) == _sig(ents[j]) and ents[i]["avg"] is not None:
                    same_vendor = ents[i]["vendor"] == ents[j]["vendor"]
                    g["flags"].append("IDENTICAL_VALUES")
                    g["notes"].append(f"{ents[i]['source_id']} 與 {ents[j]['source_id']} 數值與人數完全相同"
                                      + ("（同一家網站的不同頁面）" if same_vendor else "")
                                      + "：可能是同一份資料，不能當成兩個獨立確認")
        bases = {x["basis"] for x in ents}
        if len(ents) >= 2 and (len(bases) > 1 or None in bases):
            g["flags"].append("BASIS_DIFFERS_OR_UNSTATED")
            g["notes"].append("各來源的 EPS 口徑（GAAP／調整後）不同或沒寫，差異可能來自定義不同"
                              if metric == "eps" else "各來源口徑沒寫")
        if any(x["currency_from"] != "page" for x in ents):
            g["flags"].append("CURRENCY_ASSUMED")
            g["notes"].append("部分來源頁面沒寫幣別，使用設定檔假設：" +
                              "、".join(x["source_id"] for x in ents if x["currency_from"] != "page"))
        if any(x["n_analysts"] == 1 for x in ents):
            g["flags"].append("SINGLE_ESTIMATE_SOURCE")
        if any("FY_ROW_IS_SUM_OF_QUARTERS" in x["flags"] for x in ents):
            g["flags"].append("FY_ROW_IS_SUM_OF_QUARTERS")
        g["flags"] = sorted(set(g["flags"]))
        p = out["periods"].setdefault(fp, {"groups": [], "retrospective": []})
        p["groups"].append(g)
    for fp, p in out["periods"].items():
        m = re.fullmatch(r"(\d{4})Q([1-4])", fp)
        if m:
            p["cutoff"] = cutoffs.get(fp)
    out["periods"] = dict(sorted(out["periods"].items()))
    return out


def _fmt(v, metric):
    if v is None:
        return ""
    if metric == "revenue":
        for d, s in ((1e12, "T"), (1e9, "B"), (1e6, "M")):
            if abs(v) >= d:
                return f"{v / d:.4g}{s}"
    return f"{v:g}"


def markdown(r, max_periods=4):
    lines = [f"## 市場共識研究紀錄 {r['co_id']}（只記錄，不影響 Gate）", "",
             "| 網站 | 來源 | 存檔時間（台北） | 解析 | 備註 |", "|---|---|---|---|---|"]
    for c in r["captures"]:
        note = c.get("reason") or ""
        if c.get("same_content_as"):
            note = (note + "；" if note else "") + f"內容與 {c['same_content_as']} 存檔完全相同"
        lines.append(f"| `{c['source_id']}` | {'自行存檔' if c['origin'] == 'self_archive' else '他人 Wayback'} | "
                     f"{c['captured_at_tpe'][:16]} | {c['parse_status']} | {note.replace('|', '/')} |")
    for c in r["excluded"]:
        lines.append(f"| `{c['source_id']}` | | {c['captured_at_tpe'][:16]} | 排除：{c['integrity']} | |")
    qs = [fp for fp, p in r["periods"].items() if p["groups"] and re.fullmatch(r"\d{4}Q[1-4]", fp)]
    past = [fp for fp in qs if r["periods"][fp].get("cutoff")][-max_periods:]
    upcoming = [fp for fp in qs if not r["periods"][fp].get("cutoff")][:2]
    shown = past + upcoming
    years = [fp for fp, p in r["periods"].items() if p["groups"] and fp.startswith("FY")]
    for fp in shown:
        p = r["periods"][fp]
        co = p.get("cutoff")
        lines += ["", f"### {fp}" + (f"（截止點 {co['at'][:16]}，{co['status']}）" if co else "（截止點尚未取得）"), "",
                  "| 指標 | 來源 | 存檔時間 | 時點 | 人數 | 平均 | 低 | 高 | 口徑 |", "|---|---|---|---|---|---|---|---|---|"]
        for g in p["groups"]:
            for e in g["entries"]:
                lines.append(f"| {g['metric']} {g['currency']} {g['quote'] if g['metric'] == 'eps' else ''} | "
                             f"`{e['source_id']}` | {e['captured_at_tpe'][:16]} | {TIMING_TEXT.get(e['timing'], e['timing'])} | "
                             f"{'' if e['n_analysts'] is None else e['n_analysts']} | {_fmt(e['avg'], g['metric'])} | "
                             f"{_fmt(e['low'], g['metric'])} | {_fmt(e['high'], g['metric'])} | {e['basis'] or '未寫'} |")
        for g in p["groups"]:
            d = g.get("difference")
            if d:
                lines.append(f"\n- {g['metric']} {g['currency']}：各來源平均 {_fmt(d['avg_min'], g['metric'])}～"
                             f"{_fmt(d['avg_max'], g['metric'])}，差 {d['spread_pct_of_min']}%（只記錄，不選邊）")
            for n in g["notes"]:
                lines.append(f"- {n}")
    if years:
        lines.append(f"\n年度預估（{'、'.join(years)}）只放在 JSON，這裡不列。")
    unchanged = [s for s in r["series"] if s["points"][-1].get("unchanged_since")
                 and s["points"][-1]["timing"] in ("BEFORE_CUTOFF", "BEFORE_QUARTER_END")]
    if unchanged:
        lines.append("")
        for s in unchanged[:6]:
            lines.append(f"- `{s['source_id']}` {s['fiscal_period']} {s['metric']}：最新存檔與 "
                         f"{s['points'][-1]['unchanged_since'][:8]} 的存檔數值完全相同（網站可能未更新）")
    lines.append("\n人數各來源分開列，不加總；不同來源數值相同不代表獨立分析師。")
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description="市場共識研究紀錄（只記錄，不影響 Gate）")
    p.add_argument("--co-id", required=True)
    p.add_argument("--results-root", required=True, help="results/<代號>")
    p.add_argument("--summary", default=None, help="截止點來源 summary.json（預設：results-root 底下最新一次蒐證）")
    p.add_argument("--out", required=True)
    a = p.parse_args(argv)
    arch, disc, summary = discover_inputs(a.results_root)
    summary = a.summary or summary
    caps = [x for d in arch for x in captures_from_archive_dir(d)] + [x for d in disc for x in captures_from_discovery_dir(d)]
    cut = cutoffs_from_summary(json.load(open(summary, encoding="utf-8"))) if summary else {}
    r = build(a.co_id, caps, cut, cutoff_source=os.path.relpath(summary, a.results_root) if summary else None)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(r, f, ensure_ascii=False, indent=2)
    text = markdown(r)
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
