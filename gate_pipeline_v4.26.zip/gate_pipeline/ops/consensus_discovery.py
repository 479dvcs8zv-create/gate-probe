"""
ops/consensus_discovery.py (v4.17)
==================================
共識預估來源探測：對 contract/consensus_sources.json 列出的每個候選網站，查詢 Wayback Machine 的封存索引（CDX），
找出「各季官方截止點之前」有沒有存檔，並抽樣取回少數存檔原文（核對封存當下的 SHA-1 摘要），
供下一步判斷哪些來源能解析出預估值。

這一步只做探測，不產生任何共識值、不影響任何 Gate 判定：
  - 有存檔 ≠ 可以採信；存檔內容能不能解析出該季預估值，要再由解析器逐一確認
  - 查詢失敗、逾時、時間用完都照實記錄；沒有查到不代表網站沒有資料
  - 截止點之後的存檔一律不算（自行比對時間，不信任服務端過濾）

輸出（<out>/）：
  discovery.json             每個來源 × 每季：截止點前 window_days 天內的存檔數、最接近截止點的一筆
  cdx/<來源>_<頁>.json        CDX 原始回應
  samples/<來源>_<季>.bin     抽樣取回的存檔原文（id_ 模式，不含 Wayback 工具列）

  python gate_pipeline/ops/consensus_discovery.py --summary results/2330/<run>/summary.json --out <資料夾>
"""

import argparse
import base64
import hashlib
import json
import os
import re
import sys
import time
import urllib.parse
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

from independent_verifier import ArchiveFetchError, ArchiveIntegrityError, WebArchiveVerifier  # noqa: E402

DISCOVERY_VERSION = "4.18-discovery"
DEFAULT_SOURCES = os.path.join(ROOT, "contract", "consensus_sources.json")
TPE = timezone(timedelta(hours=8))
CDX_FL = "timestamp,original,statuscode,digest,mimetype,length"
KEYWORDS = ("Earnings Estimate", "Revenue Estimate", "Current Qtr", "Consensus", "consensus", "EPS", "Estimate",
            "預估", "共識", "earnings-forecast", "avgEstimate", "epsForecast")


class _RecordingArchive(WebArchiveVerifier):
    """沿用 WebArchiveVerifier 的連線設定（不跟隨轉址、大小上限），另外保留最後一次的原始回應。"""

    def _get(self, url):
        body = super()._get(url)
        self.last_body = body
        return body


def resolve_sources(co_id, path=DEFAULT_SOURCES):
    cfg = json.load(open(path, encoding="utf-8"))
    adr = cfg.get("adr_map", {}).get(co_id)
    out, skipped = [], []
    for s in cfg["sources"]:
        if s.get("only") and co_id not in s["only"]:
            continue
        if "{adr" in s["prefix"] and not adr:
            skipped.append({"id": s["id"], "reason": "沒有 ADR 對照"})
            continue
        prefix = s["prefix"].format(co_id=co_id, adr=adr or "", adr_lower=(adr or "").lower())
        out.append(dict(s, prefix=prefix))
    return out, skipped, adr


def _quarter_labels(q):
    """季度在網頁上常見的寫法，用來粗略提示存檔是否提到目標季度（只是提示，不是解析）。"""
    y, n = int(q[:4]), int(q[-1])
    mon = ("Mar", "Jun", "Sep", "Dec")[n - 1]
    return [f"{mon} {y}", f"{mon}. {y}", f"Q{n} {y}", f"{n}Q{str(y)[2:]}", f"Q{n}{y}", f"{y}Q{n}", f"{y}/Q{n}",
            f"{y}年第{'一二三四'[n - 1]}季", f"{y - 1911}年第{'一二三四'[n - 1]}季", f"{3 * n}/{y}"]


def _hints(body, q):
    try:
        text = body.decode("utf-8", errors="replace")
    except Exception:
        return {}
    return {"keywords": [k for k in KEYWORDS if k in text],
            "quarter_labels": [lab for lab in _quarter_labels(q) if lab in text],
            "has_script_json": bool(re.search(r"<script[^>]*>\s*(window\.|self\.|root\.App|\{\"|__NEXT_DATA__)", text)),
            "size": len(body)}


def discover(co_id, cutoffs, out_dir, base_url="https://web.archive.org", delay=3.0, timeout=60.0,
             window_days=45, max_samples_per_source=2, max_samples_total=30, time_budget=1200.0,
             page_size=1000, max_pages=10, sources_path=DEFAULT_SOURCES, retry_wait=10.0, sleep=time.sleep,
             clock=time.monotonic):
    """cutoffs：{季度: {"at": ISO 時間(含時區), "status": 截止點狀態}}。回傳 discovery dict（同時寫入 out_dir）。"""
    os.makedirs(os.path.join(out_dir, "cdx"), exist_ok=True)
    os.makedirs(os.path.join(out_dir, "samples"), exist_ok=True)
    sources, skipped, adr = resolve_sources(co_id, sources_path)
    cut = {q: datetime.fromisoformat(v["at"]) for q, v in cutoffs.items() if v.get("at")}
    result = {"discovery_version": DISCOVERY_VERSION, "co_id": co_id, "adr": adr, "base_url": base_url,
              "window_days": window_days, "started_at": datetime.now(timezone.utc).isoformat(),
              "cutoffs": {q: {"at": v["at"], "status": v.get("status")} for q, v in sorted(cutoffs.items())},
              "skipped_sources": skipped, "sources": [], "notes": [], "requests": 0}
    if not cut or not sources:
        result["notes"].append("沒有截止點或沒有適用的候選來源，未查詢")
        return _finish(result, out_dir)
    t0 = clock()
    arc = _RecordingArchive(base_url=base_url, timeout=timeout)
    first = [True]

    def budget_left():
        return time_budget - (clock() - t0)

    def get(url):
        """一次請求（含一次暫時性錯誤重試）。回傳 (body, error)。"""
        for attempt in (1, 2):
            if budget_left() <= 0:
                return None, "探測時間上限已到，未發出請求"
            if not first[0]:
                sleep(delay)
            first[0] = False
            result["requests"] += 1
            try:
                return arc._get(url), None
            except (ArchiveFetchError, ArchiveIntegrityError) as e:
                msg = str(e)
                transient = bool(re.search(r"HTTP (429|5\d\d)|無法連線", msg))
                if attempt == 1 and transient:
                    sleep(retry_wait)
                    continue
                return None, msg
        return None, "未知錯誤"

    lo = (min(cut.values()) - timedelta(days=window_days)).astimezone(timezone.utc)
    hi = max(cut.values()).astimezone(timezone.utc)
    samples_total = 0
    for s in sources:
        entry = {"id": s["id"], "vendor": s["vendor"], "prefix": s["prefix"], "unit": s.get("unit"),
                 "cdx": {"pages": 0, "records": 0, "truncated": False, "error": None, "files": []},
                 "quarters": {}, "samples": []}
        result["sources"].append(entry)
        params = {"url": s["prefix"], "matchType": "prefix", "output": "json", "fl": CDX_FL,
                  "filter": "statuscode:200", "from": lo.strftime("%Y%m%d%H%M%S"), "to": hi.strftime("%Y%m%d%H%M%S"),
                  "limit": str(page_size), "showResumeKey": "true"}
        records = []
        while True:
            url = f"{base_url.rstrip('/')}/cdx/search/cdx?{urllib.parse.urlencode(params)}"
            body, err = get(url)
            if err:
                entry["cdx"]["error"] = err
                break
            name = f"cdx/{s['id']}_{entry['cdx']['pages']:02d}.json"
            open(os.path.join(out_dir, name), "wb").write(body)
            entry["cdx"]["files"].append({"file": name, "sha256": hashlib.sha256(body).hexdigest(), "url": url})
            entry["cdx"]["pages"] += 1
            try:
                page, resume = _parse_cdx(body)
            except ValueError as e:
                entry["cdx"]["error"] = f"CDX 回應無法解析：{e}"
                break
            records.extend(page)
            if not resume:
                break
            if entry["cdx"]["pages"] >= max_pages:
                entry["cdx"]["truncated"] = True
                break
            params["resumeKey"] = resume
        entry["cdx"]["records"] = len(records)
        entry["cdx"]["distinct_urls"] = len({r["original"] for r in records})

        parsed = []
        for r in records:
            if r.get("statuscode") != "200" or not re.fullmatch(r"\d{14}", str(r.get("timestamp", ""))):
                continue
            parsed.append((datetime.strptime(r["timestamp"], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc), r))
        for q, c in sorted(cut.items()):
            c_utc = c.astimezone(timezone.utc)
            inwin = [(t, r) for t, r in parsed if c_utc - timedelta(days=window_days) <= t < c_utc]
            qe = {"captures_in_window": len(inwin), "latest": None}
            if inwin:
                t, r = max(inwin, key=lambda x: x[0])
                qe["latest"] = {"timestamp": r["timestamp"], "captured_at_tpe": t.astimezone(TPE).isoformat(),
                                "hours_before_cutoff": round((c_utc - t).total_seconds() / 3600, 1),
                                "original": r["original"], "digest": r.get("digest"), "mimetype": r.get("mimetype"),
                                "length": r.get("length")}
            entry["quarters"][q] = qe

        # 抽樣：最近的季度優先，每個來源最多 max_samples_per_source 筆
        for q in sorted(entry["quarters"], reverse=True):
            if len(entry["samples"]) >= max_samples_per_source or samples_total >= max_samples_total:
                break
            lat = entry["quarters"][q]["latest"]
            if not lat:
                continue
            samples_total += 1
            smp = {"quarter": q, "timestamp": lat["timestamp"], "original": lat["original"]}
            body, err = get(f"{base_url.rstrip('/')}/web/{lat['timestamp']}id_/{lat['original']}")
            if err:
                smp["error"] = err
            else:
                served = base64.b32encode(hashlib.sha1(body).digest()).decode("ascii")
                fname = f"samples/{s['id']}_{q}.bin"
                open(os.path.join(out_dir, fname), "wb").write(body)
                smp.update(file=fname, sha256=hashlib.sha256(body).hexdigest(), content_type=arc.last_content_type,
                           archive_digest=lat["digest"], digest_matched=(served == lat["digest"]),
                           hints=_hints(body, q))
            entry["samples"].append(smp)
        if budget_left() <= 0 and "探測時間上限已到" not in " ".join(result["notes"]):
            result["notes"].append(f"探測時間上限 {time_budget:g} 秒已到，之後的來源未查詢或未抽樣")
    return _finish(result, out_dir)


def _parse_cdx(body):
    text = body.decode("utf-8", errors="strict").strip()
    if not text:
        return [], None
    rows = json.loads(text)
    if not isinstance(rows, list) or not rows:
        return [], None
    resume = None
    if len(rows) >= 2 and rows[-2] == [] and isinstance(rows[-1], list) and len(rows[-1]) == 1:
        resume = str(rows[-1][0])
        rows = rows[:-2]
    if not rows:
        return [], resume
    header = rows[0]
    if not isinstance(header, list) or not {"timestamp", "original", "statuscode", "digest"} <= set(header):
        raise ValueError(f"欄位不符：{header!r}")
    out = []
    for r in rows[1:]:
        if not isinstance(r, list) or len(r) != len(header):
            raise ValueError("列格式錯誤")
        out.append(dict(zip(header, r)))
    return out, resume


def _finish(result, out_dir):
    result["finished_at"] = datetime.now(timezone.utc).isoformat()
    with open(os.path.join(out_dir, "discovery.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    return result


def markdown(result):
    qs = list(result["cutoffs"])
    lines = ["", f"### 共識來源探測（Wayback，截止點前 {result['window_days']} 天內）", "",
             "| 來源 | 有存檔的季數 | 缺的季度 | 抽樣 |", "|---|---|---|---|"]
    for s in result["sources"]:
        have = [q for q in qs if (s["quarters"].get(q) or {}).get("latest")]
        miss = [q for q in qs if q not in have]
        smp = "；".join(f"{x['quarter']} {'摘要相符' if x.get('digest_matched') else x.get('error') or '摘要不符'}"
                       for x in s["samples"]) or "—"
        err = f"（查詢失敗：{s['cdx']['error']}）" if s["cdx"]["error"] else ""
        lines.append(f"| {s['vendor']} `{s['id']}` | {len(have)}/{len(qs)}{err} | {'、'.join(miss) or '—'} | {smp} |")
    for n in result["notes"]:
        lines.append(f"\n- {n}")
    return "\n".join(lines)


# ---------------------------------------------------------------- 探測結果分類（v4.18）
# 每個「來源 × 季度」一個狀態。只有 CONSENSUS_CANDIDATE 代表原文裡解析得到預估值；
# 即使是 CONSENSUS_CANDIDATE，也要等來源採認規則經使用者核准後，才可能交給 Gate5B。
STATUS_ORDER = ("CONSENSUS_CANDIDATE", "NO_CONSENSUS_VALUE", "UNPARSED", "DIGEST_MISMATCH", "FETCH_FAILED",
                "NOT_SAMPLED", "NO_CAPTURE", "INCOMPLETE_INDEX", "QUERY_FAILED", "TIMEOUT")
STATUS_TEXT = {
    "CONSENSUS_CANDIDATE": "原文含可解析的預估值（待來源政策核准）",
    "NO_CONSENSUS_VALUE": "原文可驗證，但沒有這一季的預估值",
    "UNPARSED": "原文已取得、摘要相符，尚無此網站的解析器",
    "DIGEST_MISMATCH": "取回的原文與封存當下摘要不符",
    "FETCH_FAILED": "有存檔，但原文取回失敗",
    "NOT_SAMPLED": "有存檔，這次未抽樣取回",
    "NO_CAPTURE": "截止點前沒有存檔",
    "INCOMPLETE_INDEX": "封存索引超過頁數上限，未取完，無法斷定沒有存檔",
    "QUERY_FAILED": "封存索引查詢失敗，無法斷定有無存檔",
    "TIMEOUT": "探測時間上限已到，未查詢或未取回",
}
PARSERS = {}   # 來源 id -> fn(body: bytes, quarter: str) -> dict（含 "values"）或 None；看過真實原文後才逐一加入
_BUDGET_MSG = "探測時間上限已到"


def classify(result, out_dir=None, parsers=None):
    """回傳 {來源 id: {季度: {"status": ..., "detail": ...}}}。out_dir 提供時，有解析器的來源會讀原文解析。"""
    parsers = PARSERS if parsers is None else parsers
    out = {}
    for s in result["sources"]:
        per = {}
        samples = {x["quarter"]: x for x in s["samples"]}
        cdx_err = s["cdx"]["error"]
        for q in result["cutoffs"]:
            lat = (s["quarters"].get(q) or {}).get("latest")
            smp = samples.get(q)
            if lat is None:
                if cdx_err:
                    st = "TIMEOUT" if _BUDGET_MSG in cdx_err else "QUERY_FAILED"
                    per[q] = {"status": st, "detail": cdx_err}
                elif s["cdx"]["truncated"]:
                    per[q] = {"status": "INCOMPLETE_INDEX", "detail": f"取了 {s['cdx']['pages']} 頁"}
                else:
                    per[q] = {"status": "NO_CAPTURE", "detail": None}
                continue
            if smp is None:
                per[q] = {"status": "NOT_SAMPLED", "detail": lat["timestamp"]}
            elif smp.get("error"):
                per[q] = {"status": "TIMEOUT" if _BUDGET_MSG in smp["error"] else "FETCH_FAILED", "detail": smp["error"]}
            elif not smp.get("digest_matched"):
                per[q] = {"status": "DIGEST_MISMATCH", "detail": smp.get("archive_digest")}
            elif s["id"] in parsers and out_dir:
                body = open(os.path.join(out_dir, smp["file"]), "rb").read()
                if hashlib.sha256(body).hexdigest() != smp["sha256"]:
                    per[q] = {"status": "DIGEST_MISMATCH", "detail": "存檔原文與 discovery.json 記錄的 SHA-256 不符"}
                    continue
                parsed = parsers[s["id"]](body, q)
                per[q] = ({"status": "CONSENSUS_CANDIDATE", "detail": parsed} if parsed and parsed.get("values")
                          else {"status": "NO_CONSENSUS_VALUE", "detail": None})
            else:
                per[q] = {"status": "UNPARSED", "detail": smp.get("hints")}
        out[s["id"]] = per
    return out


def classification_markdown(result, cls):
    qs = list(result["cutoffs"])
    lines = ["| 來源 | " + " | ".join(qs) + " |", "|---|" + "---|" * len(qs)]
    for s in result["sources"]:
        lines.append(f"| {s['id']} | " + " | ".join(cls[s["id"]][q]["status"] for q in qs) + " |")
    return "\n".join(lines)


def cutoffs_from_summary(summary):
    """（v4.26）有快照界線（月營收＝公告當日 00:00）就用界線；舊版 summary 沒有界線時用公告時間。"""
    return {q: {"at": (v.get("snapshot_boundary") or {}).get("at") or v["earliest"]["at"], "status": v["status"],
                "announced_at": v["earliest"]["at"]}
            for q, v in summary["quarters"].items() if v.get("earliest")}


def main(argv=None):
    p = argparse.ArgumentParser(description="共識預估來源探測（Wayback）")
    p.add_argument("--summary", required=True, help="collect_evidence 產生的 summary.json")
    p.add_argument("--out", required=True)
    p.add_argument("--base-url", default="https://web.archive.org")
    p.add_argument("--delay", type=float, default=3.0)
    p.add_argument("--time-budget", type=float, default=1200.0)
    a = p.parse_args(argv)
    summary = json.load(open(a.summary, encoding="utf-8"))
    r = discover(summary["co_id"], cutoffs_from_summary(summary), a.out, base_url=a.base_url, delay=a.delay,
                 time_budget=a.time_budget)
    print(markdown(r))
    return 0


if __name__ == "__main__":
    sys.exit(main())
