"""
mops_t57sb01.py (v4.12)
=======================
臺灣證券交易所「電子資料查詢作業」（https://doc.twse.com.tw/server-java/t57sb01）財務報告書清單的
正式解析器。用途：取得財報申報（financial_report）的官方時間（上傳日期）。

來源依據：官方 mops2.js 的選單把「財務報告」電子書導向這個網址（v4.9 取得的 mops2.js）。
格式依據：v4.11 探測在 GitHub Actions 實際取得的回應（run 39100629571，
          contract/mops_real/run_39100629571/），Big5 編碼。

實測重點：
  - 查詢 step=1、co_id、year（民國）、seamon=（空）、mtype=A 會回傳該年度所有財務報告書清單；
    加上 dtype=A02 時回傳「查無所需資料」。所以「查無所需資料」不能當成「沒有申報」的證據
    （參數不對也會得到同樣的訊息），一律 fail-closed。
  - 「財務報告更(補)正」欄位顯示的是最近一次更補正資訊；只要不是「無」，就無法確定原始申報時間，
    fail-closed。v4.22 起改為「逐列」處理：該列不採用並列入 uncertain，只阻擋該列所屬的季度
    （例如 2454 民國 113 年第四季英文版個體財報該欄空白），不再讓整年度的清單失效。
  - 上傳日期為民國日期＋時間，視為臺北時間（+08:00）。

嚴格原則與 mops_t05st01 相同：只接受用真實樣本驗證過的格式，不符一律 fail-closed。
"""

import hashlib
import html
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from evidence_verification import OFFICIAL_DOMAINS, _domain_matches, _domain_of, decode_declared
from mops_t05st01 import REFUSAL_MARKERS, TPE, _clean
from reject_codes import RC

QUERY_PATH = "/server-java/t57sb01"
EXPECTED_HEADER = ["證券代號", "資料年度", "資料類型", "結案類型", "性質", "資料細節說明", "備註",
                   "電子檔案", "檔案大小", "上傳日期", "財務報告更(補)正"]
NO_DATA_MARKER = "查無所需資料"
_CN_Q = {"一": 1, "二": 2, "三": 3, "四": 4}

_RE_TABLE = re.compile(r"<table border='5'[^>]*>(.*?)</table>", re.S)
_RE_TR = re.compile(r"<tr\b[^>]*>(.*?)</tr>", re.S)
_RE_TR_OPEN = re.compile(r"<tr\b")
_RE_TH = re.compile(r"<th[^>]*>(.*?)</th>", re.S)
_RE_TD = re.compile(r"<td[^>]*>(.*?)</td>", re.S)
_RE_COMPANY = re.compile(r"公司名稱：([^<\s]+)<br>")
_RE_PERIOD = re.compile(r"(\d{3}) 年 第([一二三四])季")
_RE_FILE = re.compile(r"<a href='javascript:readfile2\(\"A\",\"(\w+)\",\"((\d{4})(\d{2})_(\w+?)_(\w+)\.pdf)\"\);'>\2</a>")
_RE_UPLOAD = re.compile(r"(\d{3})/(\d{2})/(\d{2}) (\d{2}):(\d{2}):(\d{2})")


@dataclass(frozen=True)
class FilingRow:
    document_id: str          # t57sb01:{co_id}:{filename}
    co_id: str
    fiscal_quarter: str       # 例如 2026Q2
    data_type: str            # 資料類型，例如 財務報告書
    detail: str               # 資料細節說明，例如 IFRSs合併財報
    filename: str
    uploaded_at: datetime     # 上傳日期，+08:00
    correction: str           # 財務報告更(補)正（實測為「無」）


@dataclass
class FilingListing:
    co_id: str
    company_name: str
    roc_year: int
    rows: List[FilingRow]
    request_url: str
    response_sha256: str
    retrieved_at: Optional[datetime]   # 探測紀錄的取得時間，用來判斷「尚未申報」
    uncertain: List[dict] = field(default_factory=list)   # v4.22：更(補)正欄位不是「無」的列（原始申報時間無法確定）

    def filings_for(self, fiscal_quarter: str) -> List[FilingRow]:
        return [r for r in self.rows if r.fiscal_quarter == fiscal_quarter]


def parse_t57sb01_listing(response_bytes: bytes, content_type: str, request_url: str, expected_co_id: str,
                          expected_roc_year: str, expected_company_name: Optional[str] = None,
                          retrieved_at: Optional[datetime] = None, reported_sha256: Optional[str] = None):
    """解析財務報告書清單。回傳 (listing 或 None, failures)。"""
    fails = []
    if not response_bytes:
        return None, [(RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, "財報清單回應是空的")]
    sha = hashlib.sha256(response_bytes).hexdigest()
    if reported_sha256 is not None and reported_sha256.strip().lower() != sha:
        fails.append((RC.ANNOUNCEMENT_HASH_MISMATCH, "由財報清單原始位元組重算的 SHA-256 與回報值不一致"))
    if not _domain_matches(_domain_of(request_url), OFFICIAL_DOMAINS) or QUERY_PATH not in str(request_url):
        fails.append((RC.ANNOUNCEMENT_SOURCE_NOT_OFFICIAL, f"請求網址「{request_url}」不是官方的 t57sb01 端點"))
    text, err = decode_declared(response_bytes, content_type)
    if err:
        fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"財報清單無法解碼：{err}"))
    if fails:
        return None, fails
    for marker in REFUSAL_MARKERS:
        if marker in text:
            return None, [(RC.ANNOUNCEMENT_SOURCE_REFUSED, f"官方網站回覆「{marker}」，這不是查詢結果")]
    if NO_DATA_MARKER in text:
        return None, [(RC.ANNOUNCEMENT_EVIDENCE_UNAVAILABLE,
                       "官方回覆「查無所需資料」：實測參數不對時也會得到這個訊息，不能當成沒有申報的證據")]

    cm = _RE_COMPANY.findall(text)
    if len(cm) != 1:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, "找不到唯一的「公司名稱：」欄位")]
    company = cm[0]
    if expected_company_name is not None and company != expected_company_name:
        return None, [(RC.ANNOUNCEMENT_ISSUER_MISMATCH, f"財報清單的公司是「{company}」，不是「{expected_company_name}」")]
    tables = _RE_TABLE.findall(text)
    if len(tables) != 1:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"財報清單表格數量為 {len(tables)}（應為 1）")]
    trs = _RE_TR.findall(tables[0])
    if len(_RE_TR_OPEN.findall(tables[0])) != len(trs) or not trs:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, "財報清單有無法解析的列")]
    if [_clean(h) for h in _RE_TH.findall(trs[0])] != EXPECTED_HEADER:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, "財報清單的表頭與已驗證格式不同")]

    rows, seen, uncertain = [], set(), []
    for i, tr in enumerate(trs[1:], 1):
        label = f"財報清單第 {i} 列"
        tds = _RE_TD.findall(tr)
        if len(tds) != len(EXPECTED_HEADER) or _RE_TH.search(tr):
            fails.append((RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"{label}有 {len(tds)} 欄（應為 {len(EXPECTED_HEADER)}）"))
            continue
        co, period, dtype, _, _, detail, _, filecell, _, uploaded, correction = tds
        co, period, dtype, detail, uploaded, correction = (_clean(x) for x in (co, period, dtype, detail, uploaded, correction))
        pm, um, fm = _RE_PERIOD.fullmatch(period), _RE_UPLOAD.fullmatch(uploaded), _RE_FILE.fullmatch(filecell.strip())
        if not pm or not fm:
            fails.append((RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"{label}的資料年度「{period}」或電子檔案連結格式與已驗證格式不同"))
            continue
        try:
            y, mo, d, hh, mi, ss = (int(x) for x in um.groups())
            up = datetime(y + 1911, mo, d, hh, mi, ss, tzinfo=TPE)
        except (AttributeError, ValueError):
            fails.append((RC.ANNOUNCEMENT_TIME_UNVERIFIED, f"{label}的上傳日期「{uploaded}」無效"))
            continue
        roc_y, q = int(pm.group(1)), _CN_Q[pm.group(2)]
        f_co, filename, f_year, f_q, f_co2 = fm.group(1), fm.group(2), int(fm.group(3)), int(fm.group(4)), fm.group(5)
        problems = []
        if co != str(expected_co_id) or f_co != co or f_co2 != co:
            problems.append(f"證券代號（{co}／檔案 {f_co}、{f_co2}）與查詢的 {expected_co_id} 不符")
        if roc_y != int(expected_roc_year):
            problems.append(f"資料年度 {roc_y} 不是查詢的 {expected_roc_year}")
        if f_year != roc_y + 1911 or f_q != q:
            problems.append(f"檔名 {filename} 的年度季別與資料年度「{period}」不符")
        if dtype != "財務報告書":
            problems.append(f"資料類型「{dtype}」不是財務報告書")
        uncertain_reason = None
        if correction != "無":
            uncertain_reason = f"財務報告更(補)正為「{correction}」，無法確定原始申報時間"
        if problems:
            fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{label}：" + "；".join(problems)))
            continue
        doc_id = f"t57sb01:{co}:{filename}"
        if doc_id in seen:
            fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{label}：{doc_id} 重複"))
            continue
        seen.add(doc_id)
        if uncertain_reason:
            uncertain.append({"fiscal_quarter": f"{roc_y + 1911}Q{q}", "filename": filename, "detail": detail,
                              "uploaded_at_shown": up.isoformat(), "reason": uncertain_reason})
            continue
        rows.append(FilingRow(doc_id, co, f"{roc_y + 1911}Q{q}", dtype, detail, filename, up, correction))
    if fails:
        return None, fails
    return FilingListing(str(expected_co_id), company, int(expected_roc_year), rows, request_url, sha, retrieved_at,
                         uncertain), []
