"""
test_mops_real.py (v4.10)
=========================
用 v4.9 在 GitHub Actions 實際取得的公開資訊觀測站原始回應（contract/mops_real/run_39091204611）
測試正式解析器 mops_t05st01.py，並以竄改過的回應確認每一種不符都會 fail-closed。

  python test_mops_real.py
"""
import hashlib
import json
import os
from datetime import datetime

from mops_t05st01 import TPE, cross_check_listings, cutoff_candidates, parse_t05st01_listing
from reject_codes import RC

HERE = os.path.dirname(os.path.abspath(__file__))
FIX = os.path.join(HERE, "contract", "mops_real", "run_39091204611")
MANIFEST = json.load(open(os.path.join(FIX, "manifest.json"), encoding="utf-8"))
CASES = {c["month"] or "all": c for c in MANIFEST["cases"]}


def _raw(key):
    return open(os.path.join(FIX, CASES[key]["response_file"]), "rb").read()


def _parse(key, data=None, content_type=None, **over):
    c = CASES[key]
    args = dict(response_bytes=_raw(key) if data is None else data,
                content_type=c["content_type"] if content_type is None else content_type,
                request_url=c["request_url"], expected_co_id=c["co_id"], expected_roc_year=c["roc_year"],
                expected_month=c["month"], reported_sha256=c["response_sha256"] if data is None else None)
    args.update(over)
    return parse_t05st01_listing(**args)


def _codes(fails):
    return {c for c, _ in fails}


def _swap(key, old: bytes, new: bytes, count=1):
    raw = _raw(key)
    assert raw.count(old) >= 1, f"測試前提：找不到要替換的位元組 {old[:40]!r}"
    return raw.replace(old, new, count)


# ---------------------------------------------------------------- 真實資料

def test_fixture_integrity():
    """固定測試資料必須與 GitHub Actions 取得時的雜湊完全一致。"""
    for c in MANIFEST["cases"]:
        for f, h in ((c["response_file"], c["response_sha256"]), (c["request_body_file"], c["request_body_sha256"])):
            data = open(os.path.join(FIX, f), "rb").read()
            assert hashlib.sha256(data).hexdigest() == h, f"{f} 雜湊不符"
    rep = open(os.path.join(FIX, "probe_report.json"), "rb").read()
    assert hashlib.sha256(rep).hexdigest() == MANIFEST["probe_report_sha256"]


def test_real_listings_parse():
    expect = {"07": 5, "08": 9, "all": 153}
    for key, n in expect.items():
        listing, fails = _parse(key)
        assert not fails, f"{key}：{fails}"
        assert len(listing.items) == n, f"{key} 應為 {n} 筆，實得 {len(listing.items)}"
        assert listing.co_id == "2330" and listing.company_name == "台積電" and listing.market == "上市公司"
        assert listing.sorted_ascending
        assert all(it.typek == "sii" for it in listing.items)
    full, _ = _parse("all")
    assert full.month == "all" and str(full.range_start) == "2026-01-01" and str(full.range_end) == "2026-12-31"
    assert full.items[0].announced_at.date().isoformat() == "2026-01-02"
    assert full.items[-1].roc_date_text == "115/10/15"


def test_unpadded_spoke_time_row():
    """實測：上午 10 點前的 spoke_time 不補零（06:44:29 → '64429'），必須以數值比對而不是拒絕或誤讀。"""
    full, _ = _parse("all")
    row = [it for it in full.items if it.time_text == "06:44:29"]
    assert len(row) == 1 and dict(row[0].detail_params)["spoke_time"] == "64429"
    assert row[0].announced_at == datetime(2026, 4, 29, 6, 44, 29, tzinfo=TPE)
    assert row[0].document_id == "t05st01:2330:20260429:064429:1"


def test_monthly_equals_full_year_subset():
    full, _ = _parse("all")
    jul, _ = _parse("07")
    aug, _ = _parse("08")
    assert cross_check_listings(full, [jul, aug]) == []


def test_q2_q3_events_and_conservative_cutoff():
    full, _ = _parse("all")
    q2 = cutoff_candidates(full, "2026Q2")
    types = q2["event_types_found"]
    assert types == ["board_approved_financials", "investor_conference", "quarter_revenue_complete",
                     "self_reported_results"], types
    by_type = {e["event_type"]: e for e in q2["events"]}
    assert by_type["self_reported_results"]["at"] == datetime(2026, 7, 16, 15, 12, 31, tzinfo=TPE)
    assert by_type["board_approved_financials"]["at"] == datetime(2026, 8, 11, 18, 46, 58, tzinfo=TPE)
    assert by_type["investor_conference"]["at"] == datetime(2026, 7, 16, tzinfo=TPE)
    assert by_type["investor_conference"]["precision"] == "date_only"
    assert by_type["quarter_revenue_complete"]["at"] == datetime(2026, 7, 13, 13, 50, 31, tzinfo=TPE)
    # 含營收：6 月營收公告（7/13）就已公開第二季營收，是最早的揭露
    assert q2["earliest"]["event_type"] == "quarter_revenue_complete"
    assert q2["status"] == "PROVISIONAL" and q2["blocking"], "只靠清單永遠不能放行"
    # 只看 EPS 類事件：法說會當天 00:00 是保守截止點
    q2_eps = cutoff_candidates(full, "2026Q2", include_revenue=False)
    assert q2_eps["earliest"]["at"] == datetime(2026, 7, 16, tzinfo=TPE)
    q3 = cutoff_candidates(full, "2026Q3", include_revenue=False)
    assert q3["earliest"]["at"] == datetime(2026, 10, 15, tzinfo=TPE)
    assert {e["event_type"] for e in q3["events"]} == {"investor_conference", "self_reported_results"}


def test_prior_year_quarter_is_blocked_by_coverage():
    """2025Q4 的事件跨年（法說會公告在 2025 年 12 月），只有 2026 年清單時必須列為阻擋原因。"""
    full, _ = _parse("all")
    q4 = cutoff_candidates(full, "2025Q4")
    assert any("晚於該季第一天" in b for b in q4["blocking"]), q4["blocking"]


# ---------------------------------------------------------------- 竄改與異常：一律 fail-closed

def test_tampered_bytes_hash_mismatch():
    c = CASES["07"]
    data = _swap("07", "27.25".encode(), "99.99".encode())
    _, fails = parse_t05st01_listing(data, c["content_type"], c["request_url"], "2330", "115", "07",
                                     reported_sha256=c["response_sha256"])
    assert RC.ANNOUNCEMENT_HASH_MISMATCH in _codes(fails)


def test_non_official_url():
    _, fails = _parse("07", request_url="https://mops-mirror.example.com/mops/web/ajax_t05st01")
    assert RC.ANNOUNCEMENT_SOURCE_NOT_OFFICIAL in _codes(fails)


def test_wrong_declared_charset():
    _, fails = _parse("07", content_type="text/html; charset=big5")
    assert RC.ANNOUNCEMENT_CONTENT_MISMATCH in _codes(fails)


def test_refusal_page():
    page = "<html><body><center>查詢過量，請稍後再查詢</center></body></html>".encode("utf-8")
    _, fails = _parse("07", data=page, content_type="text/html; charset=UTF-8")
    assert _codes(fails) == {RC.ANNOUNCEMENT_SOURCE_REFUSED}


def test_unknown_or_empty_format_is_not_no_announcements():
    page = "<html><body><center>查無所需資料</center></body></html>".encode("utf-8")
    _, fails = _parse("07", data=page, content_type="text/html; charset=UTF-8")
    assert _codes(fails) == {RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN}
    # 結果表格被拿掉、只剩表單
    raw = _raw("07").decode("utf-8")
    i, j = raw.index("<table class='hasBorder'>"), raw.index("</table></form>")
    _, fails = _parse("07", data=(raw[:i] + raw[j + 8:]).encode("utf-8"))
    assert _codes(fails) == {RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN}


def test_echoed_query_must_match_request():
    _, fails = _parse("07", expected_month="08")
    assert _codes(fails) == {RC.ANNOUNCEMENT_COVERAGE_INCOMPLETE}
    _, fails = _parse("07", data=_swap("07", b"name=year value=115>", b"name=year value=114>"))
    assert _codes(fails) == {RC.ANNOUNCEMENT_COVERAGE_INCOMPLETE}
    _, fails = _parse("all", expected_month="07")
    assert _codes(fails) == {RC.ANNOUNCEMENT_COVERAGE_INCOMPLETE}


def test_issuer_header_must_match():
    _, fails = _parse("07", expected_co_id="2303")
    assert _codes(fails) == {RC.ANNOUNCEMENT_ISSUER_MISMATCH}
    _, fails = _parse("07", data=_swap("07", "(上市公司)".encode(), "(上櫃公司)".encode()))
    assert _codes(fails) == {RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN}


def test_header_columns_must_match():
    _, fails = _parse("07", data=_swap("07", "<th>發言時間</th>".encode(), "<th>時間</th>".encode()))
    assert _codes(fails) == {RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN}


def test_unparseable_row_is_not_skipped():
    raw = _raw("07")
    bad = raw.replace(b"<tr class='odd'>", b"<tr class='odd2'>", 1)
    _, fails = _parse("07", data=bad)
    assert _codes(fails) == {RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN}, fails


def test_row_vs_button_params_cross_check():
    # 畫面日期與參數日期不一致
    _, fails = _parse("07", data=_swap("07", b"spoke_date.value='20260716'", b"spoke_date.value='20260715'"))
    assert RC.ANNOUNCEMENT_CONTENT_MISMATCH in _codes(fails)
    # 畫面時間與參數時間不一致
    _, fails = _parse("07", data=_swap("07", b"spoke_time.value='151231'", b"spoke_time.value='151230'"))
    assert RC.ANNOUNCEMENT_CONTENT_MISMATCH in _codes(fails)
    # 參數中的公司代號被換掉
    _, fails = _parse("07", data=_swap("07", b"co_id.value='2330';document.t05st01_fm.TYPEK",
                                      b"co_id.value='2303';document.t05st01_fm.TYPEK"))
    assert RC.ANNOUNCEMENT_CONTENT_MISMATCH in _codes(fails)
    # 少了一個參數
    _, fails = _parse("07", data=_swap("07", b"document.t05st01_fm.seq_no.value='1';", b""))
    assert RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN in _codes(fails)


def test_invalid_date_and_out_of_range():
    _, fails = _parse("07", data=_swap("07", "&nbsp;115/07/16</td>".encode(), "&nbsp;115/02/30</td>".encode()))
    assert RC.ANNOUNCEMENT_TIME_UNVERIFIED in _codes(fails)
    # 日期合法，但不在回顯的 7 月內（參數一併改，確保是範圍檢查擋下）
    data = _swap("07", "&nbsp;115/07/16</td>".encode(), "&nbsp;115/08/16</td>".encode())
    data = data.replace(b"spoke_date.value='20260716'", b"spoke_date.value='20260816'")
    _, fails = _parse("07", data=data)
    assert any("不在官方回顯的查詢範圍" in m for _, m in fails), fails


def test_duplicate_row():
    raw = _raw("07").decode("utf-8")
    start = raw.index("<tr class='even'>")
    end = raw.index("</tr>", start) + 5
    dup = raw[:end] + raw[start:end] + raw[end:]
    _, fails = _parse("07", data=dup.encode("utf-8"))
    assert any("重複" in m for _, m in fails), fails


def test_cross_check_detects_missing_and_extra():
    full, _ = _parse("all")
    jul, _ = _parse("07")
    # 單月少一筆（把最後一列拿掉後重新解析）
    raw = _raw("07").decode("utf-8")
    last = raw.rindex("<tr class='even'>")
    short = raw[:last] + raw[raw.index("</tr>", last) + 5:]
    jul_short, f = _parse("07", data=short.encode("utf-8"))
    assert not f and len(jul_short.items) == 4
    fails = cross_check_listings(full, [jul_short])
    assert _codes(fails) == {RC.ANNOUNCEMENT_QUERY_INCONSISTENT}
    # 全年少一筆 7 月的公告
    rawf = _raw("all").decode("utf-8")
    k = rawf.index("spoke_date.value='20260716'")
    s = rawf.rindex("<tr class=", 0, k)
    full_short, f = _parse("all", data=(rawf[:s] + rawf[rawf.index("</tr>", k) + 5:]).encode("utf-8"))
    assert not f and len(full_short.items) == 152
    assert _codes(cross_check_listings(full_short, [jul])) == {RC.ANNOUNCEMENT_QUERY_INCONSISTENT}


def test_no_classification_means_no_event():
    """沒驗證過的標題寫法不會被分類：該期間找不到事件就列為阻擋，不會猜。"""
    full, _ = _parse("all")
    q = cutoff_candidates(full, "2027Q1")
    assert q["earliest"] is None and any("找不到" in b for b in q["blocking"])



# ---------------------------------------------------------------- v4.10：詳細頁與獨立重跑

from mops_t05st01 import parse_t05st01_detail  # noqa: E402

FIX2 = os.path.join(HERE, "contract", "mops_real", "run_39099468097")
MANIFEST2 = json.load(open(os.path.join(FIX2, "manifest.json"), encoding="utf-8"))


def _raw2(case):
    return open(os.path.join(FIX2, case["response_file"]), "rb").read()


def _listing2():
    c = MANIFEST2["cases"][0]
    listing, fails = parse_t05st01_listing(_raw2(c), c["content_type"], c["request_url"], "2330", "115", "",
                                           c["response_sha256"])
    assert not fails, fails
    return listing


def _item_for(listing, case):
    p = case["params"]
    hits = [it for it in listing.items if dict(it.detail_params)["spoke_date"] == p["spoke_date"]
            and dict(it.detail_params)["spoke_time"] == p["spoke_time"] and str(it.seq_no) == p["seq_no"]]
    assert len(hits) == 1
    return hits[0]


def _detail_cases():
    return [c for c in MANIFEST2["cases"] if c["kind"] == "t05st01_detail"]


def _case_on(spoke_date):
    return [c for c in _detail_cases() if c["params"]["spoke_date"] == spoke_date][0]


def _parse_detail(case, data=None, item=None, **over):
    listing = _listing2()
    args = dict(response_bytes=_raw2(case) if data is None else data, content_type=case["content_type"],
                request_url=case["request_url"], item=item or _item_for(listing, case),
                reported_sha256=case["response_sha256"] if data is None else None)
    args.update(over)
    return parse_t05st01_detail(**args)


def _all_details(replace=None):
    """{document_id: detail}；replace={spoke_date: 改過的位元組} 用來測試竄改。"""
    listing = _listing2()
    out = {}
    for c in _detail_cases():
        data = (replace or {}).get(c["params"]["spoke_date"])
        d, f = _parse_detail(c, data=data)
        assert not f, f
        out[d.document_id] = d
    return listing, out


def test_v410_fixture_integrity():
    for c in MANIFEST2["cases"]:
        for f, h in ((c["response_file"], c["response_sha256"]), (c["request_body_file"], c["request_body_sha256"])):
            assert hashlib.sha256(open(os.path.join(FIX2, f), "rb").read()).hexdigest() == h, f
    assert hashlib.sha256(open(os.path.join(FIX2, "probe_report.json"), "rb").read()).hexdigest() == MANIFEST2["probe_report_sha256"]


def test_v410_full_year_replay_is_byte_identical():
    """兩次獨立的 GitHub Actions 執行（v4.9 與 v4.10，相隔約兩小時）取得完全相同的全年清單。"""
    c1, c2 = CASES["all"], MANIFEST2["cases"][0]
    assert c1["response_sha256"] == c2["response_sha256"]
    assert MANIFEST["run_id"] != MANIFEST2["run_id"]
    a, _ = _parse("all")
    b = _listing2()
    assert [(i.document_id, i.subject) for i in a.items] == [(i.document_id, i.subject) for i in b.items]


def test_v410_details_parse_and_match_listing():
    listing, details = _all_details()
    assert len(details) == 7
    clauses = {d.document_id.split(":")[2]: d.clause for d in details.values()}
    assert clauses == {"20260629": "12", "20260713": "51", "20260716": "51", "20260811": "31",
                       "20260929": "12", "20261008": "51", "20261015": "51"}, clauses
    d = details["t05st01:2330:20260629:185000:1"]
    assert d.fact_date.isoformat() == "2026-07-16" and "14 時 00 分" in d.description


def test_v410_conference_time_from_detail():
    """法說會實際 14:00 召開，早於觀測站 EPS 公告（15:12:31、15:21:38）。"""
    listing, details = _all_details()
    q2 = cutoff_candidates(listing, "2026Q2", include_revenue=False, details=details)
    assert q2["earliest"]["event_type"] == "investor_conference"
    assert q2["earliest"]["at"] == datetime(2026, 7, 16, 14, 0, tzinfo=TPE) and q2["earliest"]["precision"] == "datetime_tz"
    q3 = cutoff_candidates(listing, "2026Q3", include_revenue=False, details=details)
    assert q3["earliest"]["at"] == datetime(2026, 10, 15, 14, 0, tzinfo=TPE)
    q2r = cutoff_candidates(listing, "2026Q2", details=details)
    assert q2r["earliest"]["at"] == datetime(2026, 7, 13, 13, 50, 31, tzinfo=TPE)
    q3r = cutoff_candidates(listing, "2026Q3", details=details)
    assert q3r["earliest"]["at"] == datetime(2026, 10, 8, 13, 54, 4, tzinfo=TPE)
    for r in (q2, q3, q2r, q3r):
        assert all(e["detail_verified"] for e in r["events"])
        assert r["status"] == "PROVISIONAL" and "財報申報（financial_report）尚未查詢" in r["blocking"], r["blocking"]


def test_v4101_unclassified_review_window():
    """季末到最早事件之間的未分類公告必須人工確認；確認以公告識別碼記錄，未確認就阻擋。"""
    listing, details = _all_details()
    q2 = cutoff_candidates(listing, "2026Q2", details=details)
    ids = [r["document_id"] for r in q2["review_window"]]
    assert ids == ["t05st01:2330:20260702:173613:1", "t05st01:2330:20260708:193435:1"], ids
    assert any("需人工確認" in b for b in q2["blocking"])
    # 只確認其中一則：仍阻擋，且只列出未確認的那一則
    q2b = cutoff_candidates(listing, "2026Q2", details=details, reviewed_non_results={ids[0]})
    msg = [b for b in q2b["blocking"] if "需人工確認" in b]
    assert len(msg) == 1 and ids[1] in msg[0] and ids[0] not in msg[0]
    # 兩則都確認：只剩財報申報
    q2c = cutoff_candidates(listing, "2026Q2", details=details, reviewed_non_results=set(ids))
    assert q2c["blocking"] == ["財報申報（financial_report）尚未查詢"], q2c["blocking"]
    # 第三季：季末到 10/08 13:54:04 之間沒有未分類公告
    q3 = cutoff_candidates(listing, "2026Q3", details=details)
    assert q3["review_window"] == [] and q3["blocking"] == ["財報申報（financial_report）尚未查詢"], q3["blocking"]


def test_v410_cross_document_eps_consistency():
    """董事會通過的上半年累計 EPS（49.33）= 第一季 EPS（22.08）＋第二季 EPS（27.25）。"""
    listing, details = _all_details()
    import re as _re
    q = {m.group(1): float(m.group(2)) for it in listing.items
         if (m := _re.search(r"2026年第([一二])季每股盈餘新台幣([\d.]+)元", it.subject))}
    board = details["t05st01:2330:20260811:184658:2"].description
    h1 = float(_re.search(r"基本每股盈餘\(損失\) \(元\):([\d.]+)", board).group(1))
    assert round(q["一"] + q["二"], 2) == h1 == 49.33


def test_v410_detail_tampering_fails_closed():
    c = _case_on("20260716")
    raw = _raw2(c)
    # 雜湊
    d, f = parse_t05st01_detail(raw.replace(b"27.25", b"27.26", 1), c["content_type"], c["request_url"],
                                _item_for(_listing2(), c), reported_sha256=c["response_sha256"])
    assert RC.ANNOUNCEMENT_HASH_MISMATCH in _codes(f)
    # 發言時間與清單不符
    d, f = _parse_detail(c, data=raw.replace("&nbsp;15:12:31".encode(), "&nbsp;15:12:30".encode(), 1))
    assert _codes(f) == {RC.ANNOUNCEMENT_CONTENT_MISMATCH}
    # 拿別則公告的詳細頁冒充
    listing = _listing2()
    d, f = _parse_detail(c, item=_item_for(listing, _case_on("20260629")))
    assert _codes(f) == {RC.ANNOUNCEMENT_CONTENT_MISMATCH}
    # 公司表頭
    d, f = _parse_detail(c, data=raw.replace("(上市公司) 2330".encode(), "(上市公司) 2303".encode(), 1))
    assert _codes(f) == {RC.ANNOUNCEMENT_ISSUER_MISMATCH}
    # 欄位名稱改動
    d, f = _parse_detail(c, data=raw.replace("發言人職稱".encode(), "職稱".encode(), 1))
    assert _codes(f) == {RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN}
    # 拒絕頁
    d, f = _parse_detail(c, data="<html>查詢過量</html>".encode("utf-8"))
    assert _codes(f) == {RC.ANNOUNCEMENT_SOURCE_REFUSED}


def test_v410_detail_semantics_block_cutoff():
    conf = _raw2(_case_on("20260629"))
    # 法說會時間被拿掉：退回當天 00:00（更保守），不會猜時間
    listing, details = _all_details({"20260629": conf.replace("14 時 00 分".encode(), "".encode(), 1)})
    r = cutoff_candidates(listing, "2026Q2", include_revenue=False, details=details)
    assert r["earliest"]["at"] == datetime(2026, 7, 16, tzinfo=TPE) and r["earliest"]["precision"] == "date_only"
    # 說明中的法說會日期與主旨不一致
    listing, details = _all_details({"20260629": conf.replace("之日期：115/07/16".encode(), "之日期：115/07/17".encode(), 1)})
    r = cutoff_candidates(listing, "2026Q2", include_revenue=False, details=details)
    assert any("法說會日期不一致" in b for b in r["blocking"]), r["blocking"]
    # 每股盈餘數字與主旨不一致
    eps = _raw2(_case_on("20260716"))
    listing, details = _all_details({"20260716": eps.replace("每股盈餘為新台幣27.25元".encode(), "每股盈餘為新台幣27.52元".encode(), 1)})
    r = cutoff_candidates(listing, "2026Q2", details=details)
    assert any("每股盈餘與主旨不一致" in b for b in r["blocking"]), r["blocking"]
    # 董事會財報的報導期間不是該季
    board = _raw2(_case_on("20260811"))
    listing, details = _all_details({"20260811": board.replace("115/01/01~115/06/30".encode(), "115/01/01~115/03/31".encode(), 1)})
    r = cutoff_candidates(listing, "2026Q2", details=details)
    assert any("報導期間終點" in b for b in r["blocking"]), r["blocking"]
    # 少一份詳細頁
    listing, details = _all_details()
    details.pop("t05st01:2330:20260716:151231:1")
    r = cutoff_candidates(listing, "2026Q2", details=details)
    assert any("尚未取得核對" in b for b in r["blocking"]), r["blocking"]


# ---------------------------------------------------------------- v4.12：財報申報（電子資料查詢 t57sb01）

from mops_t57sb01 import parse_t57sb01_listing  # noqa: E402

FIX3 = os.path.join(HERE, "contract", "mops_real", "run_39100629571")
MANIFEST3 = json.load(open(os.path.join(FIX3, "manifest.json"), encoding="utf-8"))
C3 = {c["name"]: c for c in MANIFEST3["cases"]}


def _filings(data=None, name="t57sb01_2330_115_list_get", **over):
    c = C3[name]
    args = dict(response_bytes=open(os.path.join(FIX3, c["response_file"]), "rb").read() if data is None else data,
                content_type=c["content_type"], request_url=c["request_url"], expected_co_id="2330",
                expected_roc_year="115", expected_company_name="台積電",
                retrieved_at=datetime.fromisoformat(c["retrieved_at"]),
                reported_sha256=c["response_sha256"] if data is None else None)
    args.update(over)
    return parse_t57sb01_listing(**args)


def _raw3(name="t57sb01_2330_115_list_get"):
    return open(os.path.join(FIX3, C3[name]["response_file"]), "rb").read()


def test_v412_fixture_integrity():
    for c in MANIFEST3["cases"]:
        assert hashlib.sha256(_raw3(c["name"])).hexdigest() == c["response_sha256"], c["name"]
    assert hashlib.sha256(open(os.path.join(FIX3, "probe_report.json"), "rb").read()).hexdigest() == MANIFEST3["probe_report_sha256"]
    assert all("charset=big5" in c["content_type"] for c in MANIFEST3["cases"])


def test_v412_filing_listing_real():
    lst, f = _filings()
    assert not f, f
    got = [(r.fiscal_quarter, r.filename, r.uploaded_at.isoformat()) for r in lst.rows]
    assert got == [("2026Q1", "202601_2330_AI1.pdf", "2026-05-15T14:43:02+08:00"),
                   ("2026Q1", "202601_2330_AIA.pdf", "2026-05-15T14:43:22+08:00"),
                   ("2026Q2", "202602_2330_AI1.pdf", "2026-08-14T13:59:44+08:00"),
                   ("2026Q2", "202602_2330_AIA.pdf", "2026-08-14T14:00:15+08:00")], got
    assert lst.filings_for("2026Q3") == []


def test_v412_no_data_page_is_not_evidence_of_no_filing():
    """實測：加了 dtype=A02 就回「查無所需資料」，但其實有申報檔。這種回應不能當成沒有申報。"""
    for name in ("t57sb01_2330_115_dtypeA02_get", "t57sb01_2330_115_dtypeA02_post"):
        lst, f = _filings(name=name)
        assert lst is None and _codes(f) == {RC.ANNOUNCEMENT_EVIDENCE_UNAVAILABLE}, f
    lst, f = _filings(name="t57sb01_form")
    assert lst is None and _codes(f) == {RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN}


def test_v412_filing_tampering_fails_closed():
    raw = _raw3()
    big5 = lambda s: s.encode("big5")
    lst, f = _filings(data=raw.replace(b"14:43:02", b"14:43:03", 1), reported_sha256=C3["t57sb01_2330_115_list_get"]["response_sha256"])
    assert RC.ANNOUNCEMENT_HASH_MISMATCH in _codes(f)
    lst, f = _filings(content_type="text/html; charset=utf-8")
    assert _codes(f) == {RC.ANNOUNCEMENT_CONTENT_MISMATCH}
    lst, f = _filings(expected_company_name="聯電")
    assert _codes(f) == {RC.ANNOUNCEMENT_ISSUER_MISMATCH}
    lst, f = _filings(expected_roc_year="114")
    assert _codes(f) == {RC.ANNOUNCEMENT_CONTENT_MISMATCH}
    # 更補正欄位不是「無」
    assert raw.count(big5("<td align='center'>無</td>")) == 4
    lst, f = _filings(data=raw.replace(big5("<td align='center'>無</td>"), big5("<td align='center'>有</td>"), 1))
    # v4.22：逐列處理 → 該列不採用、列入 uncertain，只阻擋該列的季度（不再讓整份清單失效）
    assert not f and len(lst.rows) == 3 and len(lst.uncertain) == 1 and "更(補)正" in lst.uncertain[0]["reason"], (f, lst)
    # 檔名的季別與資料年度不符
    lst, f = _filings(data=raw.replace(b'"202602_2330_AI1.pdf");\'>202602_2330_AI1.pdf', b'"202603_2330_AI1.pdf");\'>202603_2330_AI1.pdf', 1))
    assert any("檔名" in m for _, m in f), f
    # 上傳時間無效
    lst, f = _filings(data=raw.replace(b"115/08/14 13:59:44", b"115/08/34 13:59:44", 1))
    assert _codes(f) == {RC.ANNOUNCEMENT_TIME_UNVERIFIED}
    # 表頭改動
    lst, f = _filings(data=raw.replace(big5("<th>上傳日期</th>"), big5("<th>日期</th>"), 1))
    assert _codes(f) == {RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN}
    # 非官方網址
    lst, f = _filings(request_url="https://doc.example.com/server-java/t57sb01")
    assert RC.ANNOUNCEMENT_SOURCE_NOT_OFFICIAL in _codes(f)


def test_v412_cutoff_verified_with_all_official_evidence():
    """詳細頁＋財報申報＋人工確認的未分類公告：2026Q2、Q3 的截止點證據完整。"""
    listing, details = _all_details()
    filings, f = _filings()
    assert not f
    q2_reviewed = {"t05st01:2330:20260702:173613:1", "t05st01:2330:20260708:193435:1"}
    q2 = cutoff_candidates(listing, "2026Q2", details=details, filings=filings, reviewed_non_results=q2_reviewed)
    assert q2["status"] == "CUTOFF_VERIFIED" and q2["blocking"] == [], q2["blocking"]
    assert q2["earliest"]["at"] == datetime(2026, 7, 13, 13, 50, 31, tzinfo=TPE)
    assert q2["event_types_found"] == ["board_approved_financials", "financial_report", "investor_conference",
                                       "quarter_revenue_complete", "self_reported_results"]
    fr = [e for e in q2["events"] if e["event_type"] == "financial_report"][0]
    assert fr["at"] == datetime(2026, 8, 14, 13, 59, 44, tzinfo=TPE)
    # 第三季尚未申報：清單取得時間（10/18）晚於最早事件（10/08），可確定申報不會更早
    q3 = cutoff_candidates(listing, "2026Q3", details=details, filings=filings)
    assert q3["status"] == "CUTOFF_VERIFIED" and q3["blocking"] == [], q3["blocking"]
    assert q3["financial_report_status"].startswith("not filed as of 2026-10-18")
    assert q3["earliest"]["at"] == datetime(2026, 10, 8, 13, 54, 4, tzinfo=TPE)
    # 沒有人工確認未分類公告：第二季仍是 PROVISIONAL
    q2u = cutoff_candidates(listing, "2026Q2", details=details, filings=filings)
    assert q2u["status"] == "PROVISIONAL" and any("需人工確認" in b for b in q2u["blocking"])


def test_v412_not_yet_filed_needs_late_enough_listing():
    listing, details = _all_details()
    early = datetime(2026, 10, 1, tzinfo=TPE)   # 假設清單在最早事件（10/08）之前取得
    filings, f = _filings(retrieved_at=early)
    q3 = cutoff_candidates(listing, "2026Q3", details=details, filings=filings)
    assert q3["status"] == "PROVISIONAL" and any("無法排除更早的申報" in b for b in q3["blocking"]), q3["blocking"]
    filings, f = _filings(retrieved_at=None)
    q3 = cutoff_candidates(listing, "2026Q3", details=details, filings=filings)
    assert any("沒有取得時間" in b for b in q3["blocking"])
    # 年度不符的財報清單不能拿來證明
    filings, f = _filings()
    q4 = cutoff_candidates(listing, "2025Q4", details=details, filings=filings)
    assert any("不是 2330 2025Q4" in b for b in q4["blocking"]), q4["blocking"]


# ---------------------------------------------------------------- v4.14：跨年度

def test_v414_merge_listings():
    import dataclasses
    from mops_t05st01 import merge_listings
    full, _ = _parse("all")
    fake114 = dataclasses.replace(full, roc_year=114, items=[dataclasses.replace(it, document_id=it.document_id + "-114")
                                                             for it in full.items[:3]])
    m = merge_listings([full, fake114])
    assert str(m.range_start) == "2025-01-01" and str(m.range_end) == "2026-12-31" and len(m.items) == 156
    assert m.items[0].document_id.endswith("-114"), "依年度排序，114 年在前"
    for bad in ([full, dataclasses.replace(fake114, roc_year=113)], [full, full], []):
        try:
            merge_listings(bad)
            raise AssertionError(f"應拒絕：{[x.roc_year for x in bad]}")
        except ValueError:
            pass

if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
