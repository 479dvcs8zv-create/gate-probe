"""
test_run_2454_39133967342.py (v4.22)
====================================
第一次跨標的實跑：聯發科 2454（gate-probe run 39133967342，collector 4.21）。
v4.21 時解析器只認得台積電的寫法，結果「全部暫定、認不出任何事件」— 正確阻擋，沒有錯誤通過。
v4.22 依這次取得的真實主旨加入聯發科的寫法，離線重算確認：
  - 認得：季末月營收（自結合併營收淨額公告）、季報結果、董事會通過財報、財報說明會、財務預測公告
  - 代子公司公告、參與機構投資人說明會、董事會召開日期預告 → 都不被當成財務事件
  - 截止點 = 季末月營收公告（每月 10 日前後 16:55）；仍是暫定，因為這次沒有取得詳細頁（核對前不放行）
  - 新格式（聯發科自寫的營收、結果說明）在用真實詳細頁建立核對規則之前，一律不放行
  - 財報清單：113 年第四季英文版個體財報的「更(補)正」欄位空白 → 只阻擋 2024Q4，其他季照常使用

  python test_run_2454_39133967342.py
"""
import dataclasses
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
from mops_t05st01 import classify, detail_events, is_forecast_announcement, parse_t05st01_listing  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_2454_39133967342")
MANIFEST = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))


def _items():
    out = []
    for r in MANIFEST["requests"]:
        if r["kind"] == "t05st01_listing":
            lst, f = parse_t05st01_listing(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                           r["request_url"], "2454", r["params"]["roc_year"], "", r["response_sha256"])
            assert lst and lst.company_name == "聯發科", f
            out.extend(lst.items)
    return out


ITEMS = _items()


def test_round1_was_correctly_blocked():
    """v4.21 實跑當時：認不出任何事件、全部暫定（正確阻擋）。"""
    s = json.load(open(os.path.join(RUN, "summary.json"), encoding="utf-8"))
    assert MANIFEST["collector_version"] == "4.21-collect"
    assert s["recognition"]["events_recognized"] == {} and s["detail_counts"]["wanted"] == 0
    assert all(v["status"] == "PROVISIONAL" for v in s["quarters"].values()) and len(s["quarters"]) == 11
    assert {y: v.get("items") for y, v in s["listings"].items()} == {"113": 112, "114": 96, "115": 102}


def test_mediatek_formats_recognized():
    s = ce.replay(RUN, REVIEWS)
    assert s["recognition"]["events_recognized"] == {
        "quarter_revenue_complete": 12, "investor_conference": 12, "self_reported_results": 11,
        "board_approved_financials": 11, "financial_forecast": 11}, s["recognition"]
    by = {}
    for it in ITEMS:
        for e in classify(it):
            by.setdefault((e["fiscal_quarter"], e["event_type"]), []).append((it.subject, e))
    assert by[("2025Q1", "quarter_revenue_complete")][0][0] == "聯發科技114年3月份自結合併營收淨額公告"
    assert by[("2024Q4", "self_reported_results")][0][0] == "本公司2024年第4季與2024全年合併財務報告"
    assert by[("2024Q4", "investor_conference")][0][1]["at"].isoformat() == "2025-02-07T00:00:00+08:00"
    assert by[("2025Q2", "board_approved_financials")][0][0] == "公告本公司114年第2季合併財務報告業經董事會決議通過"
    assert all(e["format"] == "mtk" for v in by.values() for _, e in v)


def test_non_events_are_not_classified():
    for it in ITEMS:
        s = it.subject
        if s.startswith(("代", "(補充")) or "參與機構投資人說明會" in s or "董事會預計召開日期" in s \
                or "董事會召開日期" in s or "財務預測公告" in s:
            assert classify(it) == [], s
    fc = {is_forecast_announcement(it) for it in ITEMS if is_forecast_announcement(it)}
    assert "2024Q2" in fc and "2026Q3" in fc and len(fc) == 11


def test_cutoffs_are_revenue_reports_but_blocked_until_details_verified():
    s = ce.replay(RUN, REVIEWS)
    for q, v in s["quarters"].items():
        assert v["status"] == "PROVISIONAL", q
        assert v["earliest"]["event_type"] == "quarter_revenue_complete", q
        assert any("公告詳細頁尚未取得核對" in b for b in v["blocking"]), (q, v["blocking"])
    assert s["quarters"]["2025Q1"]["earliest"]["at"] == "2025-04-10T16:55:54+08:00"
    assert any("202404_2454_AIC.pdf" in b for b in s["quarters"]["2024Q4"]["blocking"])
    assert not any("更(補)正" in b for b in s["quarters"]["2024Q3"]["blocking"])
    assert len(s["filings"]["113"]["rows"]) == 9 and len(s["filings"]["113"]["uncertain"]) == 1
    g = s["guidance"]
    assert g["gate"]["verified_quarters"] == 0 and g["gate_result"]["status"] == "not_connected"


def test_new_format_details_must_match():
    """（v4.23 起已有聯發科核對規則）說明內容跟主旨的年月／季度對不上 → 不放行。"""
    from mops_t05st01 import T05st01Detail
    rev = [it for it in ITEMS if it.subject == "聯發科技114年3月份自結合併營收淨額公告"][0]
    res = [it for it in ITEMS if it.subject == "本公司2025年第1季合併財務報告"][0]
    for it in (rev, res):
        det = T05st01Detail(it.document_id, it.seq_no, it.announced_at, it.subject, "51", it.announced_at.date(),
                            "（任意內容）", "", "", "https://mopsov.twse.com.tw/mops/web/ajax_t05st01", "0" * 64)
        ev, fails = detail_events(it, det)
        assert ev == [] and fails and "與主旨不一致" in fails[0][1], (it.subject, fails)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
