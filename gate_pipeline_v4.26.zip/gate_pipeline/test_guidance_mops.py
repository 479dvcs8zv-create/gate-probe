"""
test_guidance_mops.py (v4.19)
=============================
Gate5B 官方財測模式：用 gate-probe run 39114411258 的真實官方詳細頁（contract/mops_real/run_39114411258）測試。
  - 每股盈餘公告的實際結果與下一季財測解析（含「美金」「188億7千萬」「467.2億」等真實寫法）
  - 11 季都由「上一季公告的財測」對「這一季公告的實際結果」，且財測早於官方截止點
  - 財測晚於截止點、缺財測公告、截止點前有疑似更新展望的公告、季度只有暫定截止點 → 都不算已驗證
  - 解析失敗（區間顛倒、目標季度不對、欄位缺漏）→ 不採用該部分
  - 原始回應被改動 → 雜湊不符 → 該則不採用

  python test_guidance_mops.py
"""
import dataclasses
import json
import os
import shutil
import sys
import tempfile
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import guidance_mops as gm  # noqa: E402
from gates import eval_gate5b_official_guidance  # noqa: E402
from mops_t05st01 import parse_t05st01_detail, parse_t05st01_listing  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_39114411258")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))


def _load():
    m = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
    listings = {}
    for r in m["requests"]:
        if r["kind"] == "t05st01_listing" and r["response_file"]:
            lst, _ = parse_t05st01_listing(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                           r["request_url"], "2330", r["params"]["roc_year"], "", r["response_sha256"])
            if lst:
                listings[int(r["params"]["roc_year"])] = lst
    ml = list(ce._merge_runs(listings).values())[0]
    by = {it.document_id: it for it in ml.items}
    details = {}
    for r in m["requests"]:
        if r["kind"] == "t05st01_detail" and r.get("parsed"):
            it = by[r["params"]["document_id"]]
            d, _ = parse_t05st01_detail(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                        r["request_url"], it, r["response_sha256"])
            if d:
                details[it.document_id] = d
    s = ce.replay(RUN, REVIEWS)
    cut = {q: datetime.fromisoformat(v["earliest"]["at"]) for q, v in s["quarters"].items()
           if v["status"] == "CUTOFF_VERIFIED"}
    return ml.items, details, cut


ITEMS, DETAILS, CUT = _load()
JAN24 = "t05st01:2330:20240118:154253:1"
OCT26 = "t05st01:2330:20261015:152138:1"


def test_parse_real_announcements():
    p, f = gm.parse_eps_announcement(DETAILS[JAN24].description)   # 「若以美金計算」、「今（18）公佈」
    assert not f and p["reported_quarter"] == "2023Q4"
    assert p["actual"] == {"revenue_usd_bn": 19.62, "gross_margin_pct": 53.0, "operating_margin_pct": 41.6,
                           "eps_twd": 9.21, "eps_adr_usd": 1.44}, p["actual"]
    assert p["guidance"] == {"target_quarter": "2024Q1", "revenue_usd_bn": [18.0, 18.8], "gross_margin_pct": [52.0, 54.0],
                             "operating_margin_pct": [40.0, 42.0], "fx_twd_per_usd": 31.1}, p["guidance"]
    p, f = gm.parse_eps_announcement(DETAILS[OCT26].description)   # 「營收為467.2億」
    assert p["reported_quarter"] == "2026Q3" and p["actual"]["revenue_usd_bn"] == 46.72
    assert p["actual"]["eps_twd"] == 29.43 and p["actual"]["eps_adr_usd"] == 4.60
    assert p["guidance"]["target_quarter"] == "2026Q4" and p["guidance"]["revenue_usd_bn"] == [52.3, 54.3]


def _window_missing(g):
    return {q: e["window"]["missing_detail"] for q, e in g["quarters"].items() if e.get("window")}


def _filled(details, g, extra=None):
    """合成測試資料：把財測期間缺原文的公告補上一份「沒有財測內容」的假原文，只用來測判定邏輯。
    真實資料要等 v4.19 蒐證把每一則原文都抓到。"""
    base = next(iter(details.values()))
    out = dict(details)
    for ids in _window_missing(g).values():
        for doc in ids:
            out[doc] = dataclasses.replace(base, document_id=doc, description="（合成測試資料）一般公告")
    out.update(extra or {})
    return out


EARTHQUAKE_0405 = "t05st01:2330:20240405:212303:1"


def test_current_evidence_window_is_incomplete():
    """目前的真實證據只抓了財務事件與待審公告的原文：財測期間還有很多則沒有原文 → 每季都不能算已驗證。"""
    g = gm.evaluate_guidance(ITEMS, DETAILS, CUT)
    assert g["data_mode"] == "OFFICIAL_GUIDANCE" and g["gate"]["result"] == "INSUFFICIENT"
    for q, e in g["quarters"].items():
        assert e["status"] == "GUIDANCE_WINDOW_INCOMPLETE" and e["reject_code"] == "GUIDANCE_WINDOW_INCOMPLETE", q
        assert e["window"]["missing_detail"] and e["guidance"]["target_quarter"] == q, q
        assert datetime.fromisoformat(e["guidance"]["announced_at"]) < CUT[q], q   # 財測早於截止點
    assert len(g["quarters"]["2024Q1"]["window"]["missing_detail"]) > 30
    # 4/5 地震更新（全年展望維持）已有原文 → 已被標記待確認
    flagged = [x["document_id"] for x in g["quarters"]["2024Q1"]["window"]["flagged"]]
    assert flagged == [EARTHQUAKE_0405], flagged
    r = eval_gate5b_official_guidance(g)
    assert r.status == "insufficient" and "GUIDANCE_WINDOW_INCOMPLETE" in r.reject_codes and r.evidence_count == 0


def test_all_eleven_quarters_when_window_complete():
    g0 = gm.evaluate_guidance(ITEMS, DETAILS, CUT)
    details = _filled(DETAILS, g0)
    g = gm.evaluate_guidance(ITEMS, details, CUT)
    assert g["quarters"]["2024Q1"]["status"] == "GUIDANCE_UPDATE_REVIEW_PENDING"     # 4/5 待人工確認
    assert g["gate"]["verified_quarters"] == 10 and g["gate"]["result"] == "OFFICIAL_GUIDANCE_VERIFIED"
    g = gm.evaluate_guidance(ITEMS, details, CUT, guidance_reviews={"2024Q1": {EARTHQUAKE_0405}})
    assert g["gate"]["verified_quarters"] == 11 and g["parse_failures"] == [], g["parse_failures"]
    q1 = g["quarters"]["2024Q1"]
    assert q1["window"]["cleared_by_review"][0]["document_id"] == EARTHQUAKE_0405
    assert q1["guidance"]["document_id"] == JAN24 and q1["guidance"]["issued_with_results_of"] == "2023Q4"
    assert q1["actual"]["revenue_usd_bn"] == 18.87 and q1["verdicts"] == {
        "revenue_usd_bn": "ABOVE", "gross_margin_pct": "WITHIN", "operating_margin_pct": "WITHIN"}
    for q, e in g["quarters"].items():
        assert e["status"] == "VERIFIED" and e["data_mode"] == "OFFICIAL_GUIDANCE", (q, e["status"])
        assert gm.next_quarter(e["guidance"]["issued_with_results_of"]) == q
        assert datetime.fromisoformat(e["actual"]["announced_at"]) > CUT[q], q
    assert g["quarters"]["2026Q3"]["verdicts"] == {"revenue_usd_bn": "ABOVE", "gross_margin_pct": "WITHIN",
                                                   "operating_margin_pct": "ABOVE"}
    r = eval_gate5b_official_guidance(g)
    assert r.status == "official_guidance_verified" and r.status != "pass" and r.evidence_count == 11
    assert r.gate_name.startswith("Gate5B_官方財測") and all(x["data_mode"] == "OFFICIAL_GUIDANCE" for x in r.evidence_trail)
    md = gm.markdown(g)
    assert "不是市場共識" in md and "| 2024Q1 | 已驗證 | 營收 18–18.8（十億美元） → 18.87 高於" in md, md


def test_guidance_signals():
    conf = [d for d in DETAILS.values() if "法人說明會" in d.subject][0]
    assert gm.guidance_signals(conf.subject, conf.description) == []      # 「將公布…業績展望」的法說會通知不算
    assert gm.guidance_signals(DETAILS[EARTHQUAKE_0405].subject, DETAILS[EARTHQUAKE_0405].description)
    assert gm.guidance_signals("台積公司調整第二季財測", "")
    assert gm.guidance_signals("說明", "第二季營收預計介於200億美元到210億美元之間")
    assert gm.guidance_signals("TSMC update", "the company will maintain its full-year outlook")
    assert not gm.guidance_signals("本公司代子公司 TSMC Global Ltd. 公告取得固定收益證券", "交易標的：美國公債")


def test_guidance_after_cutoff_is_rejected():
    cut = dict(CUT, **{"2024Q1": datetime.fromisoformat("2024-01-18T15:00:00+08:00")})   # 財測 15:42 才發布
    g = gm.evaluate_guidance(ITEMS, DETAILS, cut)
    assert g["quarters"]["2024Q1"]["status"] == "GUIDANCE_AFTER_CUTOFF"
    assert g["quarters"]["2024Q1"]["reject_code"] == "GUIDANCE_AFTER_CUTOFF"


def test_missing_guidance_announcement():
    d = {k: v for k, v in DETAILS.items() if k != JAN24}
    g = gm.evaluate_guidance(ITEMS, d, CUT)
    assert g["quarters"]["2024Q1"]["status"] == "MISSING_GUIDANCE"
    assert {"document_id": JAN24, "reason": "詳細頁未取得"} in g["parse_failures"]


def test_guidance_update_in_body_needs_review():
    """主旨看不出來、但原文提到更新財測 → 一樣要人工確認（不依主旨略過）。"""
    g0 = gm.evaluate_guidance(ITEMS, DETAILS, CUT)
    doc = g0["quarters"]["2024Q3"]["window"]["missing_detail"][0]
    base = next(iter(DETAILS.values()))
    sneaky = dataclasses.replace(base, document_id=doc,
                                 description="（合成測試資料）本公司說明：第三季營收預計介於230億美元到238億美元之間")
    details = _filled(DETAILS, g0, extra={doc: sneaky})
    g = gm.evaluate_guidance(ITEMS, details, CUT, guidance_reviews={"2024Q1": {EARTHQUAKE_0405}})
    e = g["quarters"]["2024Q3"]
    assert e["status"] == "GUIDANCE_UPDATE_REVIEW_PENDING" and e["window"]["flagged"][0]["document_id"] == doc, e
    assert g["gate"]["verified_quarters"] == 10


def test_malformed_texts_are_not_used():
    good = DETAILS[JAN24].description
    p, _ = gm.parse_eps_announcement(good.replace("180億美元到188億美元", "188億美元到180億美元"))
    assert p["guidance"] is None and "下緣大於上緣" in p["guidance_failures"][0]
    p, _ = gm.parse_eps_announcement(good.replace("2024年第一季的業績展望", "2024年第二季的業績展望"))
    assert p["guidance"] is None and "不是下一季" in p["guidance_failures"][0]
    p, _ = gm.parse_eps_announcement(good.replace("毛利率預計介於52%到54%之間", "毛利率另行公布"))
    assert p["guidance"] is None and "解析不完整" in p["guidance_failures"][0]
    p, _ = gm.parse_eps_announcement(good.replace("營業利益率為41.6%", "營業利益率另計"))
    assert p["actual"] is None and p["guidance"] is not None        # 實際結果缺欄位不影響財測
    p, f = gm.parse_eps_announcement("本公司今日召開董事會")
    assert p is None and f


def test_only_verified_cutoffs_are_used_and_gate_threshold():
    partial = {k: v for k, v in REVIEWS.items() if k != ("2330", "2024Q3")}
    s = ce.replay(RUN, partial)
    g = s["guidance"]
    assert "2024Q3" not in g["quarters"] and g["provisional_quarters_excluded"] == ["2024Q3"]
    assert g["gate_result"]["status"] == "insufficient"
    g0 = gm.evaluate_guidance(ITEMS, DETAILS, CUT)
    details = _filled(DETAILS, g0)
    few = {q: CUT[q] for q in sorted(CUT)[1:8]}          # 7 季（不含需人工確認的 2024Q1）
    g = gm.evaluate_guidance(ITEMS, details, few)
    assert g["gate"]["verified_quarters"] == 7 and g["gate"]["result"] == "INSUFFICIENT"
    assert eval_gate5b_official_guidance(g).status == "insufficient"
    assert eval_gate5b_official_guidance({}).status == "not_connected"
    bad = {"quarters": {"2024Q2": dict(g["quarters"]["2024Q2"], data_mode="MARKET_CONSENSUS")}}
    r = eval_gate5b_official_guidance(bad)
    assert r.evidence_count == 0 and "GUIDANCE_PARSE_FAILED" in r.reject_codes


def test_tampered_guidance_response_is_rejected():
    m = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
    rec = [r for r in m["requests"] if r["kind"] == "t05st01_detail" and r["params"]["document_id"] == JAN24
           and r.get("parsed")][0]
    tmp = tempfile.mkdtemp(prefix="guidance_tamper_")
    try:
        dst = os.path.join(tmp, "run")
        shutil.copytree(RUN, dst)
        path = os.path.join(dst, rec["response_file"])
        data = open(path, "rb").read()
        open(path, "wb").write(data.replace("180億美元".encode(), "170億美元".encode()))
        s = ce.replay(dst, REVIEWS)
        assert s["guidance"]["quarters"]["2024Q1"]["status"] == "MISSING_GUIDANCE", s["guidance"]["quarters"]["2024Q1"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
