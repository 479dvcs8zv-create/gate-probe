"""
test_gate5b_mops.py (v4.13)
===========================
Gate5B 端對端：官方公告時間改用公開資訊觀測站的真實回應（contract/mops_real，離線重播）。

注意：共識快照的封存證據包仍是「合成」的（FakeIndependentVerifier，網址也是測試用），
這裡驗證的是「Gate5B 判定引擎會採用真實官方截止點」，不是任何真實共識資料。

  python test_gate5b_mops.py
"""
import copy
import dataclasses
import os

from announcement_verification import verify_earnings_announcement
from gates import VERIFIED_TIERS, eval_gate5b_pre_earnings
from mops_evidence import RecordedMopsVerifier, load_recorded_2330_115, verify_mops_evidence_bundle
from reject_codes import RC
from schema import TickerInputBundle
from test_adversarial import FakeIndependentVerifier, make_verified_snapshot

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(HERE, "contract", "mops_real")


def _recorded(with_review=True):
    bundle, reviews = load_recorded_2330_115(BASE)
    return bundle, RecordedMopsVerifier({("2330", "115"): bundle}, reviews if with_review else {})


def _codes(fails):
    return {c for c, _ in fails}


# ---------------------------------------------------------------- 官方截止點（公告層）

def test_cutoff_from_real_mops_evidence():
    _, v = _recorded()
    q2 = verify_earnings_announcement("2330", "2026Q2", verifier=v)
    assert q2["ok"], q2["failures"]
    assert q2["cutoff"]["iso"] == "2026-07-13T13:50:31+08:00" and q2["cutoff"]["event_type"] == "quarter_revenue_complete"
    assert q2["trace"]["review"]["document_ids"] == ["t05st01:2330:20260702:173613:1", "t05st01:2330:20260708:193435:1"]
    assert q2["trace"]["monthly_cross_checked"] == ["07", "08"]
    q3 = verify_earnings_announcement("2330.TW", "2026Q3", verifier=v)
    assert q3["ok"], q3["failures"]
    assert q3["cutoff"]["iso"] == "2026-10-08T13:54:04+08:00"
    assert q3["trace"]["financial_report_status"].startswith("not filed as of")
    types = [e["event_type"] for e in q2["trace"]["events"]]
    assert types == ["quarter_revenue_complete", "investor_conference", "self_reported_results",
                     "board_approved_financials", "financial_report"], types


def test_review_record_is_required_for_q2():
    _, v = _recorded(with_review=False)
    q2 = verify_earnings_announcement("2330", "2026Q2", verifier=v)
    assert not q2["ok"] and _codes(q2["failures"]) == {RC.ANNOUNCEMENT_REVIEW_PENDING}, q2["failures"]
    q3 = verify_earnings_announcement("2330", "2026Q3", verifier=v)
    assert q3["ok"], "第三季沒有未分類公告，不需要人工審查"
    # 審查紀錄缺欄位：不採用，而且明確報錯
    bundle, reviews = load_recorded_2330_115(BASE)
    bad = copy.deepcopy(reviews[("2330", "2026Q2")])
    bad.pop("reviewer")
    v2 = RecordedMopsVerifier({("2330", "115"): bundle}, {("2330", "2026Q2"): bad})
    r = verify_earnings_announcement("2330", "2026Q2", verifier=v2)
    assert not r["ok"] and RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE in _codes(r["failures"])


def test_wrong_company_or_year_or_missing_evidence():
    _, v = _recorded()
    r = verify_earnings_announcement("2303", "2026Q2", verifier=v)
    assert not r["ok"] and _codes(r["failures"]) == {RC.ANNOUNCEMENT_EVIDENCE_UNAVAILABLE}
    r = verify_earnings_announcement("2330", "2025Q4", verifier=v)
    assert not r["ok"] and _codes(r["failures"]) == {RC.ANNOUNCEMENT_EVIDENCE_UNAVAILABLE}
    bundle, reviews = load_recorded_2330_115(BASE)
    r = verify_mops_evidence_bundle(bundle, "2303", "2026Q2")
    assert _codes(r["failures"]) == {RC.ANNOUNCEMENT_ISSUER_MISMATCH}
    r = verify_mops_evidence_bundle(dataclasses.replace(bundle, filings=None), "2330", "2026Q3")
    assert not r["ok"] and RC.ANNOUNCEMENT_COVERAGE_INCOMPLETE in _codes(r["failures"])
    r = verify_mops_evidence_bundle(dataclasses.replace(bundle, details=bundle.details[:-1]), "2330", "2026Q3")
    assert not r["ok"] and any("詳細頁尚未取得" in m for _, m in r["failures"]), r["failures"]


def test_tampered_recorded_evidence_fails_closed():
    bundle, reviews = load_recorded_2330_115(BASE)
    d = bundle.details[2]   # 7/16 EPS 詳細頁
    bad = dataclasses.replace(d, response_bytes=d.response_bytes.replace(b"27.25", b"27.26", 1))
    tampered = dataclasses.replace(bundle, details=bundle.details[:2] + [bad] + bundle.details[3:])
    r = verify_earnings_announcement("2330", "2026Q2", verifier=RecordedMopsVerifier({("2330", "115"): tampered}, reviews))
    assert not r["ok"] and RC.ANNOUNCEMENT_HASH_MISMATCH in _codes(r["failures"]), r["failures"]
    L = bundle.listing
    bad_listing = dataclasses.replace(L, request_url="https://mops-mirror.example.com/mops/web/ajax_t05st01")
    r = verify_mops_evidence_bundle(dataclasses.replace(bundle, listing=bad_listing), "2330", "2026Q3")
    assert RC.ANNOUNCEMENT_SOURCE_NOT_OFFICIAL in _codes(r["failures"])
    fl = bundle.filings
    r = verify_mops_evidence_bundle(dataclasses.replace(bundle, filings=dataclasses.replace(fl, retrieved_at="")),
                                    "2330", "2026Q3")
    assert RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE in _codes(r["failures"])


# ---------------------------------------------------------------- Gate5B 判定引擎（合成共識快照）

def _gate5b_trail(captures):
    """captures: [(fiscal_quarter, 封存時間)]。回傳 {(季, 封存時間): (final_tier, reject_codes)}。"""
    fake = FakeIndependentVerifier()
    _, recorded = _recorded()
    snaps = [make_verified_snapshot(fake, "2330", q, cap, "2026-12-31T00:00:00+08:00", 10.0 + i)
             for i, (q, cap) in enumerate(captures)]
    tb = TickerInputBundle(ticker="2330")
    tb.pre_earnings_snapshots = snaps
    res = eval_gate5b_pre_earnings(tb, verifier=fake, announcement_verifier=recorded)
    return res, recorded


def test_gate5b_uses_real_official_cutoff():
    cases = [("2026Q2", "2026-07-13T13:00:00+08:00"),   # 6 月營收公布前 → 財報前
             ("2026Q2", "2026-07-13T14:00:00+08:00"),   # 營收公布後 10 分鐘 → 已不是財報前
             ("2026Q3", "2026-10-08T13:50:00+08:00"),   # 9 月營收公布前 → 財報前
             ("2026Q3", "2026-10-15T14:30:00+08:00")]   # 法說會已開始 → 已不是財報前
    res, recorded = _gate5b_trail(cases)
    tiers = [(t["fiscal_quarter"], t["final_tier"]) for t in res.evidence_trail]
    assert tiers[0][1] in VERIFIED_TIERS and tiers[2][1] in VERIFIED_TIERS, tiers
    assert tiers[1][1] not in VERIFIED_TIERS and tiers[3][1] not in VERIFIED_TIERS, tiers
    assert RC.EVIDENCE_ARCHIVED_AFTER_EARNINGS in res.reject_codes
    # 每個（公司、季度）只查一次官方證據
    assert sorted(set(recorded.calls)) == [("2330", "2026Q2"), ("2330", "2026Q3")] and len(recorded.calls) == 2
    # 只有 2 季真實證據，遠少於 Gate5B 需要的 8 季：不可能 pass
    assert res.status != "pass"


def test_old_eps_time_rule_would_have_been_wrong():
    """7/16 14:30 的快照：用觀測站 EPS 公告時間（15:12:31）當截止點會誤判為財報前；
    改用真實官方證據後（法說會 14:00、營收 7/13 13:50:31）必須擋下。"""
    res, _ = _gate5b_trail([("2026Q2", "2026-07-16T14:30:00+08:00")])
    t = res.evidence_trail[0]
    assert t["final_tier"] not in VERIFIED_TIERS, t["final_tier"]
    assert RC.EVIDENCE_ARCHIVED_AFTER_EARNINGS in res.reject_codes
    # 對照組：同一筆快照，若官方截止點只看 EPS 公告（15:12:31），會被判為財報前
    fake = FakeIndependentVerifier()
    snap = make_verified_snapshot(fake, "2330", "2026Q2", "2026-07-16T14:30:00+08:00", "2026-07-16T15:12:31+08:00", 10.0)
    tb = TickerInputBundle(ticker="2330")
    tb.pre_earnings_snapshots = [snap]
    old = eval_gate5b_pre_earnings(tb, verifier=fake, announcement_verifier=fake)
    assert old.evidence_trail[0]["final_tier"] in VERIFIED_TIERS, "對照組前提：舊規則會放行"


def test_gate5b_blocks_when_review_missing():
    fake = FakeIndependentVerifier()
    bundle, _ = load_recorded_2330_115(BASE)
    recorded = RecordedMopsVerifier({("2330", "115"): bundle}, {})
    snap = make_verified_snapshot(fake, "2330", "2026Q2", "2026-07-13T13:00:00+08:00", "2026-12-31T00:00:00+08:00", 10.0)
    tb = TickerInputBundle(ticker="2330")
    tb.pre_earnings_snapshots = [snap]
    res = eval_gate5b_pre_earnings(tb, verifier=fake, announcement_verifier=recorded)
    assert res.evidence_trail[0]["final_tier"] not in VERIFIED_TIERS
    assert RC.ANNOUNCEMENT_REVIEW_PENDING in res.reject_codes, res.reject_codes


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
