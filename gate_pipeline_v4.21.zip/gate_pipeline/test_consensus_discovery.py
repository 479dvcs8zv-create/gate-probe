"""
test_consensus_discovery.py (v4.17)
===================================
共識預估來源探測（ops/consensus_discovery.py）的離線測試：本機模擬 Wayback 的 CDX 與 id_ 端點。
確認：
  - 只算「截止點之前、window_days 天之內」的存檔：剛好在截止點、截止點之後、窗外的都不算
  - CDX 分頁（resumeKey）會逐頁取完；超過頁數上限標記 truncated
  - 抽樣原文核對封存當下的 SHA-1 摘要；不符時照實記錄 digest_matched=False
  - 503 會重試一次；一直 500 → 記錄錯誤，不中斷其他來源
  - 時間上限到了就停止發出請求並說明
  - 一鍵蒐證主程式：探測連不上也不影響已取得的官方證據（照常寫出 manifest / summary）

  python test_consensus_discovery.py
"""
import base64
import hashlib
import http.server
import json
import os
import shutil
import sys
import tempfile
import threading
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import consensus_discovery as cd  # noqa: E402

CUTOFFS = {"2026Q2": {"at": "2026-07-13T13:50:31+08:00", "status": "CUTOFF_VERIFIED"},
           "2026Q3": {"at": "2026-10-08T13:54:04+08:00", "status": "CUTOFF_VERIFIED"}}
GOOD = b"<html><h1>Earnings Estimate</h1><td>Current Qtr. (Jun 2026)</td><td>EPS</td></html>"
GOOD_Q3 = b"<html><h1>Earnings Estimate</h1><td>Current Qtr. (Sep 2026)</td></html>"
TAMPERED = b"<html>served content differs from the archived digest</html>"


def _digest(b):
    return base64.b32encode(hashlib.sha1(b).digest()).decode()


Y = "finance.yahoo.com/quote/TSM/analysis"
Z = "www.zacks.com/stock/quote/TSM/detailed-earning-estimates"
DATA = {
    Y: [["20260501000000", Y, GOOD],                    # 窗外（截止點前 73 天）
        ["20260601000000", Y + "/", GOOD],              # 窗內
        ["20260713055030", Y + "?p=TSM", GOOD],         # 截止點前 1 秒 → 2026Q2 最新
        ["20260713055031", Y, GOOD],                    # 剛好在截止點 → 不算
        ["20261001000000", Y, GOOD_Q3],                 # 2026Q3 窗內
        ["20261008060000", Y, GOOD_Q3]],                # 2026Q3 截止點之後 → 不算
    Z: [["20260705000000", Z, GOOD]],
}
BODIES = {(ts, orig): body for rows in DATA.values() for ts, orig, body in rows}
BODIES[("20260705000000", Z)] = TAMPERED            # 取回的內容與 CDX 摘要不符
FAIL = {}                                           # prefix -> 依序回傳的錯誤碼
LOG = []


class Wayback(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ct="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urllib.parse.urlsplit(self.path)
        LOG.append(self.path)
        if u.path == "/cdx/search/cdx":
            q = dict(urllib.parse.parse_qsl(u.query))
            codes = FAIL.get(q["url"])
            if codes:
                return self._send(codes.pop(0), b"busy")
            rows = DATA.get(q["url"], [])   # 刻意不依 from/to 過濾：用戶端必須自行排除窗外與截止點之後的存檔
            assert q["from"] < q["to"]
            start = int(q.get("resumeKey", "0"))
            size = int(q["limit"])
            page = rows[start:start + size]
            out = [["timestamp", "original", "statuscode", "digest", "mimetype", "length"]]
            out += [[ts, orig, "200", _digest(body), "text/html", str(len(body))] for ts, orig, body in page]
            if start + size < len(rows):
                out += [[], [str(start + size)]]
            return self._send(200, json.dumps(out).encode())
        if u.path.startswith("/web/"):
            ts, orig = u.path[len("/web/"):].split("id_/", 1)
            orig = orig + (("?" + u.query) if u.query else "")
            body = BODIES.get((ts, orig))
            return self._send(200, body, "text/html") if body else self._send(404, b"no")
        self._send(400, b"bad")


def _sources_file(tmp):
    path = os.path.join(tmp, "sources.json")
    json.dump({"adr_map": {"2330": "TSM"}, "sources": [
        {"id": "yahoo", "vendor": "Yahoo", "prefix": "finance.yahoo.com/quote/{adr}/analysis"},
        {"id": "zacks", "vendor": "Zacks", "prefix": "www.zacks.com/stock/quote/{adr}/detailed-earning-estimates"},
        {"id": "nasdaq", "vendor": "Nasdaq", "prefix": "www.nasdaq.com/market-activity/stocks/{adr_lower}/earnings"},
        {"id": "only_2317", "vendor": "X", "prefix": "x.example/{co_id}", "only": ["2317"]},
        {"id": "tw", "vendor": "TW", "prefix": "tw.example/{co_id}"}]}, open(path, "w"))
    return path


def _run(**kw):
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Wayback)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    tmp = tempfile.mkdtemp(prefix="discovery_")
    old_proxy = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    try:
        args = dict(base_url=f"http://127.0.0.1:{srv.server_address[1]}", delay=0, timeout=5, page_size=2,
                    sources_path=_sources_file(tmp), retry_wait=0)
        args.update(kw)
        r = cd.discover("2330", CUTOFFS, os.path.join(tmp, "out"), **args)
    finally:
        os.environ.update(old_proxy)
        srv.shutdown()
    return tmp, r


def _src(r, sid):
    return [s for s in r["sources"] if s["id"] == sid][0]


def test_window_and_cutoff_boundaries():
    LOG.clear()
    FAIL.clear()
    tmp, r = _run()
    try:
        y = _src(r, "yahoo")
        assert y["cdx"]["pages"] == 3 and y["cdx"]["records"] == 6 and not y["cdx"]["truncated"], y["cdx"]
        q2, q3 = y["quarters"]["2026Q2"], y["quarters"]["2026Q3"]
        assert q2["captures_in_window"] == 2 and q2["latest"]["timestamp"] == "20260713055030", q2
        assert q2["latest"]["original"] == Y + "?p=TSM" and q2["latest"]["hours_before_cutoff"] == 0.0
        assert q3["captures_in_window"] == 1 and q3["latest"]["timestamp"] == "20261001000000", q3
        # 抽樣：最近的季度優先，摘要相符，提示含目標季度寫法
        assert [s["quarter"] for s in y["samples"]] == ["2026Q3", "2026Q2"]
        s3 = y["samples"][0]
        assert s3["digest_matched"] is True and "Sep 2026" in s3["hints"]["quarter_labels"], s3
        data = open(os.path.join(tmp, "out", s3["file"]), "rb").read()
        assert hashlib.sha256(data).hexdigest() == s3["sha256"] and data == GOOD_Q3
        # 只限其他股票的來源不列入；沒有存檔的來源記為 0 季
        assert [s["id"] for s in r["sources"]] == ["yahoo", "zacks", "nasdaq", "tw"]
        assert _src(r, "tw")["quarters"]["2026Q2"]["latest"] is None and _src(r, "tw")["samples"] == []
        # 寫出 discovery.json 與 CDX 原始回應
        saved = json.load(open(os.path.join(tmp, "out", "discovery.json"), encoding="utf-8"))
        assert saved["sources"][0]["cdx"]["files"][0]["file"] == "cdx/yahoo_00.json"
        md = cd.markdown(r)
        assert "| Yahoo `yahoo` | 2/2 |" in md and "| TW `tw` | 0/2 |" in md, md
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_digest_mismatch_is_recorded():
    FAIL.clear()
    tmp, r = _run()
    try:
        z = _src(r, "zacks")
        assert z["quarters"]["2026Q2"]["latest"]["timestamp"] == "20260705000000"
        assert z["samples"][0]["digest_matched"] is False, z["samples"]
        assert "摘要不符" in cd.markdown(r)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_retry_once_then_record_error():
    FAIL.clear()
    FAIL[Z] = [503]                                                  # 第一次 503 → 重試成功
    FAIL["www.nasdaq.com/market-activity/stocks/tsm/earnings"] = [500, 500, 500]   # 一直失敗
    LOG.clear()
    tmp, r = _run()
    try:
        assert _src(r, "zacks")["cdx"]["error"] is None and _src(r, "zacks")["cdx"]["records"] == 1
        n = _src(r, "nasdaq")
        assert "HTTP 500" in n["cdx"]["error"] and n["quarters"]["2026Q2"]["latest"] is None, n["cdx"]
        nasdaq_calls = [p for p in LOG if "nasdaq" in urllib.parse.unquote(p)]
        assert len(nasdaq_calls) == 2, nasdaq_calls                  # 只重試一次
        assert _src(r, "tw")["cdx"]["error"] is None                 # 不影響後面的來源
    finally:
        FAIL.clear()
        shutil.rmtree(tmp, ignore_errors=True)


def test_page_limit_marks_truncated():
    FAIL.clear()
    tmp, r = _run(max_pages=1)
    try:
        y = _src(r, "yahoo")
        assert y["cdx"]["truncated"] is True and y["cdx"]["records"] == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_time_budget_stops_requests():
    FAIL.clear()
    LOG.clear()
    ticks = iter(range(0, 10000, 10))
    tmp, r = _run(time_budget=25, clock=lambda: next(ticks))
    try:
        assert any("探測時間上限" in n for n in r["notes"]), r["notes"]
        assert any(s["cdx"]["error"] == "探測時間上限已到，未發出請求" for s in r["sources"])
        assert r["requests"] <= 3, r["requests"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_classification():
    FAIL.clear()
    FAIL["www.nasdaq.com/market-activity/stocks/tsm/earnings"] = [500, 500]
    tmp, r = _run()
    try:
        out = os.path.join(tmp, "out")
        c = cd.classify(r, out, parsers={})
        assert c["yahoo"]["2026Q2"]["status"] == "UNPARSED" and c["yahoo"]["2026Q3"]["status"] == "UNPARSED"
        assert c["zacks"]["2026Q2"]["status"] == "DIGEST_MISMATCH" and c["zacks"]["2026Q3"]["status"] == "NO_CAPTURE"
        assert c["nasdaq"]["2026Q2"]["status"] == "QUERY_FAILED"       # 查詢失敗 ≠ 沒有存檔
        assert c["tw"]["2026Q3"]["status"] == "NO_CAPTURE"

        def fake_parser(body, q):
            return {"values": {"eps": 1.23}} if b"Sep 2026" in body else {"values": {}}
        c = cd.classify(r, out, parsers={"yahoo": fake_parser})
        assert c["yahoo"]["2026Q3"]["status"] == "CONSENSUS_CANDIDATE" and c["yahoo"]["2026Q2"]["status"] == "NO_CONSENSUS_VALUE"
        # 存檔原文被改動 → 不解析，判為摘要不符
        f = os.path.join(out, [x for x in _src(r, "yahoo")["samples"] if x["quarter"] == "2026Q3"][0]["file"])
        open(f, "ab").write(b"x")
        c = cd.classify(r, out, parsers={"yahoo": fake_parser})
        assert c["yahoo"]["2026Q3"]["status"] == "DIGEST_MISMATCH"
        md = cd.classification_markdown(r, c)
        assert md.splitlines()[0] == "| 來源 | 2026Q2 | 2026Q3 |"
    finally:
        FAIL.clear()
        shutil.rmtree(tmp, ignore_errors=True)
    # 頁數上限 → 沒有存檔的季度判為索引不完整；時間上限 → TIMEOUT；抽樣上限 → NOT_SAMPLED
    tmp, r = _run(max_pages=1, max_samples_per_source=1)
    try:
        c = cd.classify(r)
        # 第一頁只有 5/01（窗外）與 6/01（2026Q2 窗內）：2026Q2 有存檔；2026Q3 沒找到但索引沒取完 → 不能判為沒有存檔
        assert c["yahoo"]["2026Q2"]["status"] == "UNPARSED", c["yahoo"]
        assert c["yahoo"]["2026Q3"]["status"] == "INCOMPLETE_INDEX", c["yahoo"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    tmp, r = _run(max_samples_per_source=1)
    try:
        c = cd.classify(r)
        assert (c["yahoo"]["2026Q3"]["status"], c["yahoo"]["2026Q2"]["status"]) == ("UNPARSED", "NOT_SAMPLED"), c["yahoo"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    ticks = iter(range(0, 10000, 10))
    tmp, r = _run(time_budget=25, clock=lambda: next(ticks))
    try:
        c = cd.classify(r)
        assert any(c[s][q]["status"] == "TIMEOUT" for s in c for q in c[s]), c
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_no_adr_skips_adr_sources():
    tmp = tempfile.mkdtemp()
    try:
        src, skipped, adr = cd.resolve_sources("2317", _sources_file(tmp))
        assert adr is None and [s["id"] for s in src] == ["only_2317", "tw"]
        assert {s["id"] for s in skipped} == {"yahoo", "zacks", "nasdaq"}
        assert src[1]["prefix"] == "tw.example/2317"
        real, _, adr = cd.resolve_sources("2330")
        assert adr == "TSM" and real[0]["prefix"] == "finance.yahoo.com/quote/TSM/analysis"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_collect_main_survives_unreachable_wayback():
    """一鍵蒐證主程式：Wayback 連不上 → 探測記錄錯誤，官方證據照常寫出、結束碼 0。"""
    import test_collect_offline as tco
    import collect_evidence as ce
    from evidence_verification import OFFICIAL_DOMAINS
    srv = tco._Server(("127.0.0.1", 0), tco.Stub)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    netloc = f"127.0.0.1:{srv.server_address[1]}"
    OFFICIAL_DOMAINS.add(netloc)
    tmp = tempfile.mkdtemp(prefix="collect_disc_")
    old_proxy = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    step = os.path.join(tmp, "step.md")
    os.environ["GITHUB_STEP_SUMMARY"] = step
    try:
        import contextlib
        import io
        with contextlib.redirect_stdout(io.StringIO()):
            rc = ce.main(["--co-id", "2330", "--roc-years", "115", "--out", os.path.join(tmp, "r"),
                          "--reviews", os.path.join(HERE, "contract", "mops_real", "reviews"),
                          "--mops-base", f"http://{netloc}", "--doc-base", f"http://{netloc}", "--delay", "0",
                          "--retry-waits", "", "--wayback-base", "http://127.0.0.1:9", "--discovery-time-budget", "1",
                          "--consensus-discovery", "--no-cache"])
        assert rc == 0
        for name in ("manifest.json", "summary.json", "consensus_discovery/discovery.json"):
            assert os.path.exists(os.path.join(tmp, "r", name)), name
        d = json.load(open(os.path.join(tmp, "r", "consensus_discovery", "discovery.json"), encoding="utf-8"))
        assert d["sources"] and all(s["cdx"]["error"] for s in d["sources"])
        assert set(d["cutoffs"]) == {"2026Q1", "2026Q2", "2026Q3"}
        text = open(step, encoding="utf-8").read()
        assert "蒐證結果 2330" in text and "共識來源探測" in text
    finally:
        os.environ.pop("GITHUB_STEP_SUMMARY", None)
        OFFICIAL_DOMAINS.discard(netloc)
        os.environ.update(old_proxy)
        srv.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
