"""
test_collect_offline.py (v4.15)
===============================
一鍵蒐證程式（ops/collect_evidence.py）的離線測試：架一個本機模擬伺服器，回傳 contract/mops_real
裡錄製的「真實官方回應」，確認蒐證流程會正確地抓清單、挑詳細頁、抓財報清單、算截止點，
而且遇到官方拒絕、查無資料、缺詳細頁時照實記錄、fail-closed。

模擬伺服器不是官方網域，所以測試期間暫時把它加進 OFFICIAL_DOMAINS（只在這個測試行程內）。
v4.15：重試（502、逾時、官方拒絕會重試；查無資料、404 不重試）與條款自動排除規則。

  python test_collect_offline.py
"""
import hashlib
import http.server
import json
import os
import shutil
import sys
import tempfile
import threading
import time
import urllib.parse
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))

import collect_evidence as ce  # noqa: E402
from evidence_verification import OFFICIAL_DOMAINS  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
R10 = os.path.join(BASE, "run_39099468097")
R11 = os.path.join(BASE, "run_39100629571")
M10 = json.load(open(os.path.join(R10, "manifest.json"), encoding="utf-8"))
M11 = json.load(open(os.path.join(R11, "manifest.json"), encoding="utf-8"))
LISTING_115 = open(os.path.join(R10, [c for c in M10["cases"] if c["kind"] == "t05st01_query"][0]["response_file"]), "rb").read()
DETAILS = {(c["params"]["spoke_date"], c["params"]["spoke_time"], c["params"]["seq_no"]):
           open(os.path.join(R10, c["response_file"]), "rb").read() for c in M10["cases"] if c["kind"] == "t05st01_detail"}
FILINGS = {c["name"]: open(os.path.join(R11, c["response_file"]), "rb").read() for c in M11["cases"]}
LOG = []
FLAKY = {}   # key -> 依序套用的故障模式清單（"502"、"503"、"timeout"）；用完就恢復正常


def _flaky(key):
    modes = FLAKY.get(key)
    return modes.pop(0) if modes else None


class Stub(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ct):
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        body = self.rfile.read(int(self.headers["Content-Length"])).decode()
        f = dict(urllib.parse.parse_qsl(body, keep_blank_values=True))
        LOG.append(("POST", self.path, f))
        key = ("listing", f.get("year")) if f.get("step") == "1" else ("detail", f.get("spoke_date"), f.get("spoke_time"))
        mode = _flaky(key)
        if mode == "timeout":
            time.sleep(2.5)
            return
        if mode:
            return self._send(int(mode), f"<html>{mode} Bad Gateway</html>".encode(), "text/html")
        if f.get("step") == "1":
            if f.get("year") == "115":
                return self._send(200, LISTING_115, "text/html; charset=UTF-8")
            return self._send(200, "<html>查詢過量，請稍後再查詢</html>".encode("utf-8"), "text/html; charset=UTF-8")
        if f.get("step") == "2":
            d = DETAILS.get((f.get("spoke_date"), f.get("spoke_time"), f.get("seq_no")))
            if d:
                return self._send(200, d, "text/html; charset=UTF-8")
            return self._send(404, b"not recorded", "text/plain")
        self._send(400, b"bad", "text/plain")

    def do_GET(self):
        q = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(self.path).query, keep_blank_values=True))
        LOG.append(("GET", self.path, q))
        name = "t57sb01_2330_115_list_get" if q.get("year") == "115" else "t57sb01_2330_115_dtypeA02_get"
        self._send(200, FILINGS[name], "text/html;charset=big5")


class _Server(http.server.ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):   # 模擬逾時時用戶端已斷線，寫回應會失敗：忽略
        pass


def _run_collect(reviews, retry_waits=(0, 0), timeout=10):
    srv = _Server(("127.0.0.1", 0), Stub)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    netloc = f"127.0.0.1:{srv.server_address[1]}"
    OFFICIAL_DOMAINS.add(netloc)
    out = tempfile.mkdtemp(prefix="collect_test_")
    old_proxy = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    try:
        manifest, summary = ce.collect("2330", [114, 115], out, mops_base=f"http://{netloc}", doc_base=f"http://{netloc}",
                                       delay=0, timeout=timeout, reviews=reviews, today=date(2026, 10, 18),
                                       retry_waits=retry_waits)
    finally:
        OFFICIAL_DOMAINS.discard(netloc)
        os.environ.update(old_proxy)
        srv.shutdown()
    return out, manifest, summary


def test_collect_end_to_end_offline():
    LOG.clear()
    reviews = ce.load_reviews(os.path.join(BASE, "reviews"))
    out, manifest, summary = _run_collect(reviews)
    try:
        # 114 年：官方拒絕 → 照實記錄；115 年：153 筆
        assert summary["listings"]["114"]["failures"][0][0] == "ANNOUNCEMENT_SOURCE_REFUSED", summary["listings"]["114"]
        assert summary["listings"]["115"]["items"] == 153
        # 財報清單：114 年是「查無所需資料」→ 不當成沒有申報；115 年 4 筆
        assert summary["filings"]["114"]["failures"][0][0] == "ANNOUNCEMENT_EVIDENCE_UNAVAILABLE"
        assert len(summary["filings"]["115"]["rows"]) == 4
        # 各季：Q2、Q3 證據齊全；Q1 缺詳細頁（模擬伺服器沒有錄到）→ 暫定
        q = summary["quarters"]
        assert sorted(q) == ["2026Q1", "2026Q2", "2026Q3"], sorted(q)
        assert q["2026Q2"]["status"] == "CUTOFF_VERIFIED" and q["2026Q2"]["earliest"]["at"] == "2026-07-13T13:50:31+08:00", q["2026Q2"]
        assert q["2026Q2"]["review_record"] is True
        assert q["2026Q3"]["status"] == "CUTOFF_VERIFIED" and q["2026Q3"]["earliest"]["at"] == "2026-10-08T13:54:04+08:00"
        assert q["2026Q1"]["status"] == "PROVISIONAL" and any("詳細頁尚未取得" in b for b in q["2026Q1"]["blocking"])
        # 待審公告也會去抓詳細頁（7/02、7/08 在模擬伺服器沒有 → 記錄為失敗，但不影響已有人工審查的 Q2）
        asked = {(f.get("spoke_date"), f.get("spoke_time")) for m, p, f in LOG if m == "POST" and f.get("step") == "2"}
        assert ("20260702", "173613") in asked and ("20260708", "193435") in asked
        assert summary["details"]["t05st01:2330:20260702:173613:1"]["ok"] is False
        # 每一個存下來的回應，雜湊都與 manifest 一致
        for rec in manifest["requests"]:
            if rec["response_file"]:
                data = open(os.path.join(out, rec["response_file"]), "rb").read()
                assert hashlib.sha256(data).hexdigest() == rec["response_sha256"], rec
        kinds = [r["kind"] for r in manifest["requests"]]
        # 114 年清單被拒絕 → 重試到上限（3 次）；查無資料與 404 不重試
        assert kinds.count("t05st01_listing") == 4 and kinds.count("t57sb01_list") == 2, kinds
        assert summary["listings"]["114"]["attempts"] == 3 and summary["listings"]["115"]["attempts"] == 1
        assert summary["filings"]["114"]["attempts"] == 1
        assert summary["details"]["t05st01:2330:20260702:173613:1"]["attempts"] == 1
        refused = [r for r in manifest["requests"] if r["kind"] == "t05st01_listing" and r["params"]["roc_year"] == "114"]
        assert [r["attempt"] for r in refused] == [1, 2, 3] and not any(r["parsed"] for r in refused)
        assert len({r["response_file"] for r in refused}) == 3   # 每次嘗試的回應各自存檔，不互相覆蓋
    finally:
        shutil.rmtree(out, ignore_errors=True)


def test_collect_without_review_keeps_q2_provisional():
    LOG.clear()
    out, manifest, summary = _run_collect({})
    try:
        q2 = summary["quarters"]["2026Q2"]
        assert q2["status"] == "PROVISIONAL" and any("需人工確認" in b for b in q2["blocking"])
        assert [r["document_id"] for r in q2["review_window"]] == ["t05st01:2330:20260702:173613:1",
                                                                   "t05st01:2330:20260708:193435:1"]
    finally:
        shutil.rmtree(out, ignore_errors=True)


def test_retry_recovers_from_502_and_timeout():
    """115 年清單第一次 502、6/13 營收詳細頁第一次逾時 → 重試後成功；失敗的那一次也留在 manifest。"""
    LOG.clear()
    FLAKY.clear()
    FLAKY[("listing", "115")] = ["502"]
    FLAKY[("detail", "20260713", "135031")] = ["timeout"]
    reviews = ce.load_reviews(os.path.join(BASE, "reviews"))
    out, manifest, summary = _run_collect(reviews, timeout=1)
    try:
        assert summary["listings"]["115"]["attempts"] == 2 and summary["listings"]["115"]["items"] == 153
        rev = [r for r in manifest["requests"] if r["kind"] == "t05st01_detail" and r["params"]["spoke_date"] == "20260713"
               and r["params"]["spoke_time"] == "135031"]
        assert [(r["attempt"], r["parsed"], bool(r["error"])) for r in rev] == [(1, False, True), (2, True, False)], rev
        first = [r for r in manifest["requests"] if r["kind"] == "t05st01_listing" and r["params"]["roc_year"] == "115"][0]
        assert first["status"] == 502 and first["attempt"] == 1 and first["parsed"] is False
        q2 = summary["quarters"]["2026Q2"]
        assert q2["status"] == "CUTOFF_VERIFIED" and q2["earliest"]["at"] == "2026-07-13T13:50:31+08:00", q2
    finally:
        FLAKY.clear()
        shutil.rmtree(out, ignore_errors=True)


def test_retry_gives_up_and_stays_fail_closed():
    """一直 503 → 3 次後放棄，照實記錄，不會當成驗證通過。"""
    LOG.clear()
    FLAKY.clear()
    FLAKY[("listing", "115")] = ["503", "503", "503"]
    out, manifest, summary = _run_collect({})
    try:
        assert summary["listings"]["115"]["attempts"] == 3 and summary["listings"]["115"]["status"] == 503
        assert summary["quarters"] == {} and any("沒有任何年度的清單" in n for n in summary["notes"])
    finally:
        FLAKY.clear()
        shutil.rmtree(out, ignore_errors=True)


def test_retry_budget_limits_total_retries():
    """整次蒐證的重試上限用完後不再重試（避免工作逾時把所有結果一起丟掉），並在摘要說明。"""
    LOG.clear()
    FLAKY.clear()
    FLAKY[("listing", "115")] = ["502"]
    srv_out = None
    try:
        old = ce.DEFAULT_RETRY_BUDGET
        srv = _Server(("127.0.0.1", 0), Stub)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        netloc = f"127.0.0.1:{srv.server_address[1]}"
        OFFICIAL_DOMAINS.add(netloc)
        srv_out = tempfile.mkdtemp(prefix="collect_test_")
        try:
            # 114 年清單被拒絕會先用掉 2 次重試 → 115 年的 502 已沒有重試額度
            manifest, summary = ce.collect("2330", [114, 115], srv_out, mops_base=f"http://{netloc}",
                                           doc_base=f"http://{netloc}", delay=0, timeout=10, reviews={},
                                           retry_waits=(0, 0), retry_budget=2)
        finally:
            OFFICIAL_DOMAINS.discard(netloc)
            srv.shutdown()
        assert ce.DEFAULT_RETRY_BUDGET == old
        assert summary["listings"]["114"]["attempts"] == 3
        assert summary["listings"]["115"]["attempts"] == 1 and summary["listings"]["115"]["status"] == 502
        assert any("重試次數已用完" in n for n in summary["notes"]), summary["notes"]
        assert manifest["retry_budget"] == 2
    finally:
        FLAKY.clear()
        if srv_out:
            shutil.rmtree(srv_out, ignore_errors=True)


def test_clause_policy_needs_detail_page():
    """只有條款規則、沒有人工審查：7/02、7/08 在模擬伺服器沒有詳細頁 → 不知道條款 → 不自動排除，Q2 維持暫定。"""
    LOG.clear()
    reviews = ce.load_reviews(os.path.join(BASE, "reviews"))
    policy_only = {"__clause_policy__": reviews["__clause_policy__"]}
    out, manifest, summary = _run_collect(policy_only)
    try:
        q2 = summary["quarters"]["2026Q2"]
        assert q2["status"] == "PROVISIONAL", q2
        assert [(r["clause"], r["cleared_by"]) for r in q2["review_window"]] == [(None, None), (None, None)]
        assert summary["clause_policy"]["clauses"] == ["20", "6", "8"]
    finally:
        shutil.rmtree(out, ignore_errors=True)


class _StubSession:
    """同一個模擬伺服器（同一個網址）跑多次蒐證：快取的原文請求網址必須仍是「官方」網域才會被沿用。"""

    def __enter__(self):
        self.srv = _Server(("127.0.0.1", 0), Stub)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.netloc = f"127.0.0.1:{self.srv.server_address[1]}"
        OFFICIAL_DOMAINS.add(self.netloc)
        self.old_proxy = {k: os.environ.pop(k) for k in list(os.environ)
                          if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
        return self

    def __exit__(self, *a):
        OFFICIAL_DOMAINS.discard(self.netloc)
        os.environ.update(self.old_proxy)
        self.srv.shutdown()

    def collect(self, out, cache_dir=None, max_details=300):
        manifest, summary = ce.collect("2330", [115], out, mops_base=f"http://{self.netloc}",
                                       doc_base=f"http://{self.netloc}", delay=0, timeout=10,
                                       reviews=ce.load_reviews(os.path.join(BASE, "reviews")),
                                       today=date(2026, 10, 18), retry_waits=(), cache_dir=cache_dir,
                                       max_details=max_details)
        os.makedirs(out, exist_ok=True)
        for name, obj in (("manifest.json", manifest), ("summary.json", summary)):
            json.dump(obj, open(os.path.join(out, name), "w", encoding="utf-8"), ensure_ascii=False)
        return manifest, summary


def _collect_into(out, cache_dir=None, max_details=300):
    with _StubSession() as s:
        return s.collect(out, cache_dir, max_details)


def _detail_requests():
    return {(f.get("spoke_date"), f.get("spoke_time")) for m, p, f in LOG if m == "POST" and f.get("step") == "2"}


def test_guidance_window_details_are_requested():
    """（v4.19）上一季財報公告（2026-04-16 財測發布）到 2026Q2 截止點之間的每一則公告都會去抓原文。"""
    LOG.clear()
    root = tempfile.mkdtemp(prefix="collect_gw_")
    try:
        _, summary = _collect_into(os.path.join(root, "2330", "A"))
        asked = _detail_requests()
        assert any(d.startswith("202605") for d, _ in asked), sorted(asked)[:5]     # 5 月的一般公告也要原文
        assert summary["detail_counts"]["wanted"] > 7 and summary["detail_counts"]["from_cache"] == 0
        assert summary["guidance"]["quarters"]["2026Q2"]["status"] == "MISSING_GUIDANCE"   # 4/16 財報公告原文沒錄到
        g = summary["guidance"]["quarters"]["2026Q3"]          # 7/16 財測 → 10/08 截止點
        assert g["status"] == "GUIDANCE_WINDOW_INCOMPLETE" and g["window"]["missing_detail"], g   # 沒錄到的照實記錄
        assert any(d.startswith("202608") for d, _ in asked)
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_detail_cache_reuses_previous_run_and_rejects_tampered():
    LOG.clear()
    root = tempfile.mkdtemp(prefix="collect_cache_")
    try:
        a_dir, b_dir, c_dir = (os.path.join(root, "2330", x) for x in ("A", "B", "C"))
        with _StubSession() as stub:
            ma, sa = stub.collect(a_dir)
            ok_docs = {r["params"]["document_id"] for r in ma["requests"] if r["kind"] == "t05st01_detail" and r["parsed"]}
            assert len(ok_docs) == 7, ok_docs
            LOG.clear()
            mb, sb = stub.collect(b_dir, cache_dir=os.path.join(root, "2330"))
            cached = [r for r in mb["requests"] if r.get("cached_from")]
            assert {r["params"]["document_id"] for r in cached} == ok_docs
            assert all(r["cached_from"].startswith("A/") and r["attempt"] == 0 for r in cached)
            assert ("20260713", "135031") not in _detail_requests()      # 已有的原文不再向官方網站請求
            assert sb["detail_counts"]["from_cache"] == 7
            key = lambda s: {q: (v["status"], v["earliest"], v["blocking"], v["events"]) for q, v in s["quarters"].items()}
            assert key(sb) == key(sa)                                     # 沿用與重抓結果相同
            rb = ce.replay(b_dir, ce.load_reviews(os.path.join(BASE, "reviews")))
            assert rb["quarters"]["2026Q2"]["status"] == "CUTOFF_VERIFIED"   # 這次資料夾本身就是完整證據
            # 竄改 A 裡 7/13 營收詳細頁 → C 不沿用它、重新向官方網站請求
            rec = [r for r in ma["requests"] if r["kind"] == "t05st01_detail"
                   and r["params"]["spoke_date"] == "20260713" and r["parsed"]][0]
            open(os.path.join(a_dir, rec["response_file"]), "ab").write(b"x")
            shutil.rmtree(b_dir)
            LOG.clear()
            mc, sc = stub.collect(c_dir, cache_dir=os.path.join(root, "2330"))
            assert ("20260713", "135031") in _detail_requests()
            assert sc["detail_counts"]["from_cache"] == 6
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_max_details_counts_only_network_requests():
    LOG.clear()
    root = tempfile.mkdtemp(prefix="collect_cap_")
    try:
        _, s = _collect_into(os.path.join(root, "2330", "A"), max_details=3)
        assert s["detail_counts"]["fetched"] == 3 and s["detail_counts"]["skipped_over_limit"] > 0
        assert any("留待下次執行" in n for n in s["notes"])
        assert len(_detail_requests()) == 3
    finally:
        shutil.rmtree(root, ignore_errors=True)


def test_cli_input_validation():
    import contextlib
    import io
    for bad in (["--co-id", "2330;rm", "--roc-years", "115", "--out", "x"],
                ["--co-id", "2330", "--roc-years", "115,abc", "--out", "x"],
                ["--co-id", "23", "--roc-years", "115", "--out", "x"],
                ["--co-id", "2330", "--roc-years", "115", "--out", "x", "--retry-waits", "10;rm"]):
        try:
            with contextlib.redirect_stderr(io.StringIO()):
                ce.main(bad)
            raise AssertionError(f"應拒絕 {bad}")
        except SystemExit as e:
            assert e.code == 2


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
