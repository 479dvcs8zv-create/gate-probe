"""
ops/announcement_probe.py (v4.11)
==================================
公開資訊觀測站「重大訊息」實際查詢探測：在 GitHub Actions 等可連網環境，對舊版觀測站的
重大訊息查詢端點（/mops/web/ajax_t05st01）送出真實查詢，保存「送出的請求」與「收到的回應」
原始位元組，供之後撰寫與驗收公告解析器。只產生報告，不改任何 Gate 判定；只用標準函式庫。

  python ops/announcement_probe.py --co-id 2330 --roc-year 115 --month 07 --month 08 \
      --full-year --out-dir probe_out
  python ops/announcement_probe.py --co-id 2330 --roc-year 115 --full-year \
      --detail 20260716,151231,1 --detail 20260811,184658,2 --out-dir probe_out   # v4.10 詳細頁

查詢欄位依 v4.8 探測（run 39090239970）實際取得的查詢頁 t05st01 表單：
  form1 action=/mops/web/ajax_t05st01，按下「查詢」時 doAction() 把 step 設為 1、firstin 設為 1。
  欄位：step, firstin, off, keyword4, code1, TYPEK2, checkbtn, queryName, inpuType, TYPEK,
        co_id, year（民國三位數）, month, b_date, e_date
  另依常見做法在最前面加 encodeURIComponent=1；同時取回 js/mops2.js（ajax1 的實作）存證，
  以便核對實際的表單序列化方式。

每一次請求都記錄（沿用 v4.8 network_probe 的證據格式）：
  DNS、對方 IP、TLS 版本／加密套件／憑證主體／簽發者／SAN／有效期／憑證 SHA-256、
  送出的標頭、送出的本文（原始位元組另存檔並記 SHA-256）、狀態碼、回應標頭、
  回應原始位元組（存檔並記 SHA-256）與字元集證據。
POST 不跟隨轉址；若回應是轉址，記錄 Location 即止。
各請求之間預設間隔 3 秒，避免對官方網站造成負擔。

v4.10：詳細頁（--detail 發言日期,發言時間,序號）
  依 v4.9 取得的清單回應與官方 mops2.js：清單每列「詳細資料」按鈕把 seq_no、spoke_time、
  spoke_date、co_id、TYPEK 填進表單 t05st01_fm，openWindow() 把該表單所有 input（按鈕除外）
  依序交給 ajax1()，以 encodeURIComponent=1 開頭 POST 到 ajax_t05st01（step=2）。
  本探測照同樣的欄位與順序送出：
    encodeURIComponent=1, firstin=true, b_date, e_date, TYPEK, year, month, type, co_id,
    spoke_date, spoke_time, seq_no, MEETING_STEP, MODEL, ITEM, step=2, off=1
  spoke_time 照清單參數原樣送（上午 10 點前不補零，例如 64429）。

v4.11：任意官方網址的 POST（--post 網址 本文）
  用來探查「財報申報」的官方來源。官方 mops2.js 的選單把「財務報告」電子書導向
  https://doc.twse.com.tw/server-java/t57sb01（step=1、mtype=A、dtype=A02），本探測以同一個
  網址做 GET 與 POST 嘗試，保存原始回應，之後依實際格式撰寫解析器。只允許官方網域。

誠實說明：這份報告只證明「這台機器在這個時間送出這些請求、收到這些位元組」。
回應內容是否完整（是否有分頁、是否漏列）不在本探測判斷範圍，留給之後的解析器與獨立重跑。
"""

import argparse
import hashlib
import http.client
import json
import os
import platform
import ssl
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)                    # network_probe（v4.8，原樣沿用）
sys.path.insert(0, os.path.dirname(HERE))   # independent_verifier / time_utils（Wayback 檢查用）

import network_probe as npb  # noqa: E402

PROBE_VERSION = "4.11-announcement"
USER_AGENT = "gate-pipeline-announcement-probe/4.11"
DEFAULT_MOPS_BASE = "https://mopsov.twse.com.tw"
QUERY_PATH = "/mops/web/ajax_t05st01"
FORM_PAGE_PATH = "/mops/web/t05st01"
SCRIPT_PATH = "/mops/web/js/mops2.js"


def build_t05st01_fields(co_id, roc_year, month):
    """依實際查詢頁表單（按下查詢後的狀態）組出欄位，順序固定。"""
    return [
        ("encodeURIComponent", "1"),
        ("step", "1"), ("firstin", "1"), ("off", "1"),
        ("keyword4", ""), ("code1", ""), ("TYPEK2", ""), ("checkbtn", ""),
        ("queryName", "co_id"), ("inpuType", "co_id"), ("TYPEK", "all"),
        ("co_id", co_id), ("year", roc_year), ("month", month),
        ("b_date", ""), ("e_date", ""),
    ]


def post_hop(url, body, extra_headers, timeout, proxy=None, cafile=None):
    """送出一次 POST（不跟隨轉址），回傳 (hop_evidence, response_bytes)。"""
    u = urllib.parse.urlsplit(url)
    scheme, host = u.scheme, u.hostname
    port = u.port or (443 if scheme == "https" else 80)
    target = (u.path or "/") + (f"?{u.query}" if u.query else "")
    proxy_url = npb._proxy_for(scheme, host, proxy)
    hop = {"url": url, "method": "POST", "started_at": datetime.now(timezone.utc).isoformat(),
           "via_proxy": bool(proxy_url),
           "dns_addresses": npb._dns(host, port) if not proxy_url else "（經代理，由代理解析）"}
    headers = {"User-Agent": USER_AGENT, "Accept-Encoding": "identity", "Host": u.netloc,
               "Content-Type": "application/x-www-form-urlencoded", "Content-Length": str(len(body))}
    headers.update(extra_headers)
    t0 = time.monotonic()
    conn = None
    try:
        if scheme == "https":
            ctx = ssl.create_default_context(cafile=cafile)
            if proxy_url:
                p = urllib.parse.urlsplit(proxy_url)
                conn = http.client.HTTPSConnection(p.hostname, p.port or 8080, timeout=timeout, context=ctx)
                conn.set_tunnel(host, port)
            else:
                conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
        elif scheme == "http":
            if proxy_url:
                p = urllib.parse.urlsplit(proxy_url)
                conn = http.client.HTTPConnection(p.hostname, p.port or 8080, timeout=timeout)
                target = url
            else:
                conn = http.client.HTTPConnection(host, port, timeout=timeout)
        else:
            raise ValueError(f"不支援的網址協定：{scheme}")
        conn.connect()
        hop["peer_address"] = conn.sock.getpeername()[0]
        if scheme == "https":
            hop["tls"] = npb._tls_info(conn.sock)
        hop["request_headers"] = headers
        conn.request("POST", target, body=body, headers=headers)
        resp = conn.getresponse()
        data = resp.read(npb.MAX_SAVE_BYTES + 1)
        hop.update(status=resp.status, reason=resp.reason,
                   response_headers={h: resp.getheader(h) for h in npb.EVIDENCE_HEADERS
                                     if resp.getheader(h) is not None})
    except ssl.SSLCertVerificationError as e:
        data = b""
        hop.update(status=None, error=f"TLS 憑證驗證失敗：{e.verify_message}（{e}）")
    except Exception as e:
        data = b""
        hop.update(status=None, error=f"{type(e).__name__}: {e}")
    finally:
        if conn is not None:
            conn.close()
    hop["elapsed_ms"] = round((time.monotonic() - t0) * 1000)
    return hop, data


def _save(out_dir, kind, data):
    sha = hashlib.sha256(data).hexdigest()
    folder = os.path.join(out_dir, kind)
    os.makedirs(folder, exist_ok=True)
    name = f"{len(os.listdir(folder)):03d}_{sha[:12]}.bin"
    with open(os.path.join(folder, name), "wb") as f:
        f.write(data)
    return sha, f"{kind}/{name}"


def build_t05st01_detail_fields(co_id, typek, roc_year, month_echo, spoke_date, spoke_time, seq_no):
    """依清單回應的表單 t05st01_fm 欄位順序（v4.9 實測）組出詳細頁查詢欄位。"""
    return [
        ("encodeURIComponent", "1"),
        ("firstin", "true"), ("b_date", ""), ("e_date", ""), ("TYPEK", typek),
        ("year", roc_year), ("month", month_echo), ("type", ""), ("co_id", co_id),
        ("spoke_date", spoke_date), ("spoke_time", spoke_time), ("seq_no", seq_no),
        ("MEETING_STEP", ""), ("MODEL", ""), ("ITEM", ""), ("step", "2"), ("off", "1"),
    ]


def _post_query(kind, params, fields, base, out_dir, timeout, proxy=None, cafile=None):
    body = urllib.parse.urlencode(fields).encode("ascii")
    req_sha, req_file = _save(out_dir, "requests", body)
    url = base.rstrip("/") + QUERY_PATH
    origin = base.rstrip("/")
    hop, data = post_hop(url, body, {"Referer": origin + FORM_PAGE_PATH, "Origin": origin}, timeout, proxy, cafile)
    entry = {"kind": kind, "params": params,
             "request_fields": fields, "request_body_sha256": req_sha, "request_body_saved_as": req_file,
             "request_body_length": len(body), "hop": hop, "status": hop.get("status"), "error": hop.get("error")}
    truncated = len(data) > npb.MAX_SAVE_BYTES
    data = data[:npb.MAX_SAVE_BYTES]
    entry["truncated_at_bytes"] = npb.MAX_SAVE_BYTES if truncated else None
    entry["content_length"] = len(data)
    if data:
        sha, saved = _save(out_dir, "responses", data)
        entry.update(body_sha256=sha, saved_as=saved,
                     charset=npb.charset_report(data, hop.get("response_headers", {}).get("Content-Type")))
    return entry


def query_t05st01(base, co_id, roc_year, month, out_dir, timeout, proxy=None, cafile=None):
    return _post_query("t05st01_query", {"co_id": co_id, "roc_year": roc_year, "month": month or "（全年度）"},
                       build_t05st01_fields(co_id, roc_year, month), base, out_dir, timeout, proxy, cafile)


def query_t05st01_detail(base, co_id, typek, roc_year, month_echo, spoke_date, spoke_time, seq_no, out_dir,
                         timeout, proxy=None, cafile=None):
    params = {"co_id": co_id, "TYPEK": typek, "spoke_date": spoke_date, "spoke_time": spoke_time, "seq_no": seq_no}
    return _post_query("t05st01_detail", params,
                       build_t05st01_detail_fields(co_id, typek, roc_year, month_echo, spoke_date, spoke_time, seq_no),
                       base, out_dir, timeout, proxy, cafile)


OFFICIAL_SUFFIXES = ("twse.com.tw", "tpex.org.tw")


def post_any(url, body_text, out_dir, timeout, proxy=None, cafile=None):
    """對官方網域的任意網址送 POST（application/x-www-form-urlencoded），保存請求與回應。"""
    host = urllib.parse.urlsplit(url).hostname or ""
    if not any(host == s or host.endswith("." + s) for s in OFFICIAL_SUFFIXES):
        return {"kind": "post", "url": url, "status": None, "error": f"拒絕：{host} 不是官方網域"}
    body = body_text.encode("ascii")
    req_sha, req_file = _save(out_dir, "requests", body)
    origin = "{0.scheme}://{0.netloc}".format(urllib.parse.urlsplit(url))
    hop, data = post_hop(url, body, {"Referer": url, "Origin": origin}, timeout, proxy, cafile)
    entry = {"kind": "post", "url": url, "request_body_sha256": req_sha, "request_body_saved_as": req_file,
             "request_body_length": len(body), "hop": hop, "status": hop.get("status"), "error": hop.get("error")}
    data = data[:npb.MAX_SAVE_BYTES]
    entry["content_length"] = len(data)
    if data:
        sha, saved = _save(out_dir, "responses", data)
        entry.update(body_sha256=sha, saved_as=saved,
                     charset=npb.charset_report(data, hop.get("response_headers", {}).get("Content-Type")))
    return entry


def environment():
    return {
        "python": platform.python_version(), "openssl": ssl.OPENSSL_VERSION, "platform": platform.platform(),
        "github_actions": os.environ.get("GITHUB_ACTIONS") == "true",
        "runner_os": os.environ.get("RUNNER_OS"), "runner_environment": os.environ.get("RUNNER_ENVIRONMENT"),
        "github_repository": os.environ.get("GITHUB_REPOSITORY"), "github_sha": os.environ.get("GITHUB_SHA"),
        "github_run_id": os.environ.get("GITHUB_RUN_ID"), "github_run_attempt": os.environ.get("GITHUB_RUN_ATTEMPT"),
        "proxy_env_set": bool(urllib.request.getproxies()),
    }


def main(argv=None):
    ap = argparse.ArgumentParser(description="公開資訊觀測站重大訊息實際查詢探測（只產生報告）")
    ap.add_argument("--co-id", required=True, help="公司代號，例如 2330")
    ap.add_argument("--roc-year", required=True, help="民國年（三位數），例如 115")
    ap.add_argument("--month", action="append", default=[], help="月份 01–12，可重複")
    ap.add_argument("--full-year", action="store_true", help="另外查一次全年度（month 留空）")
    ap.add_argument("--detail", action="append", default=[],
                    help="詳細頁：發言日期,發言時間,序號（照清單參數原樣，例如 20260716,151231,1），可重複")
    ap.add_argument("--detail-typek", default="sii", help="詳細頁的 TYPEK（清單參數，上市為 sii）")
    ap.add_argument("--detail-month", default="all", help="詳細頁表單的 month 回顯值（全年度清單為 all）")
    ap.add_argument("--no-script", action="store_true", help="不取回 js/mops2.js")
    ap.add_argument("--post", nargs=2, action="append", default=[], metavar=("URL", "BODY"),
                    help="對官方網域網址送 POST，BODY 為 urlencoded 字串，可重複")
    ap.add_argument("--no-listing", action="store_true", help="不做 t05st01 查詢（只做 --url / --post）")
    ap.add_argument("--url", action="append", default=[], help="另外以 GET 探測的網址，可重複")
    ap.add_argument("--wayback-check", action="append", default=[], help="對這些原始網址做 Wayback 端對端取得")
    ap.add_argument("--cutoff", default="", help="Wayback 檢查的截止時間（帶時區 ISO8601）")
    ap.add_argument("--wayback-base", default="https://web.archive.org")
    ap.add_argument("--mops-base", default=DEFAULT_MOPS_BASE)
    ap.add_argument("--delay", type=float, default=3.0, help="每次請求之間的間隔秒數")
    ap.add_argument("--proxy", default=None)
    ap.add_argument("--cafile", default=None)
    ap.add_argument("--timeout", type=float, default=30.0)
    ap.add_argument("--out-dir", default="probe_out")
    a = ap.parse_args(argv)

    if not (a.co_id.isdigit() and len(a.roc_year) == 3 and a.roc_year.isdigit()):
        ap.error("co-id 必須是數字、roc-year 必須是三位數字")
    months = []
    for m in a.month:
        if not (len(m) == 2 and m.isdigit() and 1 <= int(m) <= 12):
            ap.error(f"月份格式錯誤：{m}（請用 01–12）")
        months.append(m)
    if a.full_year:
        months.append("")
    details = []
    for d in a.detail:
        parts = d.split(",")
        if len(parts) != 3 or not (len(parts[0]) == 8 and all(x.isdigit() for x in parts)
                                   and 1 <= len(parts[1]) <= 6):
            ap.error(f"--detail 格式錯誤：{d}（應為 發言日期,發言時間,序號，例如 20260716,151231,1）")
        details.append(parts)

    os.makedirs(os.path.join(a.out_dir, "responses"), exist_ok=True)
    report = {"probe_version": PROBE_VERSION, "run_at": datetime.now(timezone.utc).isoformat(),
              "environment": environment(), "mops_base": a.mops_base, "delay_seconds": a.delay}

    gets = ([] if a.no_script else [a.mops_base.rstrip("/") + SCRIPT_PATH]) + a.url
    report["targets"] = []
    for i, u in enumerate(gets):
        if i:
            time.sleep(a.delay)
        report["targets"].append(npb.probe_url(u, a.out_dir, a.timeout, a.proxy, a.cafile))

    report["queries"] = []
    for m in ([] if a.no_listing else months):
        time.sleep(a.delay)
        report["queries"].append(query_t05st01(a.mops_base, a.co_id, a.roc_year, m, a.out_dir,
                                               a.timeout, a.proxy, a.cafile))

    report["details"] = []
    for spoke_date, spoke_time, seq_no in details:
        time.sleep(a.delay)
        report["details"].append(query_t05st01_detail(a.mops_base, a.co_id, a.detail_typek, a.roc_year, a.detail_month,
                                                      spoke_date, spoke_time, seq_no, a.out_dir, a.timeout,
                                                      a.proxy, a.cafile))

    report["posts"] = []
    for url, body_text in a.post:
        time.sleep(a.delay)
        report["posts"].append(post_any(url, body_text, a.out_dir, a.timeout, a.proxy, a.cafile))

    report["wayback_checks"] = []
    for src in a.wayback_check:
        time.sleep(a.delay)
        report["wayback_checks"].append(npb.wayback_check(src, a.cutoff, a.timeout, a.wayback_base, a.proxy))

    path = os.path.join(a.out_dir, "probe_report.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    for t in report["targets"]:
        print(f"[GET  {t.get('status') or '-'}] {t['url']} {t.get('content_length', 0)}B {t.get('error') or ''}")
    for q in report["queries"]:
        print(f"[POST {q.get('status') or '-'}] t05st01 {q['params']} {q.get('content_length', 0)}B {q.get('error') or ''}")
    for q in report["details"]:
        print(f"[POST {q.get('status') or '-'}] detail {q['params']} {q.get('content_length', 0)}B {q.get('error') or ''}")
    for q in report["posts"]:
        print(f"[POST {q.get('status') or '-'}] {q['url']} {q.get('content_length', 0)}B {q.get('error') or ''}")
    for w in report["wayback_checks"]:
        print(f"[WAYBACK] {w.get('source_url')} {w.get('result')} {w.get('snapshot_id', '')} {w.get('error', '')}")
    print(f"報告：{path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
