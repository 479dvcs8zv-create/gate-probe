"""
ops/archive_consensus.py (v4.20)
================================
往後自行存檔市場預估（使用者 2026-10-18 核准：「官方財測＋往後自己存檔」）。

對 contract/consensus_sources.json 中有 archive_url 的網站：
  1. 送 Wayback Machine「Save Page Now」（匿名 GET /save/<網址>，不用任何 API 金鑰），請封存站自己抓一份
  2. 從回應標頭取得封存時間；取不到就查 CDX（只認送出之後的版本）
  3. 用 id_ 模式取回封存原文，核對 CDX 記錄的 SHA-1 摘要，保存原始位元組與 SHA-256
v4.20：送出逾時、連線中斷或 5xx 時，先查 CDX（封存站可能其實已存好），沒有才等 60 秒重送一次；
     原文若是 gzip 壓縮（id_ 模式保留網站當時送出的位元組），另記錄解壓後的長度與 SHA-256，解析時才解壓。
封存時間由 Wayback 記錄，不是我們自己宣稱的時間：之後可以獨立證明「這份預估在官方截止點之前已經存在」。

這一步只存檔，不解析數值、不影響任何 Gate 判定。之後的季度若在截止點前有存檔，
才由各網站的解析器讀出預估值，並依使用者核准的來源規則評估。

  python gate_pipeline/ops/archive_consensus.py --co-id 2330 --out results/2330/archive/<run_id>
"""

import argparse
import base64
import gzip
import hashlib
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

from consensus_discovery import DEFAULT_SOURCES, _parse_cdx  # noqa: E402
from independent_verifier import _NoRedirect  # noqa: E402

ARCHIVE_VERSION = "4.20-archive"
USER_AGENT = "gate-pipeline-consensus-archiver/4.18 (+https://github.com/479dvcs8zv-create/gate-probe)"
TPE = timezone(timedelta(hours=8))
_TS = re.compile(r"/web/(\d{14})/")


def archive_targets(co_id, path=DEFAULT_SOURCES):
    cfg = json.load(open(path, encoding="utf-8"))
    adr = cfg.get("adr_map", {}).get(co_id)
    out = []
    for s in cfg["sources"]:
        url = s.get("archive_url")
        if not url or (s.get("only") and co_id not in s["only"]) or ("{adr" in url and not adr):
            continue
        out.append({"id": s["id"], "vendor": s["vendor"], "unit": s.get("unit"),
                    "url": url.format(co_id=co_id, adr=adr or "", adr_lower=(adr or "").lower())})
    return out, adr


def _request(opener, url, timeout, max_bytes=10 * 1024 * 1024):
    """GET，不跟隨轉址。回傳 (status, headers dict, body bytes, error)。"""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Encoding": "identity"})
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status, dict(r.headers.items()), r.read(max_bytes + 1)[:max_bytes + 1], None
    except urllib.error.HTTPError as e:
        try:
            body = e.read(65536)
        except Exception:
            body = b""
        return e.code, dict(e.headers.items()) if e.headers else {}, body, None
    except Exception as e:   # 連線錯誤、逾時
        return None, {}, b"", f"{type(e).__name__}: {getattr(e, 'reason', e)}"


def decode_payload(raw):
    """封存原文可能是當時網站送出的 gzip 壓縮內容（id_ 模式原樣保留，SHA-1 摘要也是對壓縮後的位元組）。
    解析時才解壓；存檔與摘要核對一律用原始位元組。不是 gzip 就原樣回傳同一個物件。"""
    if raw[:2] == b"\x1f\x8b":
        try:
            return gzip.decompress(raw)
        except (OSError, EOFError):
            return raw
    return raw


def archive(co_id, out_dir, base_url="https://web.archive.org", delay=20.0, timeout=120.0, time_budget=1200.0,
            sources_path=DEFAULT_SOURCES, sleep=time.sleep, clock=time.monotonic, now=None, retry_wait=60.0):
    os.makedirs(os.path.join(out_dir, "captures"), exist_ok=True)
    targets, adr = archive_targets(co_id, sources_path)
    base = base_url.rstrip("/")
    opener = urllib.request.build_opener(_NoRedirect())
    t0 = clock()
    result = {"archive_version": ARCHIVE_VERSION, "co_id": co_id, "adr": adr, "base_url": base,
              "started_at": (now or datetime.now(timezone.utc)).isoformat(), "targets": [], "notes": []}
    first = True
    for tg in targets:
        rec = dict(tg, save=None, capture=None, status=None)
        result["targets"].append(rec)
        if time_budget - (clock() - t0) <= 0:
            rec["status"] = "TIMEOUT"
            continue
        if not first:
            sleep(delay)   # Save Page Now 對匿名使用有頻率限制，慢慢送
        first = False
        rec["save_attempts"] = []
        row = None
        for attempt in (1, 2):
            if attempt == 2:
                if time_budget - (clock() - t0) <= 0:
                    break
                sleep(retry_wait)   # 第一次失敗：等一下再送一次
            sent_at = now or datetime.now(timezone.utc)
            status, headers, body, err = _request(opener, f"{base}/save/{tg['url']}", timeout)
            hdr = {k: v for k, v in headers.items()
                   if k.lower() in ("location", "content-location", "link", "x-archive-wayback-runtime-error")}
            att = {"attempt": attempt, "sent_at": sent_at.isoformat(), "http_status": status, "error": err, "headers": hdr}
            rec["save_attempts"].append(att)
            rec["save"] = att
            ts = None
            for k, v in hdr.items():
                m = _TS.search(v or "")
                if m and k.lower() in ("location", "content-location", "link"):
                    ts = m.group(1)
                    break
            accepted = not err and status in (200, 301, 302, 303, 307, 308)
            # 不論送出是否回報成功都查一次 CDX：逾時或連線中斷時，封存站可能其實已經存好了
            lo = (sent_at - timedelta(minutes=10)).strftime("%Y%m%d%H%M%S")
            q = urllib.parse.urlencode({"url": tg["url"], "output": "json",
                                        "fl": "timestamp,original,statuscode,digest,mimetype,length",
                                        "from": lo, "filter": "statuscode:200", "limit": "50"})
            sleep(min(delay, 5))
            st, _, cdx_body, cerr = _request(opener, f"{base}/cdx/search/cdx?{q}", 60)
            rows = []
            if st == 200:
                try:
                    rows, _ = _parse_cdx(cdx_body)
                except ValueError as ex:
                    att["cdx_error"] = str(ex)
            else:
                att["cdx_error"] = cerr or f"HTTP {st}"
            floor = (sent_at - timedelta(minutes=2)).strftime("%Y%m%d%H%M%S")
            cands = [r for r in rows if r.get("statuscode") == "200" and r.get("original") == tg["url"]
                     and (r["timestamp"] == ts if ts else r["timestamp"] >= floor)]
            if cands:
                row = max(cands, key=lambda r: r["timestamp"])
                att["found_in_index"] = row["timestamp"]
                break
            if accepted and not att.get("cdx_error"):
                rec["status"] = "NOT_IN_INDEX_YET"   # 送出成功但索引還沒出現：封存可能還在處理，不重送
                rec["capture_timestamp_from_headers"] = ts
                break
            rec["status"] = "CDX_FAILED" if accepted else "SAVE_FAILED"
        if row is None:
            if rec["status"] is None:
                rec["status"] = "SAVE_FAILED"
            continue
        rec["status"] = None
        sent_ts = datetime.fromisoformat(rec["save"]["sent_at"]).astimezone(timezone.utc).strftime("%Y%m%d%H%M%S")
        sleep(min(delay, 5))
        st, h2, raw, err = _request(opener, f"{base}/web/{row['timestamp']}id_/{row['original']}", 60)
        if st != 200 or err:
            rec["status"] = "FETCH_FAILED"
            rec["fetch_error"] = err or f"HTTP {st}"
            continue
        served = base64.b32encode(hashlib.sha1(raw).digest()).decode("ascii")
        name = f"captures/{tg['id']}_{row['timestamp']}.bin"
        open(os.path.join(out_dir, name), "wb").write(raw)
        captured = datetime.strptime(row["timestamp"], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
        enc = {k.lower(): v for k, v in h2.items()}.get("content-encoding")
        rec["capture"] = {"timestamp": row["timestamp"], "captured_at_tpe": captured.astimezone(TPE).isoformat(),
                          "archive_url": f"{base}/web/{row['timestamp']}/{row['original']}",
                          "cdx_digest": row.get("digest"), "digest_matched": served == row.get("digest"),
                          "file": name, "sha256": hashlib.sha256(raw).hexdigest(), "length": len(raw),
                          "content_type": h2.get("Content-Type"), "content_encoding": enc, "sent_ts": sent_ts}
        decoded = decode_payload(raw)
        if decoded is not raw:
            rec["capture"].update(decoded_length=len(decoded), decoded_sha256=hashlib.sha256(decoded).hexdigest(),
                                  payload_compression="gzip")
        rec["status"] = "ARCHIVED" if served == row.get("digest") else "DIGEST_MISMATCH"
    if any(r["status"] == "TIMEOUT" for r in result["targets"]):
        result["notes"].append(f"時間上限 {time_budget:g} 秒已到，部分網站未送出")
    result["finished_at"] = datetime.now(timezone.utc).isoformat()
    with open(os.path.join(out_dir, "archive.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    return result


STATUS_TEXT = {"ARCHIVED": "已封存並核對", "DIGEST_MISMATCH": "摘要不符", "FETCH_FAILED": "封存了但取回失敗",
               "NOT_IN_INDEX_YET": "已送出，索引尚未出現", "CDX_FAILED": "索引查詢失敗", "SAVE_FAILED": "送封存失敗",
               "TIMEOUT": "時間到未送出"}


def markdown(r):
    lines = [f"## 市場預估自行存檔 {r['co_id']}（{r['started_at'][:16]} UTC）", "",
             "| 網站 | 結果 | 封存時間（台北） | 大小 |", "|---|---|---|---|"]
    for t in r["targets"]:
        c = t.get("capture") or {}
        lines.append(f"| {t['vendor']} `{t['id']}` | {STATUS_TEXT.get(t['status'], t['status'])} | "
                     f"{c.get('captured_at_tpe', '')[:19]} | {c.get('length', '')} |")
    for n in r["notes"]:
        lines.append(f"\n- {n}")
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description="市場預估網頁送 Wayback 存檔")
    p.add_argument("--co-id", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--base-url", default="https://web.archive.org")
    p.add_argument("--delay", type=float, default=20.0)
    p.add_argument("--time-budget", type=float, default=1200.0)
    a = p.parse_args(argv)
    if not re.fullmatch(r"\d{4,6}", a.co_id):
        p.error("股票代號必須是 4–6 位數字")
    r = archive(a.co_id, a.out, a.base_url, a.delay, time_budget=a.time_budget)
    text = markdown(r)
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
