"""
ops/network_probe.py (v4.8)
============================
外部網路連線探測：在「可能可以連網」的環境（例如 GitHub Actions）實際測試能否取得
Wayback 與公開資訊觀測站的回應，保存原始回應，並留下連線證據。只產生報告，不改任何判定；
只用 Python 標準函式庫。

  python ops/network_probe.py --default-targets --out-dir probe_out
  python ops/network_probe.py --url https://mops.twse.com.tw/... --out-dir probe_out
  python ops/network_probe.py --wayback-check https://mops.twse.com.tw/... \
      --cutoff 2026-01-20T13:00:00+08:00 --out-dir probe_out

每個網址逐跳記錄（不自動跟隨轉址，最多 5 跳，每一跳都有自己的證據）：
  - 請求：網址、送出的標頭、開始時間、耗時
  - 連線：DNS 解析結果、實際連線對象的 IP、是否經過代理
  - TLS（https）：協定版本、加密套件、憑證主體／簽發者／SAN／有效期、憑證 SHA-256 指紋；
    憑證鏈與主機名稱由系統信任庫驗證，驗證失敗會記錄為錯誤（這本身也是證據）
  - 回應：狀態碼、Date／Server／Content-Type／Location 等標頭
最後一跳的原始回應存檔，並附上字元集證據：標頭宣告、HTML meta 宣告、BOM、
以及以 UTF-8／CP950／Big5／宣告字元集嚴格解碼是否成功。

這些證據的意義（誠實版）：
  TLS 證明「執行探測的機器」當時連到持有該網域有效憑證的伺服器；它不對內容簽章，
  第三方無法單憑這份報告驗證內容來自官方伺服器。可信度來自「獨立執行環境」：
  GitHub 託管的 runner、run id、執行紀錄與 artifact，加上之後另一個環境重跑比對。
"""

import argparse
import base64
import codecs
import hashlib
import http.client
import json
import os
import platform
import re
import socket
import ssl
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))  # 讓 --wayback-check 能使用 gate_pipeline 的 WebArchiveVerifier

DEFAULT_TARGETS = [
    "https://web.archive.org/cdx/search/cdx?url=mops.twse.com.tw&output=json&limit=1",
    "https://mops.twse.com.tw/mops/",
    "https://mopsov.twse.com.tw/mops/web/index",
]
USER_AGENT = "gate-pipeline-network-probe/4.8"
MAX_SAVE_BYTES = 5 * 1024 * 1024
MAX_HOPS = 5
EVIDENCE_HEADERS = ("Date", "Server", "Content-Type", "Content-Length", "Content-Encoding", "Location",
                    "Last-Modified", "ETag", "Cache-Control", "Strict-Transport-Security")
CHARSET_CANDIDATES = ("utf-8", "cp950", "big5")


# ------------------------------------------------------------------ 連線

def _proxy_for(scheme, host, explicit_proxy):
    if explicit_proxy:
        return explicit_proxy
    if urllib.request.proxy_bypass(host):
        return None
    return urllib.request.getproxies().get(scheme)


def _dn(seq):
    return ", ".join("=".join(attr) for rdn in seq for attr in rdn)


def _tls_info(sock):
    der = sock.getpeercert(binary_form=True)
    cert = sock.getpeercert() or {}
    cipher = sock.cipher()
    return {"tls_version": sock.version(), "cipher": cipher[0] if cipher else None,
            "cert_subject": _dn(cert.get("subject", ())), "cert_issuer": _dn(cert.get("issuer", ())),
            "cert_san": [v for k, v in cert.get("subjectAltName", ()) if k == "DNS"],
            "cert_not_before": cert.get("notBefore"), "cert_not_after": cert.get("notAfter"),
            "cert_sha256": hashlib.sha256(der).hexdigest() if der else None,
            "chain_and_hostname_verified": True}


def _dns(host, port):
    try:
        return sorted({ai[4][0] for ai in socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)})
    except OSError as e:
        return [f"DNS 失敗：{e}"]


def fetch_hop(url, timeout, proxy=None, cafile=None):
    """發出一次 GET（不跟隨轉址），回傳 (hop_evidence, body_bytes)。"""
    u = urllib.parse.urlsplit(url)
    scheme, host = u.scheme, u.hostname
    port = u.port or (443 if scheme == "https" else 80)
    target = (u.path or "/") + (f"?{u.query}" if u.query else "")
    proxy_url = _proxy_for(scheme, host, proxy)
    hop = {"url": url, "started_at": datetime.now(timezone.utc).isoformat(), "via_proxy": bool(proxy_url),
           "dns_addresses": _dns(host, port) if not proxy_url else "（經代理，由代理解析）"}
    headers = {"User-Agent": USER_AGENT, "Accept-Encoding": "identity", "Host": u.netloc}
    t0 = time.monotonic()
    conn = None
    try:
        if scheme == "https":
            ctx = ssl.create_default_context(cafile=cafile)
            if proxy_url:
                p = urllib.parse.urlsplit(proxy_url)
                conn = http.client.HTTPSConnection(p.hostname, p.port or 8080, timeout=timeout, context=ctx)
                tunnel_headers = {}
                if p.username:
                    cred = base64.b64encode(f"{urllib.parse.unquote(p.username)}:{urllib.parse.unquote(p.password or '')}".encode()).decode()
                    tunnel_headers["Proxy-Authorization"] = f"Basic {cred}"
                conn.set_tunnel(host, port, headers=tunnel_headers)
            else:
                conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
        elif scheme == "http":
            if proxy_url:
                p = urllib.parse.urlsplit(proxy_url)
                conn = http.client.HTTPConnection(p.hostname, p.port or 8080, timeout=timeout)
                target = url
            else:
                conn = http.client.HTTPConnection(host, port, timeout=timeout)
        else:
            raise ValueError(f"不支援的網址協定：{scheme}")
        conn.connect()  # 先連線，才能在回應讀完、連線關閉前取得 TLS 與對方位址
        hop["peer_address"] = conn.sock.getpeername()[0]
        if scheme == "https":
            hop["tls"] = _tls_info(conn.sock)
        hop["request_headers"] = headers
        conn.request("GET", target, headers=headers)
        resp = conn.getresponse()
        body = resp.read(MAX_SAVE_BYTES + 1)
        hop.update(status=resp.status, reason=resp.reason,
                   response_headers={h: resp.getheader(h) for h in EVIDENCE_HEADERS if resp.getheader(h) is not None})
    except ssl.SSLCertVerificationError as e:
        body = b""
        hop.update(status=None, error=f"TLS 憑證驗證失敗：{e.verify_message}（{e}）")
    except Exception as e:
        body = b""
        hop.update(status=None, error=f"{type(e).__name__}: {e}")
    finally:
        if conn is not None:
            conn.close()
    hop["elapsed_ms"] = round((time.monotonic() - t0) * 1000)
    return hop, body


# ------------------------------------------------------------------ 字元集

def charset_report(body: bytes, content_type) -> dict:
    m = re.search(r"charset=[\"']?([\w.:-]+)", content_type or "", re.I)
    declared_header = m.group(1).lower() if m else None
    head = body[:4096].decode("ascii", errors="replace")
    mm = re.search(r"<meta[^>]+charset=[\"']?([\w.:-]+)", head, re.I)
    declared_meta = mm.group(1).lower() if mm else None
    bom = ("utf-8" if body.startswith(b"\xef\xbb\xbf")
           else "utf-16" if body[:2] in (b"\xff\xfe", b"\xfe\xff") else None)
    decodes = {}
    for enc in dict.fromkeys([*CHARSET_CANDIDATES, declared_header, declared_meta]):
        if not enc:
            continue
        try:
            codecs.lookup(enc)
            body.decode(enc)
            decodes[enc] = True
        except LookupError:
            decodes[enc] = "unknown_codec"
        except UnicodeDecodeError as e:
            decodes[enc] = f"fails_at_byte_{e.start}"
    return {"declared_in_header": declared_header, "declared_in_meta": declared_meta, "bom": bom,
            "strict_decode": decodes}


# ------------------------------------------------------------------ 探測

def probe_url(url, out_dir, timeout, proxy=None, cafile=None):
    entry = {"url": url, "hops": [], "reachable": False}
    current, body = url, b""
    for _ in range(MAX_HOPS):
        hop, body = fetch_hop(current, timeout, proxy, cafile)
        entry["hops"].append(hop)
        status = hop.get("status")
        if status is None:
            break
        entry["reachable"] = True
        location = hop.get("response_headers", {}).get("Location")
        if status in (301, 302, 303, 307, 308) and location:
            current = urllib.parse.urljoin(current, location)
            continue
        break
    last = entry["hops"][-1]
    entry.update(final_url=last["url"], status=last.get("status"), error=last.get("error"),
                 elapsed_ms=sum(h["elapsed_ms"] for h in entry["hops"]))
    entry["truncated_at_bytes"] = MAX_SAVE_BYTES if len(body) > MAX_SAVE_BYTES else None
    body = body[:MAX_SAVE_BYTES]
    entry["content_length"] = len(body)
    if body:
        sha = hashlib.sha256(body).hexdigest()
        name = f"{len(os.listdir(os.path.join(out_dir, 'responses'))):03d}_{sha[:12]}.bin"
        with open(os.path.join(out_dir, "responses", name), "wb") as f:
            f.write(body)
        entry.update(body_sha256=sha, saved_as=f"responses/{name}",
                     charset=charset_report(body, last.get("response_headers", {}).get("Content-Type")))
    return entry


def wayback_check(source_url, cutoff_iso, timeout, base_url, proxy=None):
    """用 gate_pipeline 的 WebArchiveVerifier 對真實（或指定）Wayback 做一次端對端取得。"""
    from independent_verifier import WebArchiveVerifier
    from time_utils import parse_with_precision
    entry = {"source_url": source_url, "cutoff": cutoff_iso, "base_url": base_url}
    cutoff, precision = parse_with_precision(cutoff_iso) if cutoff_iso else (None, None)
    if cutoff_iso and (cutoff is None or precision != "datetime_tz"):
        entry["error"] = "cutoff 必須是帶時區的 ISO8601 時間"
        return entry
    w = WebArchiveVerifier(base_url=base_url, timeout=timeout,
                           opener=WebArchiveVerifier.build_opener(proxy_url=proxy) if proxy else None)
    try:
        b = w.fetch_verified_bundle(source_url, captured_before=cutoff)
        if b is None:
            entry["result"] = "NO_CAPTURE_BEFORE_CUTOFF"
        else:
            entry.update(result="BUNDLE_OK", snapshot_id=b.snapshot_id, captured_at=b.captured_at,
                         archive_url=b.archive_url, content_sha256=b.sha256, content_length=len(b.content_bytes),
                         archive_digest=b.archive_digest, archive_digest_matched=b.archive_digest_matched,
                         retrieval_trace=b.retrieval_trace)
    except Exception as e:
        entry.update(result="ERROR", error=f"{type(e).__name__}: {e}",
                     reject_code_hint=getattr(e, "reject_code", None))
    entry["requests"] = list(w.requests)
    return entry


def main(argv=None):
    ap = argparse.ArgumentParser(description="外部網路連線探測（只產生報告）")
    ap.add_argument("--url", action="append", default=[], help="要探測的網址，可重複")
    ap.add_argument("--default-targets", action="store_true", help="加入預設的 Wayback 與公開資訊觀測站入口")
    ap.add_argument("--wayback-check", help="對這個原始網址做 Wayback 端對端取得")
    ap.add_argument("--cutoff", default="", help="Wayback 檢查的截止時間（帶時區 ISO8601）")
    ap.add_argument("--wayback-base", default="https://web.archive.org")
    ap.add_argument("--proxy", default=None, help="指定 HTTP(S) 代理（預設沿用環境設定與 no_proxy）")
    ap.add_argument("--cafile", default=None, help="額外信任的 CA 憑證檔（預設只用系統信任庫）")
    ap.add_argument("--timeout", type=float, default=20.0)
    ap.add_argument("--out-dir", default="probe_out")
    a = ap.parse_args(argv)

    os.makedirs(os.path.join(a.out_dir, "responses"), exist_ok=True)
    targets = (DEFAULT_TARGETS if a.default_targets else []) + a.url
    report = {
        "probe_version": "4.8",
        "run_at": datetime.now(timezone.utc).isoformat(),
        "environment": {
            "python": platform.python_version(), "openssl": ssl.OPENSSL_VERSION, "platform": platform.platform(),
            "github_actions": os.environ.get("GITHUB_ACTIONS") == "true",
            "runner_os": os.environ.get("RUNNER_OS"), "runner_environment": os.environ.get("RUNNER_ENVIRONMENT"),
            "github_repository": os.environ.get("GITHUB_REPOSITORY"), "github_sha": os.environ.get("GITHUB_SHA"),
            "github_run_id": os.environ.get("GITHUB_RUN_ID"), "github_run_attempt": os.environ.get("GITHUB_RUN_ATTEMPT"),
            "proxy_env_set": bool(urllib.request.getproxies()),
        },
        "targets": [probe_url(u, a.out_dir, a.timeout, a.proxy, a.cafile) for u in targets],
    }
    if a.wayback_check:
        report["wayback_check"] = wayback_check(a.wayback_check, a.cutoff, a.timeout, a.wayback_base, a.proxy)

    path = os.path.join(a.out_dir, "probe_report.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    for t in report["targets"]:
        status = t.get("status") if t.get("status") is not None else "-"
        tls = (t["hops"][-1].get("tls") or {}).get("tls_version", "")
        print(f"[{'OK ' if t['reachable'] else 'ERR'}] {status} {t['elapsed_ms']}ms {tls} {t['url']} {t.get('error') or ''}")
    if a.wayback_check:
        wc = report["wayback_check"]
        print(f"[WAYBACK] {wc.get('result')} {wc.get('snapshot_id', '')} {wc.get('error', '')}")
    print(f"報告：{path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
