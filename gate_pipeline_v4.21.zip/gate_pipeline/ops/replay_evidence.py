"""
ops/replay_evidence.py (v4.15)
==============================
離線重算某次一鍵蒐證的結果：只讀 <結果資料夾>/manifest.json 與 responses/，用正式解析器重新解析、
比對每個回應的 SHA-256，再套用目前的人工審查紀錄與條款規則計算各季截止點。不連任何網站。

  python gate_pipeline/ops/replay_evidence.py results/2330/39103606949 --reviews gate_pipeline/contract/mops_real/reviews

用途：新增人工審查紀錄後重新評估、或由第三方獨立複驗同一份證據。輸出 JSON 到標準輸出（--out 可另存）。
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))

import collect_evidence as ce  # noqa: E402


def main(argv=None):
    p = argparse.ArgumentParser(description="離線重算一鍵蒐證結果")
    p.add_argument("run_dir")
    p.add_argument("--reviews", default=None)
    p.add_argument("--out", default=None)
    a = p.parse_args(argv)
    s = ce.replay(a.run_dir, ce.load_reviews(a.reviews))
    text = json.dumps(s, ensure_ascii=False, indent=2)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(text)
    for q, v in sorted(s["quarters"].items()):
        e = v["earliest"] or {}
        pending = [r["document_id"] for r in v["review_window"] if r["cleared_by"] is None]
        print(f"{q}  {v['status']:<16} {e.get('at', '')}  待人工確認 {len(pending)} 則", file=sys.stderr)
    if not a.out:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
