"""
adapters/base.py
================
這是「你要接的那個洞」。

你現在資料來源是另一個 GPT 處理網站在做抓取/解析，本管線不假設它是什麼
技術形式（可能是你呼叫另一個 API、或是那個 GPT 吐出 JSON、或是你手動貼結果）。

做法：每個 Gate 需要的資料，都定義成一個「抽象 Fetcher」，你只要寫一個
function，輸入 ticker，輸出符合 schema.py 格式的物件即可。管線本身
完全不管資料怎麼來的。

實作方式三選一（擇一即可，也可以混用）：
  1. 直接呼叫你那個 GPT 處理網站的 API（如果它有對外 endpoint）
  2. 把這個 GPT 處理網站吐出的 JSON 檔案放在 outputs/raw/{ticker}/ 下，
     由 adapters 讀檔解析
  3. 先手動把資料貼進 outputs/raw/{ticker}/*.json，之後再自動化

下面是每個 Gate 對應的抽象介面，先用 NotImplementedError 佔位，
你實作其中任一個 fetch_xxx 函式即可讓對應 Gate 開始運作。
管線會自動偵測哪些還沒接，並在報告中列為「資料源未接線」而非直接當作失敗。
"""

from abc import ABC, abstractmethod
from typing import Optional
from schema import (
    PSRHistory, PEGConsensus, CapacityRiskProfile, ConvertibleBondRecord,
    HolderConcentration, GuidanceRecord, PreEarningsConsensusSnapshot,
    PeerQualification, PeerConsensusRecord, MoatComparisonItem
)


class DataSourceNotConnected(Exception):
    """當某個 fetch_xxx 尚未實作時拋出，pipeline 會攔截並標記為『未接線』，
    不會讓整個流程中斷，也不會誤判為『判定失敗』。"""
    pass


class BaseAdapter(ABC):
    """所有真實 adapter（例如 adapters/gpt_site_adapter.py）繼承這個類別，
    並覆寫你有能力提供的方法；沒覆寫的會自動回報未接線。"""

    def fetch_moat_comparisons(self, ticker: str) -> list[MoatComparisonItem]:
        raise DataSourceNotConnected("Gate4 護城河比較證據：資料源未接線")

    def fetch_psr_history(self, ticker: str) -> Optional[PSRHistory]:
        raise DataSourceNotConnected("PSR 五年歷史：資料源未接線")

    def fetch_peg_consensus(self, ticker: str, target_year: int) -> Optional[PEGConsensus]:
        raise DataSourceNotConnected("PEG 共識覆蓋：資料源未接線")

    def fetch_capacity_risk(self, ticker: str) -> Optional[CapacityRiskProfile]:
        raise DataSourceNotConnected("產能風險資料：資料源未接線")

    def fetch_cb_records(self, ticker: str) -> list[ConvertibleBondRecord]:
        raise DataSourceNotConnected("可轉債資料：資料源未接線")

    def fetch_holder_concentration(self, ticker: str) -> Optional[HolderConcentration]:
        raise DataSourceNotConnected("大戶籌碼分布：資料源未接線")

    def fetch_guidance_records(self, ticker: str) -> list[GuidanceRecord]:
        raise DataSourceNotConnected("Gate5A 年度指引配對：資料源未接線")

    def fetch_pre_earnings_snapshots(self, ticker: str) -> list[PreEarningsConsensusSnapshot]:
        raise DataSourceNotConnected("Gate5B 財報前共識快照：資料源未接線（此項本質上無法回溯補齊歷史）")

    def fetch_peer_qualifications(self, ticker: str) -> list[PeerQualification]:
        raise DataSourceNotConnected("Gate8 合格同業名單：資料源未接線")

    def fetch_peer_consensus_2yr(self, ticker: str) -> list[PeerConsensusRecord]:
        raise DataSourceNotConnected("Gate8 兩年度同業共識：資料源未接線")
