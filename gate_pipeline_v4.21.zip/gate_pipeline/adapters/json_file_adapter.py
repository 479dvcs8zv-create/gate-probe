"""
adapters/json_file_adapter.py
=============================
最快可以讓管線「先跑起來」的接法：

你那個 GPT 處理網站，不管是用什麼方式運作，只要讓它把結果寫成
outputs/raw/{ticker}/{data_type}.json，這個 adapter 就會自動讀進來，
轉成 schema.py 定義的格式。

這樣你完全不需要改這份管線的程式碼，只要保證 GPT 處理網站吐出的
JSON 符合下面每個 _load_xxx 方法裡寫的欄位格式即可。

之後如果你想改成直接呼叫 API（而不是先落地成檔案），
只要另外寫一個 adapters/api_adapter.py 繼承 BaseAdapter，
不用動 pipeline.py 或 gates/*.py 任何一行。
"""

import json
import os
from typing import Optional
from adapters.base import BaseAdapter, DataSourceNotConnected
from schema import (
    Provenance, DataPoint, PSRHistory, PEGConsensus, CapacityRiskProfile,
    ConvertibleBondRecord, HolderConcentration, GuidanceRecord,
    PreEarningsConsensusSnapshot, PeerQualification, PeerConsensusRecord,
    MoatComparisonItem, AnalystEstimate
)


class JSONFileAdapter(BaseAdapter):

    def __init__(self, raw_dir: str = "outputs/raw"):
        self.raw_dir = raw_dir

    def _path(self, ticker: str, name: str) -> str:
        return os.path.join(self.raw_dir, ticker, f"{name}.json")

    def _load(self, ticker: str, name: str) -> Optional[dict]:
        p = self._path(ticker, name)
        if not os.path.exists(p):
            return None
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _dp(d: dict) -> DataPoint:
        """把 JSON 裡的一筆資料轉成 DataPoint，d 需包含 value 與 provenance。
        預期格式：
        {
          "value": ...,
          "source_name": "...",
          "source_url": "...",
          "fetched_at": "2026-10-17T10:00:00+08:00",
          "as_of_date": "2026-10-15",
          "raw_excerpt": "...",            # 選填
          "evidence_tier": "official_record"  # 選填，這是來源「自己宣告」的等級(claimed)，
                                               # 僅供稽核比對用，實際是否可信由
                                               # evidence_verification.py 依網域規則獨立驗證，
                                               # Gate5B 不會直接採信這裡填的值。
        }
        """
        return DataPoint(
            value=d["value"],
            provenance=Provenance(
                source_name=d["source_name"],
                source_url=d.get("source_url"),
                fetched_at=d["fetched_at"],
                as_of_date=d.get("as_of_date"),
                raw_excerpt=d.get("raw_excerpt"),
                claimed_evidence_tier=d.get("evidence_tier"),
                # verified_evidence_tier 故意不在這裡填，必須由
                # evidence_verification.verify_provenance_inplace() 獨立算出。
            ),
        )

    # ---- Gate 4 ----
    def fetch_moat_comparisons(self, ticker: str):
        data = self._load(ticker, "moat_comparisons")
        if data is None:
            raise DataSourceNotConnected("Gate4: 找不到 moat_comparisons.json")
        items = []
        for row in data["items"]:
            items.append(MoatComparisonItem(
                peer_name=row["peer_name"],
                comparison_point=row["comparison_point"],
                target_value=self._dp(row["target_value"]),
                peer_value=self._dp(row["peer_value"]),
                original_text_source=self._dp(row["original_text_source"]) if row.get("original_text_source") else None,
            ))
        return items

    # ---- PSR ----
    def fetch_psr_history(self, ticker: str):
        data = self._load(ticker, "psr_history")
        if data is None:
            raise DataSourceNotConnected("PSR: 找不到 psr_history.json")
        return PSRHistory(
            ticker=ticker,
            basis_definition=data["basis_definition"],
            quarterly_series=[self._dp(x) for x in data["quarterly_series"]],
        )

    # ---- PEG ----
    def fetch_peg_consensus(self, ticker: str, target_year: int):
        """預期 JSON 格式（每個估值需含機構ID，不再只是裸值）：
        {
          "eps_estimates": [
            {"institution_id": "...", "institution_name": "...", "target_year": 2027,
             "eps": {"value": 12.5, "source_name": "...", "source_url": "...",
                     "fetched_at": "...", "as_of_date": "..."}}
          ],
          "median_eps": 12.8
        }
        """
        data = self._load(ticker, f"peg_consensus_{target_year}")
        if data is None:
            raise DataSourceNotConnected(f"PEG: 找不到 peg_consensus_{target_year}.json")
        estimates = [
            AnalystEstimate(
                institution_id=row["institution_id"],
                institution_name=row.get("institution_name", row["institution_id"]),
                target_year=row["target_year"],
                eps=self._dp(row["eps"]),
            )
            for row in data["eps_estimates"]
        ]
        return PEGConsensus(
            ticker=ticker,
            target_year=target_year,
            eps_estimates=estimates,
            median_eps=data.get("median_eps"),
            coverage_count=len(estimates),
        )

    # ---- 產能風險 ----
    def fetch_capacity_risk(self, ticker: str):
        data = self._load(ticker, "capacity_risk")
        if data is None:
            raise DataSourceNotConnected("產能風險: 找不到 capacity_risk.json")
        return CapacityRiskProfile(
            ticker=ticker,
            fab_location_exposure=[self._dp(x) for x in data.get("fab_location_exposure", [])],
            alternative_sources=[self._dp(x) for x in data.get("alternative_sources", [])],
            customer_concentration=[self._dp(x) for x in data.get("customer_concentration", [])],
        )

    # ---- CB ----
    def fetch_cb_records(self, ticker: str):
        data = self._load(ticker, "cb_records")
        if data is None:
            raise DataSourceNotConnected("CB: 找不到 cb_records.json")
        out = []
        for row in data["records"]:
            out.append(ConvertibleBondRecord(
                cb_id=row["cb_id"],
                conversion_price=self._dp(row["conversion_price"]),
                shares_outstanding_same_day=self._dp(row["shares_outstanding_same_day"]),
                fx_rate_same_day=self._dp(row["fx_rate_same_day"]),
                event_log=[self._dp(e) for e in row.get("event_log", [])],
            ))
        return out

    # ---- 大戶籌碼 ----
    def fetch_holder_concentration(self, ticker: str):
        data = self._load(ticker, "holder_concentration")
        if data is None:
            raise DataSourceNotConnected("大戶籌碼: 找不到 holder_concentration.json")
        return HolderConcentration(
            ticker=ticker,
            threshold_lots=data["threshold_lots"],
            weekly_distribution=[self._dp(x) for x in data["weekly_distribution"]],
            consecutive_weeks_trend=data.get("consecutive_weeks_trend"),
        )

    # ---- Gate 5A ----
    def fetch_guidance_records(self, ticker: str):
        data = self._load(ticker, "guidance_records")
        if data is None:
            raise DataSourceNotConnected("Gate5A: 找不到 guidance_records.json")
        out = []
        for row in data["records"]:
            out.append(GuidanceRecord(
                ticker=ticker,
                fiscal_year=row["fiscal_year"],
                guidance_text=self._dp(row["guidance_text"]),
                guidance_release_date=self._dp(row["guidance_release_date"]),
                actual_result=self._dp(row["actual_result"]),
                basis_matches=row["basis_matches"],
            ))
        return out

    # ---- Gate 5B ----
    def fetch_pre_earnings_snapshots(self, ticker: str):
        """預期每筆需含 snapshot_date 與 earnings_announcement_date。

        重要：這裡填的 raw_excerpt / claimed_archive_timestamp /
        claimed_content_hash 全部只是 adapter「聲稱」的值（claimed_*），
        Gate5B 的四層驗證（v4.2起）不會直接信任這些欄位本身——
        真正決定 Layer2/3/4 能否通過的，是呼叫端傳入的
        IndependentVerifier 現場查到的 observed_* 值。這裡填的 claimed_*
        只用來跟 observed_* 做稽核比對（若不一致會記錄
        CLAIMED_HASH_MISMATCH），不構成任何一層的通過依據。
        """
        data = self._load(ticker, "pre_earnings_snapshots")
        if data is None:
            raise DataSourceNotConnected("Gate5B: 找不到 pre_earnings_snapshots.json（此項無法回溯重建歷史，需為可驗證的歷史或逐季累積的快照）")
        out = []
        for row in data["snapshots"]:
            out.append(PreEarningsConsensusSnapshot(
                ticker=ticker,
                fiscal_quarter=row["fiscal_quarter"],
                snapshot_date=self._dp(row["snapshot_date"]),
                earnings_announcement_date=self._dp(row["earnings_announcement_date"]),
                snapshot_taken_before_earnings=row.get("snapshot_taken_before_earnings", False),
                consensus_eps=self._dp(row["consensus_eps"]),
                consensus_revenue=self._dp(row["consensus_revenue"]),
                claimed_archive_timestamp=self._dp(row["claimed_archive_timestamp"]) if row.get("claimed_archive_timestamp") else None,
                claimed_content_hash=row.get("claimed_content_hash"),
            ))
        return out

    # ---- Gate 8 ----
    def fetch_peer_qualifications(self, ticker: str):
        data = self._load(ticker, "peer_qualifications")
        if data is None:
            raise DataSourceNotConnected("Gate8: 找不到 peer_qualifications.json")
        return [
            PeerQualification(
                peer_name=row["peer_name"],
                ticker=row["ticker"],
                company_id=row.get("company_id"),
                revenue_scale_match=row["revenue_scale_match"],
                product_overlap_score=row["product_overlap_score"],
                listing_region=row["listing_region"],
                qualifies=row["qualifies"],
                reason=row["reason"],
            )
            for row in data["peers"]
        ]

    def fetch_peer_consensus_2yr(self, ticker: str):
        data = self._load(ticker, "peer_consensus_2yr")
        if data is None:
            raise DataSourceNotConnected("Gate8: 找不到 peer_consensus_2yr.json")
        out = []
        for row in data["records"]:
            out.append(PeerConsensusRecord(
                peer_name=row["peer_name"],
                ticker=row["ticker"],
                company_id=row.get("company_id"),
                year=row["year"],
                consensus_value=self._dp(row["consensus_value"]),
            ))
        return out
