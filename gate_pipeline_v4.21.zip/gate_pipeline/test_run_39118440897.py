"""
test_run_39118440897.py (v4.18)
===============================
GitHub Actions 一鍵蒐證（collector 4.17，套件 sha256 5a978b85…）2026-10-18 的真實結果，含共識來源探測。
  - 這次重新向官方網站取得的證據：11 季截止點全部 CUTOFF_VERIFIED，且與 run 39114411258 完全相同
  - 官方財測模式：兩次獨立取得的官方詳細頁算出相同的財測與實際值（11/11 季）
  - 共識來源探測：真實分類結果；沒有任何來源被當成已取得共識（尚無解析器、尚無來源政策）

  python test_run_39118440897.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import consensus_discovery as cd  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_39118440897")
PREV = os.path.join(BASE, "run_39114411258")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))
RECORDED = json.load(open(os.path.join(RUN, "summary.json"), encoding="utf-8"))
DISC = json.load(open(os.path.join(RUN, "consensus_discovery", "discovery.json"), encoding="utf-8"))


def test_fresh_collection_matches_previous():
    assert open(os.path.join(RUN, "pipeline_package.sha256")).read().startswith("5a978b85")
    assert all(v["status"] == "CUTOFF_VERIFIED" for v in RECORDED["quarters"].values()) and len(RECORDED["quarters"]) == 11
    a, b = ce.replay(RUN, REVIEWS), ce.replay(PREV, REVIEWS)
    for q in a["quarters"]:
        assert a["quarters"][q]["earliest"] == b["quarters"][q]["earliest"], q
        assert (a["quarters"][q]["status"], a["quarters"][q]["earliest"]) == \
            (RECORDED["quarters"][q]["status"], RECORDED["quarters"][q]["earliest"]), q


def test_guidance_mode_identical_across_two_collections():
    """兩次各自向官方網站取得的證據，解析出的財測完全相同；兩次都還缺財測期間的公告原文（v4.19 才開始抓）。"""
    a, b = ce.replay(RUN, REVIEWS)["guidance"], ce.replay(PREV, REVIEWS)["guidance"]
    assert set(a["quarters"]) == set(b["quarters"]) and len(a["quarters"]) == 11
    for q in a["quarters"]:
        ga = {k: v for k, v in a["quarters"][q]["guidance"].items() if k != "response_sha256"}
        gb = {k: v for k, v in b["quarters"][q]["guidance"].items() if k != "response_sha256"}
        assert ga == gb, q
        assert a["quarters"][q]["status"] == b["quarters"][q]["status"] == "GUIDANCE_WINDOW_INCOMPLETE", q
    assert a["gate_result"]["status"] == "insufficient"


def test_discovery_real_classification():
    out = os.path.join(RUN, "consensus_discovery")
    c = cd.classify(DISC, out, parsers={})
    assert DISC["discovery_version"] == "4.17-discovery" and len(DISC["sources"]) == 16
    assert c["yahoo_adr_analysis"]["2024Q4"]["status"] == "UNPARSED"
    assert c["marketbeat_adr_earnings"]["2026Q2"]["status"] == "UNPARSED"
    assert c["zacks_adr_detailed"]["2025Q1"]["status"] == "QUERY_FAILED"      # 查詢失敗 ≠ 沒有存檔
    assert c["wantgoo_tw"]["2025Q1"]["status"] == "TIMEOUT"
    assert not any(v["status"] == "CONSENSUS_CANDIDATE" for s in c.values() for v in s.values())
    for s in DISC["sources"]:
        for x in s["samples"]:
            if x.get("file"):
                import hashlib
                data = open(os.path.join(out, x["file"]), "rb").read()
                assert hashlib.sha256(data).hexdigest() == x["sha256"] and x["digest_matched"], x["file"]
    # 抽樣原文：Yahoo、Nasdaq 存檔頁面本身沒有預估數字（數字是另外載入的）
    for f in ("yahoo_adr_analysis_2025Q1.bin", "nasdaq_adr_earnings_2025Q2.bin"):
        raw = open(os.path.join(out, "samples", f), "rb").read()
        assert b"Estimate" not in raw and b"EPS" not in raw, f


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
