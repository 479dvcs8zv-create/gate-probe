"""
test_cross_company_guards.py (v4.21)
====================================
跨標的防呆：換成其他公司（例如 2454）時，凡是只對台積電成立的假設，都必須「正確阻擋」而不是「錯誤通過」。
用 2330 的真實官方證據（run 39126755093）模擬其他公司常見的差異：
  1. 公司不以重大訊息公告每月營收（多數公司只用每月營收申報系統）→ 截止點不能放行
  2. 公告主旨用民國年或不同寫法 → 不被誤判成財務事件；找不到可辨識事件 → 不能放行
  3. 每股盈餘公告不是台積電的寫法 → 官方財測模式判為缺財測／解析失敗，絕不會 VERIFIED
  4. 換股票時審查紀錄、快取都按股票代號分開，2330 的紀錄不會套用到別的公司

  python test_cross_company_guards.py
"""
import dataclasses
import json
import os
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import guidance_mops as gm  # noqa: E402
from mops_t05st01 import classify, cutoff_candidates, parse_t05st01_detail, parse_t05st01_listing  # noqa: E402
from mops_t57sb01 import parse_t57sb01_listing  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_39126755093")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))


def _load():
    m = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
    listings, filings = {}, []
    for r in m["requests"]:
        if r["kind"] == "t05st01_listing" and r["response_file"]:
            lst, _ = parse_t05st01_listing(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                           r["request_url"], "2330", r["params"]["roc_year"], "", r["response_sha256"])
            if lst:
                listings[int(r["params"]["roc_year"])] = lst
    ml = list(ce._merge_runs(listings).values())[0]
    by = {it.document_id: it for it in ml.items}
    details = {}
    for r in m["requests"]:
        if r["kind"] == "t05st01_detail" and r.get("parsed"):
            it = by[r["params"]["document_id"]]
            d, _ = parse_t05st01_detail(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                        r["request_url"], it, r["response_sha256"])
            if d:
                details[it.document_id] = d
        if r["kind"] == "t57sb01_list" and r["response_file"]:
            fl, _ = parse_t57sb01_listing(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                          r["request_url"], "2330", r["params"]["roc_year"], ml.company_name,
                                          datetime.fromisoformat(r["retrieved_at"]), r["response_sha256"])
            if fl:
                filings.append(fl)
    return ml, details, filings


ML, DETAILS, FILINGS = _load()
POLICY = set(REVIEWS["__clause_policy__"]["clauses"])


def _reviewed(q):
    rv = REVIEWS.get(("2330", q))
    return {r["document_id"] for r in rv["reviewed_non_results"]} if rv else set()


def test_baseline_2330_is_verified():
    cc = cutoff_candidates(ML, "2025Q3", details=DETAILS, filings=FILINGS, reviewed_non_results=_reviewed("2025Q3"),
                           auto_clear_clauses=POLICY)
    assert cc["status"] == "CUTOFF_VERIFIED" and cc["earliest"]["event_type"] == "quarter_revenue_complete", cc["blocking"]


def test_company_without_revenue_announcements_is_blocked():
    """把所有「營收報告」重大訊息拿掉（像多數只走月營收申報系統的公司）：其他事件都還在，但截止點不能放行。"""
    no_rev = dataclasses.replace(ML, items=[it for it in ML.items if "營收報告" not in it.subject])
    for q in ("2024Q3", "2025Q3", "2026Q2"):
        cc = cutoff_candidates(no_rev, q, details=DETAILS, filings=FILINGS, reviewed_non_results=_reviewed(q),
                               auto_clear_clauses=POLICY)
        assert cc["status"] == "PROVISIONAL", (q, cc["status"])
        assert any("找不到該季季末月份的營收公告" in b for b in cc["blocking"]), cc["blocking"]
        assert cc["earliest"] is not None and cc["earliest"]["event_type"] != "quarter_revenue_complete"
    # 研究用途明確不含營收時（include_revenue=False）才不檢查這個管道
    cc = cutoff_candidates(no_rev, "2025Q3", include_revenue=False, details=DETAILS, filings=FILINGS,
                           reviewed_non_results=_reviewed("2025Q3"), auto_clear_clauses=POLICY)
    assert not any("營收公告" in b for b in cc["blocking"])


def test_other_subject_formats_are_not_misclassified():
    eps = [it for it in ML.items if "每股盈餘" in it.subject][0]
    for subject in ("聯發科技114年第二季每股盈餘新台幣24.58元", "本公司董事會通過114年第2季合併財務報告",
                    "公告本公司將召開114年第三季法人說明會", "聯發科技公布2025年9月營收"):
        assert classify(dataclasses.replace(eps, subject=subject)) == [], subject


def test_no_recognizable_events_blocks():
    """所有財務事件主旨都換成其他寫法 → 清單裡找不到可辨識的揭露 → 阻擋。"""
    renamed = [dataclasses.replace(it, subject="（其他公司寫法）" + it.subject.replace("每股盈餘", "EPS")
                                   .replace("營收報告", "營收").replace("董事會決議通過", "董事會通過")
                                   .replace("法人說明會將於", "法說會於"))
               for it in ML.items]
    other = dataclasses.replace(ML, items=renamed)
    cc = cutoff_candidates(other, "2025Q3", details={}, filings=FILINGS, auto_clear_clauses=POLICY)
    assert cc["status"] == "PROVISIONAL" and cc["earliest"] is not None and cc["earliest"]["event_type"] == "financial_report"
    assert any("找不到該季季末月份的營收公告" in b for b in cc["blocking"]), cc["blocking"]


def test_guidance_mode_does_not_pass_other_formats():
    """每股盈餘公告不是台積電的寫法 → 沒有財測可用 → 官方財測模式不會 VERIFIED。"""
    eps_items = [it for it in ML.items if any(e["event_type"] == "self_reported_results" for e in classify(it))]
    other = {k: (dataclasses.replace(v, description="本公司114年第2季合併財務報告經董事會通過，每股盈餘新台幣24.58元。")
                 if k in {it.document_id for it in eps_items} else v) for k, v in DETAILS.items()}
    cut = {q: datetime.fromisoformat(t) for q, t in {"2025Q2": "2025-07-10T14:26:42+08:00",
                                                     "2025Q3": "2025-10-09T14:01:10+08:00"}.items()}
    g = gm.evaluate_guidance(ML.items, other, cut)
    assert {e["status"] for e in g["quarters"].values()} == {"MISSING_GUIDANCE"}, g["quarters"]
    assert g["gate"]["result"] == "INSUFFICIENT" and len(g["parse_failures"]) == len(eps_items)
    from gates import eval_gate5b_official_guidance
    assert eval_gate5b_official_guidance(g).status == "insufficient"


def test_reviews_are_per_company():
    """2330 的人工審查、財測確認紀錄只屬於 2330；換成 2454 時一筆都不會被套用。"""
    keys = [k for k in REVIEWS if isinstance(k, tuple)]
    assert keys and all(k[0] == "2330" for k in keys)
    assert all(c == "2330" for (c, q) in REVIEWS["__guidance_reviews__"]) and \
        all(c == "2330" for (c, q) in REVIEWS["__guidance_updates__"])
    apr05 = "t05st01:2330:20240405:212303:1"
    for co, cleared in (("2330", True), ("2454", False)):
        summary = {"quarters": {"2024Q1": {"status": "CUTOFF_VERIFIED", "earliest": {"at": "2024-04-10T13:50:59+08:00"}}}}
        ce._evaluate_guidance(co, {(113,): ML}, DETAILS, summary, REVIEWS)
        w = summary["guidance"]["quarters"]["2024Q1"]["window"]
        assert ([x["document_id"] for x in w["cleared_by_review"]] == [apr05]) is cleared, (co, w)
        assert ([x["document_id"] for x in w["flagged"]] == [apr05]) is (not cleared), (co, w)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
