"""
test_run_39126755093.py (v4.20)
===============================
v4.19 第二批一鍵蒐證（gate-probe run 39126755093，collector 4.19）：財測發布到截止點之間的公告原文已全部取得
（646 則中沿用 390、新抓 256；僅 2026-05-13 一則逾時）。用使用者的確認紀錄離線重算官方財測模式：
  - 2024Q1、2024Q2：地震說明經確認未更新財測 → 已驗證
  - 2025Q1：2025-02-10「營收將較趨近財測低標」經確認為更新財測 → GUIDANCE_UPDATED，不採用
  - 2026Q2：缺 1 則原文 → GUIDANCE_WINDOW_INCOMPLETE（不猜）
  - 其餘 7 季已驗證，合計 9/11 → official_guidance_verified（不是 pass）
  - 沒有確認紀錄時，三則地震相關公告都會被攔下待確認；法說會「將公布業績展望」的通知一則都不會被攔

  python test_run_39126755093.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_39126755093")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))
MANIFEST = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
SUMMARY = json.load(open(os.path.join(RUN, "summary.json"), encoding="utf-8"))
FEB10 = "t05st01:2330:20250210:140102:1"
APR05 = "t05st01:2330:20240405:212303:1"
APR18 = "t05st01:2330:20240418:191527:4"
MAY13 = "t05st01:2330:20260513:142932:1"


def test_collection_complete_except_one():
    assert MANIFEST["collector_version"] == "4.19-collect"
    assert SUMMARY["detail_counts"] == {"wanted": 646, "fetched": 256, "from_cache": 390, "skipped_over_limit": 0}
    assert [d for d, v in SUMMARY["details"].items() if not v["ok"]] == [MAY13]
    cached = [r for r in MANIFEST["requests"] if r.get("cached_from")]
    assert len(cached) == 390 and all(r["attempt"] == 0 and r["parsed"] for r in cached)
    assert all(v["status"] == "CUTOFF_VERIFIED" for v in SUMMARY["quarters"].values()) and len(SUMMARY["quarters"]) == 11


def test_guidance_mode_with_user_decisions():
    s = ce.replay(RUN, REVIEWS)
    g = s["guidance"]
    st = {q: e["status"] for q, e in g["quarters"].items()}
    assert st.pop("2025Q1") == "GUIDANCE_UPDATED" and st.pop("2026Q2") == "GUIDANCE_WINDOW_INCOMPLETE"
    assert set(st.values()) == {"VERIFIED"} and len(st) == 9
    assert g["quarters"]["2026Q2"]["window"]["missing_detail"] == [MAY13]
    assert g["quarters"]["2025Q1"]["window"]["confirmed_updates"][0]["document_id"] == FEB10
    assert [x["document_id"] for x in g["quarters"]["2024Q1"]["window"]["cleared_by_review"]] == [APR05]
    assert [x["document_id"] for x in g["quarters"]["2024Q2"]["window"]["cleared_by_review"]] == [APR18]
    gr = g["gate_result"]
    assert gr["status"] == "official_guidance_verified" and gr["evidence_count"] == 9 and gr["status"] != "pass"
    assert gr["reject_codes"] == ["GUIDANCE_UPDATED", "GUIDANCE_WINDOW_INCOMPLETE"]
    # 每一季：財測期間公告全數有原文（除 2026Q2 一則），財測早於截止點、實際結果晚於截止點
    from datetime import datetime
    for q, e in g["quarters"].items():
        if e["status"] == "VERIFIED":
            assert e["window"]["missing_detail"] == [] and e["window"]["announcements"] > 10, q
            assert datetime.fromisoformat(e["guidance"]["announced_at"]) < datetime.fromisoformat(e["cutoff"]), q
            assert datetime.fromisoformat(e["actual"]["announced_at"]) > datetime.fromisoformat(e["cutoff"]), q
    assert g["quarters"]["2025Q4"]["verdicts"] == {"revenue_usd_bn": "ABOVE", "gross_margin_pct": "ABOVE",
                                                   "operating_margin_pct": "ABOVE"}


def test_without_decisions_three_items_are_held():
    no_guidance = {k: v for k, v in REVIEWS.items() if k not in ("__guidance_reviews__", "__guidance_updates__")}
    g = ce.replay(RUN, no_guidance)["guidance"]
    held = {q: [x["document_id"] for x in e["window"]["flagged"]] for q, e in g["quarters"].items()
            if e["status"] == "GUIDANCE_UPDATE_REVIEW_PENDING"}
    assert held == {"2024Q1": [APR05], "2024Q2": [APR18], "2025Q1": [FEB10]}, held
    for e in g["quarters"].values():   # 法說會通知（「將公布…業績展望」）一則都沒有被攔
        assert not any("法人說明會" in x["subject"] for x in (e["window"] or {}).get("flagged", []))
    assert g["gate"]["verified_quarters"] == 7


def test_decision_records_point_to_real_evidence():
    sha = {r["params"]["document_id"]: r["response_sha256"] for r in MANIFEST["requests"]
           if r["kind"] == "t05st01_detail" and r.get("parsed")}
    for name in ("2330_2024Q1_guidance.json", "2330_2024Q2_guidance.json", "2330_2025Q1_guidance.json"):
        rv = json.load(open(os.path.join(BASE, "reviews", name), encoding="utf-8"))
        assert rv["reviewer"] and rv["decided_at"] and rv["decision"] in ("guidance_not_updated", "guidance_updated")
        for x in rv["reviewed"]:
            assert sha[x["document_id"]] == x["detail_response_sha256"], x["document_id"]


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
