"""
test_archive_real_39122089604.py (v4.20)
========================================
第一次真實自行存檔（gate-pipeline-archive run 39122089604，2026-10-18，archiver 4.18）：
7 個網站中 Yahoo Finance（TSM）與 Nasdaq API（Zacks 資料）由 Wayback 存檔並核對 SHA-1 摘要成功。
確認：存下來的原始位元組與記錄的雜湊、封存摘要一致；Yahoo 原文是 gzip 壓縮，解壓後含多位分析師的預估；
Nasdaq 原文是 JSON，含逐季共識 EPS 與分析師人數。這些只是存檔，尚未作為任何 Gate 的判定依據。

  python test_archive_real_39122089604.py
"""
import base64
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import archive_consensus as ac  # noqa: E402

RUN = os.path.join(HERE, "contract", "mops_real", "archive_39122089604")
R = json.load(open(os.path.join(RUN, "archive.json"), encoding="utf-8"))


def _t(i):
    return [x for x in R["targets"] if x["id"] == i][0]


def test_statuses_and_integrity():
    st = {x["id"]: x["status"] for x in R["targets"]}
    assert st["yahoo_adr_analysis"] == "ARCHIVED" and st["nasdaq_api_forecast"] == "ARCHIVED", st
    assert sum(1 for v in st.values() if v == "SAVE_FAILED") == 5
    for i in ("yahoo_adr_analysis", "nasdaq_api_forecast"):
        c = _t(i)["capture"]
        raw = open(os.path.join(RUN, c["file"]), "rb").read()
        assert hashlib.sha256(raw).hexdigest() == c["sha256"]
        assert base64.b32encode(hashlib.sha1(raw).digest()).decode() == c["cdx_digest"] and c["digest_matched"]
        assert c["captured_at_tpe"].startswith("2026-10-18T19:")


def test_contents_have_multi_analyst_estimates():
    y = ac.decode_payload(open(os.path.join(RUN, _t("yahoo_adr_analysis")["capture"]["file"]), "rb").read()).decode()
    assert "Current Qtr. (Dec 2026)" in y and "No. of Analysts" in y and "1.71T" in y
    n = json.loads(ac.decode_payload(open(os.path.join(RUN, _t("nasdaq_api_forecast")["capture"]["file"]), "rb").read()))
    row = n["data"]["quarterlyForecast"]["rows"][0]
    assert row["fiscalEnd"] == "Dec 2026" and row["consensusEPSForecast"] == 4.74 and row["noOfEstimates"] == 5, row


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
