"""
test_run_39114411258.py (v4.16)
===============================
GitHub Actions 一鍵蒐證（collector 4.15，套件 sha256 3643701e…）2026-10-18 的真實結果：
民國 113–115 年全年清單（272 / 248 / 153 則）、101 則詳細頁請求（含重試）、113–115 年財報申報清單。
離線重算確認：
  - 與 Actions 當時的 summary.json 完全一致（當時只有 2026Q2 人工審查 + 20/6/8 款規則）
  - 重試紀錄：逾時 → 第 3 次成功、502 → 第 2 次成功、連續 3 次逾時 → 放棄並照實記錄
  - 加上使用者 2026-10-18 17:47 確認的三季審查紀錄（2024Q1 五則、2024Q3 一則、2025Q2 一則）→ 11 季全部 CUTOFF_VERIFIED
  - 拿掉任何一季的審查紀錄 → 那一季退回暫定（審查紀錄只清除它列出的公告）
  - 審查紀錄中的詳細頁雜湊與蒐證 manifest 一致；4/5 地震更新內含全年展望一事有記錄在案

  python test_run_39114411258.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_39114411258")
MANIFEST = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
RECORDED = json.load(open(os.path.join(RUN, "summary.json"), encoding="utf-8"))
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))
AT_RUN_TIME = {("2330", "2026Q2"): REVIEWS[("2330", "2026Q2")], "__clause_policy__": REVIEWS["__clause_policy__"]}
NEW_REVIEW_QUARTERS = ("2024Q1", "2024Q3", "2025Q2")

EXPECTED_CUTOFFS = {
    "2024Q1": "2024-04-10T13:50:59+08:00", "2024Q2": "2024-07-10T13:48:38+08:00",
    "2024Q3": "2024-10-09T13:37:57+08:00", "2024Q4": "2025-01-10T14:05:13+08:00",
    "2025Q1": "2025-04-10T14:05:27+08:00", "2025Q2": "2025-07-10T14:26:42+08:00",
    "2025Q3": "2025-10-09T14:01:10+08:00", "2025Q4": "2026-01-09T13:51:04+08:00",
    "2026Q1": "2026-04-10T13:50:36+08:00", "2026Q2": "2026-07-13T13:50:31+08:00",
    "2026Q3": "2026-10-08T13:54:04+08:00",
}


def test_package_and_collector_version():
    assert MANIFEST["collector_version"] == "4.15-collect"
    line = open(os.path.join(RUN, "pipeline_package.sha256"), encoding="utf-8").read()
    assert line.startswith("3643701e06ff16e260b79a8bb1d4ff8ede5e8e980926bb930beb8774d701006d"), line


def test_replay_matches_actions_summary():
    s = ce.replay(RUN, AT_RUN_TIME)
    assert sorted(s["quarters"]) == sorted(RECORDED["quarters"]) == sorted(EXPECTED_CUTOFFS)
    for q, old in RECORDED["quarters"].items():
        new = s["quarters"][q]
        assert (new["status"], new["earliest"], new["blocking"], new["events"]) == \
            (old["status"], old["earliest"], old["blocking"], old["events"]), q
        assert [(r["document_id"], r["cleared_by"]) for r in new["review_window"]] == \
            [(r["document_id"], r["cleared_by"]) for r in old["review_window"]], q
    assert {y: v["items"] for y, v in s["listings"].items()} == {"113": 272, "114": 248, "115": 153}
    verified = sorted(q for q, v in s["quarters"].items() if v["status"] == "CUTOFF_VERIFIED")
    assert verified == ["2024Q2", "2024Q4", "2025Q1", "2025Q3", "2025Q4", "2026Q1", "2026Q2", "2026Q3"], verified
    auto = sum(1 for v in s["quarters"].values() for r in v["review_window"] if r["cleared_by"] == "auto_clause_rule")
    assert auto == 34, auto


def test_retry_attempts_are_recorded():
    by_doc = {}
    for r in MANIFEST["requests"]:
        if r["kind"] == "t05st01_detail":
            by_doc.setdefault(r["params"]["document_id"], []).append(
                (r["attempt"], r["status"], bool(r["error"]), r["parsed"]))
    assert by_doc["t05st01:2330:20240408:193101:2"] == [(1, None, True, False), (2, None, True, False),
                                                         (3, None, True, False)]
    assert by_doc["t05st01:2330:20240702:175630:2"] == [(1, None, True, False), (2, None, True, False),
                                                         (3, 200, False, True)]
    assert by_doc["t05st01:2330:20241009:174816:3"] == [(1, 502, False, False), (2, 200, False, True)]
    assert sum(1 for r in MANIFEST["requests"] if r.get("attempt", 1) > 1) == 5
    files = [r["response_file"] for r in MANIFEST["requests"] if r["response_file"]]
    assert len(files) == len(set(files))   # 每次嘗試各自存檔


def test_all_eleven_quarters_verified_with_reviews():
    s = ce.replay(RUN, REVIEWS)
    for q, at in EXPECTED_CUTOFFS.items():
        v = s["quarters"][q]
        assert v["status"] == "CUTOFF_VERIFIED" and v["blocking"] == [], (q, v["blocking"])
        assert v["earliest"]["at"] == at and v["earliest"]["event_type"] == "quarter_revenue_complete", q
        assert v["earliest"]["detail_verified"] is True, q
        assert all(r["cleared_by"] for r in v["review_window"]), q
    human = sorted(r["document_id"] for q in NEW_REVIEW_QUARTERS for r in s["quarters"][q]["review_window"]
                   if r["cleared_by"] == "human_review")
    assert len(human) == 7, human


def test_each_review_only_clears_its_own_quarter():
    for q in NEW_REVIEW_QUARTERS:
        partial = {k: v for k, v in REVIEWS.items() if k != ("2330", q)}
        s = ce.replay(RUN, partial)
        assert s["quarters"][q]["status"] == "PROVISIONAL", q
        others = [k for k in NEW_REVIEW_QUARTERS if k != q]
        assert all(s["quarters"][o]["status"] == "CUTOFF_VERIFIED" for o in others), q


def test_review_records_match_evidence():
    detail_sha = {r["params"]["document_id"]: r["response_sha256"] for r in MANIFEST["requests"]
                  if r["kind"] == "t05st01_detail" and r["parsed"]}
    for q in NEW_REVIEW_QUARTERS:
        rv = REVIEWS[("2330", q)]
        assert rv["reviewer"] and rv["decided_at"] == "2026-10-18T17:47:59+08:00" and rv["decision"] == "not_financial_results"
        for item in rv["reviewed_non_results"]:
            assert item["detail_response_sha256"] == detail_sha.get(item["document_id"]), item["document_id"]
    q1 = {i["document_id"]: i for i in REVIEWS[("2330", "2024Q1")]["reviewed_non_results"]}
    assert "全年業績展望" in q1["t05st01:2330:20240405:212303:1"]["note"]
    assert q1["t05st01:2330:20240408:193101:2"]["clause"] is None and \
        q1["t05st01:2330:20240408:193101:2"]["detail_response_sha256"] is None


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
