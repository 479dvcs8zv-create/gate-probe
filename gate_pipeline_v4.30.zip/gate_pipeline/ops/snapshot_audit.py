"""
ops/snapshot_audit.py (v4.28)
=============================
歷史市場共識快照的逐項資格審查。只產生研究紀錄（gate_impact = "none"），不改變任何 Gate 判定。

審查對象：研究紀錄中「截止點已取得、存檔在快照界線之前 45 天內」的每一筆預估（BEFORE_CUTOFF）。
每一筆逐項檢查，結果是 PASS／FAIL／PENDING／INFO，並寫明原因：

  原文完整性      保存的位元組 SHA-256 與紀錄相同；重算 SHA-1 摘要與封存索引記錄的摘要相同
  封存索引對應    保存下來的 CDX 原始回應裡，確實有「同一時間戳、同一網址、同一摘要、HTTP 200」這一列
  重新下載核對    在 Actions 裡第二次從 Wayback 取得同一份存檔，位元組完全相同
  時間            封存時間「嚴格早於」快照界線（月營收＝公告當日 00:00），且在 45 天內
  股票代號        頁面上的報價代號與預期相同
  目標期間        頁面期間標籤對應到受審查的季度
  單位            幣別寫在頁面上；與官方 EPS（新台幣／每股）是否同單位
  口徑            GAAP／調整後是否寫明
  人數            分析師人數（單一來源，不與其他來源加總）
  是否更新        與更早的存檔數值完全相同 → 網站可能未更新
  事後說法（INFO） 網站在公布後列出的「當時預估」，只對照，不採用

判定：任何 FAIL → NOT_ADOPTABLE；沒有 FAIL 但有 PENDING → PENDING（列出原因類別）；
全部通過 → ADOPTABLE（研究上可採用，仍不等於 Gate PASS）。

v4.28（使用者 2026-10-19 採用的四條規則，reviews/consensus_research_policy.json）：
  1. ADR 美元預估只和官方公告同季的「每單位 ADR 美元 EPS」比較，不自行換匯（美元營收同理）
  2. 頁面沒寫 GAAP／調整後 → 維持待確認
  3. 分析師人數只標品質（單一／少量／一般），不設 Gate 最低人數
  4. ADR 報價頁上的新台幣 EPS，未確認每股或每 ADR 前 → 維持待確認
  另外：重新下載失敗分成網路失敗、封存取不到、內容不一致三種；只有內容不一致才是 FAIL。
"""

import base64
import hashlib
import json
import os
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from consensus_parsers import label_to_period  # noqa: E402
from consensus_research import _fmt  # noqa: E402

AUDIT_VERSION = "4.30-snapshot-audit"
TPE = timezone(timedelta(hours=8))
STALE_DAYS = 30
# 待確認的原因類別。kind：rule＝依已採用的規則維持待確認；data＝等資料（例如官方尚未公布）；
# check＝等核對執行；open＝還沒有規則，需要使用者決定
PENDING_CATEGORIES = {
    "REFETCH": ("check", "尚未在 Actions 重新下載核對，或上次因網路／封存取不到而沒有完成"),
    "BASIS_UNSTATED": ("rule", "頁面沒寫 GAAP／調整後（規則 2：維持待確認）"),
    "SHARE_BASIS_UNSTATED": ("rule", "ADR 報價頁上的新台幣 EPS 沒寫每股或每 ADR（規則 4：維持待確認）"),
    "OFFICIAL_FIGURE_MISSING": ("data", "官方公告沒有同單位的數字（規則 1：不自行換匯），或尚未取得官方公告"),
    "CURRENCY_ASSUMED": ("rule", "頁面沒寫幣別，只有設定檔的假設（不能只憑網址推定）"),
    "STALE_VALUES": ("open", "數值與 30 天以上前的存檔完全相同，網站可能未更新；這類來源是否採用尚未決定"),
    "UNIT_CONFLICT": ("check", "頁面標示的幣別與頁面上的數值互相矛盾（同頁歷史實際值符合另一種單位，或數量級與官方同單位數字差太多），"
                              "頁面標示可能有誤，不能照標示比較"),
}
MAGNITUDE_BAND = (0.5, 2.0)   # 預估平均／官方同單位數字超出此範圍 → 視為單位可能標錯（只會變成待確認，不會放行）
COVERAGE = ((1, "單一預估"), (4, "少量"), (10 ** 9, "一般"))   # 規則 3：只標品質，不影響判定


def _digest(b):
    return base64.b32encode(hashlib.sha1(b).digest()).decode("ascii")


def _chk(name, result, detail, category=None):
    d = {"check": name, "result": result, "detail": detail}
    if category:
        d["category"] = category
    return d


def _cdx_binding(cap):
    files = cap.get("cdx_files") or []
    if not files:
        return _chk("封存索引對應", "PENDING", "沒有保存封存索引（CDX）原始回應，無法離線核對時間戳與摘要的對應")
    for path, sha in files:
        if not os.path.exists(path):
            continue
        body = open(path, "rb").read()
        if sha and hashlib.sha256(body).hexdigest() != sha:
            return _chk("封存索引對應", "FAIL", f"CDX 原始回應 {os.path.basename(path)} 的 SHA-256 與紀錄不符")
        try:
            rows = json.loads(body)
        except ValueError:
            continue
        if not rows or not isinstance(rows[0], list):
            continue
        hdr = rows[0]
        for r in rows[1:]:
            if not isinstance(r, list) or len(r) != len(hdr):
                continue
            row = dict(zip(hdr, r))
            if row.get("timestamp") == cap["capture_ts"] and row.get("original") == cap.get("original"):
                if row.get("statuscode") == "200" and row.get("digest") == cap.get("archive_digest"):
                    return _chk("封存索引對應", "PASS", f"CDX 回應 {os.path.basename(path)} 有對應列："
                                f"{row['timestamp']}、HTTP 200、摘要 {row['digest']}")
                return _chk("封存索引對應", "FAIL", f"CDX 對應列的狀態或摘要不同：{row}")
    return _chk("封存索引對應", "FAIL", "保存的 CDX 回應裡找不到這個時間戳與網址")


def _coverage(n):
    if n is None:
        return "人數未知"
    return next(label for top, label in COVERAGE if n <= top)


def _actuals_vs_official(page_actuals, official, currency):
    """頁面列出的歷史實際 EPS 與官方公告逐季比對（美元＝每單位 ADR，新台幣＝每股）。"""
    key = {"USD": "eps_usd_per_adr", "TWD": "eps_twd_per_share"}.get(currency)
    same, diff = [], []
    for fq, v in sorted(page_actuals.items()):
        o = (official.get(fq) or {}).get(key) if key else None
        if o is None or v is None:
            continue
        (same if abs(v - o) < 0.0051 else diff).append((fq, v, o))
    return same, diff


def audit_entry(fp, e, cap, cutoff, series, retro, refetch, official=None, page_actuals=None):
    checks = []
    # 1. 原文完整性
    if cap is None or not os.path.exists(cap["file"]):
        checks.append(_chk("原文完整性", "FAIL", "找不到保存的原文"))
    else:
        raw = open(cap["file"], "rb").read()
        ok_sha = hashlib.sha256(raw).hexdigest() == cap["sha256"]
        ok_dig = bool(cap.get("archive_digest")) and _digest(raw) == cap["archive_digest"]
        checks.append(_chk("原文完整性", "PASS" if ok_sha and ok_dig else "FAIL",
                           f"SHA-256 {'相符' if ok_sha else '不符'}；重算 SHA-1 摘要 {'與封存索引相同' if ok_dig else '與封存索引不同或沒有記錄'}"))
    # 2. 封存索引對應
    checks.append(_cdx_binding(cap) if cap else _chk("封存索引對應", "FAIL", "找不到存檔紀錄"))
    # 3. 重新下載核對
    rf = refetch.get((e["source_id"], e["capture_ts"]))
    st = (rf or {}).get("status")
    if st == "MATCHED":
        checks.append(_chk("重新下載核對", "PASS", f"run {rf.get('run')} 再次從 Wayback 取得，位元組完全相同"))
    elif st in ("MISMATCH_LOCAL", "MISMATCH_ARCHIVE", "MISMATCH"):
        why = {"MISMATCH_LOCAL": "再次取得的位元組符合封存摘要，但與我們保存的不同（保存的原文有問題）",
               "MISMATCH_ARCHIVE": "再次取得的位元組與封存摘要不符（封存服務送出的內容不同）"}.get(st, "位元組不同")
        checks.append(_chk("重新下載核對", "FAIL", f"run {rf.get('run')}：{why}"))
    elif st == "ARCHIVE_UNAVAILABLE":
        checks.append(_chk("重新下載核對", "PENDING", f"封存目前取不到（{rf.get('reason')}）；不代表內容被竄改", "REFETCH"))
    else:
        why = f"上次網路失敗（{rf.get('reason')}），下次重試" if rf else "還沒有執行"
        checks.append(_chk("重新下載核對", "PENDING", f"需在 Actions 再從 Wayback 取得一次核對；{why}", "REFETCH"))
    # 4. 時間
    cap_utc = datetime.strptime(e["capture_ts"], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    ti = e.get("timing_info") or {}
    b = datetime.fromisoformat(ti["conservative_boundary"]) if ti.get("conservative_boundary") else None
    if b is None:
        checks.append(_chk("時間", "FAIL", "沒有快照界線"))
    elif not cap_utc < b:
        checks.append(_chk("時間", "FAIL", f"封存時間 {cap_utc.astimezone(TPE).isoformat()} 不早於快照界線 {b.isoformat()}"))
    elif b - cap_utc > timedelta(days=45):
        checks.append(_chk("時間", "FAIL", f"封存時間早於快照界線 {(b - cap_utc).days} 天，超過 45 天"))
    else:
        checks.append(_chk("時間", "PASS", f"封存 {cap_utc.astimezone(TPE).isoformat()[:16]}，嚴格早於快照界線 "
                                         f"{b.isoformat()[:16]}（{round((b - cap_utc).total_seconds() / 86400, 1)} 天前；"
                                         f"公告時間 {ti.get('announced_at', '')[:16]}）"))
    # 5. 股票代號（解析器已檢查；不符的不會出現在這裡）
    checks.append(_chk("股票代號", "PASS", f"頁面報價代號 {e['quote'] if e['metric'] == 'eps' else '（營收）'}"))
    # 6. 目標期間
    again = label_to_period(e["period_label_raw"], e.get("period_type"))   # 從原文標籤重新推導，不沿用分組結果
    checks.append(_chk("目標期間", "PASS" if again == fp and e.get("period_type") == "quarter" else "FAIL",
                       f"頁面標籤「{e['period_label_raw']}」重新推導為 {again}，受審季度 {fp}"))
    # 7. 單位（規則 1、4）
    cur, quote = e["currency"], e["quote"]
    off = (official or {}).get(fp) or {}
    doc = f"（{off.get('document_id')}）" if off.get("document_id") else ""
    if e.get("currency_from") != "page":
        checks.append(_chk("單位", "PENDING", "頁面沒寫幣別，使用設定檔假設", "CURRENCY_ASSUMED"))
    elif e["metric"] == "eps" and cur == "TWD" and str(quote).endswith(".TW"):
        o = off.get("eps_twd_per_share")
        checks.append(_chk("單位", "PASS", "新台幣／每股（台股報價頁），與官方 EPS 同單位"
                           + (f"；官方同季 {o:g} 元{doc}" if o is not None else "")))
    elif e["metric"] == "eps" and cur == "USD":
        o = off.get("eps_usd_per_adr")
        if o is not None:
            checks.append(_chk("單位", "PASS", f"美元／ADR；官方公告同季寫明折合每單位 ADR {o:g} 美元{doc}，直接比較，不換匯"))
        elif off.get("eps_twd_per_share") is not None:
            checks.append(_chk("單位", "PENDING", "官方公告只有新台幣每股 EPS，沒有每單位 ADR 美元數字；依規則不自行換匯",
                               "OFFICIAL_FIGURE_MISSING"))
        else:
            checks.append(_chk("單位", "PENDING", "尚未取得官方同季自結財務結果公告", "OFFICIAL_FIGURE_MISSING"))
    elif e["metric"] == "eps":
        checks.append(_chk("單位", "PENDING", f"{cur}，ADR 報價頁上沒寫每股或每 ADR", "SHARE_BASIS_UNSTATED"))
    elif cur == "TWD":
        o = off.get("revenue_twd_bn")
        checks.append(_chk("單位", "PASS", "新台幣，公司合計營收" + (f"；官方同季 {o:g} 十億新台幣{doc}" if o is not None else "")))
    elif cur == "USD" and off.get("revenue_usd_bn") is not None:
        checks.append(_chk("單位", "PASS", f"美元營收；官方公告同季寫明以美元計算 {off['revenue_usd_bn']:g} 十億美元{doc}，不換匯"))
    else:
        checks.append(_chk("單位", "PENDING", f"{cur} 營收；官方公告沒有同幣別的數字，依規則不自行換匯", "OFFICIAL_FIGURE_MISSING"))
    # 7a. 單位一致性（v4.30）：頁面自己標的幣別，和頁面上的數值是否說得通。
    #     例：Yahoo 2330.TW 頁面 2024-09 版表頭寫「CURRENCY IN USD」，但數值其實是新台幣。
    unit_conflict = None
    if e.get("currency_from") == "page":
        if e["metric"] == "eps" and page_actuals:
            same, diff = _actuals_vs_official(page_actuals, official or {}, cur)
            alt = "TWD" if cur == "USD" else "USD"
            same_alt, _ = _actuals_vs_official(page_actuals, official or {}, alt)
            if not same and len(same_alt) >= 1 and len(diff) >= 1:
                ex = "、".join(f"{q} 頁面 {v:g}" for q, v, o in same_alt[:3])
                unit_conflict = (f"頁面標示 {cur}，但同一頁的歷史實際 EPS（{ex}）與官方"
                                 f"{'每股新台幣' if alt == 'TWD' else '每單位 ADR 美元'} EPS 相同")
        if unit_conflict is None and e.get("avg"):
            key = {("eps", "USD"): "eps_usd_per_adr", ("eps", "TWD"): "eps_twd_per_share",
                   ("revenue", "USD"): "revenue_usd_bn", ("revenue", "TWD"): "revenue_twd_bn"}.get((e["metric"], cur))
            o = off.get(key) if key else None
            if key == "eps_twd_per_share" and not str(quote).endswith(".TW"):
                o = None   # ADR 頁上的新台幣 EPS：每股或每 ADR 未定（規則 4），不做數量級比較
            if o:
                ratio = e["avg"] / (o * 1e9 if e["metric"] == "revenue" else o)
                if not (MAGNITUDE_BAND[0] <= ratio <= MAGNITUDE_BAND[1]):
                    unit_conflict = (f"頁面標示 {cur}，預估平均是官方同單位數字的 {ratio:.2f} 倍，"
                                     "超出合理範圍，頁面的單位標示可能有誤")
    if unit_conflict:
        checks.append(_chk("單位一致性", "PENDING", unit_conflict, "UNIT_CONFLICT"))
    # 7b. 頁面實際值對照（只佐證，不改變判定）
    if e["metric"] == "eps" and page_actuals:
        same, diff = _actuals_vs_official(page_actuals, official or {}, cur)
        if same or diff:
            base = "每單位 ADR 美元" if cur == "USD" else "每股新台幣"
            txt = f"同一份頁面列出的歷史實際 EPS 與官方{base} EPS：{len(same)} 季相同"
            if diff:
                txt += "、" + "、".join(f"{q} 頁面 {v:g}／官方 {o:g}" for q, v, o in diff[:4]) + " 不同"
                ratios = sorted({round(v / o, 2) for q, v, o in diff if o})
                if len(diff) >= 2 and len(ratios) == 1:   # 只描述觀察到的倍數，不據此換算或放行（規則 4）
                    txt += f"；不同的各季頁面值都是官方的 {ratios[0]:g} 倍（只是觀察，不據此換算）"
            checks.append(_chk("頁面實際值對照", "INFO", txt))
    # 8. 口徑
    if e["metric"] == "eps":
        if e.get("basis"):
            checks.append(_chk("口徑", "PASS", f"頁面寫明 {e['basis']}"))
        else:
            checks.append(_chk("口徑", "PENDING", "頁面沒寫 GAAP 或調整後", "BASIS_UNSTATED"))
    # 9. 人數（規則 3：只標品質，不設最低人數）
    n = e.get("n_analysts")
    checks.append(_chk("人數", "INFO", f"{'未知' if n is None else n}{'' if n is None else ' 位'}，覆蓋品質：{_coverage(n)}"
                       "（只代表這個來源，不與其他來源加總；不設 Gate 最低人數）"))
    if "FY_ROW_IS_SUM_OF_QUARTERS" in e.get("flags", []):
        checks.append(_chk("人數", "FAIL", "年度值是四季單一預估相加，不是共識"))
    # 10. 是否更新
    s = series.get((e["source_id"], fp, e["metric"]))
    stale = None
    if s:
        pt = next((p for p in s["points"] if p["capture_ts"] == e["capture_ts"]), None)
        if pt and pt.get("unchanged_since"):
            since = datetime.strptime(pt["unchanged_since"], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
            if cap_utc - since > timedelta(days=STALE_DAYS):
                stale = (cap_utc - since).days
    if stale:
        checks.append(_chk("是否更新", "PENDING", f"數值與 {stale} 天前的存檔完全相同，網站可能未更新", "STALE_VALUES"))
    else:
        checks.append(_chk("是否更新", "PASS" if s else "INFO",
                           "與更早的存檔相比有更新或間隔不長" if s else "只有這一筆存檔，無法判斷是否更新"))
    # 11. 事後說法（只對照）
    claims, seen = [], set()
    for x in (retro if e["metric"] == "eps" else []):
        if x.get("currency") and x["currency"] != cur:
            continue   # 不同幣別的事後說法不放在一起對照
        if x.get("eps_estimate") is not None and (x["source_id"], x["eps_estimate"]) not in seen:
            seen.add((x["source_id"], x["eps_estimate"]))
            claims.append(x)
    if claims:
        txt = "；".join(f"{x['source_id']}（{x['capture_ts'][:8]} 存檔）說當時預估 {x['eps_estimate']:g}"
                       f"{(' ' + x['currency']) if x.get('currency') else ''}" for x in claims[:4])
        checks.append(_chk("事後說法", "INFO", f"{txt}；快照實際是 {e['avg']:g}。事後說法不採用，只對照"))
    res = [c["result"] for c in checks]
    verdict = "NOT_ADOPTABLE" if "FAIL" in res else ("PENDING" if "PENDING" in res else "ADOPTABLE")
    return {"fiscal_period": fp, "metric": e["metric"], "currency": cur, "quote": quote, "source_id": e["source_id"],
            "vendor": e.get("vendor"), "origin": e.get("origin"), "capture_ts": e["capture_ts"],
            "captured_at_tpe": e["captured_at_tpe"], "period_label_raw": e["period_label_raw"], "basis": e.get("basis"),
            "n_analysts": n, "coverage": _coverage(n), "avg": e["avg"], "low": e["low"], "high": e["high"],
            "verdict": verdict, "checks": checks,
            "reasons": [f"{c['check']}：{c['detail']}" for c in checks if c["result"] in ("FAIL", "PENDING")],
            "pending_categories": sorted({c["category"] for c in checks if c.get("category")}),
            "evidence": {
                "wayback_url": f"https://web.archive.org/web/{e['capture_ts']}/{cap.get('original')}" if cap else None,
                "original_url": cap.get("original") if cap else None,
                "held_file": os.path.basename(cap["file"]) if cap else None,
                "held_sha256": cap.get("sha256") if cap else None,
                "archive_digest_sha1_b32": cap.get("archive_digest") if cap else None,
                "cdx_responses": [{"file": os.path.basename(p), "sha256": s} for p, s in (cap.get("cdx_files") or [])] if cap else [],
                "refetch": rf, "snapshot_boundary": ti.get("conservative_boundary"),
                "announced_at": ti.get("announced_at"), "official": {k: off.get(k) for k in
                                                                      ("eps_twd_per_share", "eps_usd_per_adr", "revenue_twd_bn",
                                                                       "revenue_usd_bn", "document_id") if k in off}}}


def audit(research, captures, refetch=None, official=None, now=None):
    """research：consensus_research.build() 的結果；captures：同一批存檔紀錄（含檔案路徑與摘要）；
    official：collect 摘要的 official_figures（官方自結財務結果公告的同季數字）。"""
    capmap = {(c["source_id"], c["capture_ts"]): c for c in captures}
    series = {(s["source_id"], s["fiscal_period"], s["metric"]): s for s in research.get("series", [])}
    actuals = {}   # 同一份存檔頁面列出的歷史實際 EPS：{(來源, 時間戳): {季度: 值}}
    for p in research["periods"].values():
        for x in p.get("retrospective", []):
            if x.get("eps_actual") is not None and x.get("fiscal_period"):
                actuals.setdefault((x["source_id"], x["capture_ts"]), {})[x["fiscal_period"]] = x["eps_actual"]
    items = []
    for fp, p in research["periods"].items():
        if not p.get("cutoff"):
            continue
        for g in p["groups"]:
            for e in g["entries"] + g.get("older_entries", []):   # 較早的快照也要審查（只是不和最新的一起比較差異）
                if e["timing"] != "BEFORE_CUTOFF":
                    continue
                e = dict(e, metric=g["metric"], currency=g["currency"], quote=g["quote"])
                items.append(audit_entry(fp, e, capmap.get((e["source_id"], e["capture_ts"])), p["cutoff"], series,
                                         p.get("retrospective", []), refetch or {}, official or {},
                                         actuals.get((e["source_id"], e["capture_ts"]))))
    items.sort(key=lambda x: (x["fiscal_period"], x["metric"], x["source_id"]))
    count = {v: sum(1 for x in items if x["verdict"] == v) for v in ("ADOPTABLE", "PENDING", "NOT_ADOPTABLE")}
    cats = sorted({c for x in items for c in x["pending_categories"]})
    return {"audit_version": AUDIT_VERSION, "data_mode": "MARKET_CONSENSUS_RESEARCH", "gate_impact": "none",
            "co_id": research["co_id"], "generated_at": (now or datetime.now(timezone.utc)).isoformat(),
            "boundary_rule": research.get("boundary_rule"), "policy": "reviews/consensus_research_policy.json",
            "counts": count, "items": items,
            "pending_categories": {k: {"kind": PENDING_CATEGORIES[k][0], "text": PENDING_CATEGORIES[k][1]} for k in cats},
            "open_decisions": {k: PENDING_CATEGORIES[k][1] for k in cats if PENDING_CATEGORIES[k][0] == "open"},
            "meaning": "ADOPTABLE＝研究上可採用的截止點前快照，不等於 Gate PASS；PENDING 依類別說明原因"}


VERDICT_TEXT = {"ADOPTABLE": "可採用", "PENDING": "待確認", "NOT_ADOPTABLE": "不可採用"}


CAT_SHORT = {"REFETCH": "待重新下載核對", "BASIS_UNSTATED": "口徑未寫", "SHARE_BASIS_UNSTATED": "每股或每ADR未寫",
             "OFFICIAL_FIGURE_MISSING": "官方無同單位數字", "CURRENCY_ASSUMED": "幣別未寫", "STALE_VALUES": "數值久未更新",
             "UNIT_CONFLICT": "頁面幣別標示與數值矛盾"}


def markdown(a):
    lines = ["", f"### 歷史快照逐項審查 {a['co_id']}（只記錄，不影響 Gate）", "",
             f"可採用 {a['counts']['ADOPTABLE']}、待確認 {a['counts']['PENDING']}、不可採用 {a['counts']['NOT_ADOPTABLE']}"
             "（「可採用」只代表研究上可用的截止點前快照，不是 Gate PASS）", "",
             "| 季度 | 指標 | 來源 | 存檔時間 | 人數（品質） | 平均 | 官方同單位（事後公布） | 判定 | 原因 |",
             "|---|---|---|---|---|---|---|---|---|"]
    for x in a["items"]:
        fails = [c["check"] for c in x["checks"] if c["result"] == "FAIL"]
        why = "；".join(fails + [CAT_SHORT.get(c, c) for c in x["pending_categories"]]) or "全部通過"
        off = x["evidence"]["official"]
        o = off.get("eps_usd_per_adr") if x["metric"] == "eps" and x["currency"] == "USD" else \
            off.get("eps_twd_per_share") if x["metric"] == "eps" and str(x["quote"]).endswith(".TW") else \
            off.get("revenue_usd_bn") if x["metric"] == "revenue" and x["currency"] == "USD" else \
            off.get("revenue_twd_bn") if x["metric"] == "revenue" and x["currency"] == "TWD" else None
        lines.append(f"| {x['fiscal_period']} | {x['metric']} {x['currency']} | `{x['source_id']}` | "
                     f"{x['captured_at_tpe'][:16]} | {'' if x['n_analysts'] is None else x['n_analysts']}（{x['coverage']}） | "
                     f"{_fmt(x['avg'], x['metric'])} | {'' if o is None else (_fmt(o * 1e9, 'revenue') if x['metric'] == 'revenue' else f'{o:g}')} | "
                     f"{VERDICT_TEXT[x['verdict']]} | {why} |")
    rf = {}
    for x in a["items"]:
        r = x["evidence"]["refetch"]
        if r:
            rf[(x["source_id"], x["capture_ts"])] = r.get("status")
    if rf:
        lines.append("\n重新下載核對：" + "、".join(f"{s} {t[:8]} {v}" for (s, t), v in sorted(rf.items())))
    if a["pending_categories"]:
        lines += ["", "待確認的原因："] + [f"- {CAT_SHORT.get(k, k)}：{v['text']}" for k, v in a["pending_categories"].items()]
    return "\n".join(lines)
