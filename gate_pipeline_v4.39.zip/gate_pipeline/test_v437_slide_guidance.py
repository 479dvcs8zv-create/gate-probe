"""
test_v437_slide_guidance.py (v4.37)
===================================
法說會簡報的官方財測 vs 實際（ops/slide_guidance.py）。固定測試資料：contract/mops_real/slides/<代號>/，
是 gate-probe 從公開資訊觀測站法說會一覽表下載的官方簡報逐頁文字（pdftotext -layout）與一覽表原始回應；
index.json 記錄每份簡報原檔的 SHA-256（原檔在 gate-probe results/<代號>/conference/<run>/files/）。

  - 3034 聯詠（新聞稿）：民國 112–115 年寫法（阿拉伯數字年度、中文數字年度、第四季只寫「第四季」）
  - 同一季的財測取最早公開的簡報；公開時間＝一覽表的日期時間（台北）
  - 實際取下一份簡報；營業利益率由同一份新聞稿的營業淨利 ÷ 營業收入淨額計算（標明 computed）

  python test_v437_slide_guidance.py
"""
import hashlib
import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import slide_guidance as sg  # noqa: E402

FIX = os.path.join(HERE, "contract", "mops_real", "slides")


def _fixture(co):
    d = os.path.join(FIX, co)
    idx = json.load(open(os.path.join(d, "index.json"), encoding="utf-8"))
    decks = {x["names"][0]: json.load(open(os.path.join(d, x["names"][0] + ".json"), encoding="utf-8"))
             for x in idx["decks"]}
    return d, idx, decks


def _tree(co):
    """把固定文字還原成 conference 探測結果的目錄結構（PDF 以佔位檔代替，pages_fn 回傳固定文字）。"""
    d, idx, decks = _fixture(co)
    tmp = tempfile.mkdtemp(prefix=f"slides_{co}_")
    run = os.path.join(tmp, "conference", "1")
    os.makedirs(os.path.join(run, "files"))
    queries = []
    for i, name in enumerate(idx["listings"]):
        shutil.copy(os.path.join(d, name), os.path.join(run, name))
        queries.append({"label": "step1_co", "roc_year": str(i), "saved_as": name})
    files, by_path = [], {}
    for name, fx in decks.items():
        for alias in fx["names"]:
            body = fx["sha256"].encode()
            path = os.path.join(run, "files", alias)
            open(path, "wb").write(body)
            files.append({"url": f"https://mopsov.twse.com.tw/nas/STR/{alias}", "is_pdf": True,
                          "saved_as": os.path.join("files", alias), "sha256": hashlib.sha256(body).hexdigest()})
            by_path[os.path.abspath(path)] = fx["pages"]
    json.dump({"co_id": co, "queries": queries, "files": files}, open(os.path.join(run, "probe.json"), "w"))
    return tmp, (lambda p: by_path[os.path.abspath(p)])


def test_cn_number_and_helpers():
    assert sg.cn_number("二十一") == 21 and sg.cn_number("十一") == 11 and sg.cn_number("二十點五") == 20.5
    assert sg.cn_number("三點二") == 3.2 and sg.cn_number("四十") == 40 and sg.cn_number("一百二十") == 120
    assert sg.roc_digits("一一五") == 115 and sg.roc_digits("112") == 112
    assert sg._amount_yi("286", "6") == 286.6 and sg._amount_yi("63", "2", "8") == 63.28 and sg._amount_yi("52", None, "9") == 52.09
    assert sg._signed("季減", 1, 3) == [-3.0, -1.0] and sg._signed("季增", 2, 4) == [2.0, 4.0]
    assert sg.flat("第一 季毛利率為  39.06%") == "第一季毛利率為 39.06%"


def test_3034_all_years():
    tmp, pages_fn = _tree("3034")
    try:
        doc = sg.build("3034", os.path.join(tmp, "conference"), pages_fn=pages_fn)
        q = doc["quarters"]
        verified = sorted(k for k, v in q.items() if v["status"] == "VERIFIED")
        assert verified == [f"{y}Q{n}" for y in (2023, 2024, 2025) for n in (1, 2, 3, 4)] + ["2026Q1", "2026Q2"], verified
        assert q["2026Q3"]["status"] == "MISSING_ACTUAL" and doc["format_unknown"] == []
        g = q["2023Q1"]["guidance"]
        assert g["deck"] == "303420230207M001.pdf" and g["published_at"] == "2023-02-07T15:00:00+08:00"
        assert {k: (v["low"], v["high"]) for k, v in g["metrics"].items()} == {
            "revenue_twd_bn": (22.2, 23.2), "gross_margin_pct": (37.5, 39.5), "operating_margin_pct": (20.0, 23.0)}
        c = q["2025Q2"]["comparison"]   # 三項都低於財測
        assert {k: v["result"] for k, v in c.items()} == {"revenue_twd_bn": "BELOW", "gross_margin_pct": "BELOW",
                                                          "operating_margin_pct": "BELOW"}
        assert c["revenue_twd_bn"]["actual"] == 26.152 and c["gross_margin_pct"]["actual"] == 36.3
        c = q["2026Q2"]["comparison"]
        assert c["revenue_twd_bn"] == {"low": 27.5, "high": 28.5, "actual": 28.66, "result": "ABOVE"}
        a = q["2026Q2"]["actual"]["metrics"]["operating_margin_pct"]
        assert "computed" in a and abs(a["value"] - 6466 / 286.6) < 0.01   # 64 億 6 仟 6 佰萬 ÷ 286 億 6 仟萬
        assert q["2026Q3"]["guidance"]["assumption"] == {"usd_twd": 32.0}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_3711_consolidated_from_2025q3_segment_only_before():
    tmp, pages_fn = _tree("3711")
    try:
        doc = sg.build("3711", os.path.join(tmp, "conference"), pages_fn=pages_fn)
        q = doc["quarters"]
        assert sorted(k for k, v in q.items() if v["status"] == "VERIFIED") == ["2025Q3", "2025Q4", "2026Q1", "2026Q2"]
        assert sorted(k for k, v in q.items() if v["status"] == "SEGMENT_ONLY_GUIDANCE") == \
            [f"{y}Q{n}" for y in (2023, 2024) for n in (1, 2, 3, 4)] + ["2025Q1", "2025Q2"]
        assert q["2026Q3"]["status"] == "MISSING_ACTUAL"
        # 2025Q3：先寫美金計價，取「以台幣計價」那一句；毛利率用「個百分點」→ 換成基點
        g = {k: (v["low"], v["high"]) for k, v in q["2025Q3"]["guidance"]["metrics"].items()}
        assert g == {"revenue_qoq_pct": (6.0, 8.0), "gross_margin_qoq_bp": (-120.0, -100.0),
                     "operating_margin_qoq_bp": (-30.0, -10.0)}
        # 2025Q4：「季對增加」筆誤也認得
        assert q["2025Q4"]["guidance"]["metrics"]["operating_margin_qoq_bp"]["low"] == 70.0
        a = q["2025Q3"]["actual"]["metrics"]
        assert a["revenue_twd_bn"]["value"] == 168.569 and round(a["revenue_qoq_pct"]["value"], 2) == 11.82
        assert {k: v["result"] for k, v in q["2026Q2"]["comparison"].items()} == {
            "revenue_qoq_pct": "ABOVE", "gross_margin_qoq_bp": "IN_RANGE", "operating_margin_qoq_bp": "IN_RANGE"}
        # 2024-10、2025-02 簡報的上一季欄名筆誤（20242）：本季仍讀得到
        assert q["2024Q3"]["actual"]["metrics"]["revenue_twd_bn"]["value"] == 160.105
        # 只有 2025-05 COMPUTEX 主題式展望會（不是財報法說）留在「寫法不認得」
        assert [x["deck"] for x in doc["format_unknown"]] == ["371120250521M001.pdf"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_5347_all_years_and_restated_guidance():
    tmp, pages_fn = _tree("5347")
    try:
        doc = sg.build("5347", os.path.join(tmp, "conference"), pages_fn=pages_fn)
        q = doc["quarters"]
        verified = sorted(k for k, v in q.items() if v["status"] == "VERIFIED")
        assert verified == [f"{y}Q{n}" for y in (2023, 2024, 2025) for n in (1, 2, 3, 4)] + ["2026Q1", "2026Q2"], verified
        assert doc["format_unknown"] == [] and q["2026Q3"]["status"] == "MISSING_ACTUAL"
        # 每一季：報告實際數字的簡報重列的財測，與原財測相同
        assert all(v["notes"] == ["報告實際數字的簡報重列的財測與原財測相同"] for k, v in q.items() if k in verified)
        # 2023 年版面：營收（億元）、毛利率、營業利益率
        c = q["2023Q1"]["comparison"]
        assert c["revenue_twd_bn"] == {"low": 7.9, "high": 8.3, "actual": 8.187, "result": "IN_RANGE"}
        assert c["operating_margin_pct"]["result"] == "ABOVE" and c["operating_margin_pct"]["actual"] == 16.7
        # 「季持平」＝0%，標註
        a = q["2024Q3"]["actual"]["metrics"]["asp_qoq_pct"]
        assert a["value"] == 0.0 and "季持平" in a["note"] and q["2024Q3"]["comparison"]["asp_qoq_pct"]["result"] == "IN_RANGE"
        # 「22 ~ 24%」第一個數字沒有 %
        assert q["2023Q4"]["guidance"]["metrics"]["gross_margin_pct"]["low"] == 22.0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_5274_invited_conference_decks():
    tmp, pages_fn = _tree("5274")
    try:
        doc = sg.build("5274", os.path.join(tmp, "conference"), pages_fn=pages_fn)
        q = doc["quarters"]
        assert sorted(k for k, v in q.items() if v["status"] == "VERIFIED") == ["2024Q4", "2025Q1", "2026Q1", "2026Q2"]
        # 一份簡報給兩季（2024-03：第一、二季）
        assert q["2024Q1"]["guidance"]["deck"] == q["2024Q2"]["guidance"]["deck"] == "527420240326M001.pdf"
        # 季中「更新營運展望」→ 不比較
        assert q["2025Q2"]["status"] == "GUIDANCE_UPDATED"
        # 2024-06 與 2024-08 給的第三季財測不同、後者沒寫「更新」→ 衝突，不比較，兩份都列出
        assert q["2024Q3"]["status"] == "GUIDANCE_CONFLICT" and "527420240822M001.pdf" in q["2024Q3"]["notes"][0]
        # 匯率寫在標題（2025-10：「1:30.0」）
        assert q["2025Q4"]["guidance"]["assumption"] == {"usd_twd": 30.0}
        c = q["2026Q2"]["comparison"]
        assert c["revenue_twd_bn"]["result"] == "ABOVE" and c["gross_margin_pct"] == {"low": 67.0, "high": 68.0,
                                                                                      "actual": 72.0, "result": "ABOVE"}
        assert [x["deck"] for x in doc["format_unknown"]] == ["527420230330M001.pdf"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_unknown_wording_is_recorded_not_guessed():
    _, _, decks = _fixture("3034")
    pages = list(decks["303420260806M001.pdf"]["pages"])
    pages[0] = pages[0].replace("合併營收預計介於", "合併營收預估在")
    d = sg.parse_3034(pages)
    assert d["guidance_quarter"] == "2026Q3" and "revenue_twd_bn" not in d["guidance"]
    assert set(d["guidance"]) == {"gross_margin_pct", "operating_margin_pct"}   # 其他兩項仍照原文解析
    pages[0] = pages[0].replace("的業績展望如下", "的業績展望")
    d = sg.parse_3034(pages)
    assert d["guidance_quarter"] is None and d["guidance"] == {}


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
