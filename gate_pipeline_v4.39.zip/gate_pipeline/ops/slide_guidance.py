"""
slide_guidance.py (v4.37)
=========================
官方財測模式的第二個來源：公開資訊觀測站「法人說明會一覽表」附的官方簡報（conference_probe.py 下載）。
2330、2454 的財測寫在重大訊息全文（guidance_mops.py）；聯詠 3034、日月光投控 3711、世界先進 5347、信驊 5274
的財測只寫在法說會簡報，2026-10-19 用官方簡報逐頁核對過（handoff/guidance_candidates_2026-10-19.md）。

做法（fail-closed，和 guidance_mops 相同精神）：
  1. 每份簡報（只收觀測站下載、SHA-256 已記錄的 PDF）逐頁抽文字（pdftotext -layout）。
  2. 依公司的已知寫法解析：這份簡報報告的季度與實際數字、下一季（或下下季）的財測區間、匯率假設。
     有「展望」頁卻解析不出來 → FORMAT_UNKNOWN（記錄，不略過、不猜）。
  3. 同一季的財測只採最早公開的簡報（公開時間取法說會一覽表的日期時間）；
     多份簡報給同一季、數字不同 → GUIDANCE_CONFLICT，不比較。
  4. 每一季：財測與實際都有 → 逐項判定 在區間內／高於／低於；只有一邊 → MISSING_ACTUAL／MISSING_GUIDANCE。
這是 Python 預驗證，不是正式 Gate PASS；季增率類財測直接比較季增率（實際季增率由同一份簡報裡兩季的官方數字計算）。

  python gate_pipeline/ops/slide_guidance.py --co-id 3034 --conference results/3034/conference --out slide_guidance.json
"""

import argparse
import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import conference_probe as cp  # noqa: E402

SLIDE_GUIDANCE_VERSION = "4.39-slides"
TPE = timezone(timedelta(hours=8))
SUPPORTED = ("3034", "3711", "5347", "5274")
METRIC_NAMES = {"revenue_twd_bn": "營收（十億新台幣）", "revenue_qoq_pct": "營收季增率（%）",
                "gross_margin_pct": "毛利率（%）", "operating_margin_pct": "營業利益率（%）",
                "shipments_qoq_pct": "晶圓出貨量季增率（%）", "asp_qoq_pct": "平均售價季增率（%）",
                "gross_margin_qoq_bp": "毛利率季變化（基點）", "operating_margin_qoq_bp": "營業利益率季變化（基點）"}

# ------------------------------------------------------------------------------------------------ 文字工具
_CN_DIGIT = {"零": 0, "〇": 0, "一": 1, "二": 2, "兩": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}


def cn_number(s):
    """中文數字（到百位、可有「點」小數）→ float：「二十一」21、「十一」11、「二十點五」20.5、「三點二」3.2、「四十」40。
    看不懂丟 ValueError。"""
    s = s.strip()
    if not s:
        raise ValueError("空字串")
    whole, _, frac = s.partition("點")
    total, cur = 0, 0
    for ch in whole:
        if ch in _CN_DIGIT:
            cur = _CN_DIGIT[ch]
        elif ch == "十":
            total += (cur or 1) * 10
            cur = 0
        elif ch == "百":
            total += (cur or 1) * 100
            cur = 0
        else:
            raise ValueError(f"不是中文數字：{s!r}")
    total += cur
    if frac:
        if any(ch not in _CN_DIGIT for ch in frac):
            raise ValueError(f"小數不是中文數字：{s!r}")
        total += float("0." + "".join(str(_CN_DIGIT[ch]) for ch in frac))
    return float(total)


_CJK = "一-鿿　-〿＀-￯"


def flat(text):
    """頁面文字壓成一行（多個空白 → 一個），方便跨行比對；中文字之間因換行產生的空白一律拿掉
    （例：「第一 季毛利率」「營業收入淨 額」）。"""
    t = re.sub(r"\s+", " ", text.replace("　", " ")).strip()
    return re.sub("(?<=[" + _CJK + "]) (?=[" + _CJK + "])", "", t)


def roc_or_ad_year(y):
    y = int(y)
    return y + 1911 if y < 1000 else y


_CN_Q = {"一": 1, "二": 2, "三": 3, "四": 4, "1": 1, "2": 2, "3": 3, "4": 4}


def quarter_str(year, q):
    return f"{roc_or_ad_year(year)}Q{_CN_Q[str(q)]}"


def next_quarter(fp):
    y, q = int(fp[:4]), int(fp[-1])
    return f"{y + (q == 4)}Q{1 if q == 4 else q + 1}"


def prev_quarter(fp):
    y, q = int(fp[:4]), int(fp[-1])
    return f"{y - (q == 1)}Q{4 if q == 1 else q - 1}"


# ------------------------------------------------------------------------------------------------ PDF 文字
def pdftotext_version():
    exe = shutil.which("pdftotext")
    if not exe:
        return None
    r = subprocess.run([exe, "-v"], capture_output=True, text=True)
    return (r.stderr or r.stdout).strip().splitlines()[0] if (r.stderr or r.stdout) else "pdftotext"


def pdf_pages(path):
    """逐頁文字（pdftotext -layout）。沒有 pdftotext 時丟 RuntimeError（Actions 會先安裝 poppler-utils）。"""
    exe = shutil.which("pdftotext")
    if not exe:
        raise RuntimeError("找不到 pdftotext（poppler-utils）")
    info = subprocess.run(["pdfinfo", path], capture_output=True, text=True)
    m = re.search(r"^Pages:\s+(\d+)", info.stdout, re.M)
    if not m:
        raise RuntimeError(f"讀不到頁數：{path}")
    pages = []
    for p in range(1, int(m.group(1)) + 1):
        r = subprocess.run([exe, "-layout", "-enc", "UTF-8", "-f", str(p), "-l", str(p), path, "-"],
                           capture_output=True)
        pages.append(r.stdout.decode("utf-8", "replace"))
    return pages


# ------------------------------------------------------------------------------------------------ 共用解析工具
_ROC_DIGIT = {"〇": "0", "零": "0", "一": "1", "二": "2", "三": "3", "四": "4", "五": "5", "六": "6", "七": "7", "八": "8",
              "九": "9"}
_NUM = r"(-?\d+(?:\.\d+)?)"
_RANGE_SEP = r"\s*(?:~|～|至|到|-|–)\s*"


def roc_digits(s):
    """逐字中文數字的民國年：「一一五」→ 115；阿拉伯數字「112」照用（2023 年的新聞稿）。"""
    s = s.strip()
    return int(s) if s.isdigit() else int("".join(_ROC_DIGIT[ch] for ch in s))


def _amount_yi(m_yi, qian=None, bai=None, shi=None):
    """「286 億 6 仟萬元」「63 億 2 仟 8 佰萬元」→ 億元（286.6、63.28）。"""
    v = float(m_yi.replace(",", ""))
    for d, w in ((qian, 0.1), (bai, 0.01), (shi, 0.001)):
        if d:
            v += int(d) * w
    return round(v, 4)


def _find(pages, pattern, start=0):
    """第一個符合的頁（從 1 起算）與 match；找不到回傳 (None, None)。"""
    rx = re.compile(pattern)
    for i in range(start, len(pages)):
        m = rx.search(flat(pages[i]))
        if m:
            return i + 1, m
    return None, None


def _quote(m, limit=240):
    return m.group(0)[:limit]


def _signed(direction, a, b):
    """季增／成長／增加 → 正；季減／減少／衰退／下滑 → 負（區間端點跟著反轉）。"""
    lo, hi = float(a), float(b)
    if direction in ("季減", "減少", "衰退", "下滑", "下降"):
        lo, hi = -hi, -lo
    return [min(lo, hi), max(lo, hi)]


OUTLOOK_HINT = re.compile(r"營運展望|業績展望|未來展望|Outlook|we currently expect|Guidance", re.I)


def _deck(co_id, fmt):
    return {"co_id": co_id, "format": fmt, "reported_quarter": None, "actual": {}, "guidance_quarter": None,
            "guidance": {}, "assumption": {}, "notes": []}


# ------------------------------------------------------------------------------------------------ 3034 聯詠（新聞稿）
_YI = r"([\d,]+)\s*億(?:\s*(\d)\s*仟)?(?:\s*(\d)\s*佰)?(?:\s*(\d)\s*拾)?\s*萬?\s*元"


def parse_3034(pages):
    d = _deck("3034", "3034-press-release")
    gp, gm_ = _find(pages, r"([〇零一二三四五六七八九]{3}|\d{3})\s*年第([一二三四])季的業績展望如下")
    guided = quarter_str(roc_digits(gm_.group(1)), gm_.group(2)) if gm_ else None
    p, m = _find(pages, r"(?:([〇零一二三四五六七八九]{3}|\d{3})\s*年)?第([一二三四])季合併營業收入淨額為新台幣\s*" + _YI)
    if m:
        if m.group(1):
            q = quarter_str(roc_digits(m.group(1)), m.group(2))
        elif guided and int(prev_quarter(guided)[-1]) == _CN_Q[m.group(2)]:
            q = prev_quarter(guided)   # 第四季的新聞稿只寫「第四季」，年度由同一份新聞稿的下一季財測推定
            d["notes"].append(f"報告季度 {q}：原文只寫「第{m.group(2)}季」，由同一份新聞稿的財測季度 {guided} 推定")
        else:
            q = None
            d["notes"].append(f"原文只寫「第{m.group(2)}季」，無法確定年度（不猜）")
        rev = _amount_yi(m.group(3), m.group(4), m.group(5), m.group(6))
        d["reported_quarter"] = q
        if q is None:
            return d
        d["actual"]["revenue_twd_bn"] = {"value": round(rev / 10, 4), "page": p, "quote": _quote(m)}
        pg, g = _find(pages, r"第" + m.group(2) + r"季毛利率為\s*" + _NUM + r"\s*%")
        if g:
            d["actual"]["gross_margin_pct"] = {"value": float(g.group(1)), "page": pg, "quote": _quote(g)}
        po, o = _find(pages, r"第" + m.group(2) + r"季營業淨利為新台幣\s*" + _YI)
        if o:
            op = _amount_yi(o.group(1), o.group(2), o.group(3), o.group(4))
            d["actual"]["operating_margin_pct"] = {
                "value": round(op / rev * 100, 4), "page": po, "quote": _quote(o),
                "computed": f"營業淨利 {op:g} 億元 ÷ 營業收入淨額 {rev:g} 億元（同一份新聞稿的兩個官方數字）"}
    p, m = _find(pages, r"([〇零一二三四五六七八九]{3}|\d{3})\s*年第([一二三四])季的業績展望如下")
    if m:
        d["guidance_quarter"] = quarter_str(roc_digits(m.group(1)), m.group(2))
        block = flat(pages[p - 1])[m.end():m.end() + 400]
        r = re.search(r"合併營收預計介於新台幣\s*" + _NUM + r"\s*億元" + _RANGE_SEP + _NUM + r"\s*億元", block)
        if r:
            d["guidance"]["revenue_twd_bn"] = {"low": round(float(r.group(1)) / 10, 4), "high": round(float(r.group(2)) / 10, 4),
                                               "page": p, "quote": r.group(0)}
        fx = re.search(r"美元兌台幣匯率以\s*1\s*[:：]\s*" + _NUM, block)
        if fx:
            d["assumption"]["usd_twd"] = float(fx.group(1))
        for key, word in (("gross_margin_pct", "毛利率"), ("operating_margin_pct", "營業利益率")):
            r = re.search(word + r"預計介於\s*" + _NUM + r"\s*%" + _RANGE_SEP + _NUM + r"\s*%", block)
            if r:
                d["guidance"][key] = {"low": float(r.group(1)), "high": float(r.group(2)), "page": p, "quote": r.group(0)}
    return d


# ------------------------------------------------------------------------------------------------ 3711 日月光投控
_CN_PCT = r"百分之([零一二三四五六七八九十百點]+)"


def parse_3711(pages):
    d = _deck("3711", "3711-deck")
    # 上一季欄名偶有筆誤（2024-10、2025-02 簡報寫「Q3 / 20242」），只取本季欄名
    p, m = _find(pages, r"合併損益表.*?Q([1-4]) / (\d{4}) % Q[1-4] / \d{4,5} %")
    if m:
        d["reported_quarter"] = f"{m.group(2)}Q{m.group(1)}"
        t = flat(pages[p - 1])
        r = re.search(r"營業收入淨額合計\s*([\d,]+)\s*[\d.]+%\s*([\d,]+)\s*[\d.]+%", t)
        if r:
            cur, prev = float(r.group(1).replace(",", "")), float(r.group(2).replace(",", ""))
            d["actual"]["revenue_twd_bn"] = {"value": cur / 1000, "page": p, "quote": r.group(0)}
            d["actual"]["revenue_qoq_pct"] = {
                "value": round((cur / prev - 1) * 100, 4), "page": p, "quote": r.group(0),
                "computed": f"{cur:,.0f} ÷ {prev:,.0f} − 1（同一頁兩季的官方數字，新台幣百萬元）"}
        for key, word in (("gross_margin_pct", r"營業毛利"), ("operating_margin_pct", r"營業淨利\s*\(淨損\)")):
            r = re.search(word + r"\s*\(?([\d,]+)\)?\s*(-?[\d.]+)%\s*\(?([\d,]+)\)?\s*(-?[\d.]+)%", t)
            if r:
                d["actual"][key] = {"value": float(r.group(2)), "page": p, "quote": r.group(0)}
                rv = re.search(r"營業收入淨額合計\s*([\d,]+)\s*[\d.]+%\s*([\d,]+)", t)
                if rv:   # 季變化（基點）：用同一頁兩季的金額計算，不用四捨五入後的百分比
                    a1, a0 = float(r.group(1).replace(",", "")), float(r.group(3).replace(",", ""))
                    r1, r0 = float(rv.group(1).replace(",", "")), float(rv.group(2).replace(",", ""))
                    d["actual"][key.replace("_pct", "_qoq_bp")] = {
                        "value": round((a1 / r1 - a0 / r0) * 10000, 2), "page": p, "quote": r.group(0),
                        "computed": f"{a1:,.0f}/{r1:,.0f} − {a0:,.0f}/{r0:,.0f}（同一頁兩季的官方金額）"}
    p, m = _find(pages, r"(\d{4})年第([一二三四])季業績展望")
    if m:
        d["guidance_quarter"] = quarter_str(m.group(1), m.group(2))
        t = flat(pages[p - 1])
        fx = re.search(r"1\s*美金兌換\s*" + _NUM + r"\s*元新台幣", t)
        if fx:
            d["assumption"]["usd_twd"] = float(fx.group(1))
        # 2025Q3 起才有投控合併財測（之前只有事業別，見下方）；2025Q3 簡報先寫美金計價，取「以台幣計價」那一句
        r = re.search(r"(?:以台幣計價，)?(?:投控合併)?(?:今年)?第[一二三四]季營收將季對季(成長|增加|減少|衰退|下滑)" + _CN_PCT +
                      r"到" + _CN_PCT, t[t.find("以台幣計價"):] if "以美金計價" in t and "以台幣計價" in t else t)
        if r and "投控合併" not in t:
            r = None
        if r:
            d["guidance"]["revenue_qoq_pct"] = dict(zip(("low", "high"), _signed(r.group(1), cn_number(r.group(2)),
                                                                              cn_number(r.group(3)))), page=p,
                                                    quote=r.group(0))
        for key, word in (("gross_margin_pct", "毛利率"), ("operating_margin_pct", "營業利益率")):
            r = re.search(r"投控合併第[一二三四]季" + word + r"將介於" + _CN_PCT + r"到" + _CN_PCT, t)
            if r:
                d["guidance"][key] = {"low": cn_number(r.group(1)), "high": cn_number(r.group(2)), "page": p,
                                      "quote": r.group(0)}
                continue
            # 季變化：「季對季增加七十到一百個基點」或「季對季減少一到一點二個百分點」（2025-10 簡報有「季對增加」筆誤）
            r = re.search(r"投控合併第[一二三四]季" + word + r"將季對季?(增長|增加|成長|減少|下降|下滑)([零一二三四五六七八九十百點]+)到"
                          r"([零一二三四五六七八九十百點]+)個(基點|百分點)", t)
            if r:   # 直接比較季變化（換成基點），不換算成百分比
                k = 1 if r.group(4) == "基點" else 100
                lo, hi = _signed(r.group(1), cn_number(r.group(2)) * k, cn_number(r.group(3)) * k)
                d["guidance"][key.replace("_pct", "_qoq_bp")] = {"low": round(lo, 4), "high": round(hi, 4), "page": p,
                                                                "quote": r.group(0)}
        if not d["guidance"] and "投控合併" not in t and re.search(r"封測事業|電子代工服務", t):
            d["segment_only_guidance"] = True   # 2025Q2 以前只有事業別（封測、電子代工），多為文字描述；不比較
            d["notes"].append(f"{d['guidance_quarter']} 只有事業別財測，沒有投控合併數字（不比較）")
    return d


# ------------------------------------------------------------------------------------------------ 5347 世界先進
_DIR = r"(季增|季減)"


def parse_5347(pages):
    d = _deck("5347", "5347-deck")
    p, m = _find(pages, r"(\d{3})年 ?第(\d)季 ?營運結果摘要")
    if m:
        d["reported_quarter"] = quarter_str(m.group(1), m.group(2))
        t = flat(pages[p - 1])
        restated = {}
        for key, word in (("shipments_qoq_pct", "晶圓出貨量"), ("asp_qoq_pct", "產品平均銷售單價")):
            r = re.search(word + r"\s*(?:" + _DIR + r"\s*" + _NUM + r"\s*%|(季持平))", t)
            if r:   # 實際值：「季增 11 %」「季減4%」；「季持平」＝0%（原文寫法，標註）
                v = 0.0 if r.group(3) else float(r.group(2)) * (-1 if r.group(1) == "季減" else 1)
                d["actual"][key] = {"value": v, "page": p, "quote": r.group(0)}
                if r.group(3):
                    d["actual"][key]["note"] = "原文「季持平」，視為季變化 0%"
                g = re.match(r"\s*" + _DIR + r"約?\s*" + _NUM + r"\s*%" + _RANGE_SEP + _NUM + r"\s*%", t[r.end():])
                if g:   # 同一列重列的上一季財測（區間）；文字描述（例：季對季約略持平）不記
                    lo, hi = _signed(g.group(1), g.group(2), g.group(3))
                    restated[key] = {"low": lo, "high": hi}
        r = re.search(r"毛利率\s*" + _NUM + r"\s*%\s*介於\s*" + _NUM + r"\s*%" + _RANGE_SEP + _NUM + r"\s*%", t)
        if r:
            d["actual"]["gross_margin_pct"] = {"value": float(r.group(1)), "page": p, "quote": r.group(0)}
            restated["gross_margin_pct"] = {"low": float(r.group(2)), "high": float(r.group(3))}
        # 2023 年以前的版面：營收（億元）與營業利益率
        r = re.search(r"合併營業收入新台幣\s*" + _NUM + r"\s*億元\s*介於新台幣\s*" + _NUM + r"\s*億元到\s*" + _NUM + r"\s*億元", t)
        if r:
            d["actual"]["revenue_twd_bn"] = {"value": round(float(r.group(1)) / 10, 4), "page": p, "quote": r.group(0)}
            restated["revenue_twd_bn"] = {"low": round(float(r.group(2)) / 10, 4), "high": round(float(r.group(3)) / 10, 4)}
        r = re.search(r"營業利益率\s*" + _NUM + r"\s*%\s*介於\s*" + _NUM + r"\s*%" + _RANGE_SEP + _NUM + r"\s*%", t)
        if r:
            d["actual"]["operating_margin_pct"] = {"value": float(r.group(1)), "page": p, "quote": r.group(0)}
            restated["operating_margin_pct"] = {"low": float(r.group(2)), "high": float(r.group(3))}
        if restated:
            d["restated_previous_guidance"] = restated   # 同一頁列出的「上一季財測」，用來核對上一份簡報
    p, m = _find(pages, r"(\d{3})年 ?第(\d)季 ?營運展望")
    while m and p and "營運結果摘要" in flat(pages[p - 1]):   # 結果摘要頁的欄名也叫「營運展望」，跳過
        p, m = _find(pages, r"(\d{3})年 ?第(\d)季 ?營運展望", start=p)
    if m:
        d["guidance_quarter"] = quarter_str(m.group(1), m.group(2))
        t = flat(pages[p - 1])
        for key, word in (("shipments_qoq_pct", "晶圓出貨量"), ("asp_qoq_pct", "產品平均銷售單價")):
            r = re.search(word + r"將" + _DIR + r"\s*" + _NUM + r"\s*%" + _RANGE_SEP + _NUM + r"\s*%", t)
            if r:
                lo, hi = _signed(r.group(1), r.group(2), r.group(3))
                d["guidance"][key] = {"low": lo, "high": hi, "page": p, "quote": r.group(0)}
        fx = re.search(r"匯率\s*" + _NUM + r"\s*的假設", t)
        if fx:
            d["assumption"]["usd_twd"] = float(fx.group(1))
        r = re.search(r"毛利率(?:將|約)?介於\s*" + _NUM + r"\s*%?" + _RANGE_SEP + _NUM + r"\s*%", t)   # 「22 ~ 24%」第一個數字可能沒有 %
        if r:
            d["guidance"]["gross_margin_pct"] = {"low": float(r.group(1)), "high": float(r.group(2)), "page": p,
                                                 "quote": r.group(0)}
        r = re.search(r"合併營業收入將約?介於新台幣\s*" + _NUM + r"\s*億元到\s*" + _NUM + r"\s*億元", t)   # 2023 年以前
        if r:
            d["guidance"]["revenue_twd_bn"] = {"low": round(float(r.group(1)) / 10, 4), "high": round(float(r.group(2)) / 10, 4), "page": p,
                                               "quote": r.group(0)}
        r = re.search(r"營業利益率(?:將|約)?介於\s*" + _NUM + r"\s*%?" + _RANGE_SEP + _NUM + r"\s*%", t)
        if r:
            d["guidance"]["operating_margin_pct"] = {"low": float(r.group(1)), "high": float(r.group(2)), "page": p,
                                                     "quote": r.group(0)}
    return d


# ------------------------------------------------------------------------------------------------ 5274 信驊
def parse_5274(pages):
    d = _deck("5274", "5274-deck")
    # 損益表頁：標題寫法多種（「2026年第二季損益表」「損益表」「綜合損益表」），季度取欄名第一個「2Q26」
    p, m = _find(pages, r"損益表.*?(?:In NT\$ thousands|Unit ?: ?NTD 1,000)\s*([1-4])Q(\d{2})\b.*?Operating Revenue")
    if m:
        d["reported_quarter"] = f"20{m.group(2)}Q{m.group(1)}"
        t = flat(pages[p - 1])
        r = re.search(r"Operating Revenue\s*([\d,]+)", t)
        if r:
            d["actual"]["revenue_twd_bn"] = {"value": round(float(r.group(1).replace(",", "")) / 1e6, 6), "page": p,
                                             "quote": r.group(0)}
        for key, word, alt in (("gross_margin_pct", "Gross Margin", "Gross Profit"),
                               ("operating_margin_pct", "Operating Margin", "Operating (?:Profit|Income)")):
            r = re.search(word + r"\s*\(%\)\s*" + _NUM + r"%", t)
            if not r:   # 2023 年版面：金額後面直接是百分比欄（例：Gross Profit 859,687 64.80）
                r = re.search(r"(?:" + alt + r")\s*[\d,]+\s+" + _NUM + r"(?=\s)", t)
            if r:
                d["actual"][key] = {"value": float(r.group(1)), "page": p, "quote": r.group(0)}
    found = []
    for i, page in enumerate(pages, 1):   # 2024–2025 年版面：「2024年第一季預估 合併營收：約新台幣 9.67億元～ 10.26億元 毛利率：62.8% ~ 64.3%」
        for g in re.finditer(r"(?P<y>\d{4})年第(?P<q>[一二三四])季(?:預估|營運展望)(?:[^合]{0,60}?匯率為\s*(?:1\s*[:：]\s*)?(?P<fx>\d+(?:\.\d+)?))?"
                             r"[^合]{0,40}?合併營收：約新台幣\s*(?P<a>\d+(?:\.\d+)?)\s*億元" + _RANGE_SEP + r"(?P<b>\d+(?:\.\d+)?)\s*億元"
                             r"\W{0,4}毛利率：\s*(?P<c>\d+(?:\.\d+)?)\s*%" + _RANGE_SEP + r"(?P<d>\d+(?:\.\d+)?)\s*%", flat(page)):
            found.append({"quarter": quarter_str(g.group("y"), g.group("q")),
                          "assumption": {"usd_twd": float(g.group("fx"))} if g.group("fx") else {}, "metrics": {
                "revenue_twd_bn": {"low": round(float(g.group("a")) / 10, 4), "high": round(float(g.group("b")) / 10, 4),
                                   "page": i, "quote": g.group(0)},
                "gross_margin_pct": {"low": float(g.group("c")), "high": float(g.group("d")), "page": i, "quote": g.group(0)}}})
        # 2025-06 版面：季中「更新營運展望」（原財測｜更新財測兩欄）→ 記為更新，取更新欄
        for g in re.finditer(r"(\d{4})年第([一二三四])季營運展望\s*原營運展望\s*更新營運展望.*?合併營收\s*NT\$\s*" + _NUM + r"B\s*~\s*\$?" + _NUM +
                             r"B\s*NT\$\s*" + _NUM + r"B\s*~\s*\$?" + _NUM + r"B\s*毛利率\s*" + _NUM + r"%\s*~\s*" + _NUM + r"%\s*" +
                             _NUM + r"%\s*~\s*" + _NUM + r"%", flat(page)):
            found.append({"quarter": quarter_str(g.group(1), g.group(2)), "assumption": {}, "updated": True, "metrics": {
                "revenue_twd_bn": {"low": float(g.group(5)), "high": float(g.group(6)), "page": i, "quote": g.group(0)[:240]},
                "gross_margin_pct": {"low": float(g.group(9)), "high": float(g.group(10)), "page": i, "quote": g.group(0)[:240]}}})
    if found:
        d["guidances"] = found
        d["guidance_quarter"], d["guidance"] = found[0]["quarter"], found[0]["metrics"]
        return d
    p, m = _find(pages, r"(\d{4})年第([一二三四])季營運展望\s*基於美元兌新台幣平均匯率為\s*" + _NUM + r"\s*的假設")
    if m:
        d["guidance_quarter"] = quarter_str(m.group(1), m.group(2))
        d["assumption"]["usd_twd"] = float(m.group(3))
        t = flat(pages[p - 1])
        r = re.search(r"合併營收約介於\s*新台幣\s*" + _NUM + r"\s*億元" + _RANGE_SEP + _NUM + r"\s*億元", t)
        if r:
            d["guidance"]["revenue_twd_bn"] = {"low": round(float(r.group(1)) / 10, 4), "high": round(float(r.group(2)) / 10, 4),
                                               "page": p, "quote": r.group(0)}
        r = re.search(r"營業毛利率約介於\s*" + _NUM + r"\s*%" + _RANGE_SEP + _NUM + r"\s*%", t)
        if r:
            d["guidance"]["gross_margin_pct"] = {"low": float(r.group(1)), "high": float(r.group(2)), "page": p,
                                                 "quote": r.group(0)}
    else:   # 英文版（2026-03 簡報）
        p, m = _find(pages, r"For (\d{4}) Q([1-4]), we currently expect")
        if m:
            d["guidance_quarter"] = f"{m.group(1)}Q{m.group(2)}"
            t = flat(pages[p - 1])
            r = re.search(r"Consolidated Revenue:\s*Around NT\$\s*" + _NUM + r"\s*billion" + _RANGE_SEP + _NUM +
                          r"\s*billion", t)
            if r:
                d["guidance"]["revenue_twd_bn"] = {"low": float(r.group(1)), "high": float(r.group(2)), "page": p,
                                                   "quote": r.group(0)}
            r = re.search(r"Gross margin:\s*" + _NUM + r"\s*%" + _RANGE_SEP + _NUM + r"\s*%", t)
            if r:
                d["guidance"]["gross_margin_pct"] = {"low": float(r.group(1)), "high": float(r.group(2)), "page": p,
                                                     "quote": r.group(0)}
            fx = re.search(r"(?:exchange rate|USD/NTD|NT\$)[^.]{0,40}?" + _NUM, t, re.I)
            if fx and 20 <= float(fx.group(1)) <= 40:
                d["assumption"]["usd_twd"] = float(fx.group(1))
    return d


PARSERS = {"3034": parse_3034, "3711": parse_3711, "5347": parse_5347, "5274": parse_5274}


# ------------------------------------------------------------------------------------------------ 彙整
def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _decode(raw):
    for enc in ("utf-8", "big5", "cp950"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def _row_time(row):
    """一覽表的「115/07/30」「115/09/07 至 115/09/08」＋「15:00」→ 台北時間（取開始日）。"""
    m = re.match(r"(\d{3})/(\d{2})/(\d{2})", row.get("date") or "")
    if not m:
        return None
    t = re.match(r"(\d{1,2}):(\d{2})", row.get("time") or "")
    hh, mm = (int(t.group(1)), int(t.group(2))) if t else (0, 0)
    return datetime(int(m.group(1)) + 1911, int(m.group(2)), int(m.group(3)), hh, mm, tzinfo=TPE)


def collect_decks(co_id, conference_root):
    """所有 conference 探測結果裡的中文簡報（M 開頭），依 SHA-256 去重；公開時間取一覽表最早一列。"""
    rows, files = [], {}
    for probe_path in sorted(glob.glob(os.path.join(conference_root, "*", "probe.json"))):
        run_dir = os.path.dirname(probe_path)
        rep = json.load(open(probe_path, encoding="utf-8"))
        if rep.get("co_id") != co_id:
            continue
        for q in rep.get("queries", []):
            if q.get("saved_as"):
                for r in cp.conference_rows(_decode(open(os.path.join(run_dir, q["saved_as"]), "rb").read()), co_id):
                    rows.append(dict(r, run=os.path.basename(run_dir)))
        for f in rep.get("files", []):
            name = f["url"].rsplit("/", 1)[-1]
            if not f.get("is_pdf") or not f.get("saved_as") or not re.fullmatch(co_id + r"\d{8}M\d{3}\.pdf", name):
                continue
            path = os.path.join(run_dir, f["saved_as"])
            sha = _sha256(path)
            if sha != f.get("sha256"):
                raise ValueError(f"簡報雜湊與探測紀錄不符：{path}")
            files.setdefault(sha, {"sha256": sha, "names": [], "path": path, "run": os.path.basename(run_dir)})
            if name not in files[sha]["names"]:
                files[sha]["names"].append(name)
    decks = []
    for sha, f in files.items():
        times = [(t, r) for r in rows if r.get("slides_zh") in f["names"] for t in [_row_time(r)] if t]
        times.sort(key=lambda x: x[0])
        first = times[0] if times else None
        decks.append(dict(f, published_at=first[0].isoformat() if first else None,
                          published_row=({k: first[1].get(k) for k in ("date", "time", "summary")} if first else None),
                          published_from="法說會一覽表" if first else None,
                          file_date=re.search(r"(\d{8})M", f["names"][0]).group(1)))
    decks.sort(key=lambda d: (d["published_at"] or d["file_date"], d["names"][0]))
    return decks


def _judge(g, a):
    if a < g["low"]:
        return "BELOW"
    if a > g["high"]:
        return "ABOVE"
    return "IN_RANGE"


def build(co_id, conference_root, now=None, pages_fn=None):
    """pages_fn(path) -> 逐頁文字；預設 pdftotext（測試用固定文字）。"""
    if co_id not in PARSERS:
        raise ValueError(f"{co_id} 尚無簡報財測解析器（支援：{', '.join(SUPPORTED)}）")
    out = {"version": SLIDE_GUIDANCE_VERSION, "co_id": co_id, "generated_at": (now or datetime.now(timezone.utc)).isoformat(),
           "tool": None if pages_fn else pdftotext_version(), "gate_impact": "none",
           "meaning": "官方財測模式（法說會簡報）：公司上一份簡報給的財測 vs 下一份簡報報告的實際。Python 預驗證，不是正式 Gate PASS。",
           "decks": [], "quarters": {}, "format_unknown": []}
    guidance, actual, segment_only = {}, {}, {}
    for dk in collect_decks(co_id, conference_root):
        pages = (pages_fn or pdf_pages)(dk["path"])
        d = PARSERS[co_id](pages)
        rec = {k: dk[k] for k in ("names", "sha256", "run", "published_at", "published_row", "file_date")}
        rec.update(pages=len(pages), reported_quarter=d["reported_quarter"], guidance_quarter=d["guidance_quarter"],
                   notes=d["notes"])
        hint = [i + 1 for i, t in enumerate(pages) if OUTLOOK_HINT.search(flat(t))]
        if d.get("segment_only_guidance"):
            segment_only.setdefault(d["guidance_quarter"], dk["names"][0])
        elif d["guidance_quarter"] and not d["guidance"]:
            out["format_unknown"].append({"deck": dk["names"][0], "reason": f"找到 {d['guidance_quarter']} 財測標題但沒有可解析的數字"})
        elif not d["guidance_quarter"] and any(re.search(r"(營運|業績)展望", flat(pages[i - 1])) for i in hint):
            out["format_unknown"].append({"deck": dk["names"][0], "pages": hint, "reason": "有「展望」頁但寫法不認得（不猜）"})
        out["decks"].append(rec)
        for g in d.get("guidances") or ([{"quarter": d["guidance_quarter"], "metrics": d["guidance"],
                                           "assumption": d["assumption"]}] if d["guidance_quarter"] else []):
            if g["metrics"]:   # 一份簡報可能同時給兩季（例：信驊 2024-03 給第一、二季）
                guidance.setdefault(g["quarter"], []).append((dk, {"guidance": g["metrics"], "assumption": g["assumption"],
                                                                    "updated": g.get("updated", False)}))
        if d["reported_quarter"] and d["actual"]:
            actual.setdefault(d["reported_quarter"], []).append((dk, d))
    for q in sorted(set(guidance) | set(actual) | set(segment_only)):
        row = {"status": None, "guidance": None, "actual": None, "comparison": {}, "notes": []}
        gs = guidance.get(q, [])
        if gs:
            first_dk, first = gs[0]
            vals = {json.dumps({k: (v["low"], v["high"]) for k, v in d["guidance"].items()}, sort_keys=True) for _, d in gs}
            row["guidance"] = {"deck": first_dk["names"][0], "sha256": first_dk["sha256"], "published_at": first_dk["published_at"],
                               "metrics": first["guidance"], "assumption": first["assumption"],
                               "also_in": [dk["names"][0] for dk, _ in gs[1:]]}
            if len(vals) > 1:
                if any(d.get("updated") for _, d in gs[1:]):
                    row["status"] = "GUIDANCE_UPDATED"
                    row["notes"].append("公司在後來的簡報寫明「更新營運展望」，同一季財測改變，不比較（同 2330 2025Q1 的處理）")
                else:
                    row["status"] = "GUIDANCE_CONFLICT"
                    row["notes"].append("多份簡報給同一季的財測數字不同，不比較：" + "；".join(
                        f"{dk['names'][0]} " + "、".join(f"{k} {v['low']:g}～{v['high']:g}" for k, v in d["guidance"].items())
                        for dk, d in gs))
        acts = actual.get(q, [])
        if acts:
            a_dk, a = acts[0]
            row["actual"] = {"deck": a_dk["names"][0], "sha256": a_dk["sha256"], "published_at": a_dk["published_at"],
                             "metrics": a["actual"]}
            if a.get("restated_previous_guidance") and row["guidance"]:   # 報告這一季的簡報重列的「本季財測」必須和原財測相同
                restated = a["restated_previous_guidance"]
                diff = [k for k, v in restated.items() if k in row["guidance"]["metrics"] and
                        (v["low"], v["high"]) != (row["guidance"]["metrics"][k]["low"], row["guidance"]["metrics"][k]["high"])]
                row["notes"].append("報告實際數字的簡報重列的財測與原財測" + ("不同：" + "、".join(diff) if diff else "相同"))
                if diff:
                    row["restated_mismatch"] = diff
        if row["status"] is None:
            if row["guidance"] and row["actual"]:
                g_at, a_at = row["guidance"]["published_at"], row["actual"]["published_at"]
                if g_at and a_at and g_at >= a_at:
                    row["status"] = "GUIDANCE_NOT_BEFORE_ACTUAL"
                else:
                    common = [k for k in row["guidance"]["metrics"] if k in row["actual"]["metrics"]]
                    row["comparison"] = {k: {"low": row["guidance"]["metrics"][k]["low"],
                                             "high": row["guidance"]["metrics"][k]["high"],
                                             "actual": row["actual"]["metrics"][k]["value"],
                                             "result": _judge(row["guidance"]["metrics"][k], row["actual"]["metrics"][k]["value"])}
                                         for k in common}
                    row["status"] = "VERIFIED" if common else "NO_COMMON_METRIC"
            elif row["guidance"]:
                row["status"] = "MISSING_ACTUAL"
            elif q in segment_only:
                row["status"] = "SEGMENT_ONLY_GUIDANCE"
                row["notes"].append(f"{segment_only[q]} 只有事業別財測，沒有公司合併數字（不比較）")
            else:
                row["status"] = "MISSING_GUIDANCE"
        out["quarters"][q] = row
    return out


_RESULT_ZH = {"IN_RANGE": "在區間內", "ABOVE": "高於", "BELOW": "低於"}


def markdown(doc):
    lines = [f"## 官方財測（法說會簡報）{doc['co_id']}", "", "| 季度 | 狀態 | 財測來源（公開時間） | 比較 |", "|---|---|---|---|"]
    for q, r in doc["quarters"].items():
        g = r["guidance"] or {}
        cmp_ = "；".join(f"{METRIC_NAMES.get(k, k)} {v['low']:g}～{v['high']:g}，實際 {v['actual']:g} {_RESULT_ZH[v['result']]}"
                        for k, v in r["comparison"].items()) or "—"
        lines.append(f"| {q} | {r['status']} | {g.get('deck', '—')}（{(g.get('published_at') or '—')[:16]}） | {cmp_} |")
    if doc["format_unknown"]:
        lines += ["", "寫法不認得（不猜）：" + "；".join(f"{x['deck']} {x['reason']}" for x in doc["format_unknown"])]
    lines += ["", doc["meaning"]]
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description="法說會簡報的官方財測 vs 實際（離線，只讀已下載的官方簡報）")
    p.add_argument("--co-id", required=True, choices=SUPPORTED)
    p.add_argument("--conference", required=True, help="results/<代號>/conference")
    p.add_argument("--out", required=True)
    a = p.parse_args(argv)
    doc = build(a.co_id, a.conference)
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
    text = markdown(doc)
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
