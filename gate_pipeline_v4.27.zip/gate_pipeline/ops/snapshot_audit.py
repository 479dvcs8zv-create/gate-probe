"""
ops/snapshot_audit.py (v4.27)
=============================
歷史市場共識快照的逐項資格審查。只產生研究紀錄（gate_impact = "none"），不改變任何 Gate 判定。

審查對象：研究紀錄中「截止點已取得、存檔在快照界線之前 45 天內」的每一筆預估（BEFORE_CUTOFF）。
每一筆逐項檢查，結果是 PASS／FAIL／PENDING／INFO，並寫明原因：

  原文完整性      保存的位元組 SHA-256 與紀錄相同；重算 SHA-1 摘要與封存索引記錄的摘要相同
  封存索引對應    保存下來的 CDX 原始回應裡，確實有「同一時間戳、同一網址、同一摘要、HTTP 200」這一列
  重新下載核對    在 Actions 裡第二次從 Wayback 取得同一份存檔，位元組完全相同
  時間            封存時間「嚴格早於」快照界線（月營收＝公告當日 00:00），且在 45 天內
  股票代號        頁面上的報價代號與預期相同
  目標期間        頁面期間標籤對應到受審查的季度
  單位            幣別寫在頁面上；與官方 EPS（新台幣／每股）是否同單位
  口徑            GAAP／調整後是否寫明
  人數            分析師人數（單一來源，不與其他來源加總）
  是否更新        與更早的存檔數值完全相同 → 網站可能未更新
  事後說法（INFO） 網站在公布後列出的「當時預估」，只對照，不採用

判定：任何 FAIL → NOT_ADOPTABLE；沒有 FAIL 但有 PENDING → PENDING（列出待決定的規則或待執行的核對）；
全部通過 → ADOPTABLE（研究上可採用，仍不等於 Gate PASS）。
"""

import base64
import hashlib
import json
import os
import sys
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from consensus_parsers import label_to_period  # noqa: E402
from consensus_research import _fmt  # noqa: E402

AUDIT_VERSION = "4.27-snapshot-audit"
TPE = timezone(timedelta(hours=8))
STALE_DAYS = 30
DECISIONS = {
    "ADR_CONVERSION": "ADR 美元預估與官方新台幣每股 EPS 的換算規則（ADR 換算比例、用哪一天的匯率）",
    "MIN_ANALYSTS": "共識最少需要幾位分析師（目前只有 1 筆預估的不能自動當成共識）",
    "BASIS_UNSTATED": "頁面沒寫 GAAP／調整後時，是否接受",
    "CURRENCY_ASSUMED": "頁面沒寫幣別時，是否接受設定檔的假設",
    "SHARE_BASIS_UNSTATED": "ADR 報價頁上的新台幣 EPS，每股或每 ADR 沒寫時如何處理",
    "STALE_VALUES": "數值長期沒有變動的來源是否採用",
}


def _digest(b):
    return base64.b32encode(hashlib.sha1(b).digest()).decode("ascii")


def _chk(name, result, detail, decision=None):
    d = {"check": name, "result": result, "detail": detail}
    if decision:
        d["decision_needed"] = decision
    return d


def _cdx_binding(cap):
    files = cap.get("cdx_files") or []
    if not files:
        return _chk("封存索引對應", "PENDING", "沒有保存封存索引（CDX）原始回應，無法離線核對時間戳與摘要的對應")
    for path, sha in files:
        if not os.path.exists(path):
            continue
        body = open(path, "rb").read()
        if sha and hashlib.sha256(body).hexdigest() != sha:
            return _chk("封存索引對應", "FAIL", f"CDX 原始回應 {os.path.basename(path)} 的 SHA-256 與紀錄不符")
        try:
            rows = json.loads(body)
        except ValueError:
            continue
        if not rows or not isinstance(rows[0], list):
            continue
        hdr = rows[0]
        for r in rows[1:]:
            if not isinstance(r, list) or len(r) != len(hdr):
                continue
            row = dict(zip(hdr, r))
            if row.get("timestamp") == cap["capture_ts"] and row.get("original") == cap.get("original"):
                if row.get("statuscode") == "200" and row.get("digest") == cap.get("archive_digest"):
                    return _chk("封存索引對應", "PASS", f"CDX 回應 {os.path.basename(path)} 有對應列："
                                f"{row['timestamp']}、HTTP 200、摘要 {row['digest']}")
                return _chk("封存索引對應", "FAIL", f"CDX 對應列的狀態或摘要不同：{row}")
    return _chk("封存索引對應", "FAIL", "保存的 CDX 回應裡找不到這個時間戳與網址")


def audit_entry(fp, e, cap, cutoff, series, retro, refetch):
    checks = []
    # 1. 原文完整性
    if cap is None or not os.path.exists(cap["file"]):
        checks.append(_chk("原文完整性", "FAIL", "找不到保存的原文"))
    else:
        raw = open(cap["file"], "rb").read()
        ok_sha = hashlib.sha256(raw).hexdigest() == cap["sha256"]
        ok_dig = bool(cap.get("archive_digest")) and _digest(raw) == cap["archive_digest"]
        checks.append(_chk("原文完整性", "PASS" if ok_sha and ok_dig else "FAIL",
                           f"SHA-256 {'相符' if ok_sha else '不符'}；重算 SHA-1 摘要 {'與封存索引相同' if ok_dig else '與封存索引不同或沒有記錄'}"))
    # 2. 封存索引對應
    checks.append(_cdx_binding(cap) if cap else _chk("封存索引對應", "FAIL", "找不到存檔紀錄"))
    # 3. 重新下載核對
    rf = refetch.get((e["source_id"], e["capture_ts"]))
    if rf and rf.get("status") == "MATCHED":
        checks.append(_chk("重新下載核對", "PASS", f"run {rf.get('run')} 再次從 Wayback 取得，位元組完全相同"))
    elif rf and rf.get("status") == "MISMATCH":
        checks.append(_chk("重新下載核對", "FAIL", f"run {rf.get('run')} 再次取得的位元組不同（{rf.get('refetched_sha256', '')[:12]}…）"))
    else:
        why = f"上次嘗試：{rf.get('status')}（{rf.get('reason')}）" if rf else "還沒有執行"
        checks.append(_chk("重新下載核對", "PENDING", f"需在 Actions 再從 Wayback 取得一次核對；{why}"))
    # 4. 時間
    cap_utc = datetime.strptime(e["capture_ts"], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    ti = e.get("timing_info") or {}
    b = datetime.fromisoformat(ti["conservative_boundary"]) if ti.get("conservative_boundary") else None
    if b is None:
        checks.append(_chk("時間", "FAIL", "沒有快照界線"))
    elif not cap_utc < b:
        checks.append(_chk("時間", "FAIL", f"封存時間 {cap_utc.astimezone(TPE).isoformat()} 不早於快照界線 {b.isoformat()}"))
    elif b - cap_utc > timedelta(days=45):
        checks.append(_chk("時間", "FAIL", f"封存時間早於快照界線 {(b - cap_utc).days} 天，超過 45 天"))
    else:
        checks.append(_chk("時間", "PASS", f"封存 {cap_utc.astimezone(TPE).isoformat()[:16]}，嚴格早於快照界線 "
                                         f"{b.isoformat()[:16]}（{round((b - cap_utc).total_seconds() / 86400, 1)} 天前；"
                                         f"公告時間 {ti.get('announced_at', '')[:16]}）"))
    # 5. 股票代號（解析器已檢查；不符的不會出現在這裡）
    checks.append(_chk("股票代號", "PASS", f"頁面報價代號 {e['quote'] if e['metric'] == 'eps' else '（營收）'}"))
    # 6. 目標期間
    again = label_to_period(e["period_label_raw"], e.get("period_type"))   # 從原文標籤重新推導，不沿用分組結果
    checks.append(_chk("目標期間", "PASS" if again == fp and e.get("period_type") == "quarter" else "FAIL",
                       f"頁面標籤「{e['period_label_raw']}」重新推導為 {again}，受審季度 {fp}"))
    # 7. 單位
    cur, quote = e["currency"], e["quote"]
    if e.get("currency_from") != "page":
        checks.append(_chk("單位", "PENDING", "頁面沒寫幣別，使用設定檔假設", "CURRENCY_ASSUMED"))
    elif e["metric"] == "eps" and cur == "TWD" and str(quote).endswith(".TW"):
        checks.append(_chk("單位", "PASS", "新台幣／每股（台股報價頁），與官方 EPS 同單位"))
    elif e["metric"] == "eps" and cur == "USD":
        checks.append(_chk("單位", "PENDING", "美元／ADR；官方 EPS 是新台幣／每股，比較前需換算", "ADR_CONVERSION"))
    elif e["metric"] == "eps":
        checks.append(_chk("單位", "PENDING", f"{cur}，ADR 報價頁上每股或每 ADR 沒寫", "SHARE_BASIS_UNSTATED"))
    elif cur == "TWD":
        checks.append(_chk("單位", "PASS", "新台幣，公司合計營收"))
    else:
        checks.append(_chk("單位", "PENDING", f"{cur} 營收；官方營收是新台幣，比較前需換算", "ADR_CONVERSION"))
    # 8. 口徑
    if e["metric"] == "eps":
        if e.get("basis"):
            checks.append(_chk("口徑", "PASS", f"頁面寫明 {e['basis']}"))
        else:
            checks.append(_chk("口徑", "PENDING", "頁面沒寫 GAAP 或調整後", "BASIS_UNSTATED"))
    # 9. 人數
    n = e.get("n_analysts")
    if n is None:
        checks.append(_chk("人數", "PENDING", "頁面沒有分析師人數", "MIN_ANALYSTS"))
    elif n < 2:
        checks.append(_chk("人數", "PENDING", "只有 1 筆預估", "MIN_ANALYSTS"))
    else:
        checks.append(_chk("人數", "PASS", f"{n} 位（只代表這個來源，不與其他來源加總）"))
    if "FY_ROW_IS_SUM_OF_QUARTERS" in e.get("flags", []):
        checks.append(_chk("人數", "FAIL", "年度值是四季單一預估相加，不是共識"))
    # 10. 是否更新
    s = series.get((e["source_id"], fp, e["metric"]))
    stale = None
    if s:
        pt = next((p for p in s["points"] if p["capture_ts"] == e["capture_ts"]), None)
        if pt and pt.get("unchanged_since"):
            since = datetime.strptime(pt["unchanged_since"], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
            if cap_utc - since > timedelta(days=STALE_DAYS):
                stale = (cap_utc - since).days
    if stale:
        checks.append(_chk("是否更新", "PENDING", f"數值與 {stale} 天前的存檔完全相同，網站可能未更新", "STALE_VALUES"))
    else:
        checks.append(_chk("是否更新", "PASS" if s else "INFO",
                           "與更早的存檔相比有更新或間隔不長" if s else "只有這一筆存檔，無法判斷是否更新"))
    # 11. 事後說法（只對照）
    claims, seen = [], set()
    for x in (retro if e["metric"] == "eps" else []):
        if x.get("eps_estimate") is not None and (x["source_id"], x["eps_estimate"]) not in seen:
            seen.add((x["source_id"], x["eps_estimate"]))
            claims.append(x)
    if claims:
        txt = "；".join(f"{x['source_id']}（{x['capture_ts'][:8]} 存檔）說當時預估 {x['eps_estimate']:g}" for x in claims[:4])
        checks.append(_chk("事後說法", "INFO", f"{txt}；快照實際是 {e['avg']:g}。事後說法不採用，只對照"))
    res = [c["result"] for c in checks]
    verdict = "NOT_ADOPTABLE" if "FAIL" in res else ("PENDING" if "PENDING" in res else "ADOPTABLE")
    return {"fiscal_period": fp, "metric": e["metric"], "currency": cur, "quote": quote, "source_id": e["source_id"],
            "vendor": e.get("vendor"), "origin": e.get("origin"), "capture_ts": e["capture_ts"],
            "captured_at_tpe": e["captured_at_tpe"], "n_analysts": n, "avg": e["avg"], "low": e["low"], "high": e["high"],
            "verdict": verdict, "checks": checks,
            "reasons": [f"{c['check']}：{c['detail']}" for c in checks if c["result"] in ("FAIL", "PENDING")],
            "decisions_needed": sorted({c["decision_needed"] for c in checks if c.get("decision_needed")})}


def audit(research, captures, refetch=None, now=None):
    """research：consensus_research.build() 的結果；captures：同一批存檔紀錄（含檔案路徑與摘要）。"""
    capmap = {(c["source_id"], c["capture_ts"]): c for c in captures}
    series = {(s["source_id"], s["fiscal_period"], s["metric"]): s for s in research.get("series", [])}
    items = []
    for fp, p in research["periods"].items():
        if not p.get("cutoff"):
            continue
        for g in p["groups"]:
            for e in g["entries"]:
                if e["timing"] != "BEFORE_CUTOFF":
                    continue
                e = dict(e, metric=g["metric"], currency=g["currency"], quote=e.get("quote") or g["quote"])
                if g["metric"] == "eps":
                    e["quote"] = g["quote"]
                items.append(audit_entry(fp, e, capmap.get((e["source_id"], e["capture_ts"])), p["cutoff"], series,
                                         p.get("retrospective", []), refetch or {}))
    items.sort(key=lambda x: (x["fiscal_period"], x["metric"], x["source_id"]))
    count = {v: sum(1 for x in items if x["verdict"] == v) for v in ("ADOPTABLE", "PENDING", "NOT_ADOPTABLE")}
    need = sorted({d for x in items for d in x["decisions_needed"]})
    return {"audit_version": AUDIT_VERSION, "data_mode": "MARKET_CONSENSUS_RESEARCH", "gate_impact": "none",
            "co_id": research["co_id"], "generated_at": (now or datetime.now(timezone.utc)).isoformat(),
            "boundary_rule": research.get("boundary_rule"), "counts": count, "items": items,
            "decisions_needed": {k: DECISIONS[k] for k in need},
            "meaning": "ADOPTABLE＝研究上可採用的截止點前快照，不等於 Gate PASS；PENDING 需要規則決定或後續核對"}


VERDICT_TEXT = {"ADOPTABLE": "可採用", "PENDING": "待確認", "NOT_ADOPTABLE": "不可採用"}


def markdown(a):
    lines = ["", f"### 歷史快照逐項審查 {a['co_id']}（只記錄，不影響 Gate）", "",
             f"可採用 {a['counts']['ADOPTABLE']}、待確認 {a['counts']['PENDING']}、不可採用 {a['counts']['NOT_ADOPTABLE']}"
             "（「可採用」只代表研究上可用的截止點前快照，不是 Gate PASS）", "",
             "| 季度 | 指標 | 來源 | 存檔時間 | 人數 | 平均 | 判定 | 原因 |", "|---|---|---|---|---|---|---|---|"]
    for x in a["items"]:
        why = "；".join(r.split("：", 1)[0] for r in x["reasons"]) or "全部通過"
        lines.append(f"| {x['fiscal_period']} | {x['metric']} {x['currency']} | `{x['source_id']}` | "
                     f"{x['captured_at_tpe'][:16]} | {'' if x['n_analysts'] is None else x['n_analysts']} | "
                     f"{_fmt(x['avg'], x['metric'])} | {VERDICT_TEXT[x['verdict']]} | {why} |")
    if a["decisions_needed"]:
        lines += ["", "待決定的規則："] + [f"- {v}" for v in a["decisions_needed"].values()]
    return "\n".join(lines)
