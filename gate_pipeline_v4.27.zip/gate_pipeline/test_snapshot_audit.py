"""
test_snapshot_audit.py (v4.27)
==============================
歷史市場共識快照：補齊（Actions 才能連 Wayback，這裡用本機模擬）與逐項資格審查（真實存檔原文）。
  - 審查：原文完整性、封存索引對應、重新下載核對、時間（嚴格早於快照界線）、代號、期間、單位、口徑、人數、是否更新
  - 判定：任何 FAIL → 不可採用；有 PENDING → 待確認（列出待決定的規則）；全部通過 → 可採用（不等於 Gate PASS）
  - 補齊：只抓快照界線之前 45 天內最新一筆（界線當下 00:00 那一筆不算）、已取得的不重抓、審查候選重新下載核對

  python test_snapshot_audit.py
"""
import base64
import copy
import hashlib
import http.server
import json
import os
import shutil
import sys
import tempfile
import threading
import urllib.parse
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import consensus_backfill as cb  # noqa: E402
import consensus_research as cr  # noqa: E402
import snapshot_audit as sa  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
ARCH = [os.path.join(BASE, d) for d in ("archive_39122089604", "archive_39186897770", "archive_39187117065")]
DISC = os.path.join(BASE, "run_39118440897", "consensus_discovery")
SUMMARY = json.load(open(os.path.join(BASE, "run_39126755093", "summary.json"), encoding="utf-8"))
CUT = cr.cutoffs_from_summary(SUMMARY)
NOW = datetime(2026, 10, 19, 4, 0, tzinfo=timezone.utc)
CAPS = cr.load_all_captures(ARCH, [DISC])
R = cr.build("2330", CAPS, CUT, now=NOW)


def _item(a, fp, metric, sid):
    xs = [x for x in a["items"] if (x["fiscal_period"], x["metric"], x["source_id"]) == (fp, metric, sid)]
    assert len(xs) == 1, [(x["fiscal_period"], x["metric"], x["source_id"]) for x in a["items"]]
    return xs[0]


def _check(x, name):
    return [c for c in x["checks"] if c["check"] == name]


def test_real_snapshots_all_pending_with_reasons():
    a = sa.audit(R, CAPS, {}, now=NOW)
    assert a["gate_impact"] == "none" and a["counts"] == {"ADOPTABLE": 0, "PENDING": 9, "NOT_ADOPTABLE": 0}, a["counts"]
    y = _item(a, "2024Q4", "eps", "yahoo_adr_analysis")
    assert (y["n_analysts"], y["avg"], y["verdict"]) == (6, 2.23, "PENDING")
    res = {c["check"]: c["result"] for c in y["checks"]}
    assert res["原文完整性"] == res["封存索引對應"] == res["時間"] == res["目標期間"] == res["人數"] == "PASS", res
    assert res["重新下載核對"] == res["單位"] == res["口徑"] == "PENDING", res
    assert y["decisions_needed"] == ["ADR_CONVERSION", "BASIS_UNSTATED"]
    assert "2025-01-10T00:00" in _check(y, "時間")[0]["detail"]
    retro = _check(y, "事後說法")[0]["detail"]
    assert "2.16" in retro and "2.22" in retro and "快照實際是 2.23" in retro   # 事後說法與快照不同，只對照
    m = _item(a, "2025Q1", "eps", "marketbeat_adr_earnings")
    assert "MIN_ANALYSTS" in m["decisions_needed"] and _check(m, "人數")[0]["result"] == "PENDING"
    s = _item(a, "2025Q4", "eps", "stockanalysis_adr_forecast")
    assert "SHARE_BASIS_UNSTATED" in s["decisions_needed"]
    assert set(a["decisions_needed"]) == {"ADR_CONVERSION", "BASIS_UNSTATED", "MIN_ANALYSTS", "SHARE_BASIS_UNSTATED"}
    md = sa.markdown(a)
    assert "不是 Gate PASS" in md and "待確認" in md


def test_refetch_result_changes_verdict():
    k = ("yahoo_adr_analysis", "20250106225927")
    a = sa.audit(R, CAPS, {k: {"status": "MATCHED", "run": "x"}}, now=NOW)
    y = _item(a, "2024Q4", "revenue", "yahoo_adr_analysis")   # 營收：新台幣、有人數，只差重新下載核對
    assert y["verdict"] == "ADOPTABLE" and not y["reasons"], y["reasons"]
    a = sa.audit(R, CAPS, {k: {"status": "MISMATCH", "run": "x", "refetched_sha256": "ab" * 32}}, now=NOW)
    assert _item(a, "2024Q4", "eps", "yahoo_adr_analysis")["verdict"] == "NOT_ADOPTABLE"
    a = sa.audit(R, CAPS, {k: {"status": "FETCH_FAILED", "reason": "HTTP 503", "run": "x"}}, now=NOW)
    assert "HTTP 503" in _check(_item(a, "2024Q4", "revenue", "yahoo_adr_analysis"), "重新下載核對")[0]["detail"]


def test_tampered_evidence_not_adoptable():
    tmp = tempfile.mkdtemp(prefix="audit_")
    try:
        d = os.path.join(tmp, "disc")
        shutil.copytree(DISC, d)
        f = os.path.join(d, "cdx", "yahoo_adr_analysis_00.json")
        rows = json.load(open(f))
        for r in rows[1:]:
            if r[0] == "20250106225927":
                r[3] = "X" * 32        # 竄改索引裡的摘要
        open(f, "w").write(json.dumps(rows))
        caps = cr.load_all_captures(ARCH, [d])
        a = sa.audit(cr.build("2330", caps, CUT, now=NOW), caps, {}, now=NOW)
        y = _item(a, "2024Q4", "eps", "yahoo_adr_analysis")
        assert y["verdict"] == "NOT_ADOPTABLE" and _check(y, "封存索引對應")[0]["result"] == "FAIL"
        caps2 = copy.deepcopy(CAPS)
        for c in caps2:
            if (c["source_id"], c["capture_ts"]) == ("yahoo_adr_analysis", "20250224154350"):
                c["archive_digest"] = "Y" * 32   # 紀錄的封存摘要與原文不符
        a = sa.audit(cr.build("2330", caps2, CUT, now=NOW), caps2, {}, now=NOW)
        y = _item(a, "2025Q1", "eps", "yahoo_adr_analysis")
        assert y["verdict"] == "NOT_ADOPTABLE" and _check(y, "原文完整性")[0]["result"] == "FAIL"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_adoptable_path_and_strict_boundary():
    """台股頁（新台幣／每股、寫明口徑、人數 22）＋索引對應＋重新下載相符 → 可採用；界線當下 00:00 的存檔不算。"""
    tmp = tempfile.mkdtemp(prefix="audit_")
    try:
        cap = [c for c in CAPS if c["source_id"] == "yahoo_tw_analysis"][0]
        raw = open(cap["file"], "rb").read()
        dig = base64.b32encode(hashlib.sha1(raw).digest()).decode()
        cdx = os.path.join(tmp, "cdx.json")
        url = "https://finance.yahoo.com/quote/2330.TW/analysis/"
        open(cdx, "w").write(json.dumps([["timestamp", "original", "statuscode", "digest", "mimetype", "length"],
                                         [cap["capture_ts"], url, "200", dig, "text/html", str(len(raw))]]))
        c = dict(cap, original=url, archive_digest=dig, cdx_files=[(cdx, hashlib.sha256(open(cdx, "rb").read()).hexdigest())])
        cut = dict(CUT, **{"2026Q4": {"at": "2026-11-20T13:30:00+08:00", "event_type": "quarter_revenue_complete",
                                      "status": "CUTOFF_VERIFIED"}})   # 合成的截止點，只為了走到審查
        r = cr.build("2330", [c], cut, now=NOW)
        a = sa.audit(r, [c], {("yahoo_tw_analysis", cap["capture_ts"]): {"status": "MATCHED", "run": "x"}}, now=NOW)
        x = _item(a, "2026Q4", "eps", "yahoo_tw_analysis")
        assert x["verdict"] == "ADOPTABLE" and x["n_analysts"] == 22 and x["avg"] == 32.96, x["reasons"]
        # 截止點改成存檔當天（界線＝當日 00:00，存檔 09:54 不早於界線）→ 不算截止點前快照，不進入審查
        cut["2026Q4"]["at"] = "2026-10-19T13:30:00+08:00"
        r = cr.build("2330", [c], cut, now=NOW)
        assert not [x for x in sa.audit(r, [c], {}, now=NOW)["items"] if x["fiscal_period"] == "2026Q4"]
        t, _ = cr._timing("2026Q4", datetime(2026, 10, 18, 16, 0, tzinfo=timezone.utc), cut)   # 剛好 00:00
        assert t == "BEFORE_ANNOUNCEMENT_SAME_DAY"
        t, _ = cr._timing("2026Q4", datetime(2026, 10, 18, 15, 59, 59, tzinfo=timezone.utc), cut)
        assert t == "BEFORE_CUTOFF"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------------------------------- 補齊（本機模擬 Wayback）
YAHOO = open(os.path.join(DISC, "samples", "yahoo_adr_analysis_2024Q4.bin"), "rb").read()
PAGES = {}


def _d(b):
    return base64.b32encode(hashlib.sha1(b).digest()).decode()


class W(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body=b"", ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urllib.parse.urlsplit(self.path)
        if u.path == "/cdx/search/cdx":
            q = dict(urllib.parse.parse_qsl(u.query))
            rows = [["timestamp", "original", "statuscode", "digest", "mimetype", "length"]]
            for (ts, url), body in sorted(PAGES.items()):
                if url.split("://", 1)[1].startswith(q["url"]):
                    rows.append([ts, url, "200", _d(body), "text/html", str(len(body))])
            return self._send(200, json.dumps(rows).encode())
        if u.path.startswith("/web/"):
            ts, url = self.path[len("/web/"):].split("id_/", 1)
            body = PAGES.get((ts, url))
            return self._send(200, body, "text/html") if body is not None else self._send(404)
        self._send(400)


def test_backfill_fetches_new_skips_held_and_refetches():
    PAGES.clear()
    u = "https://finance.yahoo.com/quote/TSM/analysis/"
    PAGES[("20250106225927", u)] = YAHOO                 # 2024Q4 界線 2025-01-10 00:00 前（已取得過）
    PAGES[("20250109155959", u)] = YAHOO + b"<!--x-->"    # 界線前 1 秒（台北 2025-01-09 23:59:59）→ 新的、最新
    PAGES[("20250109160000", u)] = YAHOO + b"<!--y-->"    # 剛好等於界線 → 不算
    PAGES[("20240920000000", u)] = YAHOO + b"<!--z-->"    # 2024Q3（界線 2024-10-09 00:00）前 19 天
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), W)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    old = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    tmp = tempfile.mkdtemp(prefix="backfill_")
    try:
        held = {("yahoo_adr_analysis", "20250106225927"): {"sha256": hashlib.sha256(YAHOO).hexdigest()}}
        refetch = [("yahoo_adr_analysis", "20250106225927", u, hashlib.sha256(YAHOO).hexdigest()),
                   ("yahoo_adr_analysis", "20240920000000", u, "0" * 64)]
        out = os.path.join(tmp, "results", "2330", "archive", "1", "backfill")
        bounds = cr.boundaries_from_summary(SUMMARY)
        r = cb.backfill("2330", bounds, out, held, refetch, base_url=f"http://127.0.0.1:{srv.server_address[1]}",
                        delay=0, sleep=lambda s: None, source_ids=("yahoo_adr_analysis",))
        y = r["sources"][0]
        assert y["quarters"]["2024Q4"]["timestamp"] == "20250109155959"      # 嚴格早於界線的最新一筆
        assert y["quarters"]["2024Q3"]["timestamp"] == "20240920000000"
        got = {x["quarter"]: x for x in y["samples"]}
        assert set(got) == {"2024Q4", "2024Q3"} and all(x["digest_matched"] for x in got.values())
        assert [x["status"] for x in r["refetch"]] == ["MATCHED", "MISMATCH"]
        assert os.path.exists(os.path.join(out, "cdx", "yahoo_adr_analysis.json"))
        # 研究紀錄讀得到補齊的存檔；重新下載核對結果進入審查
        caps = cr.captures_from_backfill_dir(out)
        assert {c["capture_ts"] for c in caps} == {"20250109155959", "20240920000000"}
        assert all(c["cdx_files"] and c["original"] == u for c in caps)
        rf = cr.refetch_records([out])
        assert rf[("yahoo_adr_analysis", "20250106225927")]["status"] == "MATCHED"
        arch, disc, _ = cr.discover_inputs(os.path.join(tmp, "results", "2330"))
        assert disc == [out]
        # 已取得的不重抓
        held.update({("yahoo_adr_analysis", c["capture_ts"]): {"sha256": c["sha256"]} for c in caps})
        r2 = cb.backfill("2330", bounds, os.path.join(tmp, "b2"), held, [], delay=0, sleep=lambda s: None,
                         base_url=f"http://127.0.0.1:{srv.server_address[1]}", source_ids=("yahoo_adr_analysis",))
        assert r2["sources"][0]["samples"] == []
        # 只用截止點已驗證的季度
        b3 = dict(bounds, **{"2024Q4": dict(bounds["2024Q4"], status="PROVISIONAL")})
        r3 = cb.backfill("2330", b3, os.path.join(tmp, "b3"), {}, [], delay=0, sleep=lambda s: None,
                         base_url=f"http://127.0.0.1:{srv.server_address[1]}", source_ids=("yahoo_adr_analysis",))
        assert "2024Q4" not in r3["sources"][0]["quarters"]
    finally:
        os.environ.update(old)
        srv.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)


def test_boundaries_from_old_summary():
    b = cr.boundaries_from_summary(SUMMARY)   # v4.26 之前的 summary 沒有 snapshot_boundary，也要算出 00:00
    assert b["2024Q4"] == {"at": "2025-01-10T00:00:00+08:00", "status": "CUTOFF_VERIFIED",
                           "announced_at": "2025-01-10T14:05:13+08:00"}


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
