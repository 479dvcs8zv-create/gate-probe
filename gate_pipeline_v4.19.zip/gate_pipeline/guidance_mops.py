"""
guidance_mops.py (v4.19)
========================
Gate5B 官方財測模式（使用者 2026-10-18 核准的方向：「官方財測＋往後自己存檔」）。
與市場共識模式（gates.eval_gate5b_pre_earnings）分開輸出：資料模式 OFFICIAL_GUIDANCE，
通過時結果為 OFFICIAL_GUIDANCE_VERIFIED，永遠不會寫成市場共識的 PASS。

資料來源只有一種：公開資訊觀測站重大訊息中，公司自己發布的「每股盈餘」公告詳細頁（已由 mops_t05st01 以官方網域、
SHA-256、與清單逐欄核對的方式解析）。台積電的這則公告同時包含：
  - 當季實際結果：美元營收、毛利率、營業利益率、每股盈餘（合併、單季，依 TIFRS）
  - 下一季業績展望（財測）：美元營收區間、毛利率區間、營業利益率區間、匯率假設
    原文寫法為「根據對當前業務狀況的評估，台積公司YYYY年第X季的業績展望如下」，是發布當時對下一季的預測。

每一季的判定（全部 fail-closed）：
  1. 財測必須來自「上一季」的每股盈餘公告，且展望的目標季度必須正好是這一季
  2. 財測的發言時間必須早於這一季的官方截止點（cutoff_candidates 算出的最早揭露時間）
  3. 財測發布後、截止點之前的「每一則」公告都要有原文：缺任何一則 → GUIDANCE_WINDOW_INCOMPLETE
     （不依主旨或分類略過）。原文含數字財測句型，或「展望／財測」附近出現維持、調整、上修、下修、更新等字眼
     → 待人工確認沒有更新這一季的財測（reviews/*.json，decision = guidance_not_updated）
  4. 實際結果必須來自這一季自己的每股盈餘公告，口徑與財測相同（合併、單季、美元營收；毛利率與營業利益率）
  5. 任何一個欄位解析不到 → 這一季不算（不猜、不補）
比較方式：實際值高於區間上緣 / 在區間內 / 低於區間下緣。
已知口徑差異：財測的毛利率、營業利益率以公告當時的匯率假設計算，實際值用實際匯率，本模組不做匯率調整（照實記錄假設匯率）。

這是「公司財測」，不是「市場共識」：意義不同，摘要與輸出都明確標示。沒有發布量化財測的公司，這個模式不適用。
Python 預驗證通過，不等於正式 Gate PASS。
"""

import re
from datetime import datetime
from typing import Optional

GUIDANCE_MODE_VERSION = "4.19-guidance"
DATA_MODE = "OFFICIAL_GUIDANCE"
MIN_QUARTERS = 8
CN = {"一": 1, "二": 2, "三": 3, "四": 4}
# 財測期間內公告原文的檢查句型（主旨＋說明，去空白後比對）
_STRONG_GUIDANCE = re.compile(r"營收預計介於|毛利率預計介於|營業利益率預計介於|業績展望如下")
_UPDATE_NEAR = re.compile(r"(展望|財測|財務預測|營運預測|業績預估|guidance|outlook).{0,25}(維持|調整|上修|下修|更新|修正|變更|調升|調降|maintain|raise|lower|revise|update)"
                          r"|(維持|調整|上修|下修|更新|修正|變更|調升|調降|maintain|raise|lower|revise|update).{0,25}(展望|財測|財務預測|營運預測|業績預估|guidance|outlook)",
                          re.IGNORECASE)


def _q(year, cn):
    return f"{int(year)}Q{CN[cn]}"


def next_quarter(q):
    y, n = int(q[:4]), int(q[-1])
    return f"{y + (n == 4)}Q{n % 4 + 1}"


def _num(s):
    return float(s.replace(",", ""))


def _yi_usd(whole, qian_wan=None):
    """「188億7千萬」→ 188.7 億；「467.2億」→ 467.2 億。回傳十億美元（billion）。"""
    v = _num(whole) + (int(qian_wan) / 10 if qian_wan else 0)
    return round(v / 10, 4)


_RE = {
    "reported": re.compile(r"公佈(\d{4})年第([一二三四])季財務報告"),
    "usd_rev": re.compile(r"若以(?:美元|美金)計算，(\d{4})年第([一二三四])季營收為([\d,]+(?:\.\d+)?)億(?:(\d)千萬)?"),
    "margins": re.compile(r"(\d{4})年第([一二三四])季毛利率為([\d.]+)%，營業利益率為([\d.]+)%"),
    "eps": re.compile(r"每股盈餘為新台幣([\d.]+)元（折合美國存託憑證每單位為([\d.]+)美元）"),
    "outlook": re.compile(r"(\d{4})年第([一二三四])季的業績展望如下"),
    "g_rev": re.compile(r"營收預計介於([\d,]+(?:\.\d+)?)億(?:美元)?(?:到|至)([\d,]+(?:\.\d+)?)億美元"),
    "g_gm": re.compile(r"毛利率預計介於([\d.]+)%(?:到|至)([\d.]+)%"),
    "g_opm": re.compile(r"營業利益率預計介於([\d.]+)%(?:到|至)([\d.]+)%"),
    "g_fx": re.compile(r"新台幣([\d.]+)元兌1美元|1美元兌換?([\d.]+)元新台幣"),
}


def parse_eps_announcement(description: str):
    """解析每股盈餘公告的「說明」。回傳 ({"reported_quarter", "actual", "actual_failures", "guidance",
    "guidance_failures"}, failures)。實際結果與財測分開解析：一邊缺欄位，那一邊整個不採用（None），不影響另一邊。
    找不到報告季度 → 整則不採用。"""
    t = re.sub(r"\s+", "", description or "")
    m = _RE["reported"].search(t)
    if not m:
        return None, ["找不到「公佈 YYYY 年第 X 季財務報告」"]
    rq = _q(*m.groups())
    actual, fails = _parse_actual(t, rq)
    guidance, gfails = _parse_guidance(t, rq)
    return {"reported_quarter": rq, "actual": actual, "actual_failures": fails,
            "guidance": guidance, "guidance_failures": gfails}, []


def _parse_actual(t, rq):
    fails = []
    actual = {}
    m = _RE["usd_rev"].search(t)
    if m and _q(m.group(1), m.group(2)) == rq:
        actual["revenue_usd_bn"] = _yi_usd(m.group(3), m.group(4))
    else:
        fails.append("找不到當季美元營收")
    m = _RE["margins"].search(t)
    if m and _q(m.group(1), m.group(2)) == rq:
        actual["gross_margin_pct"], actual["operating_margin_pct"] = float(m.group(3)), float(m.group(4))
    else:
        fails.append("找不到當季毛利率、營業利益率")
    m = _RE["eps"].search(t)
    if m:
        actual["eps_twd"], actual["eps_adr_usd"] = float(m.group(1)), float(m.group(2))
    else:
        fails.append("找不到每股盈餘")
    return (None, fails) if fails else (actual, [])


def _parse_guidance(t, rq):
    found = list(_RE["outlook"].finditer(t))
    if not found:
        return None, ["沒有業績展望段落"]
    if len({m.groups() for m in found}) > 1:
        return None, [f"同一則公告有多個不同季度的展望：{[_q(*m.groups()) for m in found]}"]
    m = found[0]
    target = _q(*m.groups())
    seg = t[m.end():m.end() + 400]
    r, gm, opm, fx = (_RE["g_rev"].search(seg), _RE["g_gm"].search(seg), _RE["g_opm"].search(seg),
                      _RE["g_fx"].search(seg))
    if not (r and gm and opm):
        return None, [f"有「{target} 業績展望」段落，但營收、毛利率或營業利益率區間解析不完整"]
    guidance = {"target_quarter": target,
                "revenue_usd_bn": [_yi_usd(r.group(1)), _yi_usd(r.group(2))],
                "gross_margin_pct": [float(gm.group(1)), float(gm.group(2))],
                "operating_margin_pct": [float(opm.group(1)), float(opm.group(2))],
                "fx_twd_per_usd": float(fx.group(1) or fx.group(2)) if fx else None}
    for k in ("revenue_usd_bn", "gross_margin_pct", "operating_margin_pct"):
        if guidance[k][0] > guidance[k][1]:
            return None, [f"{target} 財測的 {k} 區間下緣大於上緣"]
    if target != next_quarter(rq):
        return None, [f"{rq} 的公告裡的展望目標是 {target}，不是下一季 {next_quarter(rq)}"]
    return guidance, []


def _verdict(actual, rng):
    if actual > rng[1]:
        return "ABOVE"
    if actual < rng[0]:
        return "BELOW"
    return "WITHIN"


def guidance_signals(subject, description):
    """回傳這則公告原文中可能更新財測的句子（空清單 = 沒有）。"""
    text = re.sub(r"\s+", "", f"{subject or ''}{description or ''}")
    hits = []
    for m in list(_STRONG_GUIDANCE.finditer(text)) + list(_UPDATE_NEAR.finditer(text)):
        hits.append(text[max(0, m.start() - 20):m.end() + 20])
    return hits


def evaluate_guidance(items, details: dict, cutoffs: dict, eps_items=None, guidance_reviews=None):
    """items：合併後清單的所有公告（T05st01Item）；details：{document_id: T05st01Detail}（已核對過的官方詳細頁）；
    cutoffs：{季度: datetime}（官方截止點，只放已驗證的季度）；eps_items：被分類為每股盈餘公告的 items；
    guidance_reviews：{季度: set(document_id)}，人工確認「沒有更新該季財測」的公告。
    回傳 {"data_mode", "quarters": {...}, "gate": {...}, "parse_failures": [...]}"""
    from mops_t05st01 import classify
    guidance_reviews = guidance_reviews or {}
    if eps_items is None:
        eps_items = [it for it in items if any(e["event_type"] == "self_reported_results" for e in classify(it))]
    parsed, parse_failures = {}, []
    for it in eps_items:
        d = details.get(it.document_id)
        if d is None:
            parse_failures.append({"document_id": it.document_id, "reason": "詳細頁未取得"})
            continue
        p, f = parse_eps_announcement(d.description)
        if p is None:
            parse_failures.append({"document_id": it.document_id, "reason": "；".join(f)})
            continue
        if p["actual_failures"]:
            parse_failures.append({"document_id": it.document_id, "part": "actual",
                                   "reason": "實際結果未採用：" + "；".join(p["actual_failures"])})
        if p["guidance_failures"] and p["guidance_failures"] != ["沒有業績展望段落"]:
            parse_failures.append({"document_id": it.document_id, "part": "guidance",
                                   "reason": "財測未採用：" + "；".join(p["guidance_failures"])})
        parsed[it.document_id] = dict(p, announced_at=it.announced_at, document_id=it.document_id,
                                      response_sha256=d.response_sha256)
    actual_by_q, guidance_by_q = {}, {}
    for p in parsed.values():
        if p["actual"]:
            actual_by_q.setdefault(p["reported_quarter"], []).append(p)
        if p["guidance"]:
            guidance_by_q.setdefault(p["guidance"]["target_quarter"], []).append(p)

    out = {}
    for q, cutoff in sorted(cutoffs.items()):
        e = {"data_mode": DATA_MODE, "evidence_tier": "official_record", "cutoff": cutoff.isoformat(),
             "status": None, "reject_code": None, "guidance": None, "actual": None, "verdicts": None,
             "window": None, "notes": []}
        out[q] = e
        acts = actual_by_q.get(q, [])
        gs = guidance_by_q.get(q, [])
        pre = [g for g in gs if g["announced_at"] < cutoff]
        if not gs:
            e.update(status="MISSING_GUIDANCE", reject_code="GUIDANCE_MISSING")
            continue
        if not pre:
            e.update(status="GUIDANCE_AFTER_CUTOFF", reject_code="GUIDANCE_AFTER_CUTOFF")
            continue
        g = max(pre, key=lambda x: x["announced_at"])
        if len(pre) > 1:
            e["notes"].append(f"同一季有 {len(pre)} 則展望，採用截止點前最後一則：{g['document_id']}")
        e["guidance"] = dict(g["guidance"], document_id=g["document_id"], announced_at=g["announced_at"].isoformat(),
                             issued_with_results_of=g["reported_quarter"], response_sha256=g["response_sha256"])
        # 財測發布後、截止點前的每一則公告：原文都要有，且不能含可能更新財測的內容（除非已人工確認）
        window = [it for it in items if g["announced_at"] < it.announced_at < cutoff]
        missing = sorted(it.document_id for it in window if it.document_id not in details)
        flagged, cleared = [], []
        for it in window:
            d = details.get(it.document_id)
            if d is None:
                continue
            hits = guidance_signals(it.subject, d.description)
            if hits:
                rec = {"document_id": it.document_id, "subject": it.subject, "signals": hits}
                (cleared if it.document_id in guidance_reviews.get(q, set()) else flagged).append(rec)
        e["window"] = {"from": g["announced_at"].isoformat(), "to": cutoff.isoformat(), "announcements": len(window),
                       "missing_detail": missing, "flagged": flagged, "cleared_by_review": cleared}
        if missing:
            e.update(status="GUIDANCE_WINDOW_INCOMPLETE", reject_code="GUIDANCE_WINDOW_INCOMPLETE")
            continue
        if flagged:
            e.update(status="GUIDANCE_UPDATE_REVIEW_PENDING", reject_code="GUIDANCE_UPDATE_REVIEW_PENDING")
            continue
        if len(acts) > 1:
            e.update(status="MULTIPLE_ACTUALS", reject_code="GUIDANCE_MULTIPLE_ACTUALS")
            e["notes"].append(f"{q} 有 {len(acts)} 則每股盈餘公告：{[a['document_id'] for a in acts]}")
            continue
        if not acts:
            e.update(status="MISSING_ACTUAL", reject_code="GUIDANCE_ACTUAL_MISSING")
            continue
        a = acts[0]
        e["actual"] = dict(a["actual"], document_id=a["document_id"], announced_at=a["announced_at"].isoformat(),
                           response_sha256=a["response_sha256"])
        e["verdicts"] = {k: _verdict(a["actual"][k], g["guidance"][k])
                         for k in ("revenue_usd_bn", "gross_margin_pct", "operating_margin_pct")}
        e["status"] = "VERIFIED"
    n = sum(1 for e in out.values() if e["status"] == "VERIFIED")
    gate = {"data_mode": DATA_MODE, "label": "Gate5B 官方財測模式（Python 預驗證，非正式 Gate PASS）",
            "verified_quarters": n, "min_quarters": MIN_QUARTERS,
            "result": "OFFICIAL_GUIDANCE_VERIFIED" if n >= MIN_QUARTERS else "INSUFFICIENT",
            "meaning": "比較的是公司自己在上一季公布的財測，不是市場共識"}
    return {"version": GUIDANCE_MODE_VERSION, "data_mode": DATA_MODE, "quarters": out, "gate": gate,
            "parse_failures": parse_failures}


VERDICT_TEXT = {"ABOVE": "高於", "WITHIN": "區間內", "BELOW": "低於"}


def markdown(g):
    lines = ["", f"### {g['gate']['label']}", "",
             f"已驗證 {g['gate']['verified_quarters']}/{len(g['quarters'])} 季（門檻 {g['gate']['min_quarters']}）："
             f"{g['gate']['result']}。{g['gate']['meaning']}。", "",
             "| 季度 | 狀態 | 財測營收（十億美元） | 實際 | 毛利率財測 | 實際 | 營益率財測 | 實際 |",
             "|---|---|---|---|---|---|---|---|"]
    for q, e in g["quarters"].items():
        if e["status"] != "VERIFIED":
            w = e.get("window") or {}
            why = (f"缺 {len(w['missing_detail'])} 則原文" if w.get("missing_detail") else
                   f"待確認 {'、'.join(x['document_id'].split(':', 2)[2] for x in w['flagged'])}" if w.get("flagged") else "")
            lines.append(f"| {q} | {e['status']} | {why} | | | | | |")
            continue
        gd, a, v = e["guidance"], e["actual"], e["verdicts"]
        lines.append(
            f"| {q} | 已驗證 | {gd['revenue_usd_bn'][0]:g}–{gd['revenue_usd_bn'][1]:g} | {a['revenue_usd_bn']:g}"
            f"（{VERDICT_TEXT[v['revenue_usd_bn']]}） | {gd['gross_margin_pct'][0]:g}–{gd['gross_margin_pct'][1]:g}% | "
            f"{a['gross_margin_pct']:g}%（{VERDICT_TEXT[v['gross_margin_pct']]}） | "
            f"{gd['operating_margin_pct'][0]:g}–{gd['operating_margin_pct'][1]:g}% | "
            f"{a['operating_margin_pct']:g}%（{VERDICT_TEXT[v['operating_margin_pct']]}） |")
    for f in g["parse_failures"]:
        lines.append(f"\n- 未採用 {f['document_id']}：{f['reason']}")
    return "\n".join(lines)
