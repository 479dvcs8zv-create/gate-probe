/*
 * gate5b_reader.js (gate_pipeline v4.36) — 給正式網站 v227 的唯讀讀取器（瀏覽器或 Node 18+ 皆可）。
 * 只讀 gate-probe 匯出的 Gate5B 時間界線；任何一步失敗都回傳 null（＝沒有界線），由呼叫端維持現行結果。
 * 不能把 null 當成通過；research_only（季末規則）不採用。
 *
 *   const data = await loadGate5bBoundaries();
 *   const q = gate5bQuarter(data, "2330", "2026Q3");            // null 或 {cutoff_at, snapshot_boundary_at, ...}
 *   const ok = snapshotBeforeBoundary("2026-10-01T09:00:00+08:00", q);   // true／false；q 為 null 時回傳 null
 */
var GATE5B_URL = "https://raw.githubusercontent.com/479dvcs8zv-create/gate-probe/main/exports/gate5b/latest.json";
var GATE5B_SCHEMA = "gate-probe/gate5b-export/v1";

async function loadGate5bBoundaries(url) {
  try {
    var r = await fetch(url || GATE5B_URL, { cache: "no-store" });
    if (!r.ok) return null;
    var d = await r.json();
    return d && d.schema === GATE5B_SCHEMA && d.stocks ? d : null;
  } catch (e) {
    return null;
  }
}

function gate5bQuarter(data, coId, quarter) {
  var s = data && data.stocks && data.stocks[String(coId)];
  if (!s || s.verification !== "MATCH") return null;
  var q = s.quarters && s.quarters[quarter];
  return q && q.status === "CUTOFF_VERIFIED" && q.snapshot_boundary_at ? q : null;
}

function snapshotBeforeBoundary(snapshotIso, q) {
  if (!q) return null;
  var t = Date.parse(snapshotIso), b = Date.parse(q.snapshot_boundary_at);
  if (isNaN(t) || isNaN(b)) return null;
  return t < b;   // 嚴格早於；等於也不算
}

if (typeof module !== "undefined") {
  module.exports = { loadGate5bBoundaries, gate5bQuarter, snapshotBeforeBoundary, GATE5B_URL, GATE5B_SCHEMA };
}
