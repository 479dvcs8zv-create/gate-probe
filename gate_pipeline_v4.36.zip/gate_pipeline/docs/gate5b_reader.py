"""
gate5b_reader.py (gate_pipeline v4.36) — 給正式網站 v227 的唯讀讀取器（Python 3.8+，只用標準函式庫）。
只讀 gate-probe 匯出的 Gate5B 時間界線；任何一步失敗都回傳 None（＝沒有界線），由呼叫端維持現行結果。
不能把 None 當成通過；research_only（季末規則）不採用。

    data = load_gate5b_boundaries()
    q = gate5b_quarter(data, "2330", "2026Q3")           # None 或 {cutoff_at, snapshot_boundary_at, ...}
    ok = snapshot_before_boundary("2026-10-01T09:00:00+08:00", q)   # True／False；q 為 None 時回傳 None
"""
import json
import urllib.request
from datetime import datetime

GATE5B_URL = "https://raw.githubusercontent.com/479dvcs8zv-create/gate-probe/main/exports/gate5b/latest.json"
GATE5B_SCHEMA = "gate-probe/gate5b-export/v1"


def load_gate5b_boundaries(url=GATE5B_URL, timeout=20):
    try:
        if url.startswith(("http://", "https://")):
            with urllib.request.urlopen(url, timeout=timeout) as r:
                d = json.loads(r.read().decode("utf-8"))
        else:   # 本機檔案（測試或離線）
            with open(url, encoding="utf-8") as f:
                d = json.load(f)
    except Exception:
        return None
    return d if isinstance(d, dict) and d.get("schema") == GATE5B_SCHEMA and isinstance(d.get("stocks"), dict) else None


def gate5b_quarter(data, co_id, quarter):
    s = ((data or {}).get("stocks") or {}).get(str(co_id))
    if not s or s.get("verification") != "MATCH":
        return None
    q = (s.get("quarters") or {}).get(quarter)
    return q if q and q.get("status") == "CUTOFF_VERIFIED" and q.get("snapshot_boundary_at") else None


def snapshot_before_boundary(snapshot_iso, q):
    if not q:
        return None
    try:
        t, b = datetime.fromisoformat(snapshot_iso), datetime.fromisoformat(q["snapshot_boundary_at"])
        if t.tzinfo is None or b.tzinfo is None:   # 沒有時區的時間不比較
            return None
        return t < b   # 嚴格早於；等於也不算
    except (ValueError, TypeError, KeyError):
        return None
