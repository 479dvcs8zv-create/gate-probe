# gate-probe → 正式網站 v227：最小整合提案（只讀、只用時間界線）

版本：gate_pipeline v4.36（2026-10-19）　提案人：Claude（探測環境維護）　決定者：網站擁有者；v227 由 GPT 維護

## 一句話

正式網站 Gate 5B 判斷「市場共識快照是不是在財報揭露之前」時，**只**讀 gate-probe 產生的官方時間界線檔；
v227 其他程式、資料、判定規則一律不動。gate-probe 不寫入正式網站，正式網站也不寫入 gate-probe。

## 讀什麼（v4.36 起只要一個固定網址）

`https://raw.githubusercontent.com/479dvcs8zv-create/gate-probe/main/exports/gate5b/latest.json`
（schema `gate-probe/gate5b-export/v1`；公開 repo，唯讀）

每次蒐證（gate-pipeline-batch／collect）結束後，gate-pipeline-export 會自動：取每檔最新一次的
`gate5b_boundaries.json` → 用保存的官方原始回應離線重算 → **一致（MATCH）才匯出**，否則該檔 `verification`
標 STALE／MISSING、`quarters` 為空。

| 欄位 | 意思 |
|---|---|
| `stocks.<代號>.verification` | 只有 `MATCH` 才能用 |
| `stocks.<代號>.quarters.<季度>.cutoff_at` | 官方最早揭露時間（MOPS 原文：月營收、自結、董事會、法說會、財報申報取最早） |
| `stocks.<代號>.quarters.<季度>.snapshot_boundary_at` | 共識快照必須**嚴格早於**的時間（最早事件是月營收公告時＝公告當日 00:00） |
| `stocks.<代號>.quarters.<季度>.cutoff_document_id` | 依據的公告識別碼，例如 `t05st01:2454:20250410:165554:1` |
| `stocks.<代號>.research_only` | 季末規則算出的界線，**不得**用於 Gate |
| `stocks.<代號>.boundaries_file`／`boundaries_sha256`／`run_id` | 來源檔與雜湊，可回溯到原始證據 |

現成讀取器（直接貼進 v227，任何失敗都回傳 null／None＝沒有界線）：
`gate_pipeline/docs/gate5b_reader.js`（瀏覽器／Node）、`gate_pipeline/docs/gate5b_reader.py`。

## 消費規則（正式網站端必須遵守）

1. 只用 `verification` 為 `MATCH` 的股票、`quarters` 裡的季度（狀態 CUTOFF_VERIFIED）。`research_only`、`excluded` 都不能當界線。
2. 某季不在 `quarters`、檔案取不到、`--check-boundaries` 不是 MATCH → **沒有界線**，該季 Gate 5B 維持現行結果；不能解讀為通過。
3. 快照時間 `<` `snapshot_boundary_at` 才算截止點前（等於也不算）。
4. 不讀 `research.json`、`snapshot_audit.json`（`gate_impact = none`，只是研究紀錄）。
5. Python 預驗證通過不等於正式 Gate PASS；這個檔只提供時間，不提供判定。

## 怎麼複驗（不必相信 gate-probe）

- 同一資料夾有官方原始回應（`responses/`）與每個回應的 SHA-256（`manifest.json`）。
- 離線重算並逐季比對（不連網）：
  `python gate_pipeline/ops/replay_evidence.py results/<代號>/<run id> --reviews gate_pipeline/contract/mops_real/reviews --check-boundaries`
  → `MATCH` 結束碼 0；任何一季不同 → `MISMATCH` 結束碼 1。
- 人工抽查：MOPS 重大訊息查詢該公司該日，核對 `cutoff_document_id` 的發言日期與時間。
- 程式版本：`pipeline_package.sha256` 記錄當次使用的程式包雜湊。

## 驗收建議（GPT 端，約 30 分鐘）

1. 取 2330 與 2454 各一季，對照 MOPS 原文核對 `cutoff_at`。
2. 取一季 `excluded`，確認 v227 對該季的結果與整合前相同。
3. 把檔案裡一個時間改掉，執行上面的 `--check-boundaries`，確認回報 MISMATCH；v227 只採用 MATCH 的檔案。

## 目前覆蓋

- 2330：2023Q1–2026Q3 共 15 季全部有界線；2454：同期 15 季全部有界線
  （2454 的三則 Nomura @CES 於 2026-10-19 依觀測站法說會一覽表的官方附檔確認不是財務結果：附的都是季度結束前已公開的第三季簡報）。
- 實檔：gate-pipeline-batch 以 v4.35 重跑後的 `results/2330/<run id>/gate5b_boundaries.json`、`results/2454/<run id>/…`；
  每一份都可用 `--check-boundaries` 離線重算（v4.31 起的實跑結果皆為 MATCH）。
- 上櫃股票（8299、6485、6488、5347）：清單與詳細頁格式都已用真實回應人工比對；這些公司沒有以重大訊息公告月營收，
  各 15 季只有季末規則的研究用界線（`research_only`），**不在** `quarters`。季末規則是否用於 Gate，需擁有者另行決定。

## 不做的事

不改 v227 的任何判定或資料；不碰正式網站的 repo（含 main）、不開 PR；不用 API key；
外部資料取得失敗一律視為沒有證據；市場共識與官方財測維持分離。

## 撤回

正式網站移除這一個讀取即可，沒有其他相依。
