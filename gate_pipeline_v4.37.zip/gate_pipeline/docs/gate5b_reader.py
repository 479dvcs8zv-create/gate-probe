"""
gate5b_reader.py (gate_pipeline v4.37) — 給正式網站的唯讀讀取器（Python 3.8+，只用標準函式庫）。
只讀 gate-probe 匯出的 Gate5B 時間界線；任何一步失敗都回傳 None（＝沒有界線），由呼叫端維持現行結果。
不能把 None 當成通過；research_only（季末規則）不採用。

    data = load_gate5b_boundaries()
    q = gate5b_quarter(data, "2330", "2026Q3")           # None 或 {cutoff_at, snapshot_boundary_at, ...}
    ok = snapshot_before_boundary("2026-10-01T09:00:00+08:00", q)   # True／False；q 為 None 時回傳 None

v4.37（比照 v228 的檢查）：
  - gate5b_quarter 另外檢查每一季本身一致：時間格式（必須有時區）、界線 ≤ 公告時間 ≤ 現在、
    月營收公告 → 界線＝公告當日台北 00:00；其他事件 → 界線＝公告時間。
  - verify_gate5b_stock：下載 boundaries_file，驗 SHA-256，逐季逐欄與 latest.json 比對；全部一致才回傳該檔的季度。
    這是來源內一致性檢查（防止 latest.json 單獨被改），不是密碼簽章；真正的保證是官方原始回應可離線重算。
"""
import hashlib
import json
import re
import urllib.request
from datetime import datetime, timedelta, timezone

GATE5B_URL = "https://raw.githubusercontent.com/479dvcs8zv-create/gate-probe/main/exports/gate5b/latest.json"
GATE5B_SCHEMA = "gate-probe/gate5b-export/v1"
BOUNDARIES_SCHEMA = "gate-probe/gate5b-boundaries/v1"
TPE = timezone(timedelta(hours=8))
_ISO = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$")
_QUARTER = re.compile(r"^\d{4}Q[1-4]$")


def _read(url, timeout=20):
    if url.startswith(("http://", "https://")):
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.read()
    with open(url, "rb") as f:   # 本機檔案（測試或離線）
        return f.read()


def load_gate5b_boundaries(url=GATE5B_URL, timeout=20):
    try:
        d = json.loads(_read(url, timeout).decode("utf-8"))
    except Exception:
        return None
    return d if isinstance(d, dict) and d.get("schema") == GATE5B_SCHEMA and isinstance(d.get("stocks"), dict) else None


def _ts(value):
    """嚴格 ISO 8601（必須有時區）；不合格回傳 None。"""
    if not isinstance(value, str) or not _ISO.match(value):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def row_consistent(row, now=None):
    """單一季度本身一致：格式、先後順序、界線規則。"""
    if not isinstance(row, dict) or row.get("status") != "CUTOFF_VERIFIED":
        return False
    cutoff, boundary = _ts(row.get("cutoff_at")), _ts(row.get("snapshot_boundary_at"))
    if cutoff is None or boundary is None or not str(row.get("cutoff_document_id") or "").strip():
        return False
    if boundary > cutoff or cutoff > (now or datetime.now(timezone.utc)):
        return False
    if row.get("cutoff_event") == "quarter_revenue_complete":
        day = cutoff.astimezone(TPE).date()
        return row.get("snapshot_boundary_rule") == "revenue_day_midnight" and \
            boundary == datetime(day.year, day.month, day.day, tzinfo=TPE)
    return row.get("snapshot_boundary_rule") == "announced_time" and boundary == cutoff


def gate5b_quarter(data, co_id, quarter, now=None):
    s = ((data or {}).get("stocks") or {}).get(str(co_id))
    if not s or s.get("verification") != "MATCH":
        return None
    q = (s.get("quarters") or {}).get(quarter)
    return q if q and row_consistent(q, now) else None


def verify_gate5b_stock(data, co_id, fetch=None, now=None, base_url=GATE5B_URL):
    """下載該檔的 boundaries_file 並逐欄比對；全部一致回傳 {季度: row}（可能是空 dict），任何不符回傳 None。
    fetch(url) -> bytes 可替換（測試或離線）；預設用 base_url 的同一個 repo 位置。"""
    co = str(co_id)
    s = ((data or {}).get("stocks") or {}).get(co)
    try:
        if not s or s.get("co_id") != co or s.get("verification") != "MATCH":
            return None
        run, path, sha = str(s.get("run_id") or ""), s.get("boundaries_file"), str(s.get("boundaries_sha256") or "")
        quarters = s.get("quarters")
        if not run.isdigit() or path != f"results/{co}/{run}/gate5b_boundaries.json" or \
                not re.fullmatch(r"[0-9a-f]{64}", sha) or not isinstance(quarters, dict):
            return None
        if not quarters:
            return {}
        raw = (fetch or _read)(base_url.replace("exports/gate5b/latest.json", path))
        if hashlib.sha256(raw).hexdigest() != sha:
            return None
        original = json.loads(raw.decode("utf-8"))
        oq = original.get("quarters") or {}
        if original.get("schema") != BOUNDARIES_SCHEMA or original.get("co_id") != co or len(oq) != len(quarters):
            return None
        for quarter, row in quarters.items():
            if not _QUARTER.match(quarter) or oq.get(quarter) != row or not row_consistent(row, now):
                return None
        return dict(quarters)
    except Exception:
        return None


def snapshot_before_boundary(snapshot_iso, q):
    if not q:
        return None
    t, b = _ts(snapshot_iso), _ts(q.get("snapshot_boundary_at") if isinstance(q, dict) else None)
    if t is None or b is None:   # 沒有時區或格式不對的時間不比較
        return None
    return t < b   # 嚴格早於；等於也不算
