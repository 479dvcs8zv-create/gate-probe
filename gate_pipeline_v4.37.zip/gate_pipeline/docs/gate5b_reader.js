/*
 * gate5b_reader.js (gate_pipeline v4.37) — 給正式網站的唯讀讀取器（瀏覽器或 Node 18+ 皆可）。
 * 只讀 gate-probe 匯出的 Gate5B 時間界線；任何一步失敗都回傳 null（＝沒有界線），由呼叫端維持現行結果。
 * 不能把 null 當成通過；research_only（季末規則）不採用。
 *
 *   const data = await loadGate5bBoundaries();
 *   const q = gate5bQuarter(data, "2330", "2026Q3");            // null 或 {cutoff_at, snapshot_boundary_at, ...}
 *   const ok = snapshotBeforeBoundary("2026-10-01T09:00:00+08:00", q);   // true／false；q 為 null 時回傳 null
 *   const rows = await verifyGate5bStock(data, "2330");         // null 或 {季度: row}：來源檔 SHA-256 與逐欄比對都一致
 *
 * v4.37（比照 v228 的檢查）：每一季本身一致（時間格式必須有時區、界線 ≤ 公告時間 ≤ 現在、月營收公告 → 界線＝公告當日
 * 台北 00:00、其他事件 → 界線＝公告時間）；verifyGate5bStock 另外下載 boundaries_file 驗雜湊並逐欄比對。
 * 這是來源內一致性檢查，不是密碼簽章；真正的保證是官方原始回應可離線重算（replay_evidence.py --check-boundaries）。
 */
var GATE5B_URL = "https://raw.githubusercontent.com/479dvcs8zv-create/gate-probe/main/exports/gate5b/latest.json";
var GATE5B_SCHEMA = "gate-probe/gate5b-export/v1";
var GATE5B_BOUNDARIES_SCHEMA = "gate-probe/gate5b-boundaries/v1";
var GATE5B_ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/;

async function loadGate5bBoundaries(url, signal) {
  try {
    var r = await fetch(url || GATE5B_URL, { cache: "no-store", signal: signal });
    if (!r.ok) return null;
    var d = await r.json();
    return d && d.schema === GATE5B_SCHEMA && d.stocks ? d : null;
  } catch (e) {
    return null;
  }
}

function gate5bTimestamp(value) {
  if (typeof value !== "string" || !GATE5B_ISO.test(value)) return NaN;
  var day = value.slice(0, 10), utc = Date.parse(day + "T00:00:00Z");
  if (!Number.isFinite(utc) || new Date(utc).toISOString().slice(0, 10) !== day) return NaN;
  if (Number(value.slice(11, 13)) > 23 || Number(value.slice(14, 16)) > 59 || Number(value.slice(17, 19)) > 59) return NaN;
  return Date.parse(value);
}

function gate5bRowConsistent(row, now) {
  if (!row || row.status !== "CUTOFF_VERIFIED") return false;
  var cutoff = gate5bTimestamp(row.cutoff_at), boundary = gate5bTimestamp(row.snapshot_boundary_at);
  if (!Number.isFinite(cutoff) || !Number.isFinite(boundary) || !String(row.cutoff_document_id || "").trim()) return false;
  if (boundary > cutoff || cutoff > (now == null ? Date.now() : now)) return false;
  if (row.cutoff_event === "quarter_revenue_complete") {
    var day = new Date(cutoff + 8 * 3600000).toISOString().slice(0, 10);
    return row.snapshot_boundary_rule === "revenue_day_midnight" && boundary === Date.parse(day + "T00:00:00+08:00");
  }
  return row.snapshot_boundary_rule === "announced_time" && boundary === cutoff;
}

function gate5bQuarter(data, coId, quarter, now) {
  var s = data && data.stocks && data.stocks[String(coId)];
  if (!s || s.verification !== "MATCH") return null;
  var q = s.quarters && s.quarters[quarter];
  return gate5bRowConsistent(q, now) ? q : null;
}

async function verifyGate5bStock(data, coId, opts) {
  opts = opts || {};
  var co = String(coId), s = data && data.stocks && data.stocks[co];
  try {
    if (!s || s.co_id !== co || s.verification !== "MATCH" || !/^\d+$/.test(s.run_id || "") ||
        s.boundaries_file !== "results/" + co + "/" + s.run_id + "/gate5b_boundaries.json" ||
        !/^[a-f0-9]{64}$/.test(s.boundaries_sha256 || "") || !s.quarters || Array.isArray(s.quarters)) return null;
    var entries = Object.entries(s.quarters);
    if (!entries.length) return {};
    var url = (opts.baseUrl || GATE5B_URL).replace("exports/gate5b/latest.json", s.boundaries_file);
    var r = await (opts.fetchImpl || fetch)(url, { cache: "no-store", signal: opts.signal });
    if (!r.ok) return null;
    var bytes = await r.arrayBuffer();
    var digest = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)))
      .map(function (b) { return b.toString(16).padStart(2, "0"); }).join("");
    if (digest !== s.boundaries_sha256) return null;
    var original = JSON.parse(new TextDecoder().decode(bytes)), oq = original.quarters || {};
    if (original.schema !== GATE5B_BOUNDARIES_SCHEMA || original.co_id !== co || Object.keys(oq).length !== entries.length) return null;
    var out = {};
    for (var i = 0; i < entries.length; i++) {
      var quarter = entries[i][0], row = entries[i][1], src = oq[quarter];
      if (!/^\d{4}Q[1-4]$/.test(quarter) || !src || Object.keys(src).length !== Object.keys(row).length ||
          Object.keys(src).some(function (k) { return src[k] !== row[k]; }) || !gate5bRowConsistent(row, opts.now)) return null;
      out[quarter] = Object.assign({}, row);
    }
    return out;
  } catch (e) {
    return null;
  }
}

function snapshotBeforeBoundary(snapshotIso, q) {
  if (!q) return null;
  var t = gate5bTimestamp(snapshotIso), b = gate5bTimestamp(q.snapshot_boundary_at);
  if (!Number.isFinite(t) || !Number.isFinite(b)) return null;
  return t < b;   // 嚴格早於；等於也不算
}

if (typeof module !== "undefined") {
  module.exports = { loadGate5bBoundaries, gate5bQuarter, gate5bRowConsistent, gate5bTimestamp, verifyGate5bStock,
    snapshotBeforeBoundary, GATE5B_URL, GATE5B_SCHEMA, GATE5B_BOUNDARIES_SCHEMA };
}
