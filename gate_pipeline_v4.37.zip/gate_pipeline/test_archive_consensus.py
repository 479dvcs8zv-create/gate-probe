"""
test_archive_consensus.py (v4.20)
=================================
往後自行存檔（ops/archive_consensus.py）的離線測試：本機模擬 Wayback 的 /save、CDX、id_ 端點。
  - 送出成功 → 由 CDX 確認版本、取回原文、核對 SHA-1 摘要 → ARCHIVED，原文與 SHA-256 存檔
  - 429／403／連線錯誤 → SAVE_FAILED；索引尚未出現 → NOT_IN_INDEX_YET；摘要不符 → DIGEST_MISMATCH
  - 回應標頭沒有時間戳時，只認送出之後的版本（不會拿到更早的舊存檔冒充）
  - 時間上限、沒有 ADR 的股票只送台股網址

  python test_archive_consensus.py
"""
import base64
import hashlib
import http.server
import json
import os
import shutil
import sys
import tempfile
import gzip
import threading
import time
import urllib.parse
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import archive_consensus as ac  # noqa: E402

NOW = datetime(2026, 11, 1, 1, 0, 0, tzinfo=timezone.utc)
TS = "20261101010005"
OLD_TS = "20260101000000"
PAGES = {}       # url -> body（封存後的內容）
INDEX = {}       # url -> [(ts, body)]
MODE = {}        # url -> 'ok' | '429' | '403' | 'noindex' | 'tamper' | 'nohdr'


def _digest(b):
    return base64.b32encode(hashlib.sha1(b).digest()).decode()


class W(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body=b"", headers=None):
        self.send_response(code)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urllib.parse.urlsplit(self.path)
        if u.path.startswith("/save/"):
            url = self.path[len("/save/"):]
            mode = MODE.get(url, "ok")
            if mode in ("429", "403"):
                return self._send(int(mode), b"no")
            if mode == "503once":
                MODE[url] = "ok"
                return self._send(503, b"busy")
            if mode == "slow":                       # 封存站其實存好了，但回應太慢、用戶端逾時
                INDEX.setdefault(url, []).append((TS, PAGES[url]))
                time.sleep(2)
                return self._send(302, b"", {"Location": f"/web/{TS}/{url}"})
            body = PAGES[url]
            if mode != "noindex":
                INDEX.setdefault(url, []).append((TS, body))
            if mode == "nohdr":
                return self._send(200, body, {"Content-Type": "text/html"})
            if mode == "reuse":                      # Wayback 沿用稍早的存檔：回傳舊時間戳，不產生新存檔
                INDEX[url].pop()
                INDEX[url].append((OLD_TS, body))
                return self._send(302, b"", {"Location": f"/web/{OLD_TS}/{url}"})
            return self._send(302, b"", {"Location": f"/web/{TS}/{url}"})
        if u.path == "/cdx/search/cdx":
            q = dict(urllib.parse.parse_qsl(u.query))
            rows = [["timestamp", "original", "statuscode", "digest", "mimetype", "length"]]
            for ts, body in INDEX.get(q["url"], []):
                rows.append([ts, q["url"], "200", _digest(body), "text/html", str(len(body))])
            return self._send(200, json.dumps(rows).encode())
        if u.path.startswith("/web/"):
            ts, url = self.path[len("/web/"):].split("id_/", 1)
            for t, body in INDEX.get(url, []):
                if t == ts:
                    if MODE.get(url) == "tamper":
                        body = body + b"<!-- changed -->"
                    return self._send(200, body, {"Content-Type": "text/html"})
            return self._send(404, b"")
        self._send(400)


def _sources(tmp):
    p = os.path.join(tmp, "s.json")
    json.dump({"adr_map": {"2330": "TSM"}, "sources": [
        {"id": "a", "vendor": "A", "prefix": "x", "archive_url": "https://a.example/{adr}/est"},
        {"id": "b", "vendor": "B", "prefix": "x", "archive_url": "https://b.example/{adr_lower}"},
        {"id": "c", "vendor": "C", "prefix": "x", "archive_url": "https://c.example/{co_id}"},
        {"id": "d", "vendor": "D", "prefix": "x"},
        {"id": "e", "vendor": "E", "prefix": "x", "archive_url": "https://e.example/{co_id}", "only": ["2317"]}]},
        open(p, "w"))
    return p


class _Srv(http.server.ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):   # 模擬逾時：用戶端先斷線，寫回應失敗 → 忽略
        pass


def _run(modes, pages=None, **kw):
    PAGES.clear()
    INDEX.clear()
    MODE.clear()
    for u in ("https://a.example/TSM/est", "https://b.example/tsm", "https://c.example/2330"):
        PAGES[u] = f"<html>{u} EPS estimate</html>".encode()
    PAGES.update(pages or {})
    INDEX["https://b.example/tsm"] = [(OLD_TS, b"<html>old capture</html>")]
    MODE.update(modes)
    srv = _Srv(("127.0.0.1", 0), W)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    tmp = tempfile.mkdtemp(prefix="archive_")
    old = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    try:
        args = dict(base_url=f"http://127.0.0.1:{srv.server_address[1]}", delay=0, timeout=5,
                    sources_path=_sources(tmp), sleep=lambda s: None, now=NOW)
        args.update(kw)
        r = ac.archive("2330", os.path.join(tmp, "out"), **args)
    finally:
        os.environ.update(old)
        srv.shutdown()
    return tmp, r


def _t(r, i):
    return [x for x in r["targets"] if x["id"] == i][0]


def test_archived_and_verified():
    tmp, r = _run({})
    try:
        assert [x["id"] for x in r["targets"]] == ["a", "b", "c"]
        a = _t(r, "a")
        assert a["status"] == "ARCHIVED" and a["capture"]["timestamp"] == TS and a["capture"]["digest_matched"]
        data = open(os.path.join(tmp, "out", a["capture"]["file"]), "rb").read()
        assert data == PAGES["https://a.example/TSM/est"] and hashlib.sha256(data).hexdigest() == a["capture"]["sha256"]
        assert a["capture"]["captured_at_tpe"].startswith("2026-11-01T09:00:05+08:00")
        b = _t(r, "b")
        assert b["status"] == "ARCHIVED" and b["capture"]["timestamp"] == TS     # 不會拿到舊存檔
        saved = json.load(open(os.path.join(tmp, "out", "archive.json"), encoding="utf-8"))
        assert saved["targets"][0]["status"] == "ARCHIVED"
        assert "已封存並核對" in ac.markdown(r)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_failures_are_recorded():
    tmp, r = _run({"https://a.example/TSM/est": "429", "https://b.example/tsm": "noindex",
                   "https://c.example/2330": "tamper"})
    try:
        assert _t(r, "a")["status"] == "SAVE_FAILED" and _t(r, "a")["save"]["http_status"] == 429
        assert _t(r, "b")["status"] == "NOT_IN_INDEX_YET"          # 舊存檔（1 月）不算
        assert _t(r, "c")["status"] == "DIGEST_MISMATCH" and not _t(r, "c")["capture"]["digest_matched"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    tmp, r = _run({"https://a.example/TSM/est": "403"})
    try:
        assert _t(r, "a")["status"] == "SAVE_FAILED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_recent_capture_reused_and_cdx_kept():
    """（v4.27）Save Page Now 只回傳稍早的舊存檔 → RECENT_CAPTURE_REUSED，不當成新存檔、不重送；CDX 原始回應保存。"""
    tmp, r = _run({"https://c.example/2330": "reuse"})
    try:
        c = _t(r, "c")
        assert c["status"] == "RECENT_CAPTURE_REUSED" and c["capture_timestamp_from_headers"] == OLD_TS, c
        assert c["capture"] is None and len(c["save_attempts"]) == 1
        a = _t(r, "a")["save_attempts"][0]
        body = open(os.path.join(tmp, "out", a["cdx_file"]), "rb").read()
        assert hashlib.sha256(body).hexdigest() == a["cdx_sha256"] and TS.encode() in body
        assert "沿用稍早的存檔" in ac.markdown(r)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_no_timestamp_header_only_accepts_new_capture():
    tmp, r = _run({"https://b.example/tsm": "nohdr"})
    try:
        b = _t(r, "b")
        assert b["status"] == "ARCHIVED" and b["capture"]["timestamp"] == TS, b
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_timeout_but_saved_and_retry_after_503():
    tmp, r = _run({"https://a.example/TSM/est": "slow", "https://b.example/tsm": "503once"}, timeout=1)
    try:
        a = _t(r, "a")
        assert a["status"] == "ARCHIVED" and a["save_attempts"][0]["error"], a      # 逾時但索引裡已有 → 照樣取回核對
        assert len(a["save_attempts"]) == 1 and a["save_attempts"][0]["found_in_index"] == TS
        b = _t(r, "b")
        assert b["status"] == "ARCHIVED" and [x["http_status"] for x in b["save_attempts"]] == [503, 302], b
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_gzip_payload_is_kept_raw_and_decoded_for_parsing():
    html = b"<html>Revenue Estimate Current Qtr. (Dec 2026) No. of Analysts 27 Avg. Estimate 1.71T</html>"
    gz = gzip.compress(html)
    tmp, r = _run({}, pages={"https://c.example/2330": gz})
    try:
        c = _t(r, "c")["capture"]
        raw = open(os.path.join(tmp, "out", c["file"]), "rb").read()
        assert raw == gz and c["digest_matched"] and c["payload_compression"] == "gzip"   # 存原始位元組、摘要對原始位元組
        assert ac.decode_payload(raw) == html and c["decoded_sha256"] == hashlib.sha256(html).hexdigest()
        assert ac.decode_payload(b"plain") == b"plain" and "payload_compression" not in _t(r, "a")["capture"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_time_budget_and_targets_without_adr():
    ticks = iter(range(0, 1000, 100))
    tmp, r = _run({}, time_budget=150, clock=lambda: next(ticks))
    try:
        assert [x["status"] for x in r["targets"]].count("TIMEOUT") >= 1 and r["notes"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    tmp = tempfile.mkdtemp()
    try:
        t, adr = ac.archive_targets("2317", _sources(tmp))
        assert adr is None and [x["id"] for x in t] == ["c", "e"] and t[0]["url"] == "https://c.example/2317"
        real, adr = ac.archive_targets("2330")
        assert adr == "TSM" and {x["id"] for x in real} >= {"stockanalysis_adr_forecast", "marketbeat_adr_earnings"}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_service_down_stops_early():
    """（v4.32，依 run 39207359000 的實況：Wayback 回 520、交握逾時、連線被拒）連續 2 個網站在封存服務端完全失敗
    → 其餘網站不送（SKIPPED_SERVICE_DOWN），不把時間上限耗完；網站本身的錯誤（例如 404）不算服務掛掉。"""
    import socket
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()   # 這個埠沒有人在聽 → 連線被拒
    tmp = tempfile.mkdtemp(prefix="archive_down_")
    old = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    try:
        r = ac.archive("2330", os.path.join(tmp, "out"), base_url=f"http://127.0.0.1:{port}", delay=0, timeout=2,
                       sources_path=_sources(tmp), sleep=lambda s: None, now=NOW)
        st = [x["status"] for x in r["targets"]]
        assert st == ["SAVE_FAILED", "SAVE_FAILED", "SKIPPED_SERVICE_DOWN"], st
        assert r["service_down"] is True and any("封存服務暫時無法使用" in n for n in r["notes"])
        assert all(len(x["save_attempts"]) == 2 for x in r["targets"][:2])   # 每個網站仍照常重試一次
        assert "封存服務暫停" in ac.markdown(r)
    finally:
        os.environ.update(old)
        shutil.rmtree(tmp, ignore_errors=True)
    assert not ac._service_failure({"save_attempts": [{"http_status": 404, "error": None, "cdx_error": "x"}]})
    assert not ac._service_failure({"save_attempts": [{"http_status": None, "error": "refused"}]})   # 索引查得到
    assert ac._service_failure({"save_attempts": [{"http_status": 520, "error": None, "cdx_error": "refused"},
                                                  {"http_status": None, "error": "refused", "cdx_error": "refused"}]})


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
