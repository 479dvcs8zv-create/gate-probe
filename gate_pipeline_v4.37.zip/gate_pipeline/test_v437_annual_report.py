"""
test_v437_annual_report.py (v4.37)
==================================
年報探測（ops/annual_report_probe.py）的離線測試：沒有真實樣本前，只測檔名／連結擷取與「只連官方網域」。
送出的請求與回應全部由探測保存，格式確認後才會寫正式解析器。

  python test_v437_annual_report.py
"""
import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import annual_report_probe as arp  # noqa: E402
import conference_probe as cp  # noqa: E402


def test_names_and_links():
    t = ("<a href='#' onclick=\"readfile2('F','8299','2025_8299_20260528F04.pdf');\">2025_8299_20260528F04.pdf</a>"
         " 2025_8299_20260528F01.pdf 2025_2330_20260528F04.pdf")
    assert arp.pdf_names(t, "8299") == ["2025_8299_20260528F04.pdf", "2025_8299_20260528F01.pdf"]
    assert arp.download_links("<a href='/pdf/2025_8299_20260528F04_20261019213045.pdf'>x</a>") == \
        ["/pdf/2025_8299_20260528F04_20261019213045.pdf"]
    assert arp.download_links('<A HREF="/pdf/a.pdf">') == ["/pdf/a.pdf"]


def test_listing_urls_and_official_only():
    urls = [u for _, u in arp.listing_variants("8299", "114")]
    assert all(u.startswith("https://doc.twse.com.tw/server-java/t57sb01?step=1&colorchg=1&co_id=8299&year=114")
               and "mtype=F" in u for u in urls)
    with tempfile.TemporaryDirectory() as d:
        assert cp.get_file("https://example.com/x.pdf", d)["error"] == "拒絕：不是官方網域"


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
