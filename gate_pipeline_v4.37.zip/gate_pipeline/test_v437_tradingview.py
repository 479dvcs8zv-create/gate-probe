"""
test_v437_tradingview.py (v4.37)
================================
TradingView 台灣版「實際數據與預估值」頁解析（真實存檔 2026-10-19：2454 TWSE、8299 TPEX；
固定測試資料在 contract/mops_real/tradingview_20261019/）。

  - 報價代號取自頁面標題「(TWSE:2454)」「(TPEX:8299)」→ 2454.TW、8299.TWO；與市場別不符 → SYMBOL_MISMATCH
  - 「下一季度」是哪一季：頁面沒寫，用「下一份收益報告」日期之前最後一個季末推定（2454：2026-10-23 → 2026Q3）；
    期間標籤保留日期，審查時可從標籤重新推導；沒有日期 → 不推定（PERIOD_UNMAPPED）
  - 頁面寫的「上一季」實際 EPS 記為事後說法；2454 上一季 15.28＝官方 2026Q2 每股盈餘（t05st01:2454:20260731:184305:1）
  - 沒寫分析師人數與口徑 → None（規則 2：口徑待確認）

  python test_v437_tradingview.py
"""
import os
import sys
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import consensus_parsers as cp  # noqa: E402

FIX = os.path.join(HERE, "contract", "mops_real", "tradingview_20261019")
RAW = {co: open(os.path.join(FIX, f), "rb").read() for co, f in
       (("2454", "2454_20261019092426.bin"), ("8299", "8299_20261019093347.bin"))}
TYPEK = {"2454": "sii", "8299": "otc"}


def _parse(co, typek=None):
    return cp.parse_capture("tradingview_tw_forecast", RAW[co], co, None, typek=typek or TYPEK[co])


def test_real_pages():
    exp = {"2454": ("2454.TW", "2026-10-23", 15.65, 159.42e9, 15.28, 14.40),
           "8299": ("8299.TWO", "2026-11-06", 127.57, 86.39e9, 118.57, 97.43)}
    for co, (quote, nxt, eps, rev, last_act, last_est) in exp.items():
        r = _parse(co)
        assert r["status"] == "PARSED" and r["page"]["quote"] == quote and r["page"]["next_report_date"] == nxt, r
        e = {x["metric"]: x for x in r["estimates"]}
        assert set(e) == {"eps", "revenue"}
        for x in e.values():
            assert x["fiscal_period"] == "2026Q3" and x["period_end"] == "2026-09-30" and x["currency"] == "TWD"
            assert x["currency_from"] == "page" and x["quote"] == quote and x["basis"] is None and x["n_analysts"] is None
            assert "PERIOD_FROM_NEXT_REPORT_DATE" in x["flags"]
            assert cp.label_to_period(x["period_label_raw"], "quarter") == "2026Q3"   # 審查時可重新推導
        assert e["eps"]["avg"] == eps and abs(e["revenue"]["avg"] - rev) < 1
        (rt,) = r["retrospective"]
        assert rt["fiscal_period"] == "2026Q2" and rt["eps_actual"] == last_act and rt["eps_estimate"] == last_est


def test_symbol_must_match_market():
    assert _parse("2454", "otc")["status"] == "SYMBOL_MISMATCH"   # 預期 2454.TWO，頁面是 TWSE
    assert _parse("8299", "sii")["status"] == "SYMBOL_MISMATCH"
    r = cp.parse_capture("tradingview_tw_forecast", RAW["2454"], "2330", None, typek="sii")
    assert r["status"] == "SYMBOL_MISMATCH"


def test_period_rules():
    qb = cp._quarter_before
    assert qb(date(2026, 10, 23)) == ("2026Q3", "2026-09-30")
    assert qb(date(2026, 10, 1)) == ("2026Q3", "2026-09-30")
    assert qb(date(2026, 9, 30)) == ("2026Q2", "2026-06-30")       # 季末當天不算之前
    assert qb(date(2027, 1, 20)) == ("2026Q4", "2026-12-31")
    assert qb(date(2026, 3, 1)) == ("2025Q4", "2025-12-31")
    assert cp.label_to_period("下一季度（頁面沒寫下一份收益報告日期）", "quarter") is None


def test_no_date_no_guess_and_no_sentence():
    body = cp.decode(RAW["2454"]).decode("utf-8").replace("發佈下一份收益報告", "發佈報告")
    r = cp.parse_capture("tradingview_tw_forecast", body.encode("utf-8"), "2454", None, typek="sii")
    assert r["status"] == "PARSED" and all(x["fiscal_period"] is None and "PERIOD_UNMAPPED" in x["flags"]
                                           for x in r["estimates"]) and r["retrospective"] == []
    body2 = body.replace("下一季度的預期收益", "X").replace("下個季度的營收預計", "Y")
    r2 = cp.parse_capture("tradingview_tw_forecast", body2.encode("utf-8"), "2454", None, typek="sii")
    assert r2["status"] == "NO_CONSENSUS_VALUE"


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
