"""
test_v434.py (v4.34)
====================
  1. 觀察清單存檔（archive_watchlist）：清單格式、逐檔處理、封存服務掛掉後其餘股票不送
  2. 法說會簡報探測（conference_probe）：本機模擬官方網站，回應中的 .pdf 檔名與依日期推測的檔名都會下載
  3. 兩則人工審查紀錄（2330 2023Q3 公司債、2454 2023Q2 子公司股利）載入
  4. 官方財測模式：同一季多則結果公告數字完全相同（例：「內文更新」）才合併；數字不同仍不採用
  5. TradingView 網址代稱 {tv_symbol}

  python test_v434.py
"""
import dataclasses
import http.server
import json
import os
import shutil
import sys
import tempfile
import threading
from datetime import timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import announcement_probe as ap  # noqa: E402
import archive_watchlist as aw  # noqa: E402
import collect_evidence as ce  # noqa: E402
import conference_probe as cp  # noqa: E402
import guidance_mops as gm  # noqa: E402
import market_info as mi  # noqa: E402
import test_guidance_mops as tg  # noqa: E402


def test_watchlist_parse():
    tmp = tempfile.mkdtemp()
    try:
        p = os.path.join(tmp, "w.txt")
        open(p, "w", encoding="utf-8").write("# 觀察清單\n2330\n8299  # 群聯\n\n2330\nabc\n12\n6488\n")
        codes, bad = aw.read_watchlist(p)
        assert codes == ["2330", "8299", "6488"] and len(bad) == 2, (codes, bad)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_watchlist_run_stops_sending_when_service_down():
    calls = []

    def fake_archive(co, out, base, delay, time_budget):
        calls.append(("archive", co, time_budget))
        os.makedirs(out, exist_ok=True)
        down = co == "8299"
        return {"co_id": co, "started_at": "2026-10-19T00:00:00", "targets": [
            {"id": "x", "vendor": "X", "url": "u", "status": "SAVE_FAILED" if down else "ARCHIVED",
             "capture": None if down else {"captured_at_tpe": "2026-10-19T08:00:00+08:00", "length": 1}}],
            "notes": [], "service_down": down, "typek": "otc"}

    def fake_research(co, out, base, budget, delay=3.0):
        calls.append(("research", co, budget))
        return f"research {co}"

    tmp = tempfile.mkdtemp()
    try:
        rows, md = aw.run(["2330", "8299", "6488"], tmp, 77, archive=fake_archive, research=fake_research,
                          spn_budget=300, backfill_budget=240)
        assert [r["status"] for r in rows] == ["DONE", "DONE", "SKIPPED_SERVICE_DOWN"]
        assert ("archive", "6488", 300) not in calls                     # 掛掉之後不再送存檔
        assert ("research", "2330", 240) in calls and ("research", "6488", 0) in calls   # 之後只重算、不補齊
        assert os.path.isdir(os.path.join(tmp, "6488", "archive", "77")) and "封存服務暫停" in md
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


LIST_HTML = ("<html><table><tr><td>2454</td><td>聯發科</td><td>113/01/08</td>"
             "<td><a href='/nas/STR/245420240108M001.pdf'>245420240108M001.pdf</a></td>"
             "<td><a href='/nas/STR/233020240118M001.pdf'>別家</a></td></tr></table></html>").encode("utf-8")
FILES = {"/nas/STR/245420240108M001.pdf": b"%PDF-1.4 fake slides 2024",
         "/nas/STR/245420250106E001.pdf": b"%PDF-1.4 fake slides 2025 en"}
SEEN = []


class Stub(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        body = self.rfile.read(int(self.headers["Content-Length"])).decode()
        SEEN.append(("POST", self.path, body))
        self._send(200, LIST_HTML, "text/html; charset=UTF-8")

    def do_GET(self):
        SEEN.append(("GET", self.path, None))
        if self.path in FILES:
            return self._send(200, FILES[self.path], "application/pdf")
        if self.path == "/mops/web/t100sb02_1":
            return self._send(200, b"<html>form</html>", "text/html")
        self._send(404, b"not found", "text/plain")


def test_conference_probe_offline():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Stub)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    old_ap, old_cp = ap.OFFICIAL_SUFFIXES, cp.OFFICIAL_SUFFIXES
    ap.OFFICIAL_SUFFIXES = cp.OFFICIAL_SUFFIXES = ("127.0.0.1",)   # 只在這個測試內把本機當成官方網域
    old_proxy = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    tmp = tempfile.mkdtemp()
    try:
        SEEN.clear()
        r = cp.probe("2454", ["113"], ["20240108", "20250106"], tmp, base=f"http://127.0.0.1:{srv.server_address[1]}",
                     delay=0, timeout=5, sleep=lambda s: None)
        assert all(q["pdf_names"] == ["245420240108M001.pdf"] for q in r["queries"])   # 別家的檔案不收
        got = {f["url"].rsplit("/", 1)[-1]: f for f in r["files"]}
        assert got["245420240108M001.pdf"]["is_pdf"] and got["245420240108M001.pdf"]["source"] == "listed_in_response"
        assert got["245420250106E001.pdf"]["is_pdf"] and got["245420250106E001.pdf"]["source"] == "guessed_from_announcement_date"
        assert got["245420250106M001.pdf"]["status"] == 404 and not got["245420250106M001.pdf"].get("saved_as")
        assert len([f for f in r["files"] if f.get("is_pdf")]) == 2 and os.path.exists(os.path.join(tmp, "probe.json"))
        saved = open(os.path.join(tmp, got["245420240108M001.pdf"]["saved_as"]), "rb").read()
        assert saved == FILES["/nas/STR/245420240108M001.pdf"]
        assert "下載到 2 份 PDF" in cp.markdown(r)
        rec = cp.get_file("https://example.com/x.pdf", tmp)
        assert rec["error"].startswith("拒絕")
    finally:
        ap.OFFICIAL_SUFFIXES, cp.OFFICIAL_SUFFIXES = old_ap, old_cp
        os.environ.update(old_proxy)
        srv.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)


def test_new_review_records_loaded():
    rv = ce.load_reviews(os.path.join(HERE, "contract", "mops_real", "reviews"))
    a = {r["document_id"] for r in rv[("2330", "2023Q3")]["reviewed_non_results"]}
    b = {r["document_id"] for r in rv[("2454", "2023Q2")]["reviewed_non_results"]}
    assert a == {"t05st01:2330:20231003:163322:2"} and b == {"t05st01:2454:20230707:170219:1"}
    pol = json.load(open(os.path.join(HERE, "contract", "mops_real", "reviews", "revenue_quarter_end_policy.json"),
                         encoding="utf-8"))
    assert "每月十日以前" in pol["legal_basis"][0]["quote"]


def test_identical_duplicate_results_are_merged():
    g0 = gm.evaluate_guidance(tg.ITEMS, tg.DETAILS, tg.CUT)
    filled = tg._filled(tg.DETAILS, g0)   # 合成：補上財測期間缺的原文（同 test_guidance_mops）
    base = gm.evaluate_guidance(tg.ITEMS, filled, tg.CUT)
    q = next(q for q, e in sorted(base["quarters"].items()) if e["status"] == "VERIFIED")
    a = [it for it in tg.ITEMS if it.document_id == base["quarters"][q]["actual"]["document_id"]][0]
    dup_id = a.document_id.rsplit(":", 1)[0] + ":9"
    dup = dataclasses.replace(a, document_id=dup_id, announced_at=a.announced_at + timedelta(hours=1),
                              subject=a.subject + "(內文更新)", seq_no=9)
    details = dict(filled)
    details[dup_id] = dataclasses.replace(filled[a.document_id], document_id=dup_id)
    g = gm.evaluate_guidance(tg.ITEMS + [dup], details, tg.CUT)
    e = g["quarters"][q]
    assert e["status"] == "VERIFIED" and e["actual"]["document_id"] == a.document_id, e
    assert any("數字完全相同" in n for n in e["notes"])
    d = filled[a.document_id]
    eps = str(base["quarters"][q]["actual"]["eps_twd"])
    assert eps in d.description
    details[dup_id] = dataclasses.replace(d, document_id=dup_id, description=d.description.replace(eps, "99.99", 1))
    g = gm.evaluate_guidance(tg.ITEMS + [dup], details, tg.CUT)
    assert g["quarters"][q]["status"] in ("MULTIPLE_ACTUALS",), g["quarters"][q]["status"]


def test_ces_decision_is_reverifiable_from_official_files():
    """（真實資料：conference probe run 39227119449）法人說明會一覽表中三場 Nomura @CES 的「簡報內容」欄
    指向季度結束前就公開的第三季法說會簡報；審查紀錄記錄的檔名與 SHA-256 必須能由保存的官方原文重算出來。"""
    import hashlib
    base = os.path.join(HERE, "contract", "mops_real", "conference_2454_39227119449")
    r = json.load(open(os.path.join(base, "probe.json"), encoding="utf-8"))
    rv = ce.load_reviews(os.path.join(HERE, "contract", "mops_real", "reviews"))
    files = {f["url"].rsplit("/", 1)[-1]: f for f in r["files"]}
    want = {"113": ("113/01/08", "245420231027M001.pdf", "2023Q4"), "114": ("114/01/06 至 114/01/07", "245420241030M001.pdf", "2024Q4"),
            "115": ("115/01/05 至 115/01/06", "245420251031M001.pdf", "2025Q4")}
    for q in r["queries"]:
        if q["label"] != "step1_co" or q["roc_year"] not in want:
            continue
        raw = open(os.path.join(base, q["saved_as"]), "rb").read()
        assert hashlib.sha256(raw).hexdigest() == q["body_sha256"]
        ces = [x for x in cp.conference_rows(raw.decode("utf-8"), "2454") if "Nomura @CES" in x["summary"]]
        day, deck, fq = want[q["roc_year"]]
        assert len(ces) == 1 and ces[0]["date"] == day and ces[0]["slides_zh"] == deck, ces
        pdf = open(os.path.join(base, files[deck]["saved_as"]), "rb").read()
        sha = hashlib.sha256(pdf).hexdigest()
        assert pdf[:5] == b"%PDF-" and sha == files[deck]["sha256"]
        rec = [x for x in rv[("2454", fq)]["reviewed_non_results"] if x.get("official_slides")]
        assert len(rec) == 1 and rec[0]["official_slides"]["file"] == deck and rec[0]["official_slides"]["sha256"] == sha
        assert q["body_sha256"] in rec[0]["official_slides"]["listing"]
        # 簡報日期（檔名中的 YYYYMMDD）早於該季結束：附的是已公開的舊簡報
        y, n = int(fq[:4]), int(fq[-1])
        assert deck[4:12] < f"{y}{3 * n:02d}31"
    g = rv["__guidance_reviews__"][("2330", "2023Q3")]
    assert g == {"t05st01:2330:20230821:124038:1"}


def test_tradingview_symbol():
    assert mi.fill("https://tw.tradingview.com/symbols/{tv_symbol}/", "8299", None, "otc")[0] == \
        "https://tw.tradingview.com/symbols/TPEX-8299/"
    assert mi.fill("{tv_symbol}", "8299", None, None)[0] is None


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
