"""
ops/replay_evidence.py (v4.31)
==============================
離線重算某次一鍵蒐證的結果：只讀 <結果資料夾>/manifest.json 與 responses/，用正式解析器重新解析、
比對每個回應的 SHA-256，再套用目前的人工審查紀錄與條款規則計算各季截止點。不連任何網站。

  python gate_pipeline/ops/replay_evidence.py results/2330/39103606949 --reviews gate_pipeline/contract/mops_real/reviews

用途：新增人工審查紀錄後重新評估、或由第三方獨立複驗同一份證據。輸出 JSON 到標準輸出（--out 可另存）。
v4.31：--check-boundaries 比對資料夾裡給正式網站讀的 gate5b_boundaries.json（不一致 → 結束碼 1）。
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))

import collect_evidence as ce  # noqa: E402


def compare_boundaries(run_dir, replayed):
    """（v4.36）回傳 ("MATCH"／"MISMATCH"／"MISSING", 差異清單)。"""
    path = os.path.join(run_dir, "gate5b_boundaries.json")
    if not os.path.exists(path):
        return "MISSING", [f"{path} 不存在（v4.31 之前的蒐證沒有這個檔）"]
    held = json.load(open(path, encoding="utf-8"))
    man = json.load(open(os.path.join(run_dir, "manifest.json"), encoding="utf-8"))
    again = ce.gate5b_boundaries(replayed, man)
    diff = []
    for part in ("quarters", "research_only"):
        for q in sorted(set(held.get(part, {})) | set(again.get(part, {}))):
            if held.get(part, {}).get(q) != again.get(part, {}).get(q):
                diff.append(f"{part}.{q}：檔案 {held.get(part, {}).get(q)}；重算 {again.get(part, {}).get(q)}")
    if sorted(held.get("excluded", {})) != sorted(again.get("excluded", {})):
        diff.append(f"excluded 季度不同：檔案 {sorted(held.get('excluded', {}))}；重算 {sorted(again.get('excluded', {}))}")
    for k in ("co_id", "revenue_rule"):
        if held.get(k) != again.get(k):
            diff.append(f"{k}：檔案 {held.get(k)}；重算 {again.get(k)}")
    return ("MISMATCH" if diff else "MATCH"), diff


def check_boundaries(run_dir, replayed):
    """gate5b_boundaries.json 與離線重算比對。審查紀錄在蒐證之後有新增時，差異可能是合理的（訊息會提醒）。"""
    status, diff = compare_boundaries(run_dir, replayed)
    if status == "MISSING":
        print(f"MISSING：{diff[0]}")
        return 1
    if status == "MISMATCH":
        print("MISMATCH（若蒐證之後新增過人工審查紀錄，差異可能來自新紀錄；否則檔案可能被改過）")
        print("\n".join(f"- {d}" for d in diff))
        return 1
    held = json.load(open(os.path.join(run_dir, "gate5b_boundaries.json"), encoding="utf-8"))
    print(f"MATCH：{len(held.get('quarters', {}))} 季時間界線與官方原始回應重算結果相同")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description="離線重算一鍵蒐證結果")
    p.add_argument("run_dir")
    p.add_argument("--reviews", default=None)
    p.add_argument("--out", default=None)
    p.add_argument("--check-boundaries", action="store_true",
                   help="（v4.31）用原始回應重算時間界線，與資料夾裡的 gate5b_boundaries.json 逐季比對；不一致時結束碼 1")
    a = p.parse_args(argv)
    s = ce.replay(a.run_dir, ce.load_reviews(a.reviews))
    if a.check_boundaries:
        return check_boundaries(a.run_dir, s)
    text = json.dumps(s, ensure_ascii=False, indent=2)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(text)
    for q, v in sorted(s["quarters"].items()):
        e = v["earliest"] or {}
        pending = [r["document_id"] for r in v["review_window"] if r["cleared_by"] is None]
        print(f"{q}  {v['status']:<16} {e.get('at', '')}  待人工確認 {len(pending)} 則", file=sys.stderr)
    if not a.out:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
