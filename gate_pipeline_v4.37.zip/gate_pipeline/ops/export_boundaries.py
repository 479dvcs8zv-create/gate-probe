"""
export_boundaries.py (v4.36)
============================
給正式網站讀的單一入口：exports/gate5b/latest.json（以及每檔一份 exports/gate5b/<代號>.json）。

每一檔取 results/<代號>/ 底下 run id 最大、而且有 gate5b_boundaries.json 的那次蒐證，先用保存的官方原始回應
離線重算（replay_evidence.compare_boundaries），結果一致（MATCH）才匯出它的時間界線；不一致或缺檔就匯出
verification = "STALE"／"MISSING" 而且 quarters 為空──沒有界線，正式網站要維持現行結果，不能當成通過。

正式網站只需要一個固定網址（公開 repo，唯讀）：
  https://raw.githubusercontent.com/479dvcs8zv-create/gate-probe/main/exports/gate5b/latest.json

  python gate_pipeline/ops/export_boundaries.py --results results --reviews gate_pipeline/contract/mops_real/reviews \
      --out exports/gate5b
"""

import argparse
import glob
import hashlib
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import replay_evidence as rv  # noqa: E402

EXPORT_SCHEMA = "gate-probe/gate5b-export/v1"
EXPORT_VERSION = "4.36-export"
RAW_URL = "https://raw.githubusercontent.com/479dvcs8zv-create/gate-probe/main/exports/gate5b/latest.json"
USE = ("只提供 Gate5B 的時間界線。quarters 裡每一季：cutoff_at＝官方最早揭露時間；snapshot_boundary_at＝市場共識快照"
       "必須「嚴格早於」的時間。只採用 verification＝MATCH 的股票；某季不在 quarters、檔案取不到、或 verification 不是 "
       "MATCH → 沒有界線，維持現行結果，不能當成通過。research_only（季末規則）不得用於 Gate。"
       "Python 預驗證通過不等於正式 Gate PASS。")


def latest_run(company_root):
    best = None
    for p in glob.glob(os.path.join(company_root, "*", "gate5b_boundaries.json")):
        run = os.path.basename(os.path.dirname(p))
        if run.isdigit() and (best is None or int(run) > int(best)):
            best = run
    return best


def export_one(co_id, company_root, reviews):
    run = latest_run(company_root)
    if run is None:
        return {"co_id": co_id, "verification": "MISSING", "reason": "沒有 gate5b_boundaries.json（需用 v4.31 以後的程式蒐證）",
                "quarters": {}, "research_only": {}}
    run_dir = os.path.join(company_root, run)
    path = os.path.join(run_dir, "gate5b_boundaries.json")
    raw = open(path, "rb").read()
    held = json.loads(raw.decode("utf-8"))
    pkg = os.path.join(run_dir, "pipeline_package.sha256")
    base = {"co_id": co_id, "company_name": held.get("company_name"), "market": (held.get("market") or {}).get("name"),
            "run_id": run, "collector_version": held.get("collector_version"), "collected_at": held.get("collected_at"),
            "revenue_rule": held.get("revenue_rule"),
            "boundaries_file": f"results/{co_id}/{run}/gate5b_boundaries.json",
            "boundaries_sha256": hashlib.sha256(raw).hexdigest(),
            "pipeline_package": open(pkg, encoding="utf-8").read().split()[0] if os.path.exists(pkg) else None}
    try:
        status, diff = rv.compare_boundaries(run_dir, ce.replay(run_dir, reviews))
    except Exception as e:   # 重算失敗＝沒有證據
        status, diff = "ERROR", [f"{type(e).__name__}: {e}"]
    if status != "MATCH":
        return dict(base, verification="STALE" if status == "MISMATCH" else status,
                    reason="官方原始回應重算結果與檔案不一致（通常是蒐證後新增了人工審查紀錄，重跑一次蒐證即可）",
                    differences=diff[:20], quarters={}, research_only={})
    return dict(base, verification="MATCH", quarters=held.get("quarters", {}),
                research_only=held.get("research_only", {}), excluded=sorted(held.get("excluded", {})))


def export(results_root, reviews, out_dir, now=None):
    stocks = {}
    for d in sorted(glob.glob(os.path.join(results_root, "*"))):
        co = os.path.basename(d)
        if co.isdigit() and os.path.isdir(d):
            stocks[co] = export_one(co, d, reviews)
    doc = {"schema": EXPORT_SCHEMA, "export_version": EXPORT_VERSION,
           "generated_at": (now or datetime.now(timezone.utc)).isoformat(), "url": RAW_URL, "use": USE,
           "summary": {co: {"verification": s["verification"], "verified_quarters": len(s["quarters"]),
                            "research_only_quarters": len(s["research_only"])} for co, s in stocks.items()},
           "stocks": stocks}
    os.makedirs(out_dir, exist_ok=True)
    prev = os.path.join(out_dir, "latest.json")
    try:   # 內容沒變就沿用上次的 generated_at，避免每次都產生沒有意義的提交
        old = json.load(open(prev, encoding="utf-8"))
        if {k: v for k, v in old.items() if k != "generated_at"} == {k: v for k, v in doc.items() if k != "generated_at"}:
            doc["generated_at"] = old["generated_at"]
    except (OSError, ValueError, KeyError):
        pass
    for co, s in stocks.items():
        with open(os.path.join(out_dir, f"{co}.json"), "w", encoding="utf-8") as f:
            json.dump(dict(s, schema=EXPORT_SCHEMA, use=USE), f, ensure_ascii=False, indent=2)
    with open(os.path.join(out_dir, "latest.json"), "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
    return doc


def markdown(doc):
    lines = ["## 給正式網站的時間界線（exports/gate5b/latest.json）", "",
             "| 代號 | 名稱 | 市場 | 重算核對 | 可用季數 | 研究用（季末規則） | 來源 run |", "|---|---|---|---|---|---|---|"]
    for co, s in doc["stocks"].items():
        lines.append(f"| {co} | {s.get('company_name') or '—'} | {s.get('market') or '—'} | {s['verification']} | "
                     f"{len(s['quarters'])} | {len(s['research_only'])} | {s.get('run_id') or '—'} |")
    lines += ["", f"網址：{doc['url']}", "", doc["use"]]
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description="匯出給正式網站讀的 Gate5B 時間界線（重算一致才匯出）")
    p.add_argument("--results", default="results")
    p.add_argument("--reviews", required=True)
    p.add_argument("--out", default="exports/gate5b")
    a = p.parse_args(argv)
    doc = export(a.results, ce.load_reviews(a.reviews), a.out)
    text = markdown(doc)
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
