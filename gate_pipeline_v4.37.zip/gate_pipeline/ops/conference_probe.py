"""
conference_probe.py (v4.34)
===========================
探測：公開資訊觀測站「法人說明會一覽表」（t100sb02_1）與法說會簡報檔。
起因：2454 的 Nomura @CES 2024／2025／2026 三則重大訊息寫「簡報資料請參閱公開資訊觀測站」，
使用者 2026-10-19 決定先抓簡報內容來看，再決定這三季（2023Q4、2024Q4、2025Q4）的待確認公告。

這是探測，不是解析器：查詢格式還沒有真實樣本，所以同時試幾種送法，原始回應全部保存（含 SHA-256），
從回應中找出 .pdf 連結再下載；另外依重訊寫的法說會日期試官方檔名樣式 /nas/STR/<代號><日期>M001.pdf（中文）、
E001（英文）。下載到的簡報只供人工判讀，不會自動放行任何季度。只連官方網域（twse.com.tw、tpex.org.tw）。

  python gate_pipeline/ops/conference_probe.py --co-id 2454 --roc-years 112,113,114,115 \
      --dates 20240108,20250106,20250107,20260105,20260106 --out results/2454/conference/123
"""

import argparse
import hashlib
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import announcement_probe as ap  # noqa: E402

PROBE_VERSION = "4.34-conference-probe"
OFFICIAL_SUFFIXES = ("twse.com.tw", "tpex.org.tw")
MAX_PDF_BYTES = 60 * 1024 * 1024
USER_AGENT = "gate-pipeline-conference-probe/4.34 (+https://github.com/479dvcs8zv-create/gate-probe)"
_PDF = re.compile(r"""(?:/nas/STR/|STR/)?[A-Za-z0-9_.\-]+\.pdf""", re.I)


def _official(url):
    host = urllib.parse.urlsplit(url).hostname or ""
    return any(host == s or host.endswith("." + s) for s in OFFICIAL_SUFFIXES)


def query_variants(co_id, roc_year):
    """法人說明會一覽表的幾種送法（沒有真實樣本前都試，全部保存）。"""
    return [
        ("step1_co", f"encodeURIComponent=1&step=1&firstin=1&off=1&TYPEK=all&year={roc_year}&co_id={co_id}"),
        ("step1_co_month", f"encodeURIComponent=1&step=1&firstin=1&off=1&queryName=co_id&inpuType=co_id"
                           f"&TYPEK=all&co_id={co_id}&year={roc_year}&month=all"),
    ]


def pdf_names(text, co_id):
    """回應中提到的 .pdf 檔名（只收檔名以該公司代號開頭的，避免抓到別家或頁面樣板的檔案）。"""
    out = []
    for m in _PDF.finditer(text):
        name = m.group(0).split("/")[-1]
        if name.startswith(co_id) and name not in out:
            out.append(name)
    return out


_ROW = re.compile(r"<tr[^>]*>(.*?)</tr>", re.S | re.I)
_TD = re.compile(r"<td[^>]*>(.*?)</td>", re.S | re.I)


def _cell(x):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", x).replace("&nbsp;", " ")).strip()


def conference_rows(text, co_id):
    """（v4.34，依 2454 民國 112–115 年真實回應）法人說明會一覽表的資料列：
    [{date, time, place, summary, slides_zh, slides_en}]。只收第一欄等於公司代號的列；簡報欄取 .pdf 檔名。
    欄位順序：公司代號｜公司名稱｜日期｜時間｜地點｜擇要訊息｜中文檔案｜英文檔案｜…"""
    out = []
    for row in _ROW.findall(text):
        tds = _TD.findall(row)
        if len(tds) < 8 or _cell(tds[0]) != co_id:
            continue
        pdf = lambda x: (pdf_names(x, co_id) or [None])[0]   # noqa: E731
        out.append({"date": _cell(tds[2]), "time": _cell(tds[3]), "place": _cell(tds[4]), "summary": _cell(tds[5]),
                    "slides_zh": pdf(tds[6]), "slides_en": pdf(tds[7])})
    return out


def guessed_names(co_id, dates):
    return [f"{co_id}{d}{lang}001.pdf" for d in dates for lang in ("M", "E")]


def get_file(url, out_dir, timeout=60.0):
    rec = {"url": url, "started_at": datetime.now(timezone.utc).isoformat()}
    if not _official(url):
        rec.update(status=None, error="拒絕：不是官方網域")
        return rec
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept-Encoding": "identity"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read(MAX_PDF_BYTES + 1)
            rec.update(status=r.status, final_url=r.geturl(), content_type=r.headers.get("Content-Type"),
                       content_length_header=r.headers.get("Content-Length"))
    except urllib.error.HTTPError as e:
        rec.update(status=e.code, error=f"HTTPError {e.code}")
        return rec
    except Exception as e:
        rec.update(status=None, error=f"{type(e).__name__}: {e}")
        return rec
    rec["truncated"] = len(data) > MAX_PDF_BYTES
    data = data[:MAX_PDF_BYTES]
    sha = hashlib.sha256(data).hexdigest()
    rec.update(sha256=sha, length=len(data), is_pdf=data[:5] == b"%PDF-")
    if data:
        folder = os.path.join(out_dir, "files")
        os.makedirs(folder, exist_ok=True)
        name = os.path.basename(urllib.parse.urlsplit(url).path) or "file"
        path = os.path.join(folder, f"{sha[:12]}_{name}")
        with open(path, "wb") as f:
            f.write(data)
        rec["saved_as"] = os.path.relpath(path, out_dir)
    return rec


def probe(co_id, roc_years, dates, out_dir, base="https://mopsov.twse.com.tw", delay=3.0, timeout=60.0,
          sleep=time.sleep):
    os.makedirs(out_dir, exist_ok=True)
    report = {"probe_version": PROBE_VERSION, "co_id": co_id, "roc_years": roc_years, "dates": dates,
              "started_at": datetime.now(timezone.utc).isoformat(), "queries": [], "files": [], "notes": []}
    first = True

    def pause():
        nonlocal first
        if not first:
            sleep(delay)
        first = False

    # 1. 查詢表單頁本身（保存原文，日後確認真正的欄位名稱）
    pause()
    report["form_page"] = get_file(base.rstrip("/") + "/mops/web/t100sb02_1", out_dir, timeout)
    # 2. 法人說明會一覽表查詢
    names = []
    for y in roc_years:
        for label, body in query_variants(co_id, y):
            pause()
            e = ap.post_any(base.rstrip("/") + "/mops/web/ajax_t100sb02_1", body, out_dir, timeout)
            e.update(label=label, roc_year=y)
            text = ""
            if e.get("saved_as"):
                raw = open(os.path.join(out_dir, e["saved_as"]), "rb").read()
                for enc in ("utf-8", "big5", "cp950"):
                    try:
                        text = raw.decode(enc)
                        break
                    except UnicodeDecodeError:
                        continue
            found = pdf_names(text, co_id)
            e["pdf_names"] = found
            e["mentions_co_id"] = co_id in text
            names += [n for n in found if n not in names]
            report["queries"].append(e)
    # 3. 下載：回應中找到的檔名＋依日期推測的檔名
    for n in names + [g for g in guessed_names(co_id, dates) if g not in names]:
        pause()
        rec = get_file(f"{base.rstrip('/')}/nas/STR/{n}", out_dir, timeout)
        rec["source"] = "listed_in_response" if n in names else "guessed_from_announcement_date"
        report["files"].append(rec)
    got = [f for f in report["files"] if f.get("is_pdf")]
    report["notes"].append(f"查詢 {len(report['queries'])} 次，回應中找到 {len(names)} 個 .pdf 檔名；"
                           f"下載到 {len(got)} 份 PDF（只供人工判讀，不自動放行任何季度）")
    report["finished_at"] = datetime.now(timezone.utc).isoformat()
    with open(os.path.join(out_dir, "probe.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    return report


def markdown(r):
    lines = [f"## 法說會簡報探測 {r['co_id']}", "", "| 查詢 | 年度 | HTTP | 提到代號 | 找到的 PDF |", "|---|---|---|---|---|"]
    for q in r["queries"]:
        lines.append(f"| {q.get('label')} | {q.get('roc_year')} | {q.get('status') or q.get('error')} | "
                     f"{'是' if q.get('mentions_co_id') else '否'} | {', '.join(q.get('pdf_names') or []) or '—'} |")
    lines += ["", "| 檔案 | 來源 | HTTP | PDF | 大小 |", "|---|---|---|---|---|"]
    for f in r["files"]:
        lines.append(f"| {f['url'].rsplit('/', 1)[-1]} | {f.get('source')} | {f.get('status') or f.get('error')} | "
                     f"{'是' if f.get('is_pdf') else '否'} | {f.get('length', '')} |")
    lines += [""] + [f"- {n}" for n in r["notes"]]
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description="法說會一覽表與簡報檔探測（官方網站，只保存原文）")
    p.add_argument("--co-id", required=True)
    p.add_argument("--roc-years", required=True)
    p.add_argument("--dates", default="", help="法說會日期 YYYYMMDD，逗號分隔（用來推測官方檔名）")
    p.add_argument("--out", required=True)
    p.add_argument("--base", default="https://mopsov.twse.com.tw")
    p.add_argument("--delay", type=float, default=3.0)
    a = p.parse_args(argv)
    if not re.fullmatch(r"\d{4,6}", a.co_id) or not re.fullmatch(r"\d{3}(,\d{3}){0,5}", a.roc_years) \
            or not re.fullmatch(r"(\d{8}(,\d{8}){0,9})?", a.dates):
        p.error("格式錯誤：代號 4–6 位數字、民國年 3 位數逗號分隔、日期 YYYYMMDD 逗號分隔（最多 10 個）")
    r = probe(a.co_id, a.roc_years.split(","), [d for d in a.dates.split(",") if d], a.out, a.base, a.delay)
    text = markdown(r)
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
