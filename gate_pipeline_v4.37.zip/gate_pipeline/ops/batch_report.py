"""
batch_report.py (v4.31)
=======================
多檔一次跑（gate-pipeline-batch）的總表。讀每一檔這次蒐證的 summary.json，整理成一份報告；
另外用同一次蒐證存下的官方原始回應「離線重算」另一種月營收規則，讓使用者看到啟用與否的差別。

只讀 results/ 底下的檔案，不連任何網站，不改任何蒐證結果。報告是研究用的總表，不是 Gate 判定。

  python gate_pipeline/ops/batch_report.py --co-ids 8299,2404 --run-id 123 --results results \
      --reviews gate_pipeline/contract/mops_real/reviews --out results/batch/123
"""

import argparse
import json
import os
import re
import sys
from collections import Counter
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

REPORT_VERSION = "4.33-batch-report"
STATUSES = ("CUTOFF_VERIFIED", "CUTOFF_QUARTER_END_RULE", "PROVISIONAL")
# 阻擋原因分類（依 mops_t05st01.cutoff_candidates 的訊息開頭；對不上的歸 OTHER，原文照樣保留）
BLOCK_CATEGORIES = (
    ("NO_REVENUE_ANNOUNCEMENT", "找不到該季季末月份的營收公告", "重大訊息沒有季末月營收公告（多數公司只用月營收申報系統）"),
    ("UNCLASSIFIED_PENDING", "則未分類公告", "季末到最早事件之間有未分類公告，需人工確認"),
    ("DETAIL_MISSING", "公告詳細頁尚未取得", "公告詳細頁還沒抓到（下次執行會補）"),
    ("FILING", "財報", "財報申報清單的問題（尚未查詢、無法排除更早申報、更正欄不確定）"),
    ("LISTING_COVERAGE", ("清單起點", "清單終點"), "重大訊息清單沒有涵蓋整季"),
    ("NO_RESULTS_EVENT", "找不到可辨識的該季財務結果揭露", "認不得這家公司的財務結果公告寫法"),
)
CATEGORY_TEXT = {k: t for k, _, t in BLOCK_CATEGORIES}
CATEGORY_TEXT["DETAIL_CHECK_FAILED"] = "詳細頁內容核對不符"
CATEGORY_TEXT["OTHER"] = "其他"


def categorize(msg):
    for k, key, _ in BLOCK_CATEGORIES:
        if any(x in msg for x in ((key,) if isinstance(key, str) else key)):
            return k
    if "詳細頁" in msg:
        return "DETAIL_CHECK_FAILED"
    return "OTHER"


def _counts(quarters):
    c = Counter(v.get("status") for v in quarters.values())
    return {s: c.get(s, 0) for s in STATUSES}


def company_entry(co_id, run_dir, reviews=None, alt_rule=True):
    """單一公司這次蒐證的整理。run_dir 沒有 summary.json → 記為沒有結果。"""
    p = os.path.join(run_dir, "summary.json")
    if not os.path.exists(p):
        man = os.path.join(run_dir, "manifest.json")
        if os.path.exists(man):
            try:
                m = json.load(open(man, encoding="utf-8"))
            except ValueError:
                m = {}
            if m.get("partial"):
                got = sum(1 for r in m.get("requests", []) if r.get("kind") == "t05st01_detail" and r.get("parsed"))
                return {"co_id": co_id, "ok": False, "partial": True,
                        "reason": f"中途停止（取消或逾時），已取得的 {got} 則詳細頁下次會沿用；同一檔再跑一次即可"}
        return {"co_id": co_id, "ok": False, "reason": "這次沒有產生 summary.json（蒐證步驟失敗或沒有執行）"}
    s = json.load(open(p, encoding="utf-8"))
    names = {v.get("company_name") for v in s.get("listings", {}).values() if v.get("company_name")}
    listing_fail = {y: [f[0] for f in v.get("failures", [])] for y, v in s.get("listings", {}).items() if v.get("failures")}
    q = s.get("quarters", {})
    cats = Counter()
    for v in q.values():
        for b in v.get("blocking", []):
            cats[categorize(b)] += 1
    rec = s.get("recognition") or {}
    g = s.get("guidance") or {}
    pending_review = sum(1 for v in q.values() for r in v.get("review_window", []) if r.get("cleared_by") is None)
    market = s.get("market")
    if "market" not in s:   # v4.31 之前的摘要：當時只放行上市公司
        import market_info as mi
        if mi.typek_from_summary(s) == "sii":
            market = {"name": "上市公司", "typek": "sii", "inferred_from_legacy_summary": True}
    man = os.path.join(run_dir, "manifest.json")
    cv = json.load(open(man, encoding="utf-8")).get("collector_version") if os.path.exists(man) else None
    e = {"co_id": co_id, "ok": True, "company_name": "、".join(sorted(names)) or None, "collector_version": cv,
         "market": market, "revenue_rule": s.get("revenue_rule", "require_announcement"),
         "quarters": len(q), "status_counts": _counts(q),
         "quarters_by_status": {st: sorted(k for k, v in q.items() if v.get("status") == st) for st in STATUSES},
         "blocking_categories": dict(cats.most_common()),
         "pending_review_announcements": pending_review,
         "events_recognized": rec.get("events_recognized", {}), "recognition_notes": rec.get("notes", []),
         "guidance_quarters_parsed": rec.get("guidance_quarters_parsed", 0),
         "guidance_gate_status": (g.get("gate_result") or {}).get("status"),
         "listing_failures": listing_fail, "detail_counts": s.get("detail_counts"),
         "notes": s.get("notes", [])}
    if alt_rule and q and os.path.exists(os.path.join(run_dir, "manifest.json")):
        other = "quarter_end" if e["revenue_rule"] != "quarter_end" else "require_announcement"
        try:
            import collect_evidence as ce
            alt = ce.replay(run_dir, reviews, revenue_rule=other)
            e["alternative_rule"] = {"revenue_rule": other, "status_counts": _counts(alt.get("quarters", {})),
                                     "replayed_with": ce.COLLECTOR_VERSION,
                                     "note": "用同一次蒐證的官方原始回應離線重算，不連網站；只供決定是否啟用參考"}
            if cv != ce.COLLECTOR_VERSION:
                e["alternative_rule"]["note"] += f"（注意：蒐證時程式是 {cv}，重算用 {ce.COLLECTOR_VERSION}，兩欄不能直接相減）"
        except Exception as ex:   # 重算失敗不影響原本的結果
            e["alternative_rule"] = {"revenue_rule": other, "error": f"{type(ex).__name__}: {ex}"}
    e["next_steps"] = next_steps(e)
    return e


def next_steps(e):
    out = []
    lf = e.get("listing_failures") or {}
    if lf:
        codes = sorted({c for v in lf.values() for c in v})
        out.append(f"重大訊息清單有年度解析失敗（{', '.join(codes)}）：看 summary.json 的 listings；"
                   "若是市場別尚未支援（例如興櫃），目前不放行")
    cats = e.get("blocking_categories") or {}
    same_code = (e.get("alternative_rule") or {}).get("replayed_with") == e.get("collector_version")
    if cats.get("NO_REVENUE_ANNOUNCEMENT"):
        alt = ((e.get("alternative_rule") or {}).get("status_counts") or {}) if same_code else {}
        gain = alt.get("CUTOFF_QUARTER_END_RULE", 0)
        out.append(f"{cats['NO_REVENUE_ANNOUNCEMENT']} 季卡在沒有季末月營收公告"
                   + (f"；若啟用季末規則，{gain} 季可得到研究用截止點（仍與 CUTOFF_VERIFIED 分開）" if alt else ""))
    if e.get("pending_review_announcements"):
        out.append(f"{e['pending_review_announcements']} 則未分類公告待人工確認（看各季 review_window）")
    if cats.get("DETAIL_MISSING"):
        out.append("有詳細頁還沒抓到：同一檔再跑一次會沿用已取得的、補抓其餘的")
    if cats.get("NO_RESULTS_EVENT") or any("沒有認得" in n for n in e.get("recognition_notes", [])):
        out.append("有財務事件的公告寫法還不認得：把 recognition_notes 與該公司的公告主旨提供給維護者擴充寫法")
    mk = e.get("market") or {}
    if mk.get("first_sample"):
        out.append("市場別格式第一次真實樣本：請保留這次的原始回應，人工比對一次後列為已驗證")
    elif mk and mk.get("detail_pages_verified") is False and (e.get("detail_counts") or {}).get("fetched"):
        out.append(f"{mk.get('name')}的公告詳細頁第一次取得：請把這次的詳細頁交給維護者人工比對一次")
    return out


def build(co_ids, run_id, results_root, reviews=None, alt_rule=True, now=None):
    rows = [company_entry(c, os.path.join(results_root, c, str(run_id)), reviews, alt_rule) for c in co_ids]
    tot = Counter()
    for r in rows:
        for k, v in (r.get("status_counts") or {}).items():
            tot[k] += v
    return {"report_version": REPORT_VERSION, "run_id": str(run_id),
            "generated_at": (now or datetime.now(timezone.utc)).isoformat(), "gate_impact": "none",
            "meaning": "各檔官方截止點證據的總表；CUTOFF_VERIFIED 也只是截止點證據齊全，不等於 Gate PASS",
            "co_ids": list(co_ids), "totals": {s: tot.get(s, 0) for s in STATUSES},
            "companies": rows}


def markdown(rep):
    lines = [f"## 多檔蒐證總表（run {rep['run_id']}）", "",
             "| 代號 | 名稱 | 市場 | 規則 | 已驗證 | 季末規則 | 暫定 | 主要阻擋原因 | 另一規則重算 |",
             "|---|---|---|---|---|---|---|---|---|"]
    for r in rep["companies"]:
        if not r.get("ok"):
            lines.append(f"| {r['co_id']} | — | — | — | — | — | — | {r['reason']} | — |")
            continue
        sc, mk = r["status_counts"], r.get("market") or {}
        top = "；".join(f"{CATEGORY_TEXT.get(k, k)} {v}" for k, v in list(r["blocking_categories"].items())[:2]) or "—"
        alt = r.get("alternative_rule") or {}
        alt_s = ("、".join(f"{k.replace('CUTOFF_', '')} {v}" for k, v in alt["status_counts"].items() if v)
                 if alt.get("status_counts") else (alt.get("error") or "—"))
        tag = "（首次樣本）" if mk.get("first_sample") else "（舊版摘要推定）" if mk.get("inferred_from_legacy_summary") else ""
        lines.append(f"| {r['co_id']} | {r.get('company_name') or '—'} | {mk.get('name') or '未知'}{tag} | {r['revenue_rule']} | "
                     f"{sc['CUTOFF_VERIFIED']} | {sc['CUTOFF_QUARTER_END_RULE']} | {sc['PROVISIONAL']} | "
                     f"{top.replace('|', '/')} | {alt_s} |")
    t = rep["totals"]
    lines += ["", f"合計：已驗證 {t['CUTOFF_VERIFIED']} 季、季末規則 {t['CUTOFF_QUARTER_END_RULE']} 季、暫定 {t['PROVISIONAL']} 季"
              "（已驗證只代表截止點證據齊全，不等於 Gate PASS）"]
    for r in rep["companies"]:
        if r.get("ok") and r.get("next_steps"):
            lines += ["", f"**{r['co_id']} {r.get('company_name') or ''}**"] + [f"- {x}" for x in r["next_steps"]]
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description="多檔蒐證總表（只讀 results/，不連網站）")
    p.add_argument("--co-ids", required=True)
    p.add_argument("--run-id", required=True)
    p.add_argument("--results", default="results")
    p.add_argument("--reviews", default=None)
    p.add_argument("--out", required=True)
    p.add_argument("--no-alt-rule", action="store_true", help="不離線重算另一種月營收規則")
    a = p.parse_args(argv)
    if not re.fullmatch(r"\d{4,6}(,\d{4,6}){0,19}", a.co_ids) or not a.run_id.isdigit():
        p.error("代號格式錯誤（4–6 位數字，逗號分隔，最多 20 檔）或 run id 不是數字")
    codes = list(dict.fromkeys(a.co_ids.split(",")))
    reviews = None
    if a.reviews:
        import collect_evidence as ce
        reviews = ce.load_reviews(a.reviews)
    rep = build(codes, a.run_id, a.results, reviews, alt_rule=not a.no_alt_rule)
    os.makedirs(a.out, exist_ok=True)
    md = markdown(rep)
    with open(os.path.join(a.out, "batch_report.json"), "w", encoding="utf-8") as f:
        json.dump(rep, f, ensure_ascii=False, indent=2)
    with open(os.path.join(a.out, "batch_report.md"), "w", encoding="utf-8") as f:
        f.write(md + "\n")
    print(md)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(md + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
