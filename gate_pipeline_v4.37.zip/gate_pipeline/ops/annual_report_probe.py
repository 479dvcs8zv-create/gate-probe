"""
annual_report_probe.py (v4.37)
==============================
探測：臺灣證券交易所「電子資料查詢作業」（doc.twse.com.tw t57sb01）的股東會年報電子檔。
起因：正式網站的群聯 8299 Gate 4 項目（生產據點、10% 以上客戶、市占率）需要年報原文與頁碼；
原本要使用者自己上傳，這裡改由程式從官方網站下載（使用者 2026-10-19 同意由 Claude 接手）。

這是探測，不是解析器：年報類別的查詢參數還沒有真實樣本，所以
  1. step=1 依 mtype=F 查該年度清單（同時試幾種送法），原始回應全部保存；
  2. 從回應找出 <代號> 的 .pdf 檔名（F04＝股東會年報，其他 F 類照記錄）；
  3. 對每個檔名送 step=9（官方頁面點檔名時的送法），從回應找 /pdf/ 下載連結，再下載 PDF。
只連官方網域（twse.com.tw）、每次請求間隔 3 秒、不自動判讀任何內容；下載到的年報只供人工查頁碼。

  python gate_pipeline/ops/annual_report_probe.py --co-id 8299 --roc-years 114,115 --out results/8299/annual_report/123
"""

import argparse
import json
import os
import re
import sys
import time
import urllib.parse
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import announcement_probe as ap  # noqa: E402
import conference_probe as cp  # noqa: E402

PROBE_VERSION = "4.37-annual-report-probe"
BASE = "https://doc.twse.com.tw"


def listing_variants(co_id, roc_year):
    q = f"step=1&colorchg=1&co_id={co_id}&year={roc_year}"
    return [("mtype_F", f"{BASE}/server-java/t57sb01?{q}&mtype=F&"),
            ("mtype_F_seamon", f"{BASE}/server-java/t57sb01?{q}&seamon=&mtype=F&")]


def pdf_names(text, co_id):
    """回應中提到的 PDF 檔名（含代號；例：2025_8299_20260528F04.pdf）。"""
    out = []
    for m in re.finditer(r"[0-9]{4}_" + co_id + r"_[0-9]{8}F[0-9]{2}\.pdf", text):
        if m.group(0) not in out:
            out.append(m.group(0))
    return out


def download_links(text):
    return list(dict.fromkeys(re.findall(r"""href\s*=\s*['"]?(/pdf/[^'"\s>]+\.pdf)""", text, re.I)))


def _text(out_dir, rec):
    if not rec.get("saved_as"):
        return ""
    raw = open(os.path.join(out_dir, rec["saved_as"]), "rb").read()
    for enc in ("utf-8", "big5", "cp950"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def probe(co_id, roc_years, out_dir, delay=3.0, timeout=60.0, sleep=time.sleep):
    os.makedirs(out_dir, exist_ok=True)
    report = {"probe_version": PROBE_VERSION, "co_id": co_id, "roc_years": roc_years,
              "started_at": datetime.now(timezone.utc).isoformat(), "listings": [], "step9": [], "files": [], "notes": []}
    first = [True]

    def pause():
        if not first[0]:
            sleep(delay)
        first[0] = False

    names = []
    for y in roc_years:
        for label, url in listing_variants(co_id, y):
            pause()
            rec = cp.get_file(url, out_dir, timeout)
            rec.update(label=label, roc_year=y)
            found = pdf_names(_text(out_dir, rec), co_id)
            rec["pdf_names"] = found
            names += [n for n in found if n not in names]
            report["listings"].append(rec)
    links = []
    for n in names:
        pause()
        body = "step=9&kind=F&co_id=" + co_id + "&filename=" + urllib.parse.quote(n)
        e = ap.post_any(f"{BASE}/server-java/t57sb01", body, out_dir, timeout)
        e.update(filename=n)
        e["download_links"] = download_links(_text(out_dir, e))
        links += [(n, l) for l in e["download_links"] if (n, l) not in links]
        report["step9"].append(e)
    for n, link in links:
        pause()
        rec = cp.get_file(BASE + link, out_dir, timeout)
        rec.update(filename=n, link=link)
        report["files"].append(rec)
    got = [f for f in report["files"] if f.get("is_pdf")]
    report["notes"].append(f"清單 {len(report['listings'])} 次、找到 {len(names)} 個年報類檔名、下載到 {len(got)} 份 PDF"
                           "（只供人工查頁碼，不自動判讀）")
    report["finished_at"] = datetime.now(timezone.utc).isoformat()
    with open(os.path.join(out_dir, "probe.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    return report


def markdown(r):
    lines = [f"## 年報探測 {r['co_id']}", "", "| 清單送法 | 年度 | HTTP | 找到的檔名 |", "|---|---|---|---|"]
    for q in r["listings"]:
        lines.append(f"| {q.get('label')} | {q.get('roc_year')} | {q.get('status') or q.get('error')} | "
                     f"{', '.join(q.get('pdf_names') or []) or '—'} |")
    lines += ["", "| 檔名 | step=9 HTTP | 下載連結 |", "|---|---|---|"]
    for e in r["step9"]:
        lines.append(f"| {e['filename']} | {e.get('status') or e.get('error')} | {', '.join(e['download_links']) or '—'} |")
    lines += ["", "| 檔案 | HTTP | PDF | 大小 |", "|---|---|---|---|"]
    for f in r["files"]:
        lines.append(f"| {f['link']} | {f.get('status') or f.get('error')} | {'是' if f.get('is_pdf') else '否'} | {f.get('length', '')} |")
    lines += [""] + [f"- {n}" for n in r["notes"]]
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description="股東會年報電子檔探測（doc.twse.com.tw，只保存原文）")
    p.add_argument("--co-id", required=True)
    p.add_argument("--roc-years", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--delay", type=float, default=3.0)
    a = p.parse_args(argv)
    if not re.fullmatch(r"\d{4,6}", a.co_id) or not re.fullmatch(r"\d{3}(,\d{3}){0,3}", a.roc_years):
        p.error("格式錯誤：代號 4–6 位數字、民國年 3 位數逗號分隔（最多 4 個）")
    r = probe(a.co_id, a.roc_years.split(","), a.out, a.delay)
    text = markdown(r)
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
