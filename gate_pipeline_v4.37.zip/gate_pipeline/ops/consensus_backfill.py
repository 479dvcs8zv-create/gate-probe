"""
ops/consensus_backfill.py (v4.27)
=================================
歷史共識快照補齊與重新下載核對（只取得與核對證據，不解析、不影響任何 Gate 判定）。

v4.18 的來源探測只從每個網站抽樣 2 筆存檔；封存索引（CDX）裡其實還有更多「截止點前」的存檔。
這一步針對「已有解析器」的網站，對每個截止點已驗證的季度：
  1. 已經取得過、而且是審查候選的 → 先再下載一次，核對與先前保存的位元組完全相同（第二次獨立取得）
  2. 查 CDX，找出「快照界線（月營收＝公告當日 00:00）之前 45 天內」最新的一筆存檔（嚴格早於界線）
  3. 還沒取得過的 → 用 id_ 模式下載原文，核對 CDX 記錄的 SHA-1 摘要，保存原始位元組與 SHA-256
CDX 原始回應一併保存（之後可離線核對「封存時間 ↔ 摘要」的對應）。
時間上限到了就停，下一次執行接著做（已取得的不重複下載）。

輸出（<out>/）：backfill.json、cdx/<來源>.json、samples/<來源>_<季度>_<時間戳>.bin
"""

import base64
import hashlib
import json
import os
import re
import sys
import time
import urllib.parse
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

from consensus_discovery import CDX_FL, _RecordingArchive, _parse_cdx, resolve_sources  # noqa: E402
from independent_verifier import ArchiveFetchError, ArchiveIntegrityError  # noqa: E402
from mops_t05st01 import QUARTER_END_RULE_STATUS  # noqa: E402

BACKFILL_VERSION = "4.31-backfill"
RESEARCH_BOUNDARY_STATUSES = ("CUTOFF_VERIFIED", QUARTER_END_RULE_STATUS)
TPE = timezone(timedelta(hours=8))
PARSEABLE = ("yahoo_adr_analysis", "yahoo_tw_analysis", "nasdaq_api_forecast", "marketbeat_adr_earnings",
             "stockanalysis_adr_forecast")


def _digest(b):
    return base64.b32encode(hashlib.sha1(b).digest()).decode("ascii")


def _prior_cdx(prior_dirs, sid, prefix, lo, hi):
    """（v4.28）先前補齊時保存的 CDX 回應若已涵蓋需要的時間範圍，就沿用（截止點都已過去，範圍內的存檔不會再增加）。"""
    for d in sorted(prior_dirs or [], reverse=True):
        try:
            r = json.load(open(os.path.join(d, "backfill.json"), encoding="utf-8"))
        except (OSError, ValueError):
            continue
        for s in r.get("sources", []):
            c = s.get("cdx") or {}
            if s.get("id") != sid or s.get("prefix") != prefix or c.get("error") or not c.get("file"):
                continue
            q = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(c.get("url", "")).query))
            got_at = r.get("started_at", "")[:19].replace("-", "").replace(":", "").replace("T", "")
            if q.get("from", "9") <= lo and q.get("to", "0") >= hi and got_at >= hi:
                path = os.path.join(d, c["file"])
                if os.path.exists(path) and hashlib.sha256(open(path, "rb").read()).hexdigest() == c.get("sha256"):
                    return path, c
    return None, None


def backfill(co_id, cutoffs, out_dir, held=None, refetch=None, base_url="https://web.archive.org", delay=3.0,
             timeout=60.0, window_days=45, time_budget=420.0, max_new=40, max_refetch=8, source_ids=PARSEABLE,
             sources_path=None, sleep=time.sleep, clock=time.monotonic, now=None, prior_dirs=None, typek=None):
    """cutoffs：{季度: {"at": 快照界線 ISO, "status": ...}}，只用 CUTOFF_VERIFIED 的季度
    （v4.31：另含使用者啟用季末規則時的 CUTOFF_QUARTER_END_RULE；兩者都是研究用界線，不影響 Gate）。
    held：{(來源, 時間戳): {"sha256": ...}} 已取得的存檔；refetch：[(來源, 時間戳, 原網址, sha256)] 要重新下載核對的。"""
    os.makedirs(os.path.join(out_dir, "cdx"), exist_ok=True)
    os.makedirs(os.path.join(out_dir, "samples"), exist_ok=True)
    held = held or {}
    sources, skipped, adr = (resolve_sources(co_id, sources_path, typek) if sources_path
                             else resolve_sources(co_id, typek=typek))
    sources = [s for s in sources if s["id"] in source_ids]
    cut = {q: datetime.fromisoformat(v["at"]) for q, v in cutoffs.items()
           if v.get("at") and v.get("status") in RESEARCH_BOUNDARY_STATUSES}
    result = {"backfill_version": BACKFILL_VERSION, "co_id": co_id, "adr": adr, "base_url": base_url,
              "window_days": window_days, "started_at": (now or datetime.now(timezone.utc)).isoformat(),
              "cutoffs": {q: cutoffs[q] for q in sorted(cut)}, "sources": [], "refetch": [], "notes": [],
              "requests": 0}
    t0 = clock()
    arc = _RecordingArchive(base_url=base_url, timeout=timeout)
    first = [True]

    def left():
        return time_budget - (clock() - t0)

    def get(url):
        for attempt in (1, 2):
            if left() <= 0:
                return None, "時間上限已到，未發出請求"
            if not first[0]:
                sleep(delay)
            first[0] = False
            result["requests"] += 1
            try:
                return arc._get(url), None
            except (ArchiveFetchError, ArchiveIntegrityError) as e:
                if attempt == 1 and re.search(r"HTTP (429|5\d\d)|無法連線", str(e)):
                    sleep(min(delay * 3, 30))
                    continue
                return None, str(e)
        return None, "未知錯誤"

    base = base_url.rstrip("/")
    # 1. 審查候選優先：再下載一次，核對與先前保存的位元組相同（數量少，先做，避免被新下載用完時間）
    for item in (refetch or [])[:max_refetch]:
        sid, ts, original, sha = item[:4]
        digest = item[4] if len(item) > 4 else None
        rec = {"source_id": sid, "timestamp": ts, "original": original, "held_sha256": sha, "archive_digest": digest}
        if left() <= 0:
            rec.update(status="NOT_RUN", reason="時間上限已到")
        else:
            body, err = get(f"{base}/web/{ts}id_/{original}")
            if err:
                # v4.28：分開「封存取不到」（Wayback 回 403／404／410）與網路失敗；兩者都不代表內容被竄改
                gone = re.search(r"HTTP (403|404|410)\b|轉址", err)   # 轉址＝封存服務改給別的時間版本
                rec.update(status="ARCHIVE_UNAVAILABLE" if gone else "NETWORK_FAILED", reason=err)
            else:
                got = hashlib.sha256(body).hexdigest()
                if got == sha:
                    st = "MATCHED"
                elif digest and _digest(body) == digest:
                    st = "MISMATCH_LOCAL"     # 封存服務送的內容符合摘要，是我們保存的不同
                elif digest:
                    st = "MISMATCH_ARCHIVE"   # 封存服務這次送的內容與它自己的摘要不符
                else:
                    st = "MISMATCH"
                rec.update(status=st, refetched_sha256=got, refetched_digest=_digest(body),
                           refetched_at=datetime.now(timezone.utc).isoformat())
        result["refetch"].append(rec)
    # 2. 每個來源查一次 CDX（涵蓋所有季度的時間範圍）
    plan = []
    if cut:
        lo = (min(cut.values()) - timedelta(days=window_days)).astimezone(timezone.utc)
        hi = max(cut.values()).astimezone(timezone.utc)
        for s in sources:
            ent = {"id": s["id"], "vendor": s["vendor"], "prefix": s["prefix"], "unit": s.get("unit"),
                   "cdx": None, "quarters": {}, "samples": []}
            result["sources"].append(ent)
            q = {"url": s["prefix"], "matchType": "prefix", "output": "json", "fl": CDX_FL,
                 "filter": "statuscode:200", "from": lo.strftime("%Y%m%d%H%M%S"), "to": hi.strftime("%Y%m%d%H%M%S"),
                 "limit": "2000"}
            url = f"{base}/cdx/search/cdx?{urllib.parse.urlencode(q)}"
            ppath, pc = _prior_cdx(prior_dirs, s["id"], s["prefix"], q["from"], q["to"])
            if ppath:
                body, err = open(ppath, "rb").read(), None
            else:
                body, err = get(url)
            if err:
                ent["cdx"] = {"error": err, "url": url}
                continue
            name = f"cdx/{s['id']}.json"
            open(os.path.join(out_dir, name), "wb").write(body)
            ent["cdx"] = {"file": name, "sha256": hashlib.sha256(body).hexdigest(), "url": pc["url"] if pc else url,
                          "error": None}
            if ppath:
                ent["cdx"]["reused_from"] = os.path.relpath(ppath, os.path.dirname(os.path.dirname(out_dir)))
            try:
                rows, _ = _parse_cdx(body)
            except ValueError as e:
                ent["cdx"]["error"] = f"CDX 回應無法解析：{e}"
                continue
            parsed = [(datetime.strptime(r["timestamp"], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc), r)
                      for r in rows if r.get("statuscode") == "200" and re.fullmatch(r"\d{14}", str(r.get("timestamp")))]
            ent["cdx"]["records"] = len(parsed)
            for fq, c in sorted(cut.items()):
                cu = c.astimezone(timezone.utc)
                inwin = [(t, r) for t, r in parsed if cu - timedelta(days=window_days) <= t < cu]   # 嚴格早於界線
                if not inwin:
                    ent["quarters"][fq] = None
                    continue
                t, r = max(inwin, key=lambda x: x[0])
                ent["quarters"][fq] = {"timestamp": r["timestamp"], "original": r["original"], "digest": r.get("digest"),
                                       "captures_in_window": len(inwin),
                                       "days_before_boundary": round((cu - t).total_seconds() / 86400, 2)}
                if (s["id"], r["timestamp"]) not in held:
                    plan.append((fq, s, ent, r))
    # 3. 下載還沒取得的存檔：最近的季度優先
    plan.sort(key=lambda x: x[0], reverse=True)
    new = 0
    for fq, s, ent, r in plan:
        if new >= max_new or left() <= 0:
            break
        if any(x["timestamp"] == r["timestamp"] for x in ent["samples"]):
            continue   # 同一筆存檔同時是兩季的最新一筆
        new += 1
        smp = {"quarter": fq, "timestamp": r["timestamp"], "original": r["original"], "archive_digest": r.get("digest"),
               "cdx_file": ent["cdx"]["file"]}
        body, err = get(f"{base}/web/{r['timestamp']}id_/{r['original']}")
        if err:
            smp["error"] = err
        else:
            fname = f"samples/{s['id']}_{fq}_{r['timestamp']}.bin"
            open(os.path.join(out_dir, fname), "wb").write(body)
            smp.update(file=fname, sha256=hashlib.sha256(body).hexdigest(), content_type=arc.last_content_type,
                       digest_matched=(_digest(body) == r.get("digest")))
        ent["samples"].append(smp)
    pending = sum(1 for fq, s, ent, r in plan) - new
    if pending > 0:
        result["notes"].append(f"還有 {pending} 筆歷史存檔沒有下載（時間或數量上限），下次執行接著做")
    if left() <= 0:
        result["notes"].append(f"時間上限 {time_budget:g} 秒已到")
    result["finished_at"] = datetime.now(timezone.utc).isoformat()
    with open(os.path.join(out_dir, "backfill.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    return result


def markdown(r):
    got = [(s["id"], x) for s in r["sources"] for x in s["samples"]]
    ok = sum(1 for _, x in got if x.get("digest_matched"))
    bad = sum(1 for _, x in got if x.get("file") and not x.get("digest_matched"))
    err = sum(1 for _, x in got if x.get("error"))
    reused = [s["id"] for s in r["sources"] if (s.get("cdx") or {}).get("reused_from")]
    lines = ["", f"### 歷史快照補齊（快照界線前 {r['window_days']} 天內最新一筆）", "",
             f"嘗試下載 {len(got)} 筆：摘要相符 {ok}、摘要不符 {bad}、取得失敗 {err}"]
    if r["refetch"]:
        lines.append("重新下載核對：" + "、".join(f"{x['source_id']} {x['timestamp'][:8]} {x['status']}" for x in r["refetch"]))
    if reused:
        lines.append("沿用先前已查過的封存索引（歷史範圍不會再變）：" + "、".join(reused))
    for s in r["sources"]:
        if s["cdx"] and s["cdx"].get("error"):
            lines.append(f"- `{s['id']}` 索引查詢失敗：{s['cdx']['error']}")
    for n in r["notes"]:
        lines.append(f"- {n}")
    return "\n".join(lines)
