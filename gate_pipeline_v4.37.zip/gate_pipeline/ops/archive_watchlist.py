"""
archive_watchlist.py (v4.34)
============================
觀察清單上的每一檔股票依序送市場預估網頁存檔（Wayback Save Page Now），之後重算各檔的研究紀錄與快照審查。
使用者 2026-10-19 決定：每週自動存檔由「只有 2330」改成「觀察清單上的所有股票」。

觀察清單：repo 根目錄的 watchlist.txt，一行一個股票代號（4–6 位數字），# 之後是註解；最多 20 檔。
每檔的網址依市場別（官方蒐證摘要記錄的上市／上櫃）代入；沒有蒐證摘要的股票只會送不需要市場別的網站。
封存服務連不上（archive_consensus 判定 service_down）時，其餘股票不再送存檔，只用已保存的資料重算研究紀錄。
只寫 results/<代號>/archive/<run id>/；研究紀錄 gate_impact = none，不改任何 Gate 判定。

  python gate_pipeline/ops/archive_watchlist.py --watchlist watchlist.txt --results results --run-id 123
"""

import argparse
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import archive_consensus as ac  # noqa: E402

WATCHLIST_VERSION = "4.34-archive-watchlist"
MAX_CODES = 20


def read_watchlist(path):
    """回傳 (代號清單, 被略過的行)。格式不符的行不採用並列出，不猜。"""
    codes, bad = [], []
    for n, line in enumerate(open(path, encoding="utf-8"), 1):
        s = line.split("#", 1)[0].strip()
        if not s:
            continue
        if re.fullmatch(r"\d{4,6}", s):
            if s not in codes:
                codes.append(s)
        else:
            bad.append(f"第 {n} 行「{line.strip()}」不是 4–6 位數字代號")
    if len(codes) > MAX_CODES:
        bad.append(f"超過 {MAX_CODES} 檔，只取前 {MAX_CODES} 檔")
        codes = codes[:MAX_CODES]
    return codes, bad


def run(codes, results_root, run_id, base_url="https://web.archive.org", delay=20.0, spn_budget=300.0,
        backfill_budget=240.0, archive=None, research=None):
    """依序處理每一檔；回傳 (每檔結果摘要清單, markdown)。archive／research 可替換（測試用）。"""
    archive = archive or ac.archive
    research = research or ac.research_and_audit
    rows, parts, down = [], [], False
    for co in codes:
        out = os.path.join(results_root, co, "archive", str(run_id))
        row = {"co_id": co, "out": out}
        if down:
            os.makedirs(out, exist_ok=True)
            row.update(status="SKIPPED_SERVICE_DOWN", archived=0)
            parts.append(f"## {co}\n\n- 封存服務暫停，本次不送存檔")
        else:
            try:
                r = archive(co, out, base_url, delay, time_budget=spn_budget)
                row.update(status="DONE", archived=sum(1 for t in r["targets"] if t["status"] == "ARCHIVED"),
                           targets=len(r["targets"]), typek=r.get("typek"))
                parts.append(ac.markdown(r))
                down = bool(r.get("service_down"))
            except Exception as e:   # 一檔失敗不影響其他檔
                row.update(status="ERROR", error=f"{type(e).__name__}: {e}", archived=0)
                parts.append(f"## {co}\n\n- 存檔發生錯誤：{type(e).__name__}: {e}")
        try:   # 研究紀錄只用已保存的資料；封存服務掛了就不做補齊
            parts.append(research(co, out, base_url, 0 if down else backfill_budget, delay=min(delay, 3.0)))
            row["research"] = "OK"
        except Exception as e:
            row["research"] = f"{type(e).__name__}: {e}"
            parts.append(f"- {co} 研究紀錄產生失敗（封存不受影響）：{type(e).__name__}: {e}")
        rows.append(row)
    head = ["## 觀察清單存檔總表", "", "| 代號 | 結果 | 新存檔 | 研究紀錄 |", "|---|---|---|---|"]
    head += [f"| {r['co_id']} | {r['status']} | {r.get('archived', 0)}/{r.get('targets', 0)} | {r.get('research', '')} |"
             for r in rows]
    if down:
        head += ["", "封存服務暫停：之後的股票本次不送存檔，下次排程再試"]
    return rows, "\n".join(head + [""] + parts)


def main(argv=None):
    p = argparse.ArgumentParser(description="觀察清單上的股票依序送市場預估網頁存檔")
    p.add_argument("--watchlist", default="watchlist.txt")
    p.add_argument("--co-ids", default="", help="逗號分隔；有填就不讀觀察清單")
    p.add_argument("--results", default="results")
    p.add_argument("--run-id", required=True)
    p.add_argument("--base-url", default="https://web.archive.org")
    p.add_argument("--delay", type=float, default=20.0)
    p.add_argument("--spn-time-budget", type=float, default=300.0, help="每檔 Save Page Now 的時間上限（秒）")
    p.add_argument("--backfill-time-budget", type=float, default=240.0, help="每檔歷史快照補齊的時間上限（秒）")
    a = p.parse_args(argv)
    notes = []
    if a.co_ids.strip():
        codes = list(dict.fromkeys(x.strip() for x in a.co_ids.split(",") if x.strip()))
        if not all(re.fullmatch(r"\d{4,6}", c) for c in codes) or len(codes) > MAX_CODES:
            p.error(f"代號必須是 4–6 位數字，逗號分隔，最多 {MAX_CODES} 檔")
    elif os.path.exists(a.watchlist):
        codes, notes = read_watchlist(a.watchlist)
    else:
        codes, notes = ["2330"], [f"找不到 {a.watchlist}，只處理 2330"]
    if not a.run_id.isdigit():
        p.error("run id 必須是數字")
    rows, text = run(codes, a.results, a.run_id, a.base_url, a.delay, a.spn_time_budget, a.backfill_time_budget)
    if notes:
        text = "\n".join([f"- {n}" for n in notes] + ["", text])
    print(text)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"], "a", encoding="utf-8") as f:
            f.write(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
