"""
test_run_2454_39136575628.py (v4.24)
====================================
聯發科 2454 第二輪實跑（gate-probe run 39136575628，collector 4.22）：266 則詳細頁全數取得。
v4.23 依這些真實詳細頁建立聯發科的核對規則與財測解析，離線重算確認：
  - 營收公告：說明用中文數字年月（「一百一十三年三月份自結合併營收淨額」），須與主旨一致
  - 結果公告：「聯發科技公佈YYYY年第N季（或第四季）合併財務報告」，須與主旨季度一致
  - 截止點 11 季中 9 季 CUTOFF_VERIFIED；2024Q4（財報清單一列更正欄空白＋3 則待確認）、2025Q4（1 則待確認）暫定
  - 官方財測模式：聯發科「YYYY年第N季營運展望」（新台幣營收區間、毛利率中點±幅度、營業費用率）
    9 季中 8 季 VERIFIED；2026Q3 結果尚未公布（MISSING_ACTUAL）
  - 2024Q1 實際毛利率「含一次性項目」照實記錄；營業費用率公告未列實際值，不比較
  - 竄改營收詳細頁的年月 → 該季營收事件不採用 → 該季暫定
v4.24（使用者 2026-10-18 決定）：
  - 子公司 MediaTek Global 減資 2 則確認不是財務結果（reviews/2454_2024Q4_unclassified.json）
  - Nomura @CES 2025／2026 兩則「參與機構投資人說明會」暫不確認（簡報內容未取得）→ 2024Q4、2025Q4 仍暫定
  - 財報清單 202404_2454_AIC.pdf（更正欄空白）依「財報不可能早於董事會通過」不阻擋：
    2024Q4 董事會 2025-02-27 開會，晚於截止點 2025-01-10

  python test_run_2454_39136575628.py
"""
import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import guidance_mops as gm  # noqa: E402
from mops_t05st01 import _cn_number  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_2454_39136575628")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))
MANIFEST = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
S = ce.replay(RUN, REVIEWS)


def test_collection():
    s = json.load(open(os.path.join(RUN, "summary.json"), encoding="utf-8"))
    assert MANIFEST["collector_version"] == "4.22-collect"
    assert s["detail_counts"] == {"wanted": 266, "fetched": 266, "from_cache": 0, "skipped_over_limit": 0}
    assert not [d for d, v in s["details"].items() if not v["ok"]]


CES_2025, CES_2026 = "t05st01:2454:20250103:170501:2", "t05st01:2454:20260102:172706:1"


def _reviews_before_ces_decision():
    """2026-10-19 之前的審查狀態：CES 兩則使用者暫不確認（用來測試當時的行為）。"""
    import copy
    rv = copy.deepcopy(REVIEWS)
    rv.pop(("2454", "2025Q4"), None)
    rec = rv[("2454", "2024Q4")]
    rec["reviewed_non_results"] = [r for r in rec["reviewed_non_results"] if r["document_id"] != CES_2025]
    return rv


S_BEFORE = ce.replay(RUN, _reviews_before_ces_decision())


def test_cutoffs_nine_verified():
    """v4.24 時（CES 暫不確認）：9 季已驗證，2024Q4、2025Q4 各卡一則 CES。"""
    st = {q: v["status"] for q, v in S_BEFORE["quarters"].items()}
    assert [q for q, x in st.items() if x != "CUTOFF_VERIFIED"] == ["2024Q4", "2025Q4"], st
    for q, v in S_BEFORE["quarters"].items():
        assert v["earliest"]["event_type"] == "quarter_revenue_complete" and v["earliest"]["detail_verified"], q
    assert S_BEFORE["quarters"]["2025Q1"]["earliest"]["at"] == "2025-04-10T16:55:54+08:00"
    pend = {q: [r["document_id"] for r in v["review_window"] if r["cleared_by"] is None]
            for q, v in S_BEFORE["quarters"].items()}
    assert pend["2024Q4"] == [CES_2025] and pend["2025Q4"] == [CES_2026]
    human = [r["document_id"] for r in S_BEFORE["quarters"]["2024Q4"]["review_window"] if r["cleared_by"] == "human_review"]
    assert human == ["t05st01:2454:20250103:170541:1", "t05st01:2454:20250109:174323:1"]
    assert S_BEFORE["quarters"]["2024Q4"]["blocking"] == [
        "季末到最早事件之間有 1 則未分類公告，需人工確認不含財務結果：['t05st01:2454:20250103:170501:2']"]
    assert S_BEFORE["quarters"]["2024Q4"]["review_record"] is True
    assert S_BEFORE["recognition"]["notes"] == []


def test_ces_confirmed_all_eleven_verified():
    """（v4.34，使用者 2026-10-19 依官方法說會一覽表附檔確認 CES 不是結果）→ 11 季全部已驗證。"""
    assert {v["status"] for v in S["quarters"].values()} == {"CUTOFF_VERIFIED"} and len(S["quarters"]) == 11
    human = [r["document_id"] for r in S["quarters"]["2024Q4"]["review_window"] if r["cleared_by"] == "human_review"]
    assert CES_2025 in human and len(human) == 3
    assert [r["cleared_by"] for r in S["quarters"]["2025Q4"]["review_window"]] == ["human_review"]
    rec = [r for r in REVIEWS[("2454", "2024Q4")]["reviewed_non_results"] if r["document_id"] == CES_2025][0]
    assert rec["official_slides"]["file"] == "245420241030M001.pdf"


def test_uncertain_filing_set_aside_by_board_rule():
    """更正欄空白的那一列：董事會 2025-02-27 開會，晚於截止點 → 記錄後不阻擋。"""
    u = S["quarters"]["2024Q4"]["uncertain_filings"]
    assert len(u) == 1 and u[0]["filename"] == "202404_2454_AIC.pdf" and u[0]["set_aside"] is True
    assert u[0]["rule"] == "filing_not_before_board_approval" and u[0]["board_bound"] == "2025-02-27T00:00:00+08:00"
    assert not any("202404_2454_AIC.pdf" in b for b in S["quarters"]["2024Q4"]["blocking"])
    assert all(not v["uncertain_filings"] for q, v in S["quarters"].items() if q != "2024Q4")


def test_snapshot_boundary_midnight():
    """（v4.26）月營收截止點另記快照界線＝公告當日 00:00；公告時間與季度狀態都不變。"""
    q = S["quarters"]["2025Q1"]
    assert q["earliest"]["at"] == "2025-04-10T16:55:54+08:00" and q["status"] == "CUTOFF_VERIFIED"
    assert q["snapshot_boundary"] == {"at": "2025-04-10T00:00:00+08:00", "rule": "revenue_day_midnight",
                                      "note": "月營收公告當日 00:00（月營收申報系統上傳時間未查證）"}
    assert all(v["snapshot_boundary"]["rule"] == "revenue_day_midnight" for v in S["quarters"].values())
    assert S_BEFORE["quarters"]["2024Q4"]["status"] == "PROVISIONAL"   # 界線不會讓暫定的季度升級
    assert S_BEFORE["quarters"]["2024Q4"]["snapshot_boundary"]["rule"] == "revenue_day_midnight"


def test_guidance_mode_mediatek():
    g = S["guidance"]
    st = {q: e["status"] for q, e in g["quarters"].items()}
    assert st.pop("2026Q3") == "MISSING_ACTUAL" and set(st.values()) == {"VERIFIED"} and len(st) == 10   # v4.34：+2024Q4、2025Q4
    assert g["gate_result"]["status"] == "official_guidance_verified" and g["gate_result"]["evidence_count"] == 10
    assert len([1 for e in S_BEFORE["guidance"]["quarters"].values() if e["status"] == "VERIFIED"]) == 8
    q1 = g["quarters"]["2024Q1"]
    assert q1["guidance"]["revenue_twd_bn"] == [121.8, 129.6] and q1["guidance"]["gross_margin_pct"] == [45.5, 48.5]
    assert q1["guidance"]["opex_ratio_pct"] == [26.0, 30.0] and q1["guidance"]["fx_twd_per_usd"] == 31.2
    assert q1["actual"]["revenue_twd_bn"] == 133.458 and q1["actual"]["gross_margin_pct"] == 52.4
    assert q1["verdicts"] == {"revenue_twd_bn": "ABOVE", "gross_margin_pct": "ABOVE"}
    assert q1["not_compared"] == ["opex_ratio_pct"] and any("一次性項目" in n for n in q1["notes"])
    assert g["quarters"]["2026Q2"]["verdicts"] == {"revenue_twd_bn": "ABOVE", "gross_margin_pct": "WITHIN"}
    md = gm.markdown(g)
    assert "十億新台幣" in md and "公告未列實際值，未比較" in md


def test_parser_dispatch_and_numbers():
    assert gm.parse_eps_announcement("本公司董事會通過")[0] is None
    assert [_cn_number(x) for x in (113, 3, 12, 10)] == ["一百一十三", "三", "十二", "十"]


def test_tampered_mediatek_revenue_detail():
    rec = [r for r in MANIFEST["requests"] if r["kind"] == "t05st01_detail"
           and r["params"]["document_id"].startswith("t05st01:2454:20250410:165554")][0]
    tmp = tempfile.mkdtemp(prefix="mtk_tamper_")
    try:
        dst = os.path.join(tmp, "run")
        shutil.copytree(RUN, dst)
        path = os.path.join(dst, rec["response_file"])
        data = open(path, "rb").read()
        assert "一百一十四年三月份".encode() in data
        bad = data.replace("一百一十四年三月份".encode(), "一百一十四年四月份".encode())
        open(path, "wb").write(bad)
        # 雜湊仍然記錄原值 → 先被雜湊擋下；即使同時改了 manifest 的雜湊，也會被內容核對擋下
        s = ce.replay(dst, REVIEWS)
        assert s["quarters"]["2025Q1"]["status"] == "PROVISIONAL"
        import hashlib
        m = json.load(open(os.path.join(dst, "manifest.json"), encoding="utf-8"))
        for r in m["requests"]:
            if r.get("response_file") == rec["response_file"]:
                r["response_sha256"] = hashlib.sha256(bad).hexdigest()
        json.dump(m, open(os.path.join(dst, "manifest.json"), "w", encoding="utf-8"))
        s = ce.replay(dst, REVIEWS)
        q = s["quarters"]["2025Q1"]
        assert q["status"] == "PROVISIONAL" and any("營收年月與主旨不一致" in b for b in q["blocking"]), q["blocking"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
