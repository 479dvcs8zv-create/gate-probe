"""
test_v433_checkpoint.py (v4.33)
===============================
起因：gate-pipeline-batch run 39213015387 把民國 112 年加進來，2330 要新抓約 250 則 112 年的詳細頁，
官方網站每則約 10 秒，35 分鐘時被取消；已經抓到的 186 則因為 manifest 只在最後才寫，下次無法沿用。
v4.33：蒐證中途每 10 個請求或 30 秒寫一次 manifest（partial），被取消或逾時後仍能沿用已取得的詳細頁。

  python test_v433_checkpoint.py
"""
import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import batch_report as br  # noqa: E402
import collect_evidence as ce  # noqa: E402
import test_collect_offline as tco  # noqa: E402


def test_partial_manifest_written_and_reusable():
    out, manifest, summary = tco._run_collect(ce.load_reviews(os.path.join(HERE, "contract", "mops_real", "reviews")))
    try:
        mf = os.path.join(out, "manifest.json")
        assert os.path.exists(mf) and not os.path.exists(mf + ".tmp")
        part = json.load(open(mf, encoding="utf-8"))
        assert part["partial"] is True and part["checkpoint_at"]
        done = [r for r in part["requests"] if r["kind"] == "t05st01_detail" and r.get("parsed")]
        assert done and len(part["requests"]) <= len(manifest["requests"])
        # 模擬「這次被取消」：只有中途的 manifest 與 responses，沒有 summary → 下次蒐證可以沿用
        parent = tempfile.mkdtemp()
        try:
            shutil.copytree(out, os.path.join(parent, "111"))
            cache = ce._detail_cache(parent, os.path.join(parent, "222"))
            assert {r["params"]["document_id"] for r in done} <= set(cache)
            rep = br.company_entry("2330", os.path.join(parent, "111"))
            assert rep["ok"] is False and rep["partial"] is True and f"已取得的 {len(done)} 則" in rep["reason"]
        finally:
            shutil.rmtree(parent, ignore_errors=True)
    finally:
        shutil.rmtree(out, ignore_errors=True)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
