"""
test_backfill_real_39200908159.py (v4.29)
=========================================
第一次真實歷史補齊（gate-pipeline-archive run 39200908159，v4.28，2026-10-19）：
沿用先前的封存索引，新下載 5 份 2024–2025 年的他人 Wayback 存檔（4 份被 Wayback 拒絕連線，下次再試）。
這些較舊的頁面版面不同，v4.29 依原文補上解析規則，看不懂的仍明確不解析：
  - Yahoo 2024-06：表頭寫「CURRENCY IN USD」（大寫）；營收表當時是美元
  - Yahoo 2024-03：舊版面，幣別只在整個區塊標一次 → UNSUPPORTED_LAYOUT（不猜各表幣別）
  - MarketBeat 2024-06：表頭多一欄「Company Guidance」
  - StockAnalysis 2024-07：代號寫「stocks/TSM」、沒有會計年度欄位；EPS 是每 ADR 的新台幣
    （頁面 2024Q1 實際值 43.5＝官方每股 8.70 的 5 倍）——同一網站 2025-12 版改成每股，規則 4 維持待確認
  - 截止點前較早的快照（和最新一筆相差超過 7 天）也要審查，只是不一起比較差異

  python test_backfill_real_39200908159.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import consensus_parsers as cp  # noqa: E402
import consensus_research as cr  # noqa: E402
import snapshot_audit as sa  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "archive_39200908159")
SMP = os.path.join(RUN, "backfill", "samples")
BF = json.load(open(os.path.join(RUN, "backfill", "backfill.json"), encoding="utf-8"))


def _p(name, sid):
    return cp.parse_capture(sid, open(os.path.join(SMP, name), "rb").read(), "2330", "TSM")


def test_run_record():
    got = {(s["id"], x["timestamp"]): x for s in BF["sources"] for x in s["samples"]}
    assert sum(1 for x in got.values() if x.get("digest_matched")) == 5
    assert sum(1 for x in got.values() if "Connection refused" in (x.get("error") or "")) == 4
    reused = [s["id"] for s in BF["sources"] if (s.get("cdx") or {}).get("reused_from")]
    assert set(reused) == {"yahoo_adr_analysis", "yahoo_tw_analysis", "marketbeat_adr_earnings", "stockanalysis_adr_forecast"}


def test_older_layouts():
    y = _p("yahoo_adr_analysis_2024Q2_20240619114251.bin", "yahoo_adr_analysis")
    e = {(x["metric"], x["fiscal_period"]): x for x in y["estimates"]}
    assert (e[("eps", "2024Q2")]["currency"], e[("eps", "2024Q2")]["n_analysts"], e[("eps", "2024Q2")]["avg"]) == ("USD", 5, 1.38)
    assert e[("revenue", "2024Q2")]["currency"] == "USD" and e[("revenue", "2024Q2")]["avg"] == 20.02e9
    old = _p("yahoo_adr_analysis_2024Q1_20240314023526.bin", "yahoo_adr_analysis")
    assert old["status"] == "UNSUPPORTED_LAYOUT" and old["estimates"] == []
    m = _p("marketbeat_adr_earnings_2024Q2_20240629225725.bin", "marketbeat_adr_earnings")
    q2 = [x for x in m["estimates"] if x["fiscal_period"] == "2024Q2" and x["metric"] == "eps"][0]
    assert (q2["avg"], q2["n_analysts"]) == (1.33, 1) and not m.get("unparsed_rows")
    s = _p("stockanalysis_adr_forecast_2024Q2_20240701151026.bin", "stockanalysis_adr_forecast")
    q = [x for x in s["estimates"] if x["fiscal_period"] == "2024Q2" and x["metric"] == "eps"][0]
    assert q["currency"] == "TWD" and q["n_analysts"] == 26 and round(q["avg"], 2) == 45.58
    act = {x["fiscal_period"]: x["eps_actual"] for x in s["retrospective"]}
    assert act["2024Q1"] == 43.5 and any("只由日期" in n for n in s["notes"])


def test_audit_includes_older_snapshots_and_shows_share_basis_evidence():
    caps = cr.load_all_captures([os.path.join(BASE, d) for d in ("archive_39122089604", "archive_39186897770",
                                                                   "archive_39187117065", "archive_39200908159")],
                                [os.path.join(BASE, "run_39118440897", "consensus_discovery"), os.path.join(RUN, "backfill")])
    cut = cr.cutoffs_from_summary(json.load(open(os.path.join(BASE, "run_39126755093", "summary.json"), encoding="utf-8")))
    off = ce.replay(os.path.join(BASE, "run_39126755093"), ce.load_reviews(os.path.join(BASE, "reviews")))["official_figures"]
    a = sa.audit(cr.build("2330", caps, cut), caps, {}, off)
    q2 = {(x["metric"], x["source_id"]): x for x in a["items"] if x["fiscal_period"] == "2024Q2"}
    assert set(q2) == {("eps", "marketbeat_adr_earnings"), ("eps", "stockanalysis_adr_forecast"), ("eps", "yahoo_adr_analysis"),
                       ("revenue", "stockanalysis_adr_forecast"), ("revenue", "yahoo_adr_analysis")}
    y = q2[("eps", "yahoo_adr_analysis")]   # 6/19 的存檔比 MarketBeat 6/30 早 11 天：不一起比較，但照樣審查
    assert y["verdict"] == "PENDING" and "1.48 美元" in [c for c in y["checks"] if c["check"] == "單位"][0]["detail"]
    r = q2[("revenue", "yahoo_adr_analysis")]
    assert "20.82 十億美元" in [c for c in r["checks"] if c["check"] == "單位"][0]["detail"]   # 修正後的官方美元營收
    s = q2[("eps", "stockanalysis_adr_forecast")]
    ev = [c for c in s["checks"] if c["check"] == "頁面實際值對照"][0]["detail"]
    assert "2024Q1 頁面 43.5／官方 8.7" in ev and "SHARE_BASIS_UNSTATED" in s["pending_categories"]
    claims = [c for c in s["checks"] if c["check"] == "事後說法"]
    assert not claims or "USD" not in claims[0]["detail"]   # 新台幣的快照不和美元的事後說法放在一起
    assert a["counts"]["NOT_ADOPTABLE"] == 0


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
