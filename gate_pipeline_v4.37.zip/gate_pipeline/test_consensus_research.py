"""
test_consensus_research.py (v4.25)
==================================
B（市場共識解析器）：用真實封存原文測試，只產生研究紀錄，不影響 Gate。
  - 自行存檔：gate-pipeline-archive run 39186897770、39187117065（2026-10-19，Yahoo ADR／台股、Nasdaq API、
    Zacks、MarketBeat）、39122089604（2026-10-18）
  - 他人 Wayback 存檔：collect run 39118440897 的探測抽樣（Yahoo 2025-01-07、2025-02-24，MarketBeat、
    StockAnalysis、Nasdaq 網頁）
規則（使用者 2026-10-18）：差異只記錄不選邊、人數不加總、數值相同不代表獨立、必須核對目標季度與期間。

  python test_consensus_research.py
"""
import copy
import json
import os
import re
import shutil
import sys
import tempfile
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import consensus_parsers as cp  # noqa: E402
import consensus_research as cr  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
A1 = os.path.join(BASE, "archive_39186897770")
A2 = os.path.join(BASE, "archive_39187117065")
A0 = os.path.join(BASE, "archive_39122089604")
DISC = os.path.join(BASE, "run_39118440897", "consensus_discovery")
CUT = cr.cutoffs_from_summary(json.load(open(os.path.join(BASE, "run_39126755093", "summary.json"), encoding="utf-8")))
NOW = datetime(2026, 10, 19, 3, 0, tzinfo=timezone.utc)


def _cap(d, name):
    return open(os.path.join(d, "captures", name), "rb").read()


def _caps():
    return ([x for d in (A0, A1, A2) for x in cr.captures_from_archive_dir(d)] + cr.captures_from_discovery_dir(DISC))


R = cr.build("2330", _caps(), CUT, now=NOW)


def _group(period, metric, currency, quote=None):
    gs = [g for g in R["periods"][period]["groups"] if g["metric"] == metric and g["currency"] == currency
          and (quote is None or g["quote"] == quote)]
    assert len(gs) == 1, (period, metric, currency, [(g["metric"], g["currency"], g["quote"]) for g in
                                                     R["periods"][period]["groups"]])
    return gs[0]


def test_yahoo_both_pages_and_basis():
    a = cp.parse_capture("yahoo_adr_analysis", _cap(A1, "yahoo_adr_analysis_20261019014822.bin"), "2330", "TSM")
    t = cp.parse_capture("yahoo_tw_analysis", _cap(A1, "yahoo_tw_analysis_20261019015426.bin"), "2330", "TSM")
    assert a["status"] == t["status"] == "PARSED" and a["page"]["quote"] == "TSM" and t["page"]["quote"] == "2330.TW"
    e = [x for x in a["estimates"] if x["metric"] == "eps" and x["fiscal_period"] == "2026Q4"][0]
    assert (e["currency"], e["basis"], e["n_analysts"], e["avg"], e["low"], e["high"], e["year_ago"]) == \
        ("USD", "normalized", 8, 5.16, 5.1, 5.28, 3.14), e
    e = [x for x in t["estimates"] if x["metric"] == "eps" and x["fiscal_period"] == "2026Q4"][0]
    assert (e["currency"], e["basis"], e["n_analysts"], e["avg"]) == ("TWD", "normalized", 22, 32.96)
    r = [x for x in a["estimates"] if x["metric"] == "revenue" and x["fiscal_period"] == "2026Q4"][0]
    assert r["currency"] == "TWD" and r["avg"] == 1.71e12 and r["n_analysts"] == 27   # ADR 頁面的營收表是新台幣
    # 網站事後列出的歷史預估不是快照
    assert a["retrospective"] and all("無法證明" in x["note"] for x in a["retrospective"])
    assert {v["table"] for v in a["vendor_history"]} == {"epsTrend", "epsRevisions"}


def test_yahoo_old_layout_2025():
    """2025 年版面（沒有 GAAP／Normalized 切換）：口徑記為 None（頁面沒寫），不猜。"""
    r = cp.parse_capture("yahoo_adr_analysis", open(os.path.join(DISC, "samples", "yahoo_adr_analysis_2024Q4.bin"), "rb")
                         .read(), "2330", "TSM")
    e = [x for x in r["estimates"] if x["metric"] == "eps" and x["fiscal_period"] == "2024Q4"][0]
    assert (e["n_analysts"], e["avg"], e["low"], e["high"], e["basis"]) == (6, 2.23, 2.11, 2.43, None)


def test_symbol_and_period_checks():
    body = _cap(A1, "yahoo_tw_analysis_20261019015426.bin")
    r = cp.parse_capture("yahoo_adr_analysis", body, "2330", "TSM")   # 台股頁面被當成 ADR 頁面
    assert r["status"] == "SYMBOL_MISMATCH" and r["estimates"] == []
    r = cp.parse_capture("yahoo_tw_analysis", body, "2454", None)      # 換成別家公司
    assert r["status"] == "SYMBOL_MISMATCH" and r["estimates"] == []
    bad = cp.decode(body).replace(b"Current Qtr. (Dec 2026)", b"Current Qtr. (Nov 2026)")
    r = cp.parse_capture("yahoo_tw_analysis", bad, "2330", "TSM")
    odd = [x for x in r["estimates"] if x["period_label_raw"] == "Current Qtr. (Nov 2026)"]
    assert odd and all(x["fiscal_period"] is None and "PERIOD_UNMAPPED" in x["flags"] for x in odd)
    n = cp.parse_capture("nasdaq_api_forecast", _cap(A1, "nasdaq_api_forecast_20261019020624.bin"), "2330", "UMC")
    assert n["status"] == "SYMBOL_MISMATCH"
    assert cp.parse_capture("cnyes_tw", b"x", "2330", "TSM")["status"] == "UNPARSED"


def test_nasdaq_marketbeat_zacks_stockanalysis():
    n = cp.parse_capture("nasdaq_api_forecast", _cap(A1, "nasdaq_api_forecast_20261019020624.bin"), "2330", "TSM",
                         "美元／ADR")
    e = [x for x in n["estimates"] if x["fiscal_period"] == "2026Q4"][0]
    assert (e["avg"], e["n_analysts"], e["currency"], e["currency_from"]) == (4.74, 5, "USD", "config_assumption")
    assert any("asOf 是空的" in x for x in n["notes"])
    m = cp.parse_capture("marketbeat_adr_earnings", _cap(A2, "marketbeat_adr_earnings_20261019022843.bin"), "2330", "TSM")
    fy = [x for x in m["estimates"] if x["fiscal_period"] == "FY2026" and x["metric"] == "eps"][0]
    assert fy["avg"] == 11.07 and fy["n_analysts"] == 4 and "FY_ROW_IS_SUM_OF_QUARTERS" in fy["flags"]
    q4 = [x for x in m["estimates"] if x["fiscal_period"] == "2026Q4" and x["metric"] == "eps"][0]
    assert (q4["avg"], q4["n_analysts"]) == (3.12, 1)
    assert [g["range_raw"] for g in m["company_guidance_shown"] if g["fiscal_period"] == "2026Q4"] == ["$52.3 B - $54.3 B"]
    z = cp.parse_capture("zacks_adr_detailed", _cap(A1, "zacks_adr_detailed_20261019020044.bin"), "2330", "TSM")
    assert z["status"] == "BLOCKED_PAGE" and z["estimates"] == []
    s = cp.parse_capture("stockanalysis_adr_forecast", open(os.path.join(DISC, "samples",
                         "stockanalysis_adr_forecast_2025Q4.bin"), "rb").read(), "2330", "TSM", "美元／ADR")
    assert s.get("config_unit_mismatch") and s["page"]["financial_currency"] == "TWD"
    e = [x for x in s["estimates"] if x["fiscal_period"] == "2025Q4" and x["metric"] == "eps"][0]
    assert (e["currency"], e["n_analysts"], round(e["avg"], 4), e["low"]) == ("TWD", 24, 17.6422, None)
    assert not [x for x in s["estimates"] if x["fiscal_period"] in ("2026Q2", "2026Q3")]   # 付費（[PRO]）不輸出
    h = cp.parse_capture("nasdaq_adr_earnings", open(os.path.join(DISC, "samples", "nasdaq_adr_earnings_2024Q4.bin"),
                         "rb").read(), "2330", "TSM")
    assert h["status"] == "NO_CONSENSUS_VALUE"


def test_ledger_rules_no_choice_no_sum():
    assert R["data_mode"] == "MARKET_CONSENSUS_RESEARCH" and R["gate_impact"] == "none"
    assert R["boundary_rule"]["status"] == "adopted"
    g = _group("2026Q4", "eps", "USD", "TSM")
    assert g["choice"] is None and {e["source_id"] for e in g["entries"]} == \
        {"yahoo_adr_analysis", "nasdaq_api_forecast", "marketbeat_adr_earnings"}
    assert g["n_analysts_by_source"] == {"marketbeat_adr_earnings": 1, "nasdaq_api_forecast": 5, "yahoo_adr_analysis": 8}
    assert g["difference"]["avg_min"] == 3.12 and g["difference"]["avg_max"] == 5.16
    assert {"BASIS_DIFFERS_OR_UNSTATED", "CURRENCY_ASSUMED", "SINGLE_ESTIMATE_SOURCE"} <= set(g["flags"])
    text = json.dumps(R, ensure_ascii=False)
    assert not re.search(r'"(n_total|total_analysts|analysts_total|selected|chosen|pass)"', text)
    md = cr.markdown(R)
    assert "不加總" in md and "合計" not in md and "總計" not in md
    rows = [ln for ln in md.splitlines() if ln.startswith("| eps USD TSM") and "季度尚未結束" in ln]
    assert sorted(int(ln.split("|")[5]) for ln in rows if ln.split("|")[5].strip()) == [1, 1, 5, 5, 8, 10]
    # 台股 EPS（新台幣／2330.TW）與 ADR EPS（美元／TSM）不放在同一組比較
    assert _group("2026Q4", "eps", "TWD", "2330.TW")["entries"][0]["avg"] == 32.96


def test_identical_yahoo_revenue_flagged_not_independent():
    g = _group("2026Q4", "revenue", "TWD")
    assert "IDENTICAL_VALUES" in g["flags"] and any("同一家網站的不同頁面" in n for n in g["notes"])
    assert g["difference"]["spread"] == 0


def test_timing_against_cutoffs():
    g = _group("2024Q4", "eps", "USD", "TSM")
    e = g["entries"][0]
    assert e["source_id"] == "yahoo_adr_analysis" and e["origin"] == "third_party_wayback" and e["timing"] == "BEFORE_CUTOFF"
    assert e["timing_info"]["announced_at"] == "2025-01-10T14:05:13+08:00"
    assert e["timing_info"]["conservative_boundary"] == "2025-01-10T00:00:00+08:00"
    assert (e["n_analysts"], e["avg"]) == (6, 2.23)
    # 2026-10-19 的存檔對 2026Q3（截止點 2026-10-08）是截止點之後 → 不進入比較
    assert not any(e["capture_ts"].startswith("202610") for g in R["periods"]["2026Q3"]["groups"] for e in g["entries"])
    # MarketBeat 2025-02 的存檔對 2025Q4 太早（超過 45 天）→ 不比較，只留在 series
    assert not any(e["source_id"] == "marketbeat_adr_earnings" for g in R["periods"]["2025Q4"]["groups"]
                   for e in g["entries"])
    assert all(e["timing"] == "BEFORE_QUARTER_END" for g in R["periods"]["2026Q4"]["groups"] for e in g["entries"])
    # 公告當天、公告時間之前的存檔：BEFORE_ANNOUNCEMENT_SAME_DAY（v4.26 採用 00:00 界線：不算截止點前）
    t, info = cr._timing("2025Q3", datetime(2025, 10, 9, 2, 0, tzinfo=timezone.utc), CUT)
    assert t == "BEFORE_ANNOUNCEMENT_SAME_DAY" and info["conservative_boundary"] == "2025-10-09T00:00:00+08:00"
    assert cr._timing("2025Q3", datetime(2025, 10, 9, 7, 0, tzinfo=timezone.utc), CUT)[0] == "AFTER_CUTOFF"
    assert cr._timing("2025Q3", datetime(2025, 10, 8, 15, 59, tzinfo=timezone.utc), CUT)[0] == "BEFORE_CUTOFF"


def test_same_day_capture_not_compared():
    """同一份 2025-01-07 的 Yahoo 原文，把存檔時間改成 2024Q4 營收公告當天 09:00（公告 14:05 之前）→ 不進入比較。"""
    caps = [c for c in cr.captures_from_discovery_dir(DISC) if c["source_id"] == "yahoo_adr_analysis"
            and c["capture_ts"] == "20250106225927"]
    assert len(caps) == 1
    same_day = dict(caps[0], capture_ts="20250110010000")
    r = cr.build("2330", [same_day], CUT, now=NOW)
    assert not r["periods"].get("2024Q4", {}).get("groups")
    s = [x for x in r["series"] if x["fiscal_period"] == "2024Q4"]
    assert s == []   # 只有一筆就不列 series；但原始資料仍在 captures 裡
    assert r["captures"][0]["parse_status"] == "PARSED"
    r = cr.build("2330", caps, CUT, now=NOW)
    assert r["periods"]["2024Q4"]["groups"]


def test_stale_and_duplicate_content_flagged():
    nas = [c for c in R["captures"] if c["source_id"] == "nasdaq_api_forecast"]
    assert [c.get("same_content_as") for c in nas] == [None, "20261018111636"]
    s = [x for x in R["series"] if x["source_id"] == "marketbeat_adr_earnings" and x["fiscal_period"] == "2026Q4"
         and x["metric"] == "eps"][0]
    assert s["points"][-1]["unchanged_since"] == "20260609090716"


def test_tampered_capture_excluded():
    tmp = tempfile.mkdtemp(prefix="research_")
    try:
        d = os.path.join(tmp, "archive_x")
        shutil.copytree(A1, d)
        f = os.path.join(d, "captures", "nasdaq_api_forecast_20261019020624.bin")
        open(f, "ab").write(b" ")
        r = cr.build("2330", cr.captures_from_archive_dir(d), CUT, now=NOW)
        assert [c["integrity"] for c in r["excluded"]] == ["SHA256_MISMATCH"]
        assert not any(e["source_id"] == "nasdaq_api_forecast" for p in r["periods"].values() for g in p["groups"]
                       for e in g["entries"])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_archiver_order_and_research_output():
    import archive_consensus as ac
    tmp = tempfile.mkdtemp(prefix="order_")
    try:
        root = os.path.join(tmp, "results", "2330", "archive")
        for d in (A0, A1, A2):
            shutil.copytree(d, os.path.join(root, os.path.basename(d).replace("archive_", "")))
        t, adr = ac.archive_targets("2330")
        o, basis = ac.order_targets(t, root)
        assert [x["id"] for x in o][:2] == ["marketwatch_adr_estimates", "stockanalysis_adr_forecast"]
        assert "zacks_adr_detailed" not in [x["id"] for x in t]   # 防機器人頁面，不再送封存
        assert basis[-1] == {"id": "marketbeat_adr_earnings", "last_archived": "20261019022843"}
        arch, disc, summary = cr.discover_inputs(os.path.join(tmp, "results", "2330"))
        assert len(arch) == 3 and disc == [] and summary is None
        # 封存程式結束時產生研究紀錄（時間上限 0：不送任何網站，只測研究紀錄這一步）
        shutil.copytree(os.path.join(BASE, "run_39126755093"), os.path.join(tmp, "results", "2330", "39126755093"),
                        ignore=shutil.ignore_patterns("responses", "requests"))
        out = os.path.join(root, "99999")
        assert ac.main(["--co-id", "2330", "--out", out, "--time-budget", "0", "--backfill-time-budget", "0",
                        "--base-url", "http://127.0.0.1:9"]) == 0
        rr = json.load(open(os.path.join(out, "research.json"), encoding="utf-8"))
        assert rr["gate_impact"] == "none" and rr["cutoff_source"] == os.path.join("39126755093", "summary.json")
        assert len(rr["captures"]) == 7 and rr["periods"]["2026Q4"]["groups"]
        au = json.load(open(os.path.join(out, "snapshot_audit.json"), encoding="utf-8"))
        assert au["gate_impact"] == "none" and au["items"] == []   # 自行存檔都還在季度內，沒有截止點前的歷史快照
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
