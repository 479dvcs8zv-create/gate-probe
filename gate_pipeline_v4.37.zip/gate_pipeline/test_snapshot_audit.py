"""
test_snapshot_audit.py (v4.28)
==============================
歷史市場共識快照：補齊（Actions 才能連 Wayback，這裡用本機模擬）與逐項資格審查（真實存檔原文）。
  - 審查：原文完整性、封存索引對應、重新下載核對、時間（嚴格早於快照界線）、代號、期間、單位、口徑、人數、是否更新
  - 判定：任何 FAIL → 不可採用；有 PENDING → 待確認（列出待決定的規則）；全部通過 → 可採用（不等於 Gate PASS）
  - 補齊：只抓快照界線之前 45 天內最新一筆（界線當下 00:00 那一筆不算）、已取得的不重抓、審查候選重新下載核對

  python test_snapshot_audit.py
"""
import base64
import copy
import hashlib
import http.server
import json
import os
import shutil
import sys
import tempfile
import threading
import urllib.parse
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import consensus_backfill as cb  # noqa: E402
import consensus_research as cr  # noqa: E402
import official_figures as of  # noqa: E402
import snapshot_audit as sa  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
ARCH = [os.path.join(BASE, d) for d in ("archive_39122089604", "archive_39186897770", "archive_39187117065")]
DISC = os.path.join(BASE, "run_39118440897", "consensus_discovery")
SUMMARY = json.load(open(os.path.join(BASE, "run_39126755093", "summary.json"), encoding="utf-8"))
CUT = cr.cutoffs_from_summary(SUMMARY)
NOW = datetime(2026, 10, 19, 4, 0, tzinfo=timezone.utc)
CAPS = cr.load_all_captures(ARCH, [DISC])
R = cr.build("2330", CAPS, CUT, now=NOW)
OFFICIAL = ce.replay(os.path.join(BASE, "run_39126755093"), ce.load_reviews(os.path.join(BASE, "reviews")))["official_figures"]
MATCHED = {k: {"status": "MATCHED", "run": "39197661828"} for k in (   # Actions run 39197661828 的實際結果
    ("yahoo_adr_analysis", "20250106225927"), ("marketbeat_adr_earnings", "20250227184442"),
    ("yahoo_adr_analysis", "20250224154350"), ("stockanalysis_adr_forecast", "20251206120326"),
    ("marketbeat_adr_earnings", "20260609090716"))}


def _item(a, fp, metric, sid):
    xs = [x for x in a["items"] if (x["fiscal_period"], x["metric"], x["source_id"]) == (fp, metric, sid)]
    assert len(xs) == 1, [(x["fiscal_period"], x["metric"], x["source_id"]) for x in a["items"]]
    return xs[0]


def _check(x, name):
    return [c for c in x["checks"] if c["check"] == name]


def test_official_figures_from_mops_text():
    """官方自結財務結果公告原文：每股、每單位 ADR EPS，新台幣（含「兆」）與美元營收。只取原文明寫的。"""
    assert {k: OFFICIAL["2024Q4"][k] for k in ("eps_twd_per_share", "eps_usd_per_adr", "revenue_twd_bn", "revenue_usd_bn")} \
        == {"eps_twd_per_share": 14.45, "eps_usd_per_adr": 2.24, "revenue_twd_bn": 868.46, "revenue_usd_bn": 26.88}
    assert OFFICIAL["2024Q4"]["document_id"] == "t05st01:2330:20250116:154039:1"
    assert OFFICIAL["2025Q4"]["revenue_twd_bn"] == 1046.09 and OFFICIAL["2025Q4"]["eps_usd_per_adr"] == 3.14
    # v4.29：Gemini 獨立核對抓到的 3 處——「若以美金計算」與「188億7千萬元」的千萬不能丟
    assert [OFFICIAL[q]["revenue_usd_bn"] for q in ("2023Q4", "2024Q1", "2024Q2", "2024Q3")] == [19.62, 18.87, 20.82, 23.5]
    assert of.parse_results_text("若以美元計算，2024年第一季營收為188億7千萬元")["revenue_usd_bn"] == 18.87
    assert "revenue_usd_bn" not in of.parse_results_text("每股盈餘為新台幣9.21元")   # 原文沒寫就不填
    assert of.parse_results_text("每股盈餘為新台幣19.50元", "台積公司2025年第四季每股盈餘新台幣19.51元").get("error")
    mtk = ce.replay(os.path.join(BASE, "run_2454_39136575628"), ce.load_reviews(os.path.join(BASE, "reviews")))
    assert mtk["official_figures"]["2024Q4"]["eps_twd_per_share"] == 14.95
    assert "eps_usd_per_adr" not in mtk["official_figures"]["2024Q4"]


def test_rules_applied_to_real_snapshots():
    """使用者採用的四條規則＋ Actions 的重新下載結果（全部相符）：可採用 4、待確認 5、不可採用 0。"""
    a = sa.audit(R, CAPS, MATCHED, OFFICIAL, now=NOW)
    assert a["gate_impact"] == "none" and a["counts"] == {"ADOPTABLE": 4, "PENDING": 5, "NOT_ADOPTABLE": 0}, a["counts"]
    y = _item(a, "2024Q4", "eps", "yahoo_adr_analysis")
    res = {c["check"]: c["result"] for c in y["checks"]}
    assert res["原文完整性"] == res["封存索引對應"] == res["重新下載核對"] == res["時間"] == res["目標期間"] == "PASS", res
    assert res["單位"] == "PASS" and "2.24 美元" in _check(y, "單位")[0]["detail"]          # 規則 1：官方每單位 ADR
    assert "4 季相同" in _check(y, "頁面實際值對照")[0]["detail"]
    assert y["pending_categories"] == ["BASIS_UNSTATED"] and y["verdict"] == "PENDING"        # 規則 2
    assert res["人數"] == "INFO" and y["coverage"] == "一般"                                  # 規則 3
    m = _item(a, "2025Q1", "eps", "marketbeat_adr_earnings")
    assert m["coverage"] == "單一預估" and m["pending_categories"] == ["BASIS_UNSTATED"]
    s = _item(a, "2025Q4", "eps", "stockanalysis_adr_forecast")
    assert s["pending_categories"] == ["BASIS_UNSTATED", "SHARE_BASIS_UNSTATED"]                # 規則 4
    assert "2024Q4 頁面 13.8704／官方 14.45 不同" in _check(s, "頁面實際值對照")[0]["detail"]
    r = _item(a, "2024Q4", "revenue", "yahoo_adr_analysis")
    assert r["verdict"] == "ADOPTABLE" and r["evidence"]["official"]["revenue_twd_bn"] == 868.46
    assert r["evidence"]["wayback_url"] == "https://web.archive.org/web/20250106225927/https://finance.yahoo.com/quote/TSM/analysis/"
    assert r["evidence"]["cdx_responses"][0]["file"] == "yahoo_adr_analysis_00.json"
    u = _item(a, "2026Q2", "revenue", "marketbeat_adr_earnings")
    assert u["verdict"] == "ADOPTABLE" and "40.2 十億美元" in _check(u, "單位")[0]["detail"] and u["coverage"] == "人數未知"
    assert a["open_decisions"] == {} and "MIN_ANALYSTS" not in json.dumps(a)
    retro = _check(y, "事後說法")[0]["detail"]
    assert "2.16 USD" in retro and "2.22 USD" in retro and "快照實際是 2.23" in retro
    md = sa.markdown(a)
    assert "不是 Gate PASS" in md and "官方同單位（事後公布）" in md and "| 2.24 |" in md


def test_without_official_or_refetch_stays_pending():
    a = sa.audit(R, CAPS, {}, {}, now=NOW)
    assert a["counts"] == {"ADOPTABLE": 0, "PENDING": 9, "NOT_ADOPTABLE": 0}
    y = _item(a, "2024Q4", "eps", "yahoo_adr_analysis")
    assert set(y["pending_categories"]) == {"REFETCH", "BASIS_UNSTATED", "OFFICIAL_FIGURE_MISSING"}
    only_twd = {q: {"eps_twd_per_share": v["eps_twd_per_share"]} for q, v in OFFICIAL.items() if "eps_twd_per_share" in v}
    a = sa.audit(R, CAPS, MATCHED, only_twd, now=NOW)    # 官方只有新台幣每股 → 不自行換匯
    assert "不自行換匯" in _check(_item(a, "2024Q4", "eps", "yahoo_adr_analysis"), "單位")[0]["detail"]


def test_refetch_outcomes_are_distinguished():
    k = ("yahoo_adr_analysis", "20250106225927")
    base = dict(MATCHED)
    for st, verdict, word in (("ARCHIVE_UNAVAILABLE", "ADOPTABLE", "不代表內容被竄改"), ("NETWORK_FAILED", "PENDING", "網路失敗"),
                              ("MISMATCH_LOCAL", "NOT_ADOPTABLE", "保存的原文有問題"),
                              ("MISMATCH_ARCHIVE", "NOT_ADOPTABLE", "封存服務送出的內容不同")):
        rf = dict(base)
        rf[k] = {"status": st, "run": "x", "reason": "HTTP 404" if st == "ARCHIVE_UNAVAILABLE" else "timed out"}
        x = _item(sa.audit(R, CAPS, rf, OFFICIAL, now=NOW), "2024Q4", "revenue", "yahoo_adr_analysis")
        c = _check(x, "重新下載核對")[0]
        assert word in c["detail"], (st, c)
        assert x["verdict"] == ("PENDING" if verdict == "ADOPTABLE" else verdict), (st, x["verdict"])


def test_tampered_evidence_not_adoptable():
    tmp = tempfile.mkdtemp(prefix="audit_")
    try:
        d = os.path.join(tmp, "disc")
        shutil.copytree(DISC, d)
        f = os.path.join(d, "cdx", "yahoo_adr_analysis_00.json")
        rows = json.load(open(f))
        for r in rows[1:]:
            if r[0] == "20250106225927":
                r[3] = "X" * 32        # 竄改索引裡的摘要
        open(f, "w").write(json.dumps(rows))
        caps = cr.load_all_captures(ARCH, [d])
        a = sa.audit(cr.build("2330", caps, CUT, now=NOW), caps, {}, now=NOW)
        y = _item(a, "2024Q4", "eps", "yahoo_adr_analysis")
        assert y["verdict"] == "NOT_ADOPTABLE" and _check(y, "封存索引對應")[0]["result"] == "FAIL"
        caps2 = copy.deepcopy(CAPS)
        for c in caps2:
            if (c["source_id"], c["capture_ts"]) == ("yahoo_adr_analysis", "20250224154350"):
                c["archive_digest"] = "Y" * 32   # 紀錄的封存摘要與原文不符
        a = sa.audit(cr.build("2330", caps2, CUT, now=NOW), caps2, {}, now=NOW)
        y = _item(a, "2025Q1", "eps", "yahoo_adr_analysis")
        assert y["verdict"] == "NOT_ADOPTABLE" and _check(y, "原文完整性")[0]["result"] == "FAIL"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_adoptable_path_and_strict_boundary():
    """台股頁（新台幣／每股、寫明口徑、人數 22）＋索引對應＋重新下載相符 → 可採用；界線當下 00:00 的存檔不算。"""
    tmp = tempfile.mkdtemp(prefix="audit_")
    try:
        cap = [c for c in CAPS if c["source_id"] == "yahoo_tw_analysis"][0]
        raw = open(cap["file"], "rb").read()
        dig = base64.b32encode(hashlib.sha1(raw).digest()).decode()
        cdx = os.path.join(tmp, "cdx.json")
        url = "https://finance.yahoo.com/quote/2330.TW/analysis/"
        open(cdx, "w").write(json.dumps([["timestamp", "original", "statuscode", "digest", "mimetype", "length"],
                                         [cap["capture_ts"], url, "200", dig, "text/html", str(len(raw))]]))
        c = dict(cap, original=url, archive_digest=dig, cdx_files=[(cdx, hashlib.sha256(open(cdx, "rb").read()).hexdigest())])
        cut = dict(CUT, **{"2026Q4": {"at": "2026-11-20T13:30:00+08:00", "event_type": "quarter_revenue_complete",
                                      "status": "CUTOFF_VERIFIED"}})   # 合成的截止點，只為了走到審查
        r = cr.build("2330", [c], cut, now=NOW)
        a = sa.audit(r, [c], {("yahoo_tw_analysis", cap["capture_ts"]): {"status": "MATCHED", "run": "x"}},
                     {"2026Q4": {"eps_twd_per_share": 33.0}}, now=NOW)
        x = _item(a, "2026Q4", "eps", "yahoo_tw_analysis")
        assert x["verdict"] == "ADOPTABLE" and x["n_analysts"] == 22 and x["avg"] == 32.96, x["reasons"]
        # 截止點改成存檔當天（界線＝當日 00:00，存檔 09:54 不早於界線）→ 不算截止點前快照，不進入審查
        cut["2026Q4"]["at"] = "2026-10-19T13:30:00+08:00"
        r = cr.build("2330", [c], cut, now=NOW)
        assert not [x for x in sa.audit(r, [c], {}, now=NOW)["items"] if x["fiscal_period"] == "2026Q4"]
        t, _ = cr._timing("2026Q4", datetime(2026, 10, 18, 16, 0, tzinfo=timezone.utc), cut)   # 剛好 00:00
        assert t == "BEFORE_ANNOUNCEMENT_SAME_DAY"
        t, _ = cr._timing("2026Q4", datetime(2026, 10, 18, 15, 59, 59, tzinfo=timezone.utc), cut)
        assert t == "BEFORE_CUTOFF"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ------------------------------------------------------------------------------------- 補齊（本機模擬 Wayback）
YAHOO = open(os.path.join(DISC, "samples", "yahoo_adr_analysis_2024Q4.bin"), "rb").read()
PAGES = {}
HITS = []


def _d(b):
    return base64.b32encode(hashlib.sha1(b).digest()).decode()


class W(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body=b"", ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urllib.parse.urlsplit(self.path)
        HITS.append(u.path)
        if u.path == "/cdx/search/cdx":
            q = dict(urllib.parse.parse_qsl(u.query))
            rows = [["timestamp", "original", "statuscode", "digest", "mimetype", "length"]]
            for (ts, url), body in sorted(PAGES.items()):
                if url.split("://", 1)[1].startswith(q["url"]):
                    rows.append([ts, url, "200", _d(body), "text/html", str(len(body))])
            return self._send(200, json.dumps(rows).encode())
        if u.path.startswith("/web/"):
            ts, url = self.path[len("/web/"):].split("id_/", 1)
            body = PAGES.get((ts, url))
            return self._send(200, body, "text/html") if body is not None else self._send(404)
        self._send(400)


def test_backfill_fetches_new_skips_held_and_refetches():
    PAGES.clear()
    u = "https://finance.yahoo.com/quote/TSM/analysis/"
    PAGES[("20250106225927", u)] = YAHOO                 # 2024Q4 界線 2025-01-10 00:00 前（已取得過）
    PAGES[("20250109155959", u)] = YAHOO + b"<!--x-->"    # 界線前 1 秒（台北 2025-01-09 23:59:59）→ 新的、最新
    PAGES[("20250109160000", u)] = YAHOO + b"<!--y-->"    # 剛好等於界線 → 不算
    PAGES[("20240920000000", u)] = YAHOO + b"<!--z-->"    # 2024Q3（界線 2024-10-09 00:00）前 19 天
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), W)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    old = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    tmp = tempfile.mkdtemp(prefix="backfill_")
    try:
        held = {("yahoo_adr_analysis", "20250106225927"): {"sha256": hashlib.sha256(YAHOO).hexdigest()}}
        z = YAHOO + b"<!--z-->"
        refetch = [("yahoo_adr_analysis", "20250106225927", u, hashlib.sha256(YAHOO).hexdigest(), _d(YAHOO)),
                   ("yahoo_adr_analysis", "20240920000000", u, "0" * 64, _d(z)),        # 服務端符合摘要、我們保存的不同
                   ("yahoo_adr_analysis", "20240920000000", u, "0" * 64, "Q" * 32),     # 服務端與摘要不符
                   ("yahoo_adr_analysis", "20240101000000", u, "0" * 64, "Q" * 32)]     # 封存取不到（404）
        out = os.path.join(tmp, "results", "2330", "archive", "1", "backfill")
        bounds = cr.boundaries_from_summary(SUMMARY)
        r = cb.backfill("2330", bounds, out, held, refetch, base_url=f"http://127.0.0.1:{srv.server_address[1]}",
                        delay=0, sleep=lambda s: None, source_ids=("yahoo_adr_analysis",))
        y = r["sources"][0]
        assert y["quarters"]["2024Q4"]["timestamp"] == "20250109155959"      # 嚴格早於界線的最新一筆
        assert y["quarters"]["2024Q3"]["timestamp"] == "20240920000000"
        got = {x["quarter"]: x for x in y["samples"]}
        assert set(got) == {"2024Q4", "2024Q3"} and all(x["digest_matched"] for x in got.values())
        assert [x["status"] for x in r["refetch"]] == ["MATCHED", "MISMATCH_LOCAL", "MISMATCH_ARCHIVE",
                                                        "ARCHIVE_UNAVAILABLE"], r["refetch"]
        assert os.path.exists(os.path.join(out, "cdx", "yahoo_adr_analysis.json"))
        # 研究紀錄讀得到補齊的存檔；重新下載核對結果進入審查
        caps = cr.captures_from_backfill_dir(out)
        assert {c["capture_ts"] for c in caps} == {"20250109155959", "20240920000000"}
        assert all(c["cdx_files"] and c["original"] == u for c in caps)
        rf = cr.refetch_records([out])
        assert rf[("yahoo_adr_analysis", "20250106225927")]["status"] == "MATCHED"
        arch, disc, _ = cr.discover_inputs(os.path.join(tmp, "results", "2330"))
        assert disc == [out]
        # 已取得的不重抓
        held.update({("yahoo_adr_analysis", c["capture_ts"]): {"sha256": c["sha256"]} for c in caps})
        HITS.clear()
        r2 = cb.backfill("2330", bounds, os.path.join(tmp, "b2", "x", "backfill"), held, [], delay=0, sleep=lambda s: None,
                         base_url=f"http://127.0.0.1:{srv.server_address[1]}", source_ids=("yahoo_adr_analysis",),
                         prior_dirs=[out])
        assert r2["sources"][0]["samples"] == []
        assert HITS == [] and r2["sources"][0]["cdx"]["reused_from"]     # 歷史範圍已查過：沿用 CDX 回應，不再查詢
        # 只用截止點已驗證的季度
        b3 = dict(bounds, **{"2024Q4": dict(bounds["2024Q4"], status="PROVISIONAL")})
        r3 = cb.backfill("2330", b3, os.path.join(tmp, "b3"), {}, [], delay=0, sleep=lambda s: None,
                         base_url=f"http://127.0.0.1:{srv.server_address[1]}", source_ids=("yahoo_adr_analysis",))
        assert "2024Q4" not in r3["sources"][0]["quarters"]
    finally:
        os.environ.update(old)
        srv.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)


def test_boundaries_from_old_summary():
    b = cr.boundaries_from_summary(SUMMARY)   # v4.26 之前的 summary 沒有 snapshot_boundary，也要算出 00:00
    assert b["2024Q4"] == {"at": "2025-01-10T00:00:00+08:00", "status": "CUTOFF_VERIFIED",
                           "announced_at": "2025-01-10T14:05:13+08:00"}


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
