"""
test_unit_conflict_39203353595.py (v4.30)
=========================================
v4.29 實跑（gate-pipeline-archive run 39203353595）補齊到 Yahoo 2330.TW 頁面 2024-09-27 的存檔：
表頭寫「CURRENCY IN USD」，但數值其實是新台幣（EPS 預估 11.33、營收 746.3B；同頁歷史實際 EPS 9.21／8.70／9.56
正是官方每股新台幣 EPS）。v4.29 會照頁面標示當成美元比較，營收那筆在重新下載核對後會被誤判為可採用。
v4.30 新增「單位一致性」檢查：同頁歷史實際值符合另一種單位、或數量級與官方同單位數字差太多 → 待確認（不放行）。
另外：StockAnalysis 2026-06 起頁面明寫「EPS and Forward PE are based on non-GAAP adjusted numbers」→ 口徑由頁面讀出。

  python test_unit_conflict_39203353595.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import consensus_parsers as cp  # noqa: E402
import consensus_research as cr  # noqa: E402
import snapshot_audit as sa  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "archive_39203353595")
ARCH = [os.path.join(BASE, d) for d in ("archive_39122089604", "archive_39186897770", "archive_39187117065",
                                         "archive_39200908159", "archive_39203353595")]
DISC = [os.path.join(BASE, "run_39118440897", "consensus_discovery"), os.path.join(BASE, "archive_39200908159", "backfill"),
        os.path.join(RUN, "backfill")]
CAPS = cr.load_all_captures(ARCH, DISC)
CUT = cr.cutoffs_from_summary(json.load(open(os.path.join(BASE, "run_39126755093", "summary.json"), encoding="utf-8")))
OFF = ce.replay(os.path.join(BASE, "run_39126755093"), ce.load_reviews(os.path.join(BASE, "reviews")))["official_figures"]
ALL_MATCHED = {(c["source_id"], c["capture_ts"]): {"status": "MATCHED", "run": "x"} for c in CAPS}
A = sa.audit(cr.build("2330", CAPS, CUT), CAPS, ALL_MATCHED, OFF)


def _item(fp, metric, sid):
    return [x for x in A["items"] if (x["fiscal_period"], x["metric"], x["source_id"]) == (fp, metric, sid)][0]


def test_page_label_is_wrong_but_values_are_twd():
    raw = open([os.path.join(RUN, "backfill", "samples", f) for f in os.listdir(os.path.join(RUN, "backfill", "samples"))
                if f.startswith("yahoo_tw")][0], "rb").read()
    r = cp.parse_capture("yahoo_tw_analysis", raw, "2330", "TSM")
    e = [x for x in r["estimates"] if x["metric"] == "eps" and x["fiscal_period"] == "2024Q3"][0]
    assert e["currency"] == "USD" and e["avg"] == 11.33          # 頁面標示是 USD（照實記錄）
    acts = {x["fiscal_period"]: x["eps_actual"] for x in r["retrospective"]}
    assert [acts[q] for q in ("2023Q4", "2024Q1", "2024Q2")] == [9.21, 8.7, 9.56]   # 其實是官方每股新台幣


def test_unit_conflict_blocks_adoption_even_after_refetch():
    eps = _item("2024Q3", "eps", "yahoo_tw_analysis")
    rev = _item("2024Q3", "revenue", "yahoo_tw_analysis")
    for x in (eps, rev):
        assert x["verdict"] == "PENDING" and "UNIT_CONFLICT" in x["pending_categories"], x["pending_categories"]
    assert "官方每股新台幣 EPS 相同" in [c for c in eps["checks"] if c["check"] == "單位一致性"][0]["detail"]
    assert "31.76 倍" in [c for c in rev["checks"] if c["check"] == "單位一致性"][0]["detail"]
    # 同一季 ADR 頁（真的是美元）不受影響
    ok = _item("2024Q3", "revenue", "yahoo_adr_analysis")
    assert ok["verdict"] == "ADOPTABLE" and "UNIT_CONFLICT" not in ok["pending_categories"]
    assert A["counts"]["NOT_ADOPTABLE"] == 0


def test_stockanalysis_basis_read_from_page_when_stated():
    raw = cp.decode(open(os.path.join(BASE, "run_39118440897", "consensus_discovery", "samples",
                                      "stockanalysis_adr_forecast_2025Q4.bin"), "rb").read())
    r = cp.parse_capture("stockanalysis_adr_forecast", raw, "2330", "TSM")
    assert all(e["basis"] is None for e in r["estimates"] if e["metric"] == "eps")   # 「may be non-GAAP」＝未確定
    new = raw.replace(b"Historical EPS numbers are GAAP, while forecasted numbers may be non-GAAP.",
                      b"EPS and Forward PE are based on non-GAAP adjusted numbers.")
    r = cp.parse_capture("stockanalysis_adr_forecast", new, "2330", "TSM")
    assert {e["basis"] for e in r["estimates"] if e["metric"] == "eps" and e["period_type"] == "quarter"} == {"non_gaap_adjusted"}


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
