"""
official_figures.py (v4.29)
===========================
從公開資訊觀測站「自結財務結果」重大訊息的詳細頁原文，取出公司官方公布的同季數字（只取原文明寫的，不換算）：
  eps_twd_per_share   每股盈餘（新台幣／普通股）
  eps_usd_per_adr     折合美國存託憑證每單位（美元）—原文有寫才有（例如台積電）
  revenue_twd_bn      合併營收（十億新台幣）
  revenue_usd_bn      若以美元計算的營收（十億美元）—原文有寫才有

用途：市場共識研究的「單位」檢查（使用者 2026-10-19 採用：ADR 美元預估只和官方同季每單位 ADR 美元 EPS 比較，
不自行換匯）。不影響任何 Gate 判定。每一筆都記錄公告識別碼與詳細頁 SHA-256。
"""

import re

from mops_t05st01 import classify

_EPS_TSMC = re.compile(r"每股盈餘為新台幣(-?[\d.]+)元（折合美國存託憑證每單位為(-?[\d.]+)美元）")
_EPS_GENERIC = re.compile(r"每股盈餘(?:為)?新台幣(-?[\d.]+)元")
_REV_TWD = re.compile(r"合併營收(?:約)?新台幣(?:(\d+)兆)?([\d,]+)億(?:(\d+)千萬|(\d+)百萬)?元?")
# v4.29：Gemini 獨立核對發現：2023Q4 原文寫「若以美金計算」；2024Q1、Q2 寫「188億7千萬元」「208億2千萬元」（千萬不能丟）
_REV_USD = re.compile(r"若以美[元金]計算，\d{4}年第[一二三四]季營收為([\d.]+)億(?:(\d+)千萬|(\d+)百萬)?")


def _twd_bn(m):
    """「1兆460億9千萬元」→ 1046.09（十億新台幣）。"""
    yi = int(m.group(1) or 0) * 10000 + int(m.group(2).replace(",", ""))
    return round((yi + int(m.group(3) or 0) * 0.1 + int(m.group(4) or 0) * 0.01) / 10, 4)


def parse_results_text(description, subject=""):
    """回傳 dict（只含原文明寫的欄位）。原文的換行先拿掉再比對（觀測站會在句中斷行）。"""
    t = re.sub(r"\s+", "", description or "")
    out = {}
    m = _EPS_TSMC.search(t)
    if m:
        out.update(eps_twd_per_share=float(m.group(1)), eps_usd_per_adr=float(m.group(2)))
    else:
        m = _EPS_GENERIC.search(t)
        if m:
            out["eps_twd_per_share"] = float(m.group(1))
    m = _REV_TWD.search(t)
    if m:
        out["revenue_twd_bn"] = _twd_bn(m)
    m = _REV_USD.search(t)
    if m:
        yi = float(m.group(1)) + int(m.group(2) or 0) * 0.1 + int(m.group(3) or 0) * 0.01
        out["revenue_usd_bn"] = round(yi / 10, 4)
    s = re.search(r"每股盈餘新台幣(-?[\d.]+)元", subject or "")
    if s and "eps_twd_per_share" in out and float(s.group(1)) != out["eps_twd_per_share"]:
        out = {"error": f"主旨每股盈餘 {s.group(1)} 與說明 {out['eps_twd_per_share']} 不一致"}
    return out


def extract(items, details):
    """items：重大訊息清單項目；details：{document_id: T05st01Detail}。回傳 {季度: 數字與出處}。
    同一季有兩則以上自結財務結果公告時不採用（記錄 error），避免選錯。"""
    found = {}
    for it in items:
        for e in classify(it):
            if e["event_type"] != "self_reported_results":
                continue
            d = details.get(it.document_id)
            if d is None:
                continue
            rec = parse_results_text(d.description, it.subject)
            rec.update(document_id=it.document_id, announced_at=it.announced_at.isoformat(),
                       detail_sha256=d.response_sha256, subject=it.subject)
            found.setdefault(e["fiscal_quarter"], []).append(rec)
    out = {}
    for q, recs in sorted(found.items()):
        uniq = {r["document_id"]: r for r in recs}
        if len(uniq) > 1:
            out[q] = {"error": f"同一季有 {len(uniq)} 則自結財務結果公告，不採用", "documents": sorted(uniq)}
        else:
            out[q] = list(uniq.values())[0]
    return out
