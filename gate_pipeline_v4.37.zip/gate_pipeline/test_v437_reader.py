"""
test_v437_reader.py (v4.37)
===========================
參考讀取器比照 v228 的檢查（Python 與 JS 兩份，同一組情境）：
  - 每一季本身一致：時間必須有時區、界線 ≤ 公告時間 ≤ 現在、月營收 → 公告當日台北 00:00、其他 → 公告時間
  - verify_gate5b_stock／verifyGate5bStock：來源檔 SHA-256、逐季逐欄比對；任何不符 → None／null
  - 只改 latest.json 的時間但保留 MATCH：單季檢查可能看不出來（同一天內的時間），逐欄比對一定拒收

  python test_v437_reader.py
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, os.path.join(HERE, "docs"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import export_boundaries as eb  # noqa: E402
import gate5b_reader as gr  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))


def _tree():
    tmp = tempfile.mkdtemp(prefix="reader_")
    r = os.path.join(tmp, "results", "2454", "111")
    shutil.copytree(os.path.join(BASE, "run_2454_39136575628"), r)
    m = json.load(open(os.path.join(r, "manifest.json"), encoding="utf-8"))
    with open(os.path.join(r, "gate5b_boundaries.json"), "w", encoding="utf-8") as f:
        json.dump(ce.gate5b_boundaries(ce.replay(r, REVIEWS), m), f, ensure_ascii=False, indent=2)
    shutil.copytree(os.path.join(BASE, "run_8299_39217359367"), os.path.join(tmp, "results", "8299", "222"))
    out = os.path.join(tmp, "exports", "gate5b")
    eb.export(os.path.join(tmp, "results"), REVIEWS, out)
    return tmp, os.path.join(out, "latest.json")


def _write(path, doc):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)


def test_python_reader():
    tmp, latest = _tree()
    try:
        d = gr.load_gate5b_boundaries(latest)
        rows = gr.verify_gate5b_stock(d, "2454", base_url=latest)
        assert rows is not None and len(rows) == 11 and rows["2025Q1"]["cutoff_at"] == "2025-04-10T16:55:54+08:00"
        assert gr.verify_gate5b_stock(d, "8299", base_url=latest) == {}            # 只有研究用 → 沒有季度
        assert gr.verify_gate5b_stock(d, "9999", base_url=latest) is None
        q = gr.gate5b_quarter(d, "2454", "2025Q1")
        assert q and gr.snapshot_before_boundary("2025-04-09T23:59:59+08:00", q) is True
        assert gr.snapshot_before_boundary("2025-04-10T00:00:00+08:00", q) is False
        assert gr.snapshot_before_boundary("2025-04-09T23:59:59", q) is None        # 沒有時區不比較
        # 公告時間晚於「現在」→ 不一致
        assert gr.gate5b_quarter(d, "2454", "2025Q1", now=datetime(2025, 1, 1, tzinfo=timezone.utc)) is None

        # 1. 只改 latest.json 同一天內的公告時間、保留 MATCH：單季檢查看不出，逐欄比對拒收
        t = json.load(open(latest, encoding="utf-8"))
        t["stocks"]["2454"]["quarters"]["2025Q1"]["cutoff_at"] = "2025-04-10T18:00:00+08:00"
        _write(latest, t)
        d1 = gr.load_gate5b_boundaries(latest)
        assert gr.gate5b_quarter(d1, "2454", "2025Q1") is not None
        assert gr.verify_gate5b_stock(d1, "2454", base_url=latest) is None
        # 2. 改界線到隔天：單季規則就拒收
        t["stocks"]["2454"]["quarters"]["2025Q1"]["snapshot_boundary_at"] = "2025-04-11T00:00:00+08:00"
        _write(latest, t)
        assert gr.gate5b_quarter(gr.load_gate5b_boundaries(latest), "2454", "2025Q1") is None
        # 3. 來源檔被改：SHA-256 不符
        eb.export(os.path.join(tmp, "results"), REVIEWS, os.path.dirname(latest))   # 還原 latest
        d3 = gr.load_gate5b_boundaries(latest)
        src = os.path.join(tmp, "results", "2454", "111", "gate5b_boundaries.json")
        with open(src, "a", encoding="utf-8") as f:
            f.write(" ")
        assert gr.verify_gate5b_stock(d3, "2454", base_url=latest) is None
        # 4. boundaries_file 指到別的路徑
        bad = json.loads(json.dumps(d3))
        bad["stocks"]["2454"]["boundaries_file"] = "results/2454/999/gate5b_boundaries.json"
        assert gr.verify_gate5b_stock(bad, "2454", base_url=latest) is None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


JS = r"""
const fs = require('fs');
const r = require(process.argv[2]);
const latest = process.argv[3];
const fetchImpl = async (url) => {
  try { const b = fs.readFileSync(url); return { ok: true, arrayBuffer: async () => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) }; }
  catch (e) { return { ok: false }; }
};
(async () => {
  const d = JSON.parse(fs.readFileSync(latest, 'utf8'));
  const out = {};
  out.rows = Object.keys(await r.verifyGate5bStock(d, '2454', { fetchImpl, baseUrl: latest }) || {}).length;
  out.otc = JSON.stringify(await r.verifyGate5bStock(d, '8299', { fetchImpl, baseUrl: latest }));
  const q = r.gate5bQuarter(d, '2454', '2025Q1');
  out.before = r.snapshotBeforeBoundary('2025-04-09T23:59:59+08:00', q);
  out.equal = r.snapshotBeforeBoundary('2025-04-10T00:00:00+08:00', q);
  out.notz = r.snapshotBeforeBoundary('2025-04-09T23:59:59', q);
  const t = JSON.parse(JSON.stringify(d));
  t.stocks['2454'].quarters['2025Q1'].cutoff_at = '2025-04-10T18:00:00+08:00';
  out.tamperQuarter = r.gate5bQuarter(t, '2454', '2025Q1') !== null;
  out.tamperVerify = await r.verifyGate5bStock(t, '2454', { fetchImpl, baseUrl: latest });
  t.stocks['2454'].quarters['2025Q1'].snapshot_boundary_at = '2025-04-11T00:00:00+08:00';
  out.ruleBreak = r.gate5bQuarter(t, '2454', '2025Q1');
  console.log(JSON.stringify(out));
})();
"""


def test_js_reader_same_cases():
    node = shutil.which("node")
    if not node:
        print("（略過：沒有 node）")
        return
    tmp, latest = _tree()
    try:
        script = os.path.join(tmp, "t.js")
        with open(script, "w", encoding="utf-8") as f:
            f.write(JS)
        res = subprocess.run([node, script, os.path.join(HERE, "docs", "gate5b_reader.js"), latest],
                             capture_output=True, text=True, timeout=60)
        assert res.returncode == 0, res.stderr
        out = json.loads(res.stdout.strip().splitlines()[-1])
        assert out == {"rows": 11, "otc": "{}", "before": True, "equal": False, "notz": None,
                       "tamperQuarter": True, "tamperVerify": None, "ruleBreak": None}, out
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
