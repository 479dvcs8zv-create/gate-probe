"""
test_run_8299_39217359367.py (v4.34)
====================================
群聯 8299 第一次抓到公告詳細頁（gate-pipeline-batch run 39217359367，collector 4.33，民國 112–115 年，季末規則）。
  - 107 則詳細頁全部通過逐欄嚴格核對（上櫃詳細頁格式第一次真實樣本）
  - 「公告董事會決議通過民國114年第2季合併財務報告」等 14 則：說明欄位與台積電相同，
    起訖日期以「-」分隔（114/01/01-114/06/30）→ v4.34 起核對報導期間終點後採用
  - 季末規則下 15 季都是 CUTOFF_QUARTER_END_RULE，界線檔 quarters 為空（只放 research_only）
  - 竄改報導期間終點 → 該則不採用（fail-closed）

  python test_run_8299_39217359367.py
"""
import dataclasses
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import mops_t05st01 as mt  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN = os.path.join(BASE, "run_8299_39217359367")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))
S = ce.replay(RUN, REVIEWS)


def _boards(s):
    return [(q, e) for q, v in sorted(s["quarters"].items()) for e in v["events"]
            if e["event_type"] == "board_approved_financials"]


def test_collection_as_recorded():
    m = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
    s = json.load(open(os.path.join(RUN, "summary.json"), encoding="utf-8"))
    assert m["collector_version"] == "4.33-collect" and m["revenue_rule"] == "quarter_end" and "partial" not in m
    assert s["detail_counts"] == {"wanted": 107, "fetched": 107, "from_cache": 0, "skipped_over_limit": 0}
    assert all(v["ok"] for v in s["details"].values()) and len(s["details"]) == 107


def test_board_approvals_detail_verified():
    b = _boards(S)
    assert len(b) == 14 and all(e["detail_verified"] for _, e in b), [(q, e["detail_verified"]) for q, e in b]
    assert not [x for v in S["quarters"].values() for x in (v.get("superseded_blocking") or []) if "board" in x]
    assert S["market"]["detail_pages_verified"] is True


def test_quarter_end_rule_and_boundaries():
    assert {v["status"] for v in S["quarters"].values()} == {"CUTOFF_QUARTER_END_RULE"} and len(S["quarters"]) == 15
    b = ce.gate5b_boundaries(S)
    assert b["quarters"] == {} and len(b["research_only"]) == 15


def test_old_rule_still_blocks_only_on_revenue():
    s = ce.replay(RUN, REVIEWS, revenue_rule="require_announcement")
    for q, v in s["quarters"].items():
        assert v["status"] == "PROVISIONAL" and any("季末月份的營收公告" in x for x in v["blocking"]), q


def test_tampered_period_end_rejected():
    m = json.load(open(os.path.join(RUN, "manifest.json"), encoding="utf-8"))
    doc = "t05st01:8299:20250814:163414:1"
    listings = {}
    for r in m["requests"]:
        if r["kind"] == "t05st01_listing" and r.get("response_file"):
            lst, _ = mt.parse_t05st01_listing(open(os.path.join(RUN, r["response_file"]), "rb").read(), r["content_type"],
                                              r["request_url"], "8299", r["params"]["roc_year"], "", r["response_sha256"])
            listings[int(r["params"]["roc_year"])] = lst
    ml = mt.merge_listings([listings[y] for y in sorted(listings)])
    it = [x for x in ml.items if x.document_id == doc][0]
    rec = [r for r in m["requests"] if r["kind"] == "t05st01_detail" and r["params"].get("document_id") == doc][0]
    d, f = mt.parse_t05st01_detail(open(os.path.join(RUN, rec["response_file"]), "rb").read(), rec["content_type"],
                                   rec["request_url"], it, rec["response_sha256"])
    assert d and not f
    ok, fails = mt.detail_events(it, d)
    assert [e["event_type"] for e in ok] == ["board_approved_financials"] and not fails
    bad = dataclasses.replace(d, description=d.description.replace("114/01/01-114/06/30", "114/01/01-114/03/31"))
    ok, fails = mt.detail_events(it, bad)
    assert ok == [] and fails and "不是 2025Q2 的最後一天" in fails[0][1]


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
