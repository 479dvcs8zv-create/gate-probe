"""
test_v436_export.py (v4.36)
===========================
給正式網站的單一入口 exports/gate5b/latest.json：
  - 每檔取最新一次蒐證的 gate5b_boundaries.json，用保存的官方原始回應重算一致（MATCH）才匯出
  - 不一致（STALE）或缺檔 → quarters 為空（沒有界線）
  - 季末規則的季度只在 research_only
  - 讀取器（docs/gate5b_reader.py）：取不到、STALE、研究用 → None；快照必須嚴格早於界線
  - 內容沒變時 generated_at 不變（避免無意義提交）

  python test_v436_export.py
"""
import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, os.path.join(HERE, "docs"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import export_boundaries as eb  # noqa: E402
import gate5b_reader as gr  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))


def _tree():
    tmp = tempfile.mkdtemp(prefix="export_")
    r2454 = os.path.join(tmp, "results", "2454", "111")
    shutil.copytree(os.path.join(BASE, "run_2454_39136575628"), r2454)
    m = json.load(open(os.path.join(r2454, "manifest.json"), encoding="utf-8"))
    json.dump(ce.gate5b_boundaries(ce.replay(r2454, REVIEWS), m),
              open(os.path.join(r2454, "gate5b_boundaries.json"), "w", encoding="utf-8"), ensure_ascii=False)
    shutil.copytree(os.path.join(BASE, "run_8299_39217359367"), os.path.join(tmp, "results", "8299", "222"))
    os.makedirs(os.path.join(tmp, "results", "2330", "333"))   # 沒有界線檔的股票
    return tmp


def test_export_match_stale_missing_and_reader():
    tmp = _tree()
    try:
        out = os.path.join(tmp, "exports", "gate5b")
        doc = eb.export(os.path.join(tmp, "results"), REVIEWS, out)
        s = doc["stocks"]
        assert s["2454"]["verification"] == "MATCH" and len(s["2454"]["quarters"]) == 11 and s["2454"]["run_id"] == "111"
        assert s["8299"]["verification"] == "MATCH" and s["8299"]["quarters"] == {} and len(s["8299"]["research_only"]) == 15
        assert s["2330"]["verification"] == "MISSING" and s["2330"]["quarters"] == {}
        assert doc["schema"] == "gate-probe/gate5b-export/v1" and "不能當成通過" in doc["use"]
        assert os.path.exists(os.path.join(out, "2454.json")) and "| 2454 | 聯發科 | 上市公司 | MATCH | 11 |" in eb.markdown(doc)
        # 讀取器
        d = gr.load_gate5b_boundaries(os.path.join(out, "latest.json"))
        q = gr.gate5b_quarter(d, "2454", "2025Q1")
        assert q["snapshot_boundary_at"] == "2025-04-10T00:00:00+08:00" and q["cutoff_at"] == "2025-04-10T16:55:54+08:00"
        assert gr.snapshot_before_boundary("2025-04-09T23:59:59+08:00", q) is True
        assert gr.snapshot_before_boundary("2025-04-10T00:00:00+08:00", q) is False   # 等於也不算
        assert gr.snapshot_before_boundary("2025-04-09T23:59:59", q) is None           # 沒有時區不比較
        assert gr.gate5b_quarter(d, "8299", "2025Q1") is None                           # 研究用不採用
        assert gr.gate5b_quarter(d, "2330", "2025Q1") is None and gr.snapshot_before_boundary("x", None) is None
        assert gr.load_gate5b_boundaries(os.path.join(tmp, "nope.json")) is None
        # 內容沒變 → generated_at 不變
        again = eb.export(os.path.join(tmp, "results"), REVIEWS, out, now=__import__("datetime").datetime(2030, 1, 1))
        assert again["generated_at"] == doc["generated_at"]
        # 檔案被改過 → STALE，沒有界線
        p = os.path.join(tmp, "results", "2454", "111", "gate5b_boundaries.json")
        b = json.load(open(p, encoding="utf-8"))
        b["quarters"]["2025Q1"]["snapshot_boundary_at"] = "2025-04-11T00:00:00+08:00"
        json.dump(b, open(p, "w", encoding="utf-8"), ensure_ascii=False)
        doc = eb.export(os.path.join(tmp, "results"), REVIEWS, out)
        assert doc["stocks"]["2454"]["verification"] == "STALE" and doc["stocks"]["2454"]["quarters"] == {}
        assert gr.gate5b_quarter(gr.load_gate5b_boundaries(os.path.join(out, "latest.json")), "2454", "2025Q1") is None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
