"""
market_info.py (v4.31)
======================
市場別（上市 sii／上櫃 otc）與網址代稱。市場別只從官方蒐證摘要（collect_evidence 的 summary.json）取得：
t05st01 清單表頭「本資料由（市場別）…公司提供」與每一列的 TYPEK 參數一致時才記錄。不用股票代號猜。

網址模板的代稱：{co_id}、{adr}、{adr_lower}、{tw_quote}（上市＝<代號>.TW，上櫃＝<代號>.TWO）。
需要的代稱沒有值（沒有 ADR 對照、市場別未知）→ 回傳 None 與原因，呼叫端略過該網站，不猜。
"""

import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from mops_t05st01 import QUOTE_SUFFIX  # noqa: E402

LEGACY_TYPEK = "sii"   # v4.31 之前的解析器只放行上市公司


def typek_from_summary(summary):
    """summary.json → 'sii'／'otc'／None。
    v4.31 起 summary 一定有 "market" 欄位（不一致時為 None）。舊版沒有這個欄位：當時解析器只放行「上市公司」，
    只要有任何年度清單解析成功（有 company_name 或 items），市場別就一定是上市。"""
    if not summary:
        return None
    if "market" in summary:
        m = summary.get("market") or {}
        return m.get("typek") if m.get("typek") in QUOTE_SUFFIX else None
    ok = any(isinstance(v, dict) and ("items" in v) for v in (summary.get("listings") or {}).values())
    return LEGACY_TYPEK if ok else None


def latest_summary_path(company_root):
    """results/<代號>/<run_id>/summary.json 中 run_id 最大的一份（與 consensus_research.discover_inputs 相同規則）。"""
    best = None
    for p in glob.glob(os.path.join(company_root, "*", "summary.json")):
        run = os.path.basename(os.path.dirname(p))
        if run.isdigit() and (best is None or int(run) > best[0]):
            best = (int(run), p)
    return best[1] if best else None


def typek_for(company_root):
    p = latest_summary_path(company_root)
    if not p:
        return None
    try:
        return typek_from_summary(json.load(open(p, encoding="utf-8")))
    except (OSError, ValueError):
        return None


def tw_quote(co_id, typek):
    suf = QUOTE_SUFFIX.get(typek)
    return f"{co_id}{suf}" if suf else None


def fill(template, co_id, adr=None, typek=None):
    """回傳 (網址或 None, 略過原因或 None)。"""
    if "{adr" in template and not adr:
        return None, "沒有 ADR 對照"
    q = tw_quote(co_id, typek)
    if "{tw_quote}" in template and not q:
        return None, "市場別未知（需要先跑一次官方蒐證取得上市／上櫃別）"
    return template.format(co_id=co_id, adr=adr or "", adr_lower=(adr or "").lower(), tw_quote=q or ""), None
