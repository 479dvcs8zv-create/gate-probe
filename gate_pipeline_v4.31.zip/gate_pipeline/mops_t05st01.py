"""
mops_t05st01.py (v4.10.1)
=========================
公開資訊觀測站「重大訊息」查詢回應（POST https://mopsov.twse.com.tw/mops/web/ajax_t05st01）
的正式解析器。依 v4.9 探測在 GitHub Actions 實際取得的官方回應撰寫
（run 39091204611，固定測試資料在 contract/mops_real/run_39091204611/）。

嚴格原則：只接受「已用真實樣本驗證過」的格式，任何不符一律 fail-closed，不猜測。
  1. 請求網址必須是官方網域；回應 SHA-256 一律由原始位元組重算。
  2. 依 Content-Type 宣告的字元集嚴格解碼（實測為 UTF-8）。
  3. 官方網站的拒絕或錯誤頁（查詢過量等）→ ANNOUNCEMENT_SOURCE_REFUSED。
  4. 回應本身回顯的查詢條件必須等於請求：
       公司：表頭「本資料由 (上市公司) 2330 台積電 公司提供」
       年月：表單 t05st01_fm 的隱藏欄位 year、month（全年度查詢回顯為 month=all）
  5. 結果表格（class='hasBorder'）必須恰好一個，表頭必須逐欄等於
       公司代號｜公司名稱｜發言日期｜發言時間｜主旨｜（空白）
  6. 表格中每一個 <tr> 都必須被解析成表頭或資料列，不允許「解析不了就略過」。
  7. 每一列六欄；公司代號、名稱必須等於表頭；發言日期（民國）與發言時間必須有效；
     「詳細資料」按鈕的參數（seq_no、spoke_date、spoke_time、co_id、TYPEK）必須齊全，
     且與畫面上的日期、時間、公司一致。實測發現：上午 10 點前的 spoke_time 不補零
     （06:44:29 → '64429'），所以以數值比對。
  8. 每一列的日期必須落在回顯的查詢年月內；同一份清單內公告識別碼不得重複。
  9. 沒有見過「查無資料」的實際回應：沒有結果表格時一律 fail-closed（不當成「沒有公告」）。

分頁：實測全年 153 筆在單一回應中，沒有任何分頁標記；本解析器不會因此宣稱「完整」，
完整性靠 cross_check_listings（單月與全年互相核對）與日後的獨立重跑比對。

事件分類（cutoff_candidates）只採用在 2330 真實公告上驗證過的標題寫法；
其他公司或其他寫法不會被分類，該期間就找不到事件而 fail-closed，不會誤放行。

v4.10.1：詳細頁（step=2）
  依 v4.10 探測（run 39099468097，contract/mops_real/run_39099468097/）取得的 7 份真實詳細頁撰寫。
  parse_t05st01_detail 逐欄核對（序號、發言日期、發言時間、主旨）必須等於清單中的那一列，
  欄位名稱與順序必須等於已驗證格式。detail_events 再核對內容：
    - 法說會：從「說明」取出實際召開日期與時間（實測 14:00，早於觀測站 EPS 公告約 70–80 分鐘），
      日期必須等於主旨與事實發生日；取不到時間就維持當天 00:00
    - 每股盈餘：說明中必須是同一季、同一個數字
    - 董事會通過財報：報導期間終點必須是該季最後一天
    - 季末月營收：說明中必須是同一年同一月
  同一天的全年清單在兩次獨立執行中位元組完全相同（v4.9 與 v4.10）。
"""

import hashlib
import html
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import List, Optional

from evidence_verification import OFFICIAL_DOMAINS, _domain_matches, _domain_of, decode_declared
from reject_codes import RC

TPE = timezone(timedelta(hours=8))
QUERY_PATH = "/mops/web/ajax_t05st01"
EXPECTED_HEADER = ["公司代號", "公司名稱", "發言日期", "發言時間", "主旨", ""]
# 只放有真實樣本驗證過的市場別；其他市場別沒有樣本前一律 fail-closed
# v4.31：加入上櫃公司（otc）。官方查詢頁的市場別選項 sii＝上市、otc＝上櫃；表格、按鈕與參數格式沿用上市的嚴格核對，
# 只多認一種表頭市場別。尚未有真實樣本前列在 FIRST_SAMPLE_MARKETS：解析照常嚴格，但 summary 會標示「首次樣本」，
# 等第一次真實執行的原始回應人工比對過後再移出。若官方的 TYPEK 參數不是 otc，每一列都會核對失敗而 fail-closed。
VERIFIED_MARKET_TYPEK = {"上市公司": "sii", "上櫃公司": "otc"}
FIRST_SAMPLE_MARKETS = {"上櫃公司"}
QUOTE_SUFFIX = {"sii": ".TW", "otc": ".TWO"}   # Yahoo 等網站的台股報價代號字尾
QUARTER_END_RULE_STATUS = "CUTOFF_QUARTER_END_RULE"
REVENUE_RULES = ("require_announcement", "quarter_end")
REFUSAL_MARKERS = ("查詢過量", "查詢過於頻繁", "因為安全性考量", "系統忙碌", "伺服器忙碌", "請稍後再查詢")
DETAIL_PARAM_KEYS = ("seq_no", "spoke_time", "spoke_date", "co_id", "TYPEK")

_RE_FORM = re.compile(r"<form action='/mops/web/ajax_t05st01' name='t05st01_fm' id='t05st01_fm' method='post'")
_RE_HIDDEN = re.compile(r"<input type=hidden name=(year|month) value=([^>\s]*)>")
_RE_COMP = re.compile(r"<td class='compName'[^>]*>(.*?)</td>", re.S)
_RE_COMP_TEXT = re.compile(r"本資料由\s*\(([^)]+)\)\s*(\w+)\s+(.+?)\s*公司提供")
_RE_TABLE = re.compile(r"<table class='hasBorder'>(.*?)</table>", re.S)
_RE_TR_OPEN = re.compile(r"<tr\b")
_RE_HEAD = re.compile(r"<tr class='tblHead'>(.*?)</tr>", re.S)
_RE_ROW = re.compile(r"<tr class='(even|odd)'>(.*?)</tr>", re.S)
_RE_TD = re.compile(r"<td[^>]*>(.*?)</td>", re.S)
_RE_TH = re.compile(r"<th[^>]*>(.*?)</th>", re.S)
_RE_SUBJECT = re.compile(r"^<pre style='font-family:[^']*;'><font size='3'>(.*)</font></pre>$", re.S)
_RE_BUTTON = re.compile(r"<input type='button' value='詳細資料' onclick=\"(document\.t05st01_fm\.action='ajax_t05st01';"
                        r"(?:document\.t05st01_fm\.\w+\.value='[^']*';)+openWindow\(this\.form ,''\);)\">")
_RE_ASSIGN = re.compile(r"document\.t05st01_fm\.(\w+)\.value='([^']*)';")
_RE_ROC_DATE = re.compile(r"(\d{2,3})/(\d{2})/(\d{2})")
_RE_TIME = re.compile(r"(\d{2}):(\d{2}):(\d{2})")


@dataclass(frozen=True)
class T05st01Item:
    document_id: str          # t05st01:{co_id}:{YYYYMMDD}:{HHMMSS}:{seq_no}，由官方參數組成
    co_id: str
    company_name: str
    typek: str
    seq_no: int
    announced_at: datetime    # 發言日期＋發言時間，+08:00
    roc_date_text: str        # 畫面上的原文，例如 115/07/16
    time_text: str            # 畫面上的原文，例如 15:12:31
    subject: str
    detail_params: tuple      # ((name, value), ...)，原樣保留供詳細頁查詢


@dataclass
class T05st01Listing:
    co_id: str
    company_name: str
    market: str
    roc_year: int
    month: str                # '01'..'12' 或 'all'（官方回顯值）
    items: List[T05st01Item]
    request_url: str
    response_sha256: str
    sorted_ascending: bool
    range_start: date = field(init=False)
    range_end: date = field(init=False)

    def __post_init__(self):
        y = self.roc_year + 1911
        if self.month == "all":
            self.range_start, self.range_end = date(y, 1, 1), date(y, 12, 31)
        else:
            m = int(self.month)
            self.range_start = date(y, m, 1)
            self.range_end = (date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1))


def _clean(s: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", "", s)).replace("\xa0", " ")).strip()


def parse_t05st01_listing(response_bytes: bytes, content_type: str, request_url: str,
                          expected_co_id: str, expected_roc_year: str, expected_month: str,
                          reported_sha256: Optional[str] = None):
    """解析一次 t05st01 查詢的官方回應。

    expected_month：'01'..'12'，或 '' 代表全年度查詢（官方回顯為 'all'）。
    回傳 (listing 或 None, failures[(reject_code, message)])；有任何 failure 時 listing 為 None。
    """
    fails = []
    sha = hashlib.sha256(response_bytes or b"").hexdigest()
    if not response_bytes:
        return None, [(RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, "官方回應是空的")]
    if reported_sha256 is not None and reported_sha256.strip().lower() != sha:
        fails.append((RC.ANNOUNCEMENT_HASH_MISMATCH, "由回應原始位元組重算的 SHA-256 與回報值不一致"))
    u = _domain_of(request_url)
    if not _domain_matches(u, OFFICIAL_DOMAINS) or not str(request_url).split("?")[0].endswith(QUERY_PATH):
        fails.append((RC.ANNOUNCEMENT_SOURCE_NOT_OFFICIAL, f"請求網址「{request_url}」不是官方的 t05st01 查詢端點"))
    want_month = "all" if expected_month == "" else expected_month
    if not (str(expected_co_id).isalnum() and re.fullmatch(r"\d{3}", str(expected_roc_year))
            and re.fullmatch(r"all|0[1-9]|1[0-2]", want_month)):
        fails.append((RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, "查詢條件格式錯誤（公司代號、民國三位數年、月份 01–12 或全年）"))
    text, err = decode_declared(response_bytes, content_type)
    if err:
        fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"官方回應無法解碼：{err}"))
    if fails:
        return None, fails

    for marker in REFUSAL_MARKERS:
        if marker in text:
            return None, [(RC.ANNOUNCEMENT_SOURCE_REFUSED, f"官方網站回覆「{marker}」，這不是查詢結果")]

    # ---- 回顯的查詢條件 ----
    if len(_RE_FORM.findall(text)) != 1:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, "找不到（或不只一個）t05st01_fm 結果表單，不是已驗證過的清單格式")]
    hidden = {}
    for name, value in _RE_HIDDEN.findall(text):
        if name in hidden and hidden[name] != value:
            return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"回應中有多個不同的 {name} 回顯值")]
        hidden[name] = value
    if hidden.get("year") != str(expected_roc_year) or hidden.get("month") != want_month:
        return None, [(RC.ANNOUNCEMENT_COVERAGE_INCOMPLETE,
                       f"官方回顯的查詢年月（year={hidden.get('year')}, month={hidden.get('month')}）"
                       f"與請求（{expected_roc_year}, {want_month}）不符")]
    comps = _RE_COMP.findall(text)
    m = _RE_COMP_TEXT.search(_clean(comps[0])) if len(comps) == 1 else None
    if not m:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, "找不到「本資料由（市場別）代號 名稱 公司提供」表頭")]
    market, co_id, company_name = m.group(1), m.group(2), m.group(3)
    if co_id != str(expected_co_id):
        return None, [(RC.ANNOUNCEMENT_ISSUER_MISMATCH, f"官方回應的公司是 {co_id}，不是請求的 {expected_co_id}")]
    if market not in VERIFIED_MARKET_TYPEK:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"市場別「{market}」尚無真實樣本驗證，不放行")]
    want_typek = VERIFIED_MARKET_TYPEK[market]

    # ---- 結果表格 ----
    tables = _RE_TABLE.findall(text)
    if len(tables) != 1:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN,
                       f"結果表格數量為 {len(tables)}（應為 1）；沒有見過「查無資料」的實際格式，不當成沒有公告")]
    table = tables[0]
    heads = _RE_HEAD.findall(table)
    if len(heads) != 1 or [_clean(h) for h in _RE_TH.findall(heads[0])] != EXPECTED_HEADER:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, "結果表格的表頭與已驗證格式不同")]
    rows = _RE_ROW.findall(table)
    n_tr = len(_RE_TR_OPEN.findall(table))
    if n_tr != 1 + len(rows):
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN,
                       f"表格有 {n_tr} 個 <tr>，只認得表頭 1 列＋資料 {len(rows)} 列，有無法解析的列")]

    items, seen = [], set()
    y0 = int(expected_roc_year) + 1911
    lo = date(y0, 1, 1) if want_month == "all" else date(y0, int(want_month), 1)
    hi = (date(y0, 12, 31) if want_month == "all"
          else date(y0 + (want_month == "12"), int(want_month) % 12 + 1, 1) - timedelta(days=1))
    for i, (_, row) in enumerate(rows, 1):
        label = f"第 {i} 列"
        tds = _RE_TD.findall(row)
        if len(tds) != 6:
            fails.append((RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"{label}有 {len(tds)} 欄（應為 6）"))
            continue
        r_co, r_name, r_date, r_time = (_clean(x) for x in tds[:4])
        sm = _RE_SUBJECT.match(tds[4].strip())
        btn = _RE_BUTTON.findall(tds[5])
        if not sm or len(btn) != 1:
            fails.append((RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"{label}的主旨或「詳細資料」按鈕格式與已驗證格式不同"))
            continue
        subject = _clean(sm.group(1))
        params = _RE_ASSIGN.findall(btn[0])
        pdict = dict(params)
        if sorted(pdict) != sorted(DETAIL_PARAM_KEYS) or len(params) != len(DETAIL_PARAM_KEYS):
            fails.append((RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"{label}的詳細資料參數不是預期的 {DETAIL_PARAM_KEYS}"))
            continue
        dm, tm = _RE_ROC_DATE.fullmatch(r_date), _RE_TIME.fullmatch(r_time)
        try:
            d = date(int(dm.group(1)) + 1911, int(dm.group(2)), int(dm.group(3)))
            hh, mm, ss = (int(x) for x in tm.groups())
            announced = datetime(d.year, d.month, d.day, hh, mm, ss, tzinfo=TPE)
        except (AttributeError, ValueError):
            fails.append((RC.ANNOUNCEMENT_TIME_UNVERIFIED, f"{label}的發言日期「{r_date}」或時間「{r_time}」無效"))
            continue
        problems = []
        if r_co != co_id or pdict["co_id"] != co_id:
            problems.append(f"公司代號（畫面 {r_co}／參數 {pdict['co_id']}）與表頭 {co_id} 不符")
        if r_name != company_name:
            problems.append(f"公司名稱「{r_name}」與表頭「{company_name}」不符")
        if pdict["TYPEK"] != want_typek:
            problems.append(f"市場別參數 {pdict['TYPEK']} 與表頭「{market}」不符")
        if pdict["spoke_date"] != d.strftime("%Y%m%d"):
            problems.append(f"參數發言日期 {pdict['spoke_date']} 與畫面 {r_date} 不符")
        if not pdict["spoke_time"].isdigit() or int(pdict["spoke_time"]) != hh * 10000 + mm * 100 + ss:
            problems.append(f"參數發言時間 {pdict['spoke_time']} 與畫面 {r_time} 不符")
        if not pdict["seq_no"].isdigit() or int(pdict["seq_no"]) < 1:
            problems.append(f"序號 {pdict['seq_no']} 無效")
        if not (lo <= d <= hi):
            problems.append(f"發言日期 {d} 不在官方回顯的查詢範圍 {lo}～{hi}")
        if problems:
            fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{label}：" + "；".join(problems)))
            continue
        doc_id = f"t05st01:{co_id}:{d:%Y%m%d}:{hh:02d}{mm:02d}{ss:02d}:{int(pdict['seq_no'])}"
        if doc_id in seen:
            fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{label}：公告識別碼 {doc_id} 重複"))
            continue
        seen.add(doc_id)
        items.append(T05st01Item(doc_id, co_id, company_name, pdict["TYPEK"], int(pdict["seq_no"]), announced,
                                 r_date, r_time, subject, tuple(params)))
    if fails:
        return None, fails
    keys = [(it.announced_at, it.seq_no) for it in items]
    return T05st01Listing(co_id, company_name, market, int(expected_roc_year), want_month, items,
                          request_url, sha, keys == sorted(keys)), []


def merge_listings(listings: List[T05st01Listing]) -> T05st01Listing:
    """把同一公司「連續年度」的全年清單合成一份，供跨年度的季度使用（例如第四季的公告在隔年初）。
    年度必須連續、都是全年度查詢；公告識別碼不得重複。不符就丟 ValueError（呼叫端視為 fail-closed）。"""
    if not listings:
        raise ValueError("沒有清單可以合併")
    ls = sorted(listings, key=lambda x: x.roc_year)
    if any(x.month != "all" for x in ls) or len({x.co_id for x in ls}) != 1:
        raise ValueError("只能合併同一公司的全年度清單")
    years = [x.roc_year for x in ls]
    if years != list(range(years[0], years[0] + len(years))):
        raise ValueError(f"年度不連續：{years}")
    items = [it for x in ls for it in x.items]
    if len({it.document_id for it in items}) != len(items):
        raise ValueError("合併後有重複的公告識別碼")
    merged = T05st01Listing(ls[0].co_id, ls[0].company_name, ls[0].market, ls[0].roc_year, "all", items,
                            ls[0].request_url, "+".join(x.response_sha256 for x in ls),
                            all(x.sorted_ascending for x in ls))
    merged.range_end = ls[-1].range_end
    return merged


def cross_check_listings(full_year: T05st01Listing, monthly: List[T05st01Listing]):
    """單月查詢的結果必須與全年查詢中同月份的部分完全相同（識別碼、時間、主旨、順序）。"""
    fails = []
    if full_year.month != "all":
        return [(RC.ANNOUNCEMENT_QUERY_INCONSISTENT, "第一個參數必須是全年度查詢的清單")]
    for ml in monthly:
        tag = f"{ml.roc_year}/{ml.month}"
        if ml.co_id != full_year.co_id or ml.roc_year != full_year.roc_year or ml.month == "all":
            fails.append((RC.ANNOUNCEMENT_QUERY_INCONSISTENT, f"{tag} 不是同一公司、同一年度的單月查詢"))
            continue
        sub = [(it.document_id, it.subject) for it in full_year.items
               if ml.range_start <= it.announced_at.date() <= ml.range_end]
        mon = [(it.document_id, it.subject) for it in ml.items]
        if sub != mon:
            only_full = sorted(set(sub) - set(mon))
            only_month = sorted(set(mon) - set(sub))
            fails.append((RC.ANNOUNCEMENT_QUERY_INCONSISTENT,
                          f"{tag}：單月 {len(mon)} 筆、全年中同月 {len(sub)} 筆不一致"
                          f"（只在全年：{[d for d, _ in only_full][:5]}；只在單月：{[d for d, _ in only_month][:5]}"
                          f"{'；順序不同' if not only_full and not only_month else ''}）"))
    return fails


# ---------------------------------------------------------------- 事件分類與保守截止點

_CN_Q = {"一": 1, "二": 2, "三": 3, "四": 4, "1": 1, "2": 2, "3": 3, "4": 4}
# 只收在真實公告上驗證過的寫法：format "tsmc" 為 2330（見 test_mops_real.py），
# format "mtk" 為 v4.22 依 2454 民國 113–115 年真實主旨加入（見 test_run_2454_39133967342.py）。
# 主旨只決定「可能是哪一種事件」；詳細頁的內容核對（detail_events）依格式分別處理，新格式在用真實詳細頁
# 建立核對規則之前一律不放行。
_PAT_EPS = re.compile(r"(\d{4})年第([一二三四])季每股盈餘")
_PAT_BOARD_Q = re.compile(r"(民國)?(\d{3})年度?第([一二三四1-4])季合併財務報告業經\s*董事會決議通過")
_PAT_BOARD_FY = re.compile(r"(民國)?(\d{3})年度合併財務報告業經\s*董事會決議通過")
_PAT_CONF = re.compile(r"(\d{3})年第([一二三四])季法人說明會將於(\d{3})年(\d{1,2})月(\d{1,2})日召開")
_PAT_REVENUE = re.compile(r"(\d{4})年(\d{1,2})月營收報告")
_PAT_MTK_REVENUE = re.compile(r"(\d{3,4})年(\d{1,2})月份?自結合併營收淨額公告")
_PAT_MTK_RESULTS = re.compile(r"^本公司(\d{4})年第([1-4])季(?:與\d{4}全年)?合併財務報告$")
_PAT_MTK_CONF = re.compile(r"^本公司於(\d{3})/(\d{1,2})/(\d{1,2})召開第([一二三四])季財報暨營運(?:線上)?說明會$")
_PAT_FORECAST = re.compile(r"(\d{3})年度第([一二三四1-4])季簡式合併財務預測公告")
# 代子公司、代行子公司的公告不是本公司的財務結果
_PAT_ON_BEHALF = re.compile(r"代(?:重要)?子公司|代行(?:重要)?子公司|代重要子|代行重要")


def _cn_number(n):
    """1–199 的中文數字寫法（2454 詳細頁：一百一十三年、十二月）。"""
    digits = "零一二三四五六七八九"
    n = int(n)
    out = ""
    if n >= 100:
        out += digits[n // 100] + "百"
        n %= 100
        if 0 < n < 10:
            return out + "零" + digits[n]
        if 10 <= n < 20:
            return out + "一十" + (digits[n % 10] if n % 10 else "")
    if n >= 20:
        out += digits[n // 10] + "十" + (digits[n % 10] if n % 10 else "")
    elif n >= 10:
        out += "十" + (digits[n % 10] if n % 10 else "")
    elif n > 0:
        out += digits[n]
    return out


def _year(y):
    y = int(y)
    return y + 1911 if y < 1000 else y


def classify(item: T05st01Item):
    """回傳這則公告代表的財務結果揭露事件 [{event_type, fiscal_quarter, at, precision, note, format}]。"""
    s, out = item.subject, []
    if _PAT_ON_BEHALF.search(s):
        return out
    if m := _PAT_EPS.search(s):
        out.append(dict(event_type="self_reported_results", fiscal_quarter=f"{m.group(1)}Q{_CN_Q[m.group(2)]}",
                        at=item.announced_at, precision="datetime_tz", note="每股盈餘公告的發言時間", format="tsmc"))
    if m := _PAT_MTK_RESULTS.search(s):
        out.append(dict(event_type="self_reported_results", fiscal_quarter=f"{m.group(1)}Q{_CN_Q[m.group(2)]}",
                        at=item.announced_at, precision="datetime_tz", note="公司公告當季合併財務報告（結果）的發言時間",
                        format="mtk"))
    if m := _PAT_BOARD_Q.search(s):
        out.append(dict(event_type="board_approved_financials",
                        fiscal_quarter=f"{int(m.group(2)) + 1911}Q{_CN_Q[m.group(3)]}",
                        at=item.announced_at, precision="datetime_tz", note="董事會通過季報的發言時間",
                        format="tsmc" if m.group(1) else "mtk"))
    elif m := _PAT_BOARD_FY.search(s):
        out.append(dict(event_type="board_approved_financials", fiscal_quarter=f"{int(m.group(2)) + 1911}Q4",
                        at=item.announced_at, precision="datetime_tz", note="董事會通過年報（涵蓋第四季）的發言時間",
                        format="tsmc" if m.group(1) else "mtk"))
    if m := _PAT_CONF.search(s):
        try:
            conf_day = date(int(m.group(3)) + 1911, int(m.group(4)), int(m.group(5)))
        except ValueError:
            conf_day = None
        if conf_day:
            out.append(dict(event_type="investor_conference",
                            fiscal_quarter=f"{int(m.group(1)) + 1911}Q{_CN_Q[m.group(2)]}",
                            at=datetime(conf_day.year, conf_day.month, conf_day.day, tzinfo=TPE), precision="date_only",
                            note=f"法說會日期（公告於 {item.roc_date_text}）；只有日期，取當天 00:00 作保守起點",
                            format="tsmc"))
    if m := _PAT_MTK_CONF.search(s):
        try:
            conf_day = date(int(m.group(1)) + 1911, int(m.group(2)), int(m.group(3)))
        except ValueError:
            conf_day = None
        if conf_day:
            qn = _CN_Q[m.group(4)]
            fy = conf_day.year if conf_day.month > 3 * qn else conf_day.year - 1   # 第四季的說明會在隔年初
            out.append(dict(event_type="investor_conference", fiscal_quarter=f"{fy}Q{qn}",
                            at=datetime(conf_day.year, conf_day.month, conf_day.day, tzinfo=TPE), precision="date_only",
                            note=f"財報說明會日期（公告於 {item.roc_date_text}）；只有日期，取當天 00:00 作保守起點",
                            format="mtk"))
    for pat, fmt in ((_PAT_REVENUE, "tsmc"), (_PAT_MTK_REVENUE, "mtk")):
        if m := pat.search(s):
            y, mo = _year(m.group(1)), int(m.group(2))
            if mo in (3, 6, 9, 12):
                out.append(dict(event_type="quarter_revenue_complete", fiscal_quarter=f"{y}Q{mo // 3}",
                                at=item.announced_at, precision="datetime_tz",
                                note=f"{y} 年 {mo} 月營收公告後，該季營收（三個月加總）即已公開", format=fmt))
    return out


def is_forecast_announcement(item: T05st01Item):
    """（v4.22）公司正式的財務預測公告（例如 2454「民國114年度第二季簡式合併財務預測公告」）。
    它是對未來季度的預測，不是財務結果，不進截止點；蒐證時抓原文，供官方財測模式日後解析。"""
    m = _PAT_FORECAST.search(item.subject)
    if not m or _PAT_ON_BEHALF.search(item.subject):
        return None
    return f"{int(m.group(1)) + 1911}Q{_CN_Q[m.group(2)]}"


# ---------------------------------------------------------------- 詳細頁（step=2）

EXPECTED_DETAIL_FIELDS = ["序號", "發言日期", "發言時間", "發言人", "發言人職稱", "發言人電話",
                          "主旨", "符合條款", "事實發生日", "說明"]
_RE_DETAIL_TABLE = re.compile(r"<TABLE class='hasBorder'>(.*?)</table>", re.S | re.I)
_RE_CELL_SPLIT = re.compile(r"<td\b([^>]*)>", re.I)
_RE_CELL_END = re.compile(r"</td>", re.I)
_RE_PRE = re.compile(r"<pre[^>]*>(.*?)</pre>", re.S | re.I)
_RE_CONF_DATE = re.compile(r"召開法人說明會之日期：\s*(\d{3})/(\d{2})/(\d{2})")
_RE_CONF_TIME = re.compile(r"召開法人說明會之時間：\s*(\d{1,2})\s*時\s*(\d{1,2})\s*分")


@dataclass(frozen=True)
class T05st01Detail:
    document_id: str
    seq_no: int
    announced_at: datetime
    subject: str
    clause: str               # 符合條款，例如 '12'、'51'
    fact_date: date           # 事實發生日
    description: str          # 說明（保留換行）
    speaker: str
    speaker_title: str
    request_url: str
    response_sha256: str


def parse_t05st01_detail(response_bytes: bytes, content_type: str, request_url: str, item: T05st01Item,
                         reported_sha256: Optional[str] = None):
    """解析一則公告的詳細頁，並與清單中的那一列逐欄核對。回傳 (detail 或 None, failures)。"""
    fails = []
    if not response_bytes:
        return None, [(RC.ANNOUNCEMENT_EVIDENCE_INCOMPLETE, "詳細頁回應是空的")]
    sha = hashlib.sha256(response_bytes).hexdigest()
    if reported_sha256 is not None and reported_sha256.strip().lower() != sha:
        fails.append((RC.ANNOUNCEMENT_HASH_MISMATCH, "由詳細頁原始位元組重算的 SHA-256 與回報值不一致"))
    if not _domain_matches(_domain_of(request_url), OFFICIAL_DOMAINS) or not str(request_url).split("?")[0].endswith(QUERY_PATH):
        fails.append((RC.ANNOUNCEMENT_SOURCE_NOT_OFFICIAL, f"請求網址「{request_url}」不是官方的 t05st01 端點"))
    text, err = decode_declared(response_bytes, content_type)
    if err:
        fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"詳細頁無法解碼：{err}"))
    if fails:
        return None, fails
    for marker in REFUSAL_MARKERS:
        if marker in text:
            return None, [(RC.ANNOUNCEMENT_SOURCE_REFUSED, f"官方網站回覆「{marker}」，這不是公告內容")]

    comps = _RE_COMP.findall(text)
    m = _RE_COMP_TEXT.search(_clean(comps[0])) if len(comps) == 1 else None
    if not m:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, "詳細頁找不到「本資料由（市場別）代號 名稱 公司提供」表頭")]
    if m.group(2) != item.co_id or m.group(3) != item.company_name:
        return None, [(RC.ANNOUNCEMENT_ISSUER_MISMATCH,
                       f"詳細頁的公司是 {m.group(2)} {m.group(3)}，清單列是 {item.co_id} {item.company_name}")]
    tables = _RE_DETAIL_TABLE.findall(text)
    if len(tables) != 1:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"詳細頁內容表格數量為 {len(tables)}（應為 1）")]
    parts = _RE_CELL_SPLIT.split(tables[0])
    cells = [("tblHead" in parts[k], _RE_CELL_END.split(parts[k + 1])[0]) for k in range(1, len(parts), 2)]
    labels = [_clean(v) for h, v in cells[0::2]]
    if (len(cells) != 2 * len(EXPECTED_DETAIL_FIELDS) or labels != EXPECTED_DETAIL_FIELDS
            or not all(h for h, _ in cells[0::2]) or any(h for h, _ in cells[1::2])):
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, f"詳細頁欄位與已驗證格式不同：{labels}")]
    raw = dict(zip(labels, (v for _, v in cells[1::2])))
    val = {k: _clean(v) for k, v in raw.items()}
    pre = _RE_PRE.findall(raw["說明"])
    if len(pre) != 1:
        return None, [(RC.ANNOUNCEMENT_LISTING_FORMAT_UNKNOWN, "詳細頁的「說明」不是單一 <pre> 區塊")]
    description = html.unescape(re.sub(r"<[^>]+>", "", pre[0])).replace("\r\n", "\n").strip("\n")
    sm = _RE_SUBJECT.match(raw["主旨"].strip())
    subject = _clean(sm.group(1)) if sm else None
    clause = re.sub(r"\D", "", val["符合條款"])
    fd = _RE_ROC_DATE.fullmatch(val["事實發生日"])
    problems = []
    if val["序號"] != str(item.seq_no):
        problems.append(f"序號 {val['序號']} ≠ 清單 {item.seq_no}")
    if val["發言日期"] != item.roc_date_text or val["發言時間"] != item.time_text:
        problems.append(f"發言時間 {val['發言日期']} {val['發言時間']} ≠ 清單 {item.roc_date_text} {item.time_text}")
    if subject != item.subject:
        problems.append(f"主旨「{subject}」≠ 清單「{item.subject}」")
    if not clause:
        problems.append("符合條款不是數字")
    try:
        fact_date = date(int(fd.group(1)) + 1911, int(fd.group(2)), int(fd.group(3)))
    except (AttributeError, ValueError):
        fact_date = None
        problems.append(f"事實發生日「{val['事實發生日']}」無效")
    if problems:
        return None, [(RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"詳細頁 {item.document_id}：" + "；".join(problems))]
    return T05st01Detail(item.document_id, item.seq_no, item.announced_at, subject, clause, fact_date, description,
                         val["發言人"], val["發言人職稱"], request_url, sha), []


def detail_events(item: T05st01Item, detail: T05st01Detail):
    """用詳細頁內容核對並細化 classify(item) 的事件。回傳 (events, failures)。

    - 法說會：從「說明」取出實際召開日期與時間，日期必須等於主旨與事實發生日；有時間就改用精確時間。
    - 每股盈餘：說明中必須出現同一季、同一個每股盈餘數字。
    - 董事會通過財報：報導期間終點必須是該季最後一天。
    - 季末月營收：說明中必須是同一年同一月的營收報告。
    """
    fails, out = [], []
    d = detail.description
    for e in classify(item):
        q_year, q_no = int(e["fiscal_quarter"][:4]), int(e["fiscal_quarter"][-1])
        e = {**e, "detail_sha256": detail.response_sha256}
        if e.get("format") == "mtk" and e["event_type"] in ("self_reported_results", "quarter_revenue_complete"):
            # v4.23：依 2454 真實詳細頁（run 39136575628）建立的核對規則
            flat = re.sub(r"\s+", "", d)
            if e["event_type"] == "quarter_revenue_complete":
                rm = _PAT_MTK_REVENUE.search(item.subject)
                roc, mo = _year(rm.group(1)) - 1911, int(rm.group(2))
                ok = (f"{_cn_number(roc)}年{_cn_number(mo)}月份自結合併營收淨額" in flat
                      or f"{roc}年{mo}月份自結合併營收淨額" in flat)
                if not ok:
                    fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{item.document_id}：說明中的營收年月與主旨不一致"))
                    continue
            else:
                qs = {f"公佈{q_year}年第{q_no}季", f"公佈{q_year}年第{'一二三四'[q_no - 1]}季"}
                if not any(x in flat for x in qs) or "合併財務報告" not in flat:
                    fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{item.document_id}：說明中公佈的季度與主旨不一致"))
                    continue
            out.append(e)
            continue
        if e.get("format") not in (None, "tsmc", "mtk") or (e.get("format") != "tsmc" and e["event_type"] in
                                                             ("self_reported_results", "quarter_revenue_complete")):
            fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH,
                          f"{item.document_id}：{e['event_type']} 的「{e.get('format')}」格式說明核對規則尚未以真實詳細頁建立"))
            continue
        if e["event_type"] == "investor_conference":
            dm, tm = _RE_CONF_DATE.search(d), _RE_CONF_TIME.search(d)
            try:
                conf_day = date(int(dm.group(1)) + 1911, int(dm.group(2)), int(dm.group(3)))
            except (AttributeError, ValueError):
                fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{item.document_id}：說明中找不到有效的法說會日期"))
                continue
            if conf_day != e["at"].date() or conf_day != detail.fact_date:
                fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH,
                              f"{item.document_id}：法說會日期不一致（說明 {conf_day}、主旨 {e['at'].date()}、事實發生日 {detail.fact_date}）"))
                continue
            if tm and 0 <= int(tm.group(1)) <= 23 and 0 <= int(tm.group(2)) <= 59:
                e.update(at=datetime(conf_day.year, conf_day.month, conf_day.day, int(tm.group(1)), int(tm.group(2)),
                                     tzinfo=TPE), precision="datetime_tz",
                         note=f"法說會實際召開時間（公告於 {item.roc_date_text}，詳細頁「召開法人說明會之時間」）")
            else:
                e["note"] += "；詳細頁沒有可解析的召開時間，維持當天 00:00"
        elif e["event_type"] == "self_reported_results":
            eps = re.search(r"每股盈餘新台幣([\d.]+)元", item.subject)
            cn = "一二三四"[q_no - 1]
            if not (eps and f"公佈{q_year}年第{cn}季財務報告" in d and f"每股盈餘為新台幣{eps.group(1)}元" in d):
                fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{item.document_id}：說明中的季度或每股盈餘與主旨不一致"))
                continue
        elif e["event_type"] == "board_approved_financials":
            pm = re.search(r"起訖日期\(XXX/XX/XX~XXX/XX/XX\):(\d{3})/(\d{2})/(\d{2})~(\d{3})/(\d{2})/(\d{2})", d)
            q_end = date(q_year + (q_no == 4), (3 * q_no) % 12 + 1, 1) - timedelta(days=1)
            try:
                period_end = date(int(pm.group(4)) + 1911, int(pm.group(5)), int(pm.group(6)))
            except (AttributeError, ValueError):
                period_end = None
            if period_end != q_end:
                fails.append((RC.ANNOUNCEMENT_PERIOD_MISMATCH,
                              f"{item.document_id}：財報報導期間終點 {period_end} 不是 {e['fiscal_quarter']} 的最後一天 {q_end}"))
                continue
        elif e["event_type"] == "quarter_revenue_complete":
            rm = re.search(r"(\d{4})年(\d{1,2})月營收報告", item.subject)
            if not (rm and f"公佈{rm.group(1)}年{int(rm.group(2))}月營收報告" in d):
                fails.append((RC.ANNOUNCEMENT_CONTENT_MISMATCH, f"{item.document_id}：說明中的營收年月與主旨不一致"))
                continue
        out.append(e)
    return out, fails


def snapshot_boundary(earliest):
    """（v4.26，使用者 2026-10-19 採用）市場共識快照必須早於的時間界線。不覆寫 earliest（原文公告時間照舊保留）。
    最早事件是季末月營收公告時，界線取公告當日 00:00：公司另以「每月營業收入」申報系統揭露，
    該系統的上傳時間尚未查證，當天稍早可能已公開。其他事件用原文記載的時間。
    這只是保守的時間界線（風控假設），不是實際發布時間；也不會讓任何季度升級為 CUTOFF_VERIFIED。"""
    if earliest is None:
        return None
    at = earliest["at"]
    if earliest["event_type"] == "quarter_revenue_complete":
        mid = datetime(at.year, at.month, at.day, tzinfo=at.tzinfo)
        return {"at": mid, "rule": "revenue_day_midnight", "announced_at": at,
                "note": "月營收公告當日 00:00（月營收申報系統上傳時間未查證）"}
    return {"at": at, "rule": "announced_time", "announced_at": at, "note": "原文記載的公告時間"}


def _quarter_end_rule(listing, fiscal_quarter, events, prior_blocking, filings, uncertain_filings):
    """（v4.31）季末規則：截止點＝季度結束隔天 00:00。只有清單涵蓋整季、且沒有任何該季結果事件早於界線時才成立。"""
    m = re.fullmatch(r"(\d{4})Q([1-4])", fiscal_quarter)
    y, qn = int(m.group(1)), int(m.group(2))
    q_start = date(y, 3 * (qn - 1) + 1, 1)
    q_end_next = date(y + (qn == 4), (3 * qn) % 12 + 1, 1)
    bound = datetime(q_end_next.year, q_end_next.month, q_end_next.day, tzinfo=TPE)
    blocking = []
    if listing.range_start > q_start:
        blocking.append(f"清單起點 {listing.range_start} 晚於該季第一天 {q_start}，可能漏掉季中的揭露")
    if listing.range_end < q_end_next:
        blocking.append(f"清單終點 {listing.range_end} 早於季度結束隔天 {q_end_next}，季度還沒結束或清單不完整")
    early = [e for e in events if e["at"] < bound]
    if early:
        blocking.append(f"有該季結果事件早於季度結束（{[e['document_id'] for e in early]}），與季末規則的前提不符")
    synthetic = {"event_type": "quarter_end_boundary", "fiscal_quarter": fiscal_quarter, "at": bound,
                 "precision": "datetime_tz", "document_id": None, "subject": None, "detail_verified": False,
                 "note": "季末規則（使用者可選設定）：季度結束隔天 00:00，不是任何公告的時間"}
    return {"fiscal_quarter": fiscal_quarter,
            "status": "PROVISIONAL" if blocking else QUARTER_END_RULE_STATUS,
            "revenue_rule": "quarter_end",
            "snapshot_boundary": {"at": bound, "rule": "quarter_end", "announced_at": None,
                                  "note": "季末規則：季度結束隔天 00:00（重大訊息沒有季末月營收公告）"},
            "events": sorted(events, key=lambda e: e["at"]),
            "earliest": synthetic, "event_types_found": sorted({e["event_type"] for e in events}),
            "blocking": blocking,
            "superseded_blocking": list(prior_blocking) + [
                "重大訊息中找不到該季季末月份的營收公告（季末規則下不阻擋）"],
            "review_window": [], "financial_report_status": None, "uncertain_filings": uncertain_filings,
            "listing_response_sha256": listing.response_sha256,
            "filing_listing_sha256": getattr(filings, "response_sha256", None)}


def cutoff_candidates(listing: T05st01Listing, fiscal_quarter: str, include_revenue: bool = True,
                      details: Optional[dict] = None, reviewed_non_results: Optional[set] = None,
                      filings=None, auto_clear_clauses: Optional[set] = None,
                      revenue_rule: str = "require_announcement"):
    """列出某季的財務結果揭露事件與最早的保守截止點。

    revenue_rule（v4.31，可選設定，預設不啟用）：
      - require_announcement（預設，與 v4.21 起相同）：重大訊息中找不到季末月營收公告 → 阻擋。
      - quarter_end：只在「找不到季末月營收公告」的季度改用季末規則──截止點取季度結束隔天 00:00（台北），
        狀態為 CUTOFF_QUARTER_END_RULE（不是 CUTOFF_VERIFIED）。依據：季末月份的營收最早也要等該月結束後
        才能申報，任何該季結果都不會早於季度結束；這是比月營收公告當日 00:00 更早（更保守）的界線。
        只檢查清單涵蓋整季且沒有任何該季結果事件早於界線；原本的阻擋原因保留在 superseded_blocking 供稽核。
        有季末月營收公告的季度不受影響。

    details：{document_id: T05st01Detail}（已通過 parse_t05st01_detail）。有詳細頁的事件會以
    detail_events() 核對並細化（例如法說會改用實際召開時間）。

    include_revenue 預設 True（v4.10.1 決議）：季末月營收公告後該季營收即已公開，快照含營收共識，
    所以截止點取含營收的最早事件。v4.21 起，重大訊息中找不到季末月營收公告 → 阻擋（見下方說明）。

    未分類公告（v4.10.1）：季末之後、最早事件之前，清單中沒有被分類的公告列為 review_window。
    它們是否「不含財務結果」由人工判斷，判斷結果以公告識別碼放進 reviewed_non_results（可稽核）；
    尚未確認的公告會列為阻擋原因，不會自動放過。季中公告視為業績展望而非結果揭露（假設，已記錄）。

    filings（v4.12）：mops_t57sb01.FilingListing（電子資料查詢的財務報告書清單）。
      - 該季有申報檔：取最早的上傳日期作為 financial_report 事件
      - 該季沒有申報檔：只有在清單「取得時間」晚於其他最早事件時，才能確定申報不會更早；
        否則列為阻擋（不能排除更早的申報）
      - 公司或年度不符：阻擋

    auto_clear_clauses（v4.15）：使用者核准的條款集合（contract/mops_real/reviews/clause_policy.json）。
      review_window 中已取得詳細頁、且詳細頁「符合條款」在集合內的公告自動排除；
      每一則都記錄 cleared_by=auto_clause_rule 與條款。沒有詳細頁就無法得知條款，不會自動排除。

    status：沒有任何阻擋原因時為 CUTOFF_VERIFIED（截止點的每個組成都有官方原文證據），
    否則為 PROVISIONAL。這只是截止點證據的狀態；Gate5B 是否通過仍由判定引擎決定。
    阻擋原因包括：
      - 任何事件沒有詳細頁、或詳細頁核對失敗
      - 財報申報（financial_report）尚未查詢或無法排除更早的申報
      - 清單範圍必須涵蓋該季第一天到最早事件
      - 季末到最早事件之間有未經人工確認的未分類公告
    """
    m = re.fullmatch(r"(\d{4})Q([1-4])", fiscal_quarter)
    if not m:
        raise ValueError(f"期間格式錯誤：{fiscal_quarter}")
    q_start = date(int(m.group(1)), 3 * (int(m.group(2)) - 1) + 1, 1)
    details = details or {}
    events, blocking, missing_detail = [], [], []
    for it in listing.items:
        evs = [e for e in classify(it) if e["fiscal_quarter"] == fiscal_quarter
               and (include_revenue or e["event_type"] != "quarter_revenue_complete")]
        if not evs:
            continue
        det = details.get(it.document_id)
        if det is None:
            missing_detail.append(it.document_id)
            events.extend({**e, "document_id": it.document_id, "subject": it.subject, "detail_verified": False}
                          for e in evs)
            continue
        refined, f = detail_events(it, det)
        blocking.extend(msg for _, msg in f)
        events.extend({**e, "document_id": it.document_id, "subject": it.subject, "detail_verified": True}
                      for e in refined if e["fiscal_quarter"] == fiscal_quarter
                      and (include_revenue or e["event_type"] != "quarter_revenue_complete"))
    if missing_detail:
        blocking.append(f"公告詳細頁尚未取得核對：{missing_detail}")
    filing_status = None
    uncertain_rows = []   # 只有財報清單的公司與年度都相符時才會填入
    if isinstance(filings, (list, tuple)):   # 多年度財報清單：只用該季所屬年度的那一份
        match = [f for f in filings if f.roc_year == int(m.group(1)) - 1911]
        filings = match[0] if len(match) == 1 else None
    if filings is None:
        blocking.append("財報申報（financial_report）尚未查詢")
    elif filings.co_id != listing.co_id or filings.roc_year != int(m.group(1)) - 1911:
        blocking.append(f"財報清單是 {filings.co_id} 民國 {filings.roc_year} 年，不是 {listing.co_id} {fiscal_quarter}")
    else:
        rows = filings.filings_for(fiscal_quarter)
        uncertain_rows = [u for u in getattr(filings, "uncertain", None) or [] if u["fiscal_quarter"] == fiscal_quarter]
        if rows:
            first = min(rows, key=lambda r: r.uploaded_at)
            events.append({"event_type": "financial_report", "fiscal_quarter": fiscal_quarter, "at": first.uploaded_at,
                           "precision": "datetime_tz", "note": "財務報告書最早的上傳日期（電子資料查詢 t57sb01）",
                           "document_id": first.document_id, "subject": f"{first.detail} {first.filename}",
                           "detail_verified": True})
            filing_status = f"filed {first.uploaded_at.isoformat()}"
        else:
            others = min((e["at"] for e in events), default=None)
            if filings.retrieved_at is None:
                blocking.append("財報清單沒有取得時間，無法證明該季尚未申報")
            elif others is None or filings.retrieved_at <= others:
                blocking.append(f"財報清單取得時間 {filings.retrieved_at.isoformat()} 不晚於最早事件，無法排除更早的申報")
            else:
                filing_status = f"not filed as of {filings.retrieved_at.isoformat()}"
    earliest = min(events, key=lambda e: e["at"]) if events else None
    # v4.24（使用者 2026-10-18 核准「財報不可能早於董事會通過」）：更(補)正欄位不確定的申報列，
    # 只有在同一季「董事會通過財報」公告已以詳細頁核對、且截止點早於董事會開會當天 00:00 時才不阻擋。
    # 依據：財務報告須經董事會通過後才能申報，所以任何版本的申報都不會早於董事會開會日。
    # 開會日取詳細頁的「事實發生日」與公告日兩者較早的一天（保守）。每一列都記錄在 uncertain_filings。
    uncertain_filings = []
    if uncertain_rows:
        boards =[e for e in events if e["event_type"] == "board_approved_financials" and e.get("detail_verified")]
        bound = None
        if boards:
            days = []
            for e in boards:
                days.append(e["at"].astimezone(TPE).date())
                det = details.get(e["document_id"])
                if det is not None and det.fact_date:
                    days.append(det.fact_date)
            d0 = min(days)
            bound = datetime(d0.year, d0.month, d0.day, tzinfo=TPE)
        for u in uncertain_rows:
            rec = dict(u, set_aside=False)
            if bound is not None and earliest is not None and earliest["at"] < bound:
                rec.update(set_aside=True, rule="filing_not_before_board_approval", board_bound=bound.isoformat(),
                           note=f"財報須經董事會通過後才能申報；董事會開會日 {bound.date()} 晚於截止點 "
                                f"{earliest['at'].isoformat()}，此列不論原始申報時間為何都不會早於截止點")
            else:
                why = ("該季董事會通過財報公告尚未以詳細頁核對" if bound is None
                       else f"截止點不早於董事會開會日 {bound.date()}")
                blocking.append(f"財報清單中 {u['filename']}（{u['detail']}）{u['reason']}；{why}")
            uncertain_filings.append(rec)
    # v4.21：季末月營收的揭露管道必須有證據。台積電另以重大訊息公告每月營收，所以清單裡看得到；
    # 多數公司只透過「每月營業收入」申報系統揭露，不在重大訊息清單裡。若重大訊息找不到季末月營收，
    # 就無法證明截止點早於營收揭露 → 不放行（不是假設沒有揭露）。
    if revenue_rule not in REVENUE_RULES:
        raise ValueError(f"月營收規則只能是 {REVENUE_RULES}：{revenue_rule}")
    no_revenue = include_revenue and not any(e["event_type"] == "quarter_revenue_complete" for e in events)
    if no_revenue and revenue_rule == "quarter_end":
        return _quarter_end_rule(listing, fiscal_quarter, events, blocking, filings, uncertain_filings)
    if no_revenue:
        blocking.append("重大訊息中找不到該季季末月份的營收公告；公司可能只透過每月營收申報系統揭露，"
                        "該管道的揭露時間尚未查證，無法確認截止點早於營收揭露")
    if listing.range_start > q_start:
        blocking.append(f"清單起點 {listing.range_start} 晚於該季第一天 {q_start}，可能漏掉較早的揭露")
    if earliest is None:
        blocking.append("清單中找不到可辨識的該季財務結果揭露")
    elif listing.range_end < earliest["at"].date():
        blocking.append("清單終點早於最早事件")
    review_window = []
    if earliest is not None:
        q_no = int(m.group(2))
        q_end_next = date(int(m.group(1)) + (q_no == 4), (3 * q_no) % 12 + 1, 1)
        window_start = datetime(q_end_next.year, q_end_next.month, q_end_next.day, tzinfo=TPE)
        review_window = []
        for it in listing.items:
            if window_start <= it.announced_at < earliest["at"] and not classify(it):
                det = details.get(it.document_id)
                clause = det.clause if det else None
                if it.document_id in (reviewed_non_results or set()):
                    cleared = "human_review"
                elif clause is not None and clause in (auto_clear_clauses or set()):
                    cleared = "auto_clause_rule"
                else:
                    cleared = None
                review_window.append({"document_id": it.document_id, "announced_at": it.announced_at,
                                      "subject": it.subject, "clause": clause, "cleared_by": cleared})
        pending = [r["document_id"] for r in review_window if r["cleared_by"] is None]
        if pending:
            blocking.append(f"季末到最早事件之間有 {len(pending)} 則未分類公告，需人工確認不含財務結果：{pending}")
    found = sorted({e["event_type"] for e in events})
    return {"fiscal_quarter": fiscal_quarter, "status": "PROVISIONAL" if blocking else "CUTOFF_VERIFIED",
            "revenue_rule": "require_announcement",
            "snapshot_boundary": snapshot_boundary(earliest),
            "events": sorted(events, key=lambda e: e["at"]),
            "earliest": earliest, "event_types_found": found, "blocking": blocking,
            "review_window": review_window, "financial_report_status": filing_status,
            "uncertain_filings": uncertain_filings,
            "listing_response_sha256": listing.response_sha256,
            "filing_listing_sha256": getattr(filings, "response_sha256", None)}
