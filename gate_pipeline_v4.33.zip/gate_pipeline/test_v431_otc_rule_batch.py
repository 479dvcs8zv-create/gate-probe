"""
test_v431_otc_rule_batch.py (v4.31)
===================================
v4.31 三項新功能與一項修正：
  1. 上櫃股票：市場別「上櫃公司」（TYPEK otc）可解析（第一次真實樣本前標示 first_sample）；
     市場別記在 summary；Yahoo 台股頁網址與報價代號依市場別用 .TW／.TWO；市場別未知就略過該網站，不猜。
  2. 月營收規則可選設定（預設不啟用）：quarter_end＝找不到季末月營收公告的季度，截止點改用季度結束隔天 00:00，
     狀態 CUTOFF_QUARTER_END_RULE（與 CUTOFF_VERIFIED 分開，官方財測模式不使用）。
  3. 多檔總表 batch_report：只讀 results/，並離線重算另一種規則供比較。
  4. 快照審查新增「截止點狀態」：暫定季度的快照不能列為可採用。
  另：聯發科「一次性項目」照實記錄（2025Q2 毛利率含 +1.9 個百分點），不調整數字。

  python test_v431_otc_rule_batch.py
"""
import dataclasses
import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import archive_consensus as ac  # noqa: E402
import batch_report as br  # noqa: E402
import collect_evidence as ce  # noqa: E402
import consensus_backfill as cb  # noqa: E402
import consensus_discovery as cd  # noqa: E402
import consensus_parsers as cp  # noqa: E402
import consensus_research as cr  # noqa: E402
import guidance_mops as gm  # noqa: E402
import market_info as mi  # noqa: E402
import mops_t05st01 as mt  # noqa: E402
import snapshot_audit as sa  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
RUN54 = os.path.join(BASE, "run_2454_39136575628")
RUN30 = os.path.join(BASE, "run_39126755093")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))
S54 = ce.replay(RUN54, REVIEWS)


def _listings(run):
    m = json.load(open(os.path.join(run, "manifest.json"), encoding="utf-8"))
    out = {}
    for rec in m["requests"]:
        if rec["kind"] == "t05st01_listing" and rec.get("response_file"):
            lst, f = mt.parse_t05st01_listing(open(os.path.join(run, rec["response_file"]), "rb").read(),
                                              rec["content_type"], rec["request_url"], m["co_id"],
                                              rec["params"]["roc_year"], "", rec["response_sha256"])
            if lst:
                out[int(rec["params"]["roc_year"])] = lst
    return out


# ------------------------------------------------------------------------------------------------ 1. 上櫃
def test_market_recorded_from_official_listing():
    mk = S54["market"]
    assert mk["name"] == "上市公司" and mk["typek"] == "sii" and mk["quote_suffix"] == ".TW" and not mk["first_sample"]
    assert all(v["market"] == "上市公司" and v["typek"] == ["sii"] for v in S54["listings"].values())
    assert mt.QUOTE_SUFFIX == cp.TW_QUOTE_SUFFIX   # 兩處的對照表必須一致
    # v4.32：上櫃清單格式已用真實樣本人工比對（run 39211980039），詳細頁尚未
    assert not mt.FIRST_SAMPLE_MARKETS and mt.VERIFIED_MARKET_TYPEK["上櫃公司"] == "otc"
    assert "上櫃公司" not in mt.DETAIL_VERIFIED_MARKETS and mk["detail_pages_verified"] is True


def test_market_from_old_and_new_summaries():
    old = json.load(open(os.path.join(RUN30, "summary.json"), encoding="utf-8"))
    assert "market" not in old and mi.typek_from_summary(old) == "sii"   # 舊版：當時只放行上市
    assert mi.typek_from_summary({"market": None, "listings": {"115": {"items": 3}}}) is None
    assert mi.typek_from_summary({"listings": {"115": {"failures": [["X", "y"]]}}}) is None
    assert mi.typek_from_summary({"market": {"typek": "otc"}}) == "otc"
    assert mi.typek_from_summary({"market": {"typek": "rotc"}}) is None   # 未支援的市場別
    tmp = tempfile.mkdtemp()
    try:
        for run, typek in (("100", "sii"), ("200", "otc")):
            os.makedirs(os.path.join(tmp, run))
            json.dump({"market": {"typek": typek}}, open(os.path.join(tmp, run, "summary.json"), "w"))
        os.makedirs(os.path.join(tmp, "archive", "999"))
        assert mi.typek_for(tmp) == "otc"   # run id 最大的那份
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_url_templates_use_market_suffix():
    assert mi.fill("q/{tw_quote}/a", "8299", None, "otc") == ("q/8299.TWO/a", None)
    assert mi.fill("q/{tw_quote}/a", "2330", "TSM", "sii") == ("q/2330.TW/a", None)
    url, why = mi.fill("q/{tw_quote}/a", "8299", None, None)
    assert url is None and "市場別未知" in why
    assert mi.fill("q/{adr}/a", "8299", None, "otc")[0] is None
    t, _ = ac.archive_targets("8299", typek="otc")
    assert [x["url"] for x in t] == ["https://finance.yahoo.com/quote/8299.TWO/analysis/"]
    sk = []
    t, _ = ac.archive_targets("8299", typek=None, skipped=sk)
    assert t == [] and [x["id"] for x in sk] == ["yahoo_tw_analysis"]
    t, adr = ac.archive_targets("2330", typek="sii")
    assert adr == "TSM" and "https://finance.yahoo.com/quote/2330.TW/analysis/" in [x["url"] for x in t]
    src, skipped, _ = cd.resolve_sources("8299", typek="otc")
    assert [s["prefix"] for s in src if s["id"] == "yahoo_tw_analysis"] == ["finance.yahoo.com/quote/8299.TWO/analysis"]
    src, skipped, _ = cd.resolve_sources("8299")
    assert not [s for s in src if s["id"] == "yahoo_tw_analysis"]
    assert {"id": "yahoo_tw_analysis", "reason": "市場別未知（需要先跑一次官方蒐證取得上市／上櫃別）"} in skipped


def test_otc_quote_is_checked_on_page():
    """（合成）把真實 2330.TW 頁面的代號換成 8299.TWO：上櫃市場別才解析；未知或上市 → 代號不符，不收。"""
    caps = cr.load_all_captures([os.path.join(BASE, "archive_39186897770")], [])
    raw = open([c for c in caps if c["source_id"] == "yahoo_tw_analysis"][0]["file"], "rb").read()
    body = cp.decode(raw)
    assert b"2330.TW" in body
    fake = body.replace(b"2330.TWO", b"XXXX").replace(b"2330.TW", b"8299.TWO")
    assert cp.parse_capture("yahoo_tw_analysis", fake, "8299", None, None, "otc")["status"] == "PARSED"
    assert cp.parse_capture("yahoo_tw_analysis", fake, "8299", None, None, "sii")["status"] == "SYMBOL_MISMATCH"
    assert cp.parse_capture("yahoo_tw_analysis", fake, "8299", None)["status"] == "SYMBOL_MISMATCH"
    assert cp.parse_capture("yahoo_tw_analysis", body, "2330", "TSM", None, "otc")["status"] == "SYMBOL_MISMATCH"
    assert cp.parse_capture("yahoo_tw_analysis", body, "2330", "TSM", None, "sii")["status"] == "PARSED"


# ------------------------------------------------------------------------------------------ 2. 月營收規則
def _without_revenue(lst):
    keep = [it for it in lst.items if not any(e["event_type"] == "quarter_revenue_complete" for e in mt.classify(it))]
    assert len(keep) < len(lst.items)
    out = dataclasses.replace(lst, items=keep)
    out.range_start, out.range_end = lst.range_start, lst.range_end   # 合併清單的範圍（replace 會依第一年重算）
    return out


def test_quarter_end_rule_only_when_enabled():
    ls = _listings(RUN54)
    merged = mt.merge_listings([ls[y] for y in sorted(ls)])
    no_rev = _without_revenue(merged)
    default = mt.cutoff_candidates(no_rev, "2025Q1")
    assert default["status"] == "PROVISIONAL" and default["revenue_rule"] == "require_announcement"
    assert any("季末月份的營收公告" in b for b in default["blocking"])
    qe = mt.cutoff_candidates(no_rev, "2025Q1", revenue_rule="quarter_end")
    assert qe["status"] == "CUTOFF_QUARTER_END_RULE" and qe["blocking"] == []
    assert qe["earliest"]["event_type"] == "quarter_end_boundary" and qe["earliest"]["document_id"] is None
    assert qe["earliest"]["at"].isoformat() == "2025-04-01T00:00:00+08:00"
    assert qe["snapshot_boundary"]["rule"] == "quarter_end" and qe["review_window"] == []
    assert "財報申報（financial_report）尚未查詢" in qe["superseded_blocking"]   # 原本的阻擋原因保留供稽核
    assert any("季末規則下不阻擋" in b for b in qe["superseded_blocking"])
    assert qe["events"]   # 實際事件照樣記錄
    # 有季末月營收公告的季度不受設定影響
    full = mt.cutoff_candidates(merged, "2025Q1", revenue_rule="quarter_end")
    assert full["revenue_rule"] == "require_announcement" and full["earliest"]["event_type"] == "quarter_revenue_complete"
    try:
        mt.cutoff_candidates(merged, "2025Q1", revenue_rule="guess")
        raise AssertionError("未知規則應該丟例外")
    except ValueError:
        pass


def test_quarter_end_rule_needs_full_quarter_listing():
    ls = _listings(RUN54)
    only114 = _without_revenue(ls[114])
    r = mt.cutoff_candidates(only114, "2024Q4", revenue_rule="quarter_end")   # 114 年清單沒有涵蓋 2024Q4
    assert r["status"] == "PROVISIONAL" and any("清單起點" in b for b in r["blocking"])
    only115 = _without_revenue(ls[115])
    r = mt.cutoff_candidates(only115, "2026Q4", revenue_rule="quarter_end")   # 季度還沒結束
    assert r["status"] == "PROVISIONAL" and any("清單終點" in b for b in r["blocking"])


def test_replay_with_rule_keeps_real_announcements():
    """聯發科每季都有季末月營收公告：啟用季末規則也不改變任何一季。規則記在 summary。"""
    alt = ce.replay(RUN54, REVIEWS, revenue_rule="quarter_end")
    assert alt["revenue_rule"] == "quarter_end" and S54["revenue_rule"] == "require_announcement"
    assert {q: v["status"] for q, v in alt["quarters"].items()} == {q: v["status"] for q, v in S54["quarters"].items()}
    assert all(v["revenue_rule"] == "require_announcement" for v in alt["quarters"].values())
    assert alt["guidance"]["provisional_quarters_excluded"] == S54["guidance"]["provisional_quarters_excluded"]


def test_rule_boundary_used_by_research_not_by_guidance():
    s = {"quarters": {"2025Q1": {"status": "CUTOFF_QUARTER_END_RULE",
                                 "earliest": {"event_type": "quarter_end_boundary", "at": "2025-04-01T00:00:00+08:00"},
                                 "snapshot_boundary": {"at": "2025-04-01T00:00:00+08:00", "rule": "quarter_end"}}}}
    assert cr.boundaries_from_summary(s)["2025Q1"]["at"] == "2025-04-01T00:00:00+08:00"
    assert "CUTOFF_QUARTER_END_RULE" in cb.RESEARCH_BOUNDARY_STATUSES
    # 摘要記錄的界線與重算不同 → 取較早者
    s["quarters"]["2025Q1"]["snapshot_boundary"]["at"] = "2025-03-31T00:00:00+08:00"
    assert cr.boundaries_from_summary(s)["2025Q1"]["at"] == "2025-03-31T00:00:00+08:00"


# ------------------------------------------------------------------------------- 4. 審查：截止點狀態
def test_audit_requires_settled_cutoff():
    arch = [os.path.join(BASE, d) for d in ("archive_39122089604", "archive_39186897770", "archive_39187117065",
                                             "archive_39200908159", "archive_39203353595")]
    disc = [os.path.join(BASE, "run_39118440897", "consensus_discovery"),
            os.path.join(BASE, "archive_39200908159", "backfill"), os.path.join(BASE, "archive_39203353595", "backfill")]
    caps = cr.load_all_captures(arch, disc)
    cut = cr.cutoffs_from_summary(json.load(open(os.path.join(RUN30, "summary.json"), encoding="utf-8")))
    off = ce.replay(RUN30, REVIEWS)["official_figures"]
    matched = {(c["source_id"], c["capture_ts"]): {"status": "MATCHED", "run": "x"} for c in caps}
    a = sa.audit(cr.build("2330", caps, cut), caps, matched, off)
    ok = [x for x in a["items"] if x["verdict"] == "ADOPTABLE"]
    assert ok and all(any(c["check"] == "截止點狀態" and c["result"] == "PASS" for c in x["checks"]) for x in ok)
    q = ok[0]["fiscal_period"]
    for status, want in (("PROVISIONAL", "PENDING"), ("CUTOFF_QUARTER_END_RULE", "ADOPTABLE")):
        c2 = {k: dict(v) for k, v in cut.items()}
        c2[q]["status"] = status
        a2 = sa.audit(cr.build("2330", caps, c2), caps, matched, off)
        same = [x for x in a2["items"] if (x["fiscal_period"], x["source_id"], x["capture_ts"], x["metric"]) ==
                (q, ok[0]["source_id"], ok[0]["capture_ts"], ok[0]["metric"])][0]
        assert same["verdict"] == want, (status, same["reasons"])
        if want == "PENDING":
            assert "CUTOFF_PROVISIONAL" in same["pending_categories"]


# ------------------------------------------------------------------------------------- 3. 多檔總表
def test_batch_report_from_results_tree():
    tmp = tempfile.mkdtemp()
    try:
        shutil.copytree(RUN54, os.path.join(tmp, "2454", "555"))
        os.makedirs(os.path.join(tmp, "8299", "555"))   # 蒐證失敗：沒有 summary.json
        json.dump(S54, open(os.path.join(tmp, "2454", "555", "summary.json"), "w", encoding="utf-8"), ensure_ascii=False)
        m = json.load(open(os.path.join(tmp, "2454", "555", "manifest.json"), encoding="utf-8"))
        m["collector_version"] = ce.COLLECTOR_VERSION   # 模擬用目前程式蒐證
        json.dump(m, open(os.path.join(tmp, "2454", "555", "manifest.json"), "w", encoding="utf-8"), ensure_ascii=False)
        rep = br.build(["2454", "8299"], 555, tmp, REVIEWS)
        a, b = rep["companies"]
        assert a["ok"] and a["company_name"] == "聯發科" and a["market"]["typek"] == "sii"
        assert a["status_counts"] == {"CUTOFF_VERIFIED": 9, "CUTOFF_QUARTER_END_RULE": 0, "PROVISIONAL": 2}
        assert a["alternative_rule"]["revenue_rule"] == "quarter_end"
        assert a["alternative_rule"]["status_counts"] == a["status_counts"]
        assert a["blocking_categories"] == {"UNCLASSIFIED_PENDING": 2}
        assert a["pending_review_announcements"] == 2
        assert not b["ok"] and "summary.json" in b["reason"]
        assert rep["totals"]["CUTOFF_VERIFIED"] == 9 and rep["gate_impact"] == "none"
        md = br.markdown(rep)
        assert "| 2454 | 聯發科 | 上市公司 |" in md and "| 8299 |" in md and "不等於 Gate PASS" in md
        out = os.path.join(tmp, "batch", "555")
        assert br.main(["--co-ids", "2454,8299", "--run-id", "555", "--results", tmp, "--out", out,
                        "--no-alt-rule"]) == 0
        assert json.load(open(os.path.join(out, "batch_report.json"), encoding="utf-8"))["co_ids"] == ["2454", "8299"]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def test_batch_categories():
    assert br.categorize("重大訊息中找不到該季季末月份的營收公告；公司可能…") == "NO_REVENUE_ANNOUNCEMENT"
    assert br.categorize("季末到最早事件之間有 1 則未分類公告，需人工確認不含財務結果：[…]") == "UNCLASSIFIED_PENDING"
    assert br.categorize("財報清單取得時間 x 不晚於最早事件，無法排除更早的申報") == "FILING"
    assert br.categorize("清單起點 2025-01-01 晚於該季第一天 2024-10-01，可能漏掉較早的揭露") == "LISTING_COVERAGE"
    assert br.categorize("公告詳細頁尚未取得核對：[…]") == "DETAIL_MISSING"
    assert br.categorize("詳細頁的營收年月與主旨不符") == "DETAIL_CHECK_FAILED"
    assert br.categorize("別的訊息") == "OTHER"


def test_boundary_export_only_verified():
    m = json.load(open(os.path.join(RUN54, "manifest.json"), encoding="utf-8"))
    b = ce.gate5b_boundaries(S54, m)
    assert b["schema"] == "gate-probe/gate5b-boundaries/v1" and b["co_id"] == "2454" and b["company_name"] == "聯發科"
    assert sorted(b["excluded"]) == ["2024Q4", "2025Q4"] and len(b["quarters"]) == 9 and b["research_only"] == {}
    r = b["quarters"]["2025Q1"]
    assert r["cutoff_at"] == "2025-04-10T16:55:54+08:00" and r["snapshot_boundary_at"] == "2025-04-10T00:00:00+08:00"
    assert r["snapshot_boundary_rule"] == "revenue_day_midnight" and r["cutoff_document_id"].startswith("t05st01:2454:")
    assert "不等於正式 Gate PASS" in b["use"]
    # 複驗：放進資料夾 → 重算相符；改一個時間 → 不符（結束碼 1）
    import replay_evidence as rv
    tmp = tempfile.mkdtemp()
    try:
        d = os.path.join(tmp, "run")
        shutil.copytree(RUN54, d)
        json.dump(ce.gate5b_boundaries(S54, m), open(os.path.join(d, "gate5b_boundaries.json"), "w", encoding="utf-8"),
                  ensure_ascii=False)
        assert rv.main([d, "--reviews", os.path.join(BASE, "reviews"), "--check-boundaries"]) == 0
        bad = json.load(open(os.path.join(d, "gate5b_boundaries.json"), encoding="utf-8"))
        bad["quarters"]["2025Q1"]["snapshot_boundary_at"] = "2025-04-11T00:00:00+08:00"
        json.dump(bad, open(os.path.join(d, "gate5b_boundaries.json"), "w", encoding="utf-8"), ensure_ascii=False)
        assert rv.main([d, "--reviews", os.path.join(BASE, "reviews"), "--check-boundaries"]) == 1
        os.remove(os.path.join(d, "gate5b_boundaries.json"))
        assert rv.main([d, "--check-boundaries"]) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    fake = {"co_id": "9999", "listings": {}, "quarters": {"2025Q1": {
        "status": "CUTOFF_QUARTER_END_RULE", "earliest": {"at": "2025-04-01T00:00:00+08:00", "event_type": "quarter_end_boundary"},
        "snapshot_boundary": {"at": "2025-04-01T00:00:00+08:00", "rule": "quarter_end"}}}}
    b = ce.gate5b_boundaries(fake)
    assert b["quarters"] == {} and b["research_only"]["2025Q1"]["snapshot_boundary_rule"] == "quarter_end"


def test_cli_end_to_end_otc_offline():
    """（合成，本機模擬伺服器）上櫃清單（表頭上櫃、TYPEK otc）→ 一鍵蒐證 CLI：summary 記錄市場別與首次樣本、
    季末規則參數寫進 manifest／summary、輸出 gate5b_boundaries.json。"""
    import threading
    import test_collect_offline as tco
    from evidence_verification import OFFICIAL_DOMAINS
    orig = tco.LISTING_115
    tco.LISTING_115 = orig.replace("(上市公司)".encode(), "(上櫃公司)".encode(), 1).replace(
        b"TYPEK.value='sii'", b"TYPEK.value='otc'")
    srv = tco._Server(("127.0.0.1", 0), tco.Stub)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    netloc = f"127.0.0.1:{srv.server_address[1]}"
    OFFICIAL_DOMAINS.add(netloc)
    out = tempfile.mkdtemp(prefix="otc_cli_")
    old_proxy = {k: os.environ.pop(k) for k in list(os.environ) if k.lower() in ("http_proxy", "https_proxy", "all_proxy")}
    try:
        tco.LOG.clear()
        rc = ce.main(["--co-id", "2330", "--roc-years", "115", "--out", os.path.join(out, "1"), "--mops-base",
                      f"http://{netloc}", "--doc-base", f"http://{netloc}", "--delay", "0", "--retry-waits", "",
                      "--revenue-rule", "quarter_end", "--no-cache",
                      "--reviews", os.path.join(BASE, "reviews")])
        assert rc == 0
        s = json.load(open(os.path.join(out, "1", "summary.json"), encoding="utf-8"))
        m = json.load(open(os.path.join(out, "1", "manifest.json"), encoding="utf-8"))
        assert s["market"]["name"] == "上櫃公司" and s["market"]["typek"] == "otc" and not s["market"]["first_sample"]
        assert s["market"]["detail_pages_verified"] is False and any("詳細頁尚無人工比對過的樣本" in n for n in s["notes"])
        assert s["market"]["quote_suffix"] == ".TWO"
        assert m["revenue_rule"] == s["revenue_rule"] == "quarter_end" and m["collector_version"] == ce.COLLECTOR_VERSION
        details = [f for meth, _, f in tco.LOG if meth == "POST" and f.get("step") == "2"]
        assert details and all(f.get("TYPEK") == "otc" for f in details)   # 詳細頁用清單列的 TYPEK
        b = json.load(open(os.path.join(out, "1", "gate5b_boundaries.json"), encoding="utf-8"))
        assert b["market"]["typek"] == "otc" and b["revenue_rule"] == "quarter_end"
        assert mi.typek_for(out) == "otc"
        t, _ = ac.archive_targets("2330", typek=mi.typek_for(out))
        assert "https://finance.yahoo.com/quote/2330.TWO/analysis/" in [x["url"] for x in t]
    finally:
        tco.LISTING_115 = orig
        OFFICIAL_DOMAINS.discard(netloc)
        os.environ.update(old_proxy)
        srv.shutdown()
        shutil.rmtree(out, ignore_errors=True)


# ------------------------------------------------------------------------------------- 一次性項目
def test_one_time_items_recorded_without_adjusting():
    g = S54["guidance"]["quarters"]
    q2 = [n for n in g["2025Q2"]["notes"] if "一次性" in n]
    assert len(q2) == 1 and q2[0].startswith("本季含一次性項目（原文：對毛利率正面影響 1.9 個百分點）")
    assert g["2025Q2"]["actual"]["gross_margin_pct"] == 49.1   # 數字照公告原值
    q3 = [n for n in g["2025Q3"]["notes"] if "一次性" in n]
    assert q3 and all(n.startswith("比較期間") for n in q3)   # 說的是前季，不是本季
    assert any(n.startswith("本季含一次性項目") for n in g["2024Q1"]["notes"])
    assert gm.one_time_notes("本季毛利率較前季增加，主要因產品組合較佳。") == []
    assert gm.one_time_notes("本季及前季皆含一次性項目")[0].startswith("提到一次性項目，無法判斷") or \
        gm.one_time_notes("本季及前季皆含一次性項目")[0].startswith("比較期間")


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
