"""
test_run_otc_39211980039.py (v4.32)
===================================
上櫃第一次真實樣本（gate-pipeline-batch run 39211980039，collector 4.31，民國 113–115 年）：
群聯 8299、環球晶 6488、世界先進 5347。固定測試資料在 contract/mops_real/run_<代號>_39211980039/。

  - 清單：表頭「本資料由 (上櫃公司) 代號 名稱 公司提供」、每一列 TYPEK=otc；與同次 2330 清單只差公司、市場別與
    「財務及交易資訊重點專區」按鈕參數（v4.32 人工比對後列為已驗證；詳細頁尚無上櫃樣本）
  - 財報申報清單（doc.twse t57sb01）三家各年度都解析成功
  - 三家都沒有以重大訊息公告月營收 → 預設舊規則（蒐證時）各 11 季暫定；季末規則（2026-10-19 採用為研究用預設）
    → 各 11 季 CUTOFF_QUARTER_END_RULE，但不進 gate5b_boundaries.json 的 quarters
  - v4.32 認得三家的「董事會通過合併財務報告」寫法（各 11 則），開會預告不算
  - Gemini 第五輪引用的 9 則群聯公告時間，與官方清單逐秒相符（只作交叉核對紀錄）

  python test_run_otc_39211980039.py
"""
import json
import os
import sys
from datetime import date, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "ops"))
sys.path.insert(0, HERE)

import collect_evidence as ce  # noqa: E402
import mops_t05st01 as mt  # noqa: E402

BASE = os.path.join(HERE, "contract", "mops_real")
REVIEWS = ce.load_reviews(os.path.join(BASE, "reviews"))
CODES = {"8299": "群聯", "6488": "環球晶", "5347": "世界"}
RUN = {c: os.path.join(BASE, f"run_{c}_39211980039") for c in CODES}
OLD = {c: ce.replay(RUN[c], REVIEWS) for c in CODES}                                # 蒐證時的規則（manifest 記錄）
NEW = {c: ce.replay(RUN[c], REVIEWS, revenue_rule="quarter_end") for c in CODES}    # 採用後的研究用規則


def _items(c):
    m = json.load(open(os.path.join(RUN[c], "manifest.json"), encoding="utf-8"))
    out = []
    for r in m["requests"]:
        if r["kind"] == "t05st01_listing" and r.get("response_file"):
            lst, f = mt.parse_t05st01_listing(open(os.path.join(RUN[c], r["response_file"]), "rb").read(),
                                              r["content_type"], r["request_url"], c, r["params"]["roc_year"], "",
                                              r["response_sha256"])
            assert lst and not f, f
            assert lst.market == "上櫃公司" and lst.company_name == CODES[c]
            out += lst.items
    return out


ITEMS = {c: _items(c) for c in CODES}


def test_collection_as_recorded():
    for c in CODES:
        m = json.load(open(os.path.join(RUN[c], "manifest.json"), encoding="utf-8"))
        s = json.load(open(os.path.join(RUN[c], "summary.json"), encoding="utf-8"))
        assert m["collector_version"] == "4.31-collect" and m["revenue_rule"] == "require_announcement"
        assert s["market"]["typek"] == "otc" and s["market"]["first_sample"] is True   # 當時的標示
        assert sorted(s["filings"]) == ["113", "114", "115"] and all("rows" in v for v in s["filings"].values())
        assert all(it.typek == "otc" for it in ITEMS[c])


def test_market_now_verified_for_listings():
    for c in CODES:
        mk = OLD[c]["market"]
        assert mk["name"] == "上櫃公司" and mk["quote_suffix"] == ".TWO"
        assert mk["first_sample"] is False and mk["detail_pages_verified"] is False


def test_board_approvals_recognized_notices_not():
    for c in CODES:
        ev = [(e["fiscal_quarter"], it) for it in ITEMS[c] for e in mt.classify(it)
              if e["event_type"] == "board_approved_financials"]
        qs = sorted(q for q, _ in ev)
        assert len(ev) == 11 and len(set(qs)) == 11, (c, qs)
        assert qs[0] == "2023Q4" and qs[-1] == "2026Q2"
        assert all(e["format"] == "generic" for it in ITEMS[c] for e in mt.classify(it))
        notices = [it for it in ITEMS[c] if ("召開" in it.subject or "預計" in it.subject) and "合併財務報告" in it.subject]
        assert notices and all(not mt.classify(it) for it in notices)
    # 群聯 2025Q3：董事會 2025-11-07 16:30:06（財報申報 13:22:57 更早，最早事件仍是申報）
    q = OLD["8299"]["quarters"]["2025Q3"]
    assert q["earliest"]["event_type"] == "financial_report" and q["earliest"]["at"] == "2025-11-07T13:22:57+08:00"
    assert any(e["event_type"] == "board_approved_financials" and e["at"] == "2025-11-07T16:30:06+08:00"
               for e in q["events"])


def test_old_rule_all_provisional():
    for c in CODES:
        st = {q: v["status"] for q, v in OLD[c]["quarters"].items()}
        assert len(st) == 11 and set(st.values()) == {"PROVISIONAL"}, (c, st)
        assert all(any("季末月份的營收公告" in b for b in v["blocking"]) for v in OLD[c]["quarters"].values())


def test_quarter_end_rule_gives_research_boundaries_only():
    for c in CODES:
        qs = NEW[c]["quarters"]
        assert {v["status"] for v in qs.values()} == {"CUTOFF_QUARTER_END_RULE"}, (c, {q: v["blocking"] for q, v in qs.items()})
        for q, v in qs.items():
            y, n = int(q[:4]), int(q[-1])
            nxt = date(y + (n == 4), (3 * n) % 12 + 1, 1)
            assert v["earliest"]["at"] == datetime(nxt.year, nxt.month, nxt.day, tzinfo=mt.TPE).isoformat()
            assert v["snapshot_boundary"]["rule"] == "quarter_end" and v["review_window"] == []
            assert all(datetime.fromisoformat(e["at"]) >= datetime.fromisoformat(v["earliest"]["at"]) for e in v["events"])
        b = ce.gate5b_boundaries(NEW[c])
        assert b["quarters"] == {} and len(b["research_only"]) == 11   # 不進給網站的界線
        assert NEW[c]["guidance"]["provisional_quarters_excluded"] == sorted(qs)   # 官方財測模式也不用


def test_gemini_round5_timestamps_match_official_listing():
    """Gemini 第五輪引用的公開資訊觀測站發言時間（轉載網站上的），與官方清單逐秒相符。"""
    by = {it.announced_at.strftime("%Y-%m-%d %H:%M:%S"): it.subject for it in ITEMS["8299"]}
    for t, word in (("2025-11-07 16:30:06", "第3季合併財務報告"), ("2026-04-08 14:30:44", "海外第一次無擔保轉換公司債"),
                    ("2026-04-17 14:34:15", "1Q26"), ("2026-05-18 23:57:23", "完成訂價"),
                    ("2026-06-01 14:30:22", "除息基準日"), ("2026-06-12 14:31:07", "轉換價格調整"),
                    ("2026-08-05 14:43:57", "115年第2季"), ("2026-10-16 14:44:19", "3Q26")):
        assert word in by.get(t, ""), (t, by.get(t))
    # 2026 年（到 10/16 清單最後一則）沒有海外轉換債調整轉換價格的公告
    assert [s for t, s in by.items() if t >= "2026-01-01" and "轉換價格" in s] == ["公告本公司國內第三次無擔保轉換公司債轉換價格調整"]


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            print(f"✗ {t.__name__}: {e}")
            failed += 1
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"✗ {t.__name__}: 執行例外 {type(e).__name__}: {e}")
            failed += 1
    print(f"\n{'全部通過' if failed == 0 else f'{failed} 項仍有問題'} （共{len(tests)}項）")
