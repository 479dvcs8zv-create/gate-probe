# gate-probe → 正式網站 v227：最小整合提案（只讀、只用時間界線）

版本：gate_pipeline v4.33（2026-10-19）　提案人：Claude（探測環境維護）　決定者：網站擁有者；v227 由 GPT 維護

## 一句話

正式網站 Gate 5B 判斷「市場共識快照是不是在財報揭露之前」時，**只**讀 gate-probe 產生的官方時間界線檔；
v227 其他程式、資料、判定規則一律不動。gate-probe 不寫入正式網站，正式網站也不寫入 gate-probe。

## 讀什麼

每次蒐證（gate-pipeline-collect 或 gate-pipeline-batch）會在
`results/<代號>/<run id>/gate5b_boundaries.json` 寫一個小檔（schema `gate-probe/gate5b-boundaries/v1`）：

| 欄位 | 意思 |
|---|---|
| `quarters.<季度>.cutoff_at` | 官方最早揭露時間（MOPS 重大訊息原文；月營收、自結、董事會、法說會、財報申報取最早） |
| `quarters.<季度>.snapshot_boundary_at` | 共識快照必須**嚴格早於**的時間（最早事件是月營收公告時＝公告當日 00:00） |
| `quarters.<季度>.cutoff_document_id` | 依據的公告識別碼，例如 `t05st01:2454:20250410:165554:1` |
| `research_only` | 季末規則（可選設定）算出的界線，**不得**用於 Gate |
| `excluded` | 暫定季度與阻擋原因（沒有界線） |

網址（公開 repo，唯讀）：
`https://raw.githubusercontent.com/479dvcs8zv-create/gate-probe/main/results/<代號>/<run id>/gate5b_boundaries.json`

## 消費規則（正式網站端必須遵守）

1. 只用 `quarters` 裡的季度（狀態 CUTOFF_VERIFIED）。`research_only`、`excluded` 都不能當界線。
2. 某季不在 `quarters`、檔案取不到、`--check-boundaries` 不是 MATCH → **沒有界線**，該季 Gate 5B 維持現行結果；不能解讀為通過。
3. 快照時間 `<` `snapshot_boundary_at` 才算截止點前（等於也不算）。
4. 不讀 `research.json`、`snapshot_audit.json`（`gate_impact = none`，只是研究紀錄）。
5. Python 預驗證通過不等於正式 Gate PASS；這個檔只提供時間，不提供判定。

## 怎麼複驗（不必相信 gate-probe）

- 同一資料夾有官方原始回應（`responses/`）與每個回應的 SHA-256（`manifest.json`）。
- 離線重算並逐季比對（不連網）：
  `python gate_pipeline/ops/replay_evidence.py results/<代號>/<run id> --reviews gate_pipeline/contract/mops_real/reviews --check-boundaries`
  → `MATCH` 結束碼 0；任何一季不同 → `MISMATCH` 結束碼 1。
- 人工抽查：MOPS 重大訊息查詢該公司該日，核對 `cutoff_document_id` 的發言日期與時間。
- 程式版本：`pipeline_package.sha256` 記錄當次使用的程式包雜湊。

## 驗收建議（GPT 端，約 30 分鐘）

1. 取 2330 與 2454 各一季，對照 MOPS 原文核對 `cutoff_at`。
2. 取一季 `excluded`，確認 v227 對該季的結果與整合前相同。
3. 把檔案裡一個時間改掉，執行上面的 `--check-boundaries`，確認回報 MISMATCH；v227 只採用 MATCH 的檔案。

## 目前覆蓋

- 2330：11 季中 11 季有界線；2454：11 季中 9 季（2024Q4、2025Q4 等 Nomura @CES 簡報內容確認）。
- 實檔：`results/2330/39211980039/gate5b_boundaries.json`、`results/2454/39211980039/gate5b_boundaries.json`
  （gate-pipeline-batch run 39211980039，v4.31）；兩檔都已用 `--check-boundaries` 離線重算，結果 MATCH。
- 上櫃股票：清單格式已用 8299、6488、5347 的真實回應人工比對（v4.32 列為已驗證）；公告詳細頁的上櫃樣本待取得。
- 多數公司沒有以重大訊息公告月營收。季末規則（季度結束隔天 00:00）已在 2026-10-19 採用為**研究用**預設，
  這些季度會出現在 `research_only`，**不在** `quarters`；季末規則是否用於 Gate，需擁有者另行決定。

## 不做的事

不改 v227 的任何判定或資料；不碰正式網站的 repo（含 main）、不開 PR；不用 API key；
外部資料取得失敗一律視為沒有證據；市場共識與官方財測維持分離。

## 撤回

正式網站移除這一個讀取即可，沒有其他相依。
